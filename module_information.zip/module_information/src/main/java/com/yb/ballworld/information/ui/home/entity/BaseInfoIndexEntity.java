package com.yb.ballworld.information.ui.home.entity;

import com.chad.library.adapter.base.entity.MultiItemEntity;

/**
 * Desc 资讯列表基类实体
 * Date 2019/10/16
 * author mengk
 */
public class BaseInfoIndexEntity implements MultiItemEntity {
    private int itemViewType;
    private Object data;

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public int getItemViewType() {
        return itemViewType;
    }

    public void setItemViewType(int itemViewType) {
        this.itemViewType = itemViewType;
    }

    @Override
    public int getItemType() {
        return 0;
    }
}
