package com.yb.ballworld.information.ui.auth;

import android.text.TextUtils;
import android.util.Log;

import androidx.lifecycle.LifecycleOwner;

import com.google.gson.Gson;
import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.livedata.LiveDataWrap;
import com.yb.ballworld.information.ui.auth.data.PhoneCodeGetEvent;
import com.yb.ballworld.information.ui.auth.data.SpecialAuthSubmitBean;
import com.yb.ballworld.information.ui.auth.data.SpecialReviewBean;
import com.yb.ballworld.information.ui.home.bean.FileDataBean;
import com.yb.ballworld.information.ui.profile.http.ProfileHttp;

import org.json.JSONObject;

import java.io.File;
import java.util.List;

/**
 * @author Gethin
 * @time 2019/11/8 12:57
 */

public class SpecialPresenter extends BasePresenter<LifecycleOwner, VoidModel> {

    ProfileHttp http = new ProfileHttp();

    public LiveDataWrap<PhoneCodeGetEvent> phoneCode = new LiveDataWrap<>();
    // 查询
    public LiveDataWrap<SpecialReviewBean> authGet = new LiveDataWrap<>();
    // 提交或修改 200成功其余都是失败处理
    public LiveDataWrap<SpecialAuthSubmitBean> autSubmit = new LiveDataWrap<>();


    //发送短信
    public void sendAuthCode(String phone, String areaNo) {
        add(http.getAuthCode(phone, areaNo, "4", new LifecycleCallback<String>(mView) {
            @Override
            public void onSuccess(String data) {
                phoneCode.setData(new PhoneCodeGetEvent(PhoneCodeGetEvent.SUCCESS));
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                PhoneCodeGetEvent phoneCodeGetEvent = new PhoneCodeGetEvent(PhoneCodeGetEvent.FAILURE);
                phoneCodeGetEvent.setErrCode(errCode);
                phoneCodeGetEvent.setErrMsg(errMsg);
                phoneCode.setData(phoneCodeGetEvent);
            }
        }));
    }

    // 查询
    public void getSpecialReview() {
        add(http.getSpecialReview(new LifecycleCallback<String>(mView) {
            @Override
            public void onSuccess(String data) {
                try {
                    if (!TextUtils.isEmpty(data)) {
                        JSONObject jsonObject = new JSONObject(data);
                        if (200 == jsonObject.optInt("code")) { // 请求成功
                            String json = jsonObject.optString("data");
                            if (json != null) { // 有提交过数据
                                SpecialReviewBean specialReviewBean = new Gson().fromJson(json, SpecialReviewBean.class);
                                authGet.setData(specialReviewBean);
                            } else { // 未提交过数据
                                authGet.setData(null);
                            }
                        } else { // 非200的异常
                            authGet.setError(jsonObject.optInt("code"), jsonObject.optString("msg"));
                        }
                    } else {
                        authGet.setError(-1, "特约审核数据查询，服务器异常");
                    }
                } catch (Exception e) {
                    authGet.setError(-1, "特约审核数据查询，数据解析异常");
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                authGet.setError(errCode, TextUtils.isEmpty(errMsg) ? "特约审核数据查询" : errMsg);
            }
        }));
    }

    // 提交
    private void saveSpecialReview(SpecialReviewBean data) {
        add(http.saveSpecialReview(data, new LifecycleCallback<String>(mView) {
            @Override
            public void onSuccess(String data) {
                try {
                    if (!TextUtils.isEmpty(data)) {
                        JSONObject jsonObject = new JSONObject(data);
                        if (200 == jsonObject.optInt("code")) { // 数据提交成功, data没有返回值不用处理
                            autSubmit.setData(new SpecialAuthSubmitBean(SpecialAuthSubmitBean.SUCCESS, "特约审核提交成功"));
                        } else { // 非200的异常
                            autSubmit.setError(jsonObject.optInt("code"), jsonObject.optString("msg"));
                        }
                    } else {
                        autSubmit.setError(-1, "特约审核数据提交，服务器异常");
                    }
                } catch (Exception e) {
                    autSubmit.setError(-1, "特约审核数据提交，数据解析异常");
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                autSubmit.setError(errCode, TextUtils.isEmpty(errMsg) ? "特约审核数据提交，服务器异常" : errMsg);
            }
        }));
    }

    // 更新
    private void updateSpecialReview(SpecialReviewBean data) {
        add(http.updateSpecialReview(data, new LifecycleCallback<String>(mView) {
            @Override
            public void onSuccess(String data) {
                try {
                    if (!TextUtils.isEmpty(data)) {
                        JSONObject jsonObject = new JSONObject(data);
                        if (200 == jsonObject.optInt("code")) { // 数据提交成功, data没有返回值不用处理
                            autSubmit.setData(new SpecialAuthSubmitBean(SpecialAuthSubmitBean.SUCCESS, "特约审核提交成功"));
                        } else { // 非200的异常
                            autSubmit.setError(jsonObject.optInt("code"), jsonObject.optString("msg"));
                        }
                    } else {
                        autSubmit.setError(-1, "特约审核数据提交，服务器异常");
                    }
                } catch (Exception e) {
                    autSubmit.setError(-1, "特约审核数据提交，数据解析异常");
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                autSubmit.setError(errCode, TextUtils.isEmpty(errMsg) ? "特约审核数据提交，服务器异常" : errMsg);
            }
        }));
    }

    /**
     *  提交认证数据
     * @param files     照片等其它图片文件
     * @param postData  认证的表单数据
     */
    public void submitAuthFormData(List<File> files, SpecialReviewBean postData) {
        if (!TextUtils.isEmpty(postData.getIdUrl())) {
            if (files.isEmpty()) {  //没有其它图片文件, 提交认证表单
                if (SpecialReviewBean.TYPE_SAVE.equals(postData.getSubmitType())) { // 首次上传
                    saveSpecialReview(postData);
                } else { // 更新
                    updateSpecialReview(postData);
                }
            } else { // 有其它图片文件,上传其它文件
                uploadFiles(files, "image", postData);
            }
        } else {
            if (files == null || files.size() == 0) {
                autSubmit.setError(-1, "未找到认证照片");
                return;
            }
            File file = files.remove(0); //照片
            // 上传照片
            add(http.uploadFile(file, "image", new LifecycleCallback<FileDataBean>(mView) {
                @Override
                public void onSuccess(FileDataBean data) {
                    if (data != null) {
                        String imgUrl = data.getImgUrl();
                        if (!TextUtils.isEmpty(imgUrl)) { //照片上传成功
                            postData.setIdUrl(imgUrl);
                            if (files.isEmpty()) {  //没有其它图片文件
                                //提交认证表单
                                if (SpecialReviewBean.TYPE_SAVE.equals(postData.getSubmitType())) {
                                    saveSpecialReview(postData);
                                } else {
                                    updateSpecialReview(postData);
                                }
                            } else { // 有其它图片文件
                                uploadFiles(files, "image", postData); //上传其它文件
                            }
                        } else {
                            autSubmit.setError(-1, "照片上传失败");
                        }
                    } else {
                        autSubmit.setError(-1, "照片上传失败");
                    }
                }

                @Override
                public void onFailed(int errCode, String errMsg) {
                    autSubmit.setError(errCode, TextUtils.isEmpty(errMsg) ? "照片上传请求服务器失败" :  errMsg);
                }
            }));
        }
    }

    // 图片成功上传计数
    private int count = 0;
    private void uploadFiles(List<File> files, String type, SpecialReviewBean postData) {
        count = 0;
        StringBuilder imageUrls = new StringBuilder();
        if (!TextUtils.isEmpty(postData.getImgUrl())) {
            imageUrls.append(postData.getImgUrl());
        }
        int length = files.size();  //需要上传的图片文件数量
        for (File file : files) {
            add(http.uploadFile(file, type, new LifecycleCallback<FileDataBean>(mView) {
                        @Override
                        public void onSuccess(FileDataBean data) {
                            if (data != null) {
                                String imgUrl = data.getImgUrl();
                                if (!TextUtils.isEmpty(imgUrl)) { //图片URL
                                    count++;  //图片成功上传计数
                                    imageUrls.append(imgUrl);
                                    if (count >= length) {  //所有图片都上传成功,提交认证表单
                                        postData.setImgUrl(imageUrls.toString());
                                        if (SpecialReviewBean.TYPE_SAVE.equals(postData.getSubmitType())) {
                                            saveSpecialReview(postData);
                                        } else {
                                            updateSpecialReview(postData);
                                        }
                                        count = 0;
                                    } else {
                                        imageUrls.append(",");
                                    }
                                } else {
                                    autSubmit.setError(-1, "图片上传失败");
                                    count = 0;
                                }

                            } else {
                                autSubmit.setError(-1, "图片上传失败");
                                count = 0;
                            }
                        }

                        @Override
                        public void onFailed(int errCode, String errMsg) {
                            autSubmit.setError(-1, TextUtils.isEmpty(errMsg) ? "图片上传请求服务器失败" :  errMsg);
                            count = 0;
                        }
                    })
            );
        }
    }
}
