package com.yb.ballworld.information.ui.detail;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.alibaba.android.arouter.launcher.ARouter;
import com.bfw.util.ToastUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.ethanhua.skeleton.Skeleton;
import com.ethanhua.skeleton.SkeletonScreen;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.constant.Constant;
import com.yb.ballworld.baselib.core.RouterHub;
import com.yb.ballworld.baselib.data.UserInfo;
import com.yb.ballworld.baselib.utils.JsonUtils;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.common.base.mvp.BaseMvpActivity;
import com.yb.ballworld.common.widget.CommonTitleBar;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.data.RootBean;
import com.yb.ballworld.information.ui.community.bean.Topic;
import com.yb.ballworld.information.ui.community.bean.TopicCommentList;
import com.yb.ballworld.information.ui.event.InforCommentCountEvent;
import com.yb.ballworld.information.ui.home.bean.PublishCommentResBean;
import com.yb.ballworld.information.ui.home.constant.PublishIntentParam;
import com.yb.ballworld.information.ui.home.constant.PublishReqCode;
import com.yb.ballworld.information.ui.home.utils.JZReleaseUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.personal.view.InformationPersonalActivity;
import com.yb.ballworld.information.ui.personal.view.InformationPersonalActivityNew;
import com.yb.ballworld.information.utils.CommondUtil;
import com.yb.ballworld.information.widget.NewsDetailBottomLayout;
import com.yb.ballworld.information.widget.bubbleview.BubblePopupWindow;
import com.yb.ballworld.information.widget.bubbleview.BubbleTextView;
import com.yb.ballworld.information.widget.bubbleview.RelativePos;
import com.yb.ballworld.information.widget.listener.OnElementClickListener;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

import cn.jzvd.Jzvd;

import static com.yb.ballworld.common.widget.CommonTitleBar.ACTION_LEFT_BUTTON;
import static com.yb.ballworld.information.ui.detail.InforConstant.TopicDetailItemType.TYPE_TOPIC;
import static com.yb.ballworld.information.ui.detail.InforConstant.TopicDetailItemType.TYPE_TOPIC_COMMENT_IMAGE;
import static com.yb.ballworld.information.ui.detail.InforConstant.TopicDetailItemType.TYPE_TOPIC_COMMENT_TEXT;
import static com.yb.ballworld.information.ui.detail.InforConstant.TopicDetailItemType.TYPE_TOPIC_COMMENT_VIDEO;
import static com.yb.ballworld.information.widget.bubbleview.RelativePos.CENTER_HORIZONTAL;

/**
 * Desc:
 *
 * @author ink
 * created at 2019/11/13 16:24
 */
public class CommunityCommentActivity extends BaseMvpActivity<CommunityCommentPresenter>
        implements OnElementClickListener,
        BaseQuickAdapter.OnItemClickListener, BaseQuickAdapter.OnItemChildClickListener, BaseQuickAdapter.OnItemLongClickListener, RecyclerView.OnItemTouchListener {
    private BubblePopupWindow mBubblePopupWindow;
    private CommunityCommentQuickAdapter mNewsAdapter;

    private PlaceholderView placeholderView;
    //底部评论View
    private NewsDetailBottomLayout newsDetailBottomLayout;
    private SmartRefreshLayout mSmartRefreshLayout;
    private RecyclerView recyclerView;
    private Topic commit;
    private List<MultiItemEntity> mMultiList = new ArrayList<>();
    private boolean isChanged = false;
    private String newsId = null;
    private int commentId = -1;
    private int targetId = -1;
    private int commentType = -1;
    private boolean isNeedJump = false;
    private Topic parentCommit = null;
    private boolean isReply = false;
    private SkeletonScreen skeletonScreen;
    private View replaceView;
    private List<Integer> myCommitList = new ArrayList<>();


    @Override
    protected SmartRefreshLayout getSmartRefreshLayout() {
        return mSmartRefreshLayout;
    }

    @Override
    public void initPresenter() {
        if (mPresenter != null) {
            mPresenter.setVM(this);
        }
        Intent intent = getIntent();
        if (intent != null) {
            commit = (Topic) intent.getSerializableExtra("TOPIC");
            if (commit != null) {
                mPresenter.setCommentId(commit.getId());
                isNeedJump = false;
            } else {
                //commentId_65 + mainId_43
                isNeedJump = true;
                commentId = intent.getIntExtra("TOPIC_ID", -1);
                commentType = intent.getIntExtra("TOPIC_TYPE", -1);
                targetId = intent.getIntExtra("MAIN_TOPIC_ID", -1);
                mPresenter.setCommentId(commentId);
                if (commentType > 0) {
                    mPresenter.setTargetId(targetId);
                }
            }
        }
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_infor_comment;
    }


    @Override
    public PlaceholderView getPlaceholderView() {
        return placeholderView;
    }


    @Override
    protected void initView() {
        mSmartRefreshLayout = F(R.id.smartRefreshLayout);
        mSmartRefreshLayout.setRefreshFooter(getRefreshFooter());
        mSmartRefreshLayout.setRefreshHeader(getRefreshHeader());
        mSmartRefreshLayout.setEnableAutoLoadMore(true);
        initRefreshView();
        enableRefresh(false);
        enableLoadMore(false);
        placeholderView = F(R.id.placeholderView);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerView = F(R.id.recyclerView);
        recyclerView.setLayoutManager(linearLayoutManager);
        mNewsAdapter = new CommunityCommentQuickAdapter(null, this);
        recyclerView.setAdapter(mNewsAdapter);
        mNewsAdapter.bindToRecyclerView(recyclerView);
        newsDetailBottomLayout = F(R.id.nbl_view_header2);
        newsDetailBottomLayout.switchStyle(NewsDetailBottomLayout.STYLE_TEXT_ONLY);
        JZReleaseUtil.observeReleaseVideos(recyclerView, mNewsAdapter.getVideoViewId());
        if (!isNeedJump) {
            if(commit!=null) {
                mPresenter.setCommentId(commit.getId());
                newsDetailBottomLayout.setParam(commit.getCommentStatus(), String.valueOf(commit.getMainPostId()), String.valueOf(commit.getId()), NewsDetailBottomLayout.TYPE_TOPIC);
            }
        }
        mPresenter.setFristPage(true);
        LiveEventBus.get().with(LiveEventBusKey.KEY_TOPIC_PUBLIC_COMMENT, Topic.class).observe(this,topicObserver);
    }

    @Override
    protected void onRefreshData() {
        super.onRefreshData();
        mPresenter.setFristPage(true);
        mPresenter.initLoad();
    }

    @Override
    protected void bindEvent() {
        ((CommonTitleBar) F(R.id.infor_titlebar)).setListener((v, action, extra) -> {
            if (action == ACTION_LEFT_BUTTON) {
                finish();
            }
        });
        if (getPlaceholderView() != null) {
            getPlaceholderView().setPageErrorRetryListener(v -> initData());
        }

        mNewsAdapter.setOnItemClickListener(this);
        mNewsAdapter.setOnElementClickListener(this);
        mNewsAdapter.setOnItemChildClickListener(this);
        mNewsAdapter.setOnItemLongClickListener(this);
        recyclerView.addOnItemTouchListener(this);
    }

    @Override
    protected void initData() {
        replaceView = F(R.id.replaceView);
        if (commit != null) {
            List<MultiItemEntity> entityList = new ArrayList<>();
            entityList.add(commit);
            entityList.add(new RootBean(InforConstant.ItemType.DETAIL_HEADER_COMMENT, 0));
            mMultiList.addAll(entityList);
            mNewsAdapter.addData(entityList);
            mNewsAdapter.notifyDataSetChanged();
            showPageContent();
        } else {
            skeletonScreen = Skeleton.bind(replaceView)
                    .load(R.layout.infor_comment_loading)
                    .duration(1000)
                    .shimmer(true)//是否开启动画
                    .color(R.color.white)
                    .angle(0)
                    .show();
        }
        enableRefresh(true);
        showDialogLoading();
        onRefreshData();
    }


    @Override
    protected void onLoadMoreData() {
        super.onLoadMoreData();
        mPresenter.pullUp();
    }

    public void showCommits(TopicCommentList commitBeanList, boolean firstPage) {
        if (skeletonScreen != null) {
            skeletonScreen.hide();
            if (replaceView != null) {
                replaceView.setVisibility(View.GONE);
            }
        }
        if (mPresenter.isFristPage()) {
            hideDialogLoading();

        }
        mNewsAdapter.setHasMore(mPresenter.hasPullUpMore());
        enableLoadMore(mPresenter.hasPullUpMore());
        stopLoadMore();
        stopRefresh();
        if (commitBeanList != null) {
            Topic tempCommit = commitBeanList.getParent();
            if (tempCommit != null) {
                commit=tempCommit;
                mNewsAdapter.setCommentId(tempCommit.getId());
                newsDetailBottomLayout.setParam(tempCommit.getCommentStatus(), String.valueOf(tempCommit.getMainPostId()), String.valueOf(tempCommit.getId()), NewsDetailBottomLayout.TYPE_TOPIC);
                mPresenter.setCommentId(tempCommit.getId());
            }
            if (firstPage) {
                List<MultiItemEntity> multiItemEntities = new ArrayList<>();
                if (mMultiList.isEmpty()) {
                    mMultiList.add(commitBeanList.getParent());
                    mMultiList.add(new RootBean(InforConstant.ItemType.DETAIL_HEADER_COMMENT, 0));
                    multiItemEntities.addAll(mMultiList);
                    if (isListNotEmpty(commitBeanList)) {
                        multiItemEntities.addAll(commitBeanList.getSon().getList());
                    } else {
                        //添加空提示item
                    }
                } else {
                    multiItemEntities.addAll(mMultiList);
                    if (isListNotEmpty(commitBeanList)) {
                        multiItemEntities.addAll(commitBeanList.getSon().getList());
                    } else {
                        //添加空提示item
                    }
                }

                mNewsAdapter.replaceData(multiItemEntities);
                mPresenter.setFristPage(false);
                moveToPosition(1);
                myCommitList.clear();
            } else {
                if (isListNotEmpty(commitBeanList)) {
                    List<Topic> commitBeans = commitBeanList.getSon().getList();
                    int size = commitBeans.size() - 1;
                    for (int i = size; i >= 0; i--) {
                        if (myCommitList.contains(commitBeans.get(i).getId())) {
                            commitBeans.remove(i);
                        }
                    }
                    mNewsAdapter.addData(commitBeanList.getSon().getList());
                }
            }
            if(mMultiList.size()>0) {
                mNewsAdapter.changedCommentCount(commit.getSonNum());
                mNewsAdapter.notifyItemChanged(mMultiList.size()-1);
            }
            // mNewsAdapter.notifyDataSetChanged();
        }
    }

    private boolean isListNotEmpty(TopicCommentList commitBeanList) {
        return commitBeanList != null && commitBeanList.getSon() != null && !CommondUtil.isEmpty(commitBeanList.getSon().getList());
    }

    private void moveToPosition(int position) {
        if (position != -1 && !isChanged) {
            isChanged = true;
            recyclerView.scrollToPosition(position);
            LinearLayoutManager mLayoutManager =
                    (LinearLayoutManager) recyclerView.getLayoutManager();
            mLayoutManager.scrollToPositionWithOffset(position, 0);
        }
    }

    public void showEmpty(int area) {
        if (area == mPresenter.INFOR_COMMITS) {
            if (skeletonScreen != null) {
                skeletonScreen.hide();
                if (replaceView != null) {
                    replaceView.setVisibility(View.GONE);
                }
            }
            if (mPresenter.isFristPage()) {
                hideDialogLoading();
            }
            stopLoadMore();
            stopRefresh();
            enableLoadMore(false);
        }
    }


    public void showError(int area) {
        if (skeletonScreen != null) {
            skeletonScreen.hide();
            if (replaceView != null) {
                replaceView.setVisibility(View.GONE);
            }
        }
        hideDialogLoading();
        hidePageLoading();
        if (area == mPresenter.INFOR_COMMITS) {
            stopLoadMore();
            stopRefresh();
            ToastUtils.showToast("拉取评论失败");
        }
    }

    @Override
    protected void processClick(View view) {
        int viewId = view.getId();
        if (viewId == R.id.inforDetail_like) {
            ImageView likeView = F(R.id.inforDetail_like);
            likeView.setImageResource(R.drawable.icon_priase_info);
            //goodView.show(F(R.id.inforDetail_like));
            if (!(Boolean) likeView.getTag()) {
                likeView.setTag(true);
                mPresenter.addArticleLike();
                showLike(mPresenter.INFOR_DETAIL, 0, 0, true);
            }
        } else if (viewId == R.id.inforDetail_shareLayout || (viewId == R.id.infor_titlebar_share)) {
            //分享
            ToastUtils.showToast(R.string.prompt_coding);
        } else if (viewId == R.id.infor_titlebar_back) {
            finish();
        }
    }

    /**
     * 跳转到登陆界面
     */
    private void toLogin() {
        ARouter.getInstance().build(RouterHub.USER_LOGIN_REGISTER_ACTIVITY)
                .navigation(this, Constant.COMMON_LOGIN_REQUEST);
    }

    /**
     * 是否点赞成功/包括评论内的点赞
     *
     * @param area
     * @param id
     * @param isSuccess
     */
    public void showLike(int area, int id, int position, boolean isSuccess) {
        if (area == mPresenter.INFOR_DETAIL) {
//            //文章处点赞
//            ImageView likeView = F(R.id.inforDetail_like);
//            likeView.setImageResource(isSuccess ? R.drawable.icon_priase_info : R.drawable.icon_priase_info_normal);
//            if (isSuccess) {
//                TextView likeCountView = F(R.id.inforDetail_likeCount);
//                String likeCountstr = likeCountView.getText().toString();
//                int likeCount = (TextUtils.isEmpty(likeCountstr) ? 0 : Integer.parseInt(likeCountstr)) + 1;
//                ((TextView) F(R.id.inforDetail_likeCount)).setText(String.valueOf(likeCount));
//                likeView.setTag(true);
//                LiveEventBus.get().with(LiveEventBusKey.KEY_NEWS_LIKE, String.class).post(mPresenter.com);
//            } else {
//                likeView.setTag(false);
//            }
        } else if (area == mPresenter.INFOR_COMMITS) {
            //评论区点赞
            List<MultiItemEntity> entityList = mNewsAdapter.getData();
            if (!CommondUtil.isEmpty(entityList) && position < entityList.size()) {
                MultiItemEntity bean = mNewsAdapter.getItem(position);
                //先用位置判断
                if (bean != null && bean instanceof Topic) {
                    Topic commitBean = ((Topic) bean);
                    if (commitBean.getId() == id) {
                        RecyclerView.ViewHolder viewHolder = recyclerView.findViewHolderForLayoutPosition(position);
                        commitBean.setIsLike(isSuccess);
                        commitBean.setLikeCount(commitBean.getLikeCount() + (isSuccess ? 1 : 0));
                        if (viewHolder != null) {
                            mNewsAdapter.changedLike(commitBean, (BaseViewHolder) viewHolder);
                        } else {
                            mNewsAdapter.notifyItemChanged(position);
                        }
                    }
                } else {
                    //如果不匹配，用commitId去迭代匹配，都没有就放弃吧
                    boolean isMatched;
                    Topic commitBean = null;
                    int truthPos = 0;
                    for (MultiItemEntity entity : entityList) {
                        isMatched = entity instanceof Topic && (commitBean = (Topic) entity).getId() == id;
                        if (isMatched) {
                            RecyclerView.ViewHolder viewHolder = recyclerView.findViewHolderForLayoutPosition(truthPos);
                            commitBean.setIsLike(isSuccess);
                            commitBean.setLikeCount(commitBean.getLikeCount() + (isSuccess ? 1 : 0));
                            if (viewHolder != null) {
                                mNewsAdapter.changedLike(commitBean, (BaseViewHolder) viewHolder);
                            } else {
                                mNewsAdapter.notifyItemChanged(position);
                            }
                            //mNewsAdapter.notifyItemChanged(truthPos);
                        }
                        truthPos++;
                    }
                }
            }
        }
        if (!isSuccess) {
            ToastUtils.showToast(R.string.prompt_likeFailed);
        }
    }


    @Override
    public void onElementClick(@NotNull String url, int type, int position, List<String> peerList) {
        if (type == InforConstant.WebMediaType.TYPE_IMG) {
            if (!CommondUtil.isEmpty(peerList)) {
                NavigateToDetailUtil.navigateToGalleryActivityWithoutShare(this, peerList, position);
            }
        } else if (type == InforConstant.WebMediaType.TYPE_LINK) {
            InformationLinkNewActivity.start(this, url, "", true, true, 0);
        } else if (type == InforConstant.WebMediaType.TYPE_VIDEO) {

        }
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
        if (adapter.getItemCount() > position) {
            CommunityCommentQuickAdapter inforDetailQuickAdapter = (CommunityCommentQuickAdapter) adapter;
            MultiItemEntity entity = inforDetailQuickAdapter.getItem(position);
            if (position > 0 && entity instanceof Topic) {
                onItemLongClick(adapter, view, position);
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        Jzvd.releaseAllVideos();
    }

    @Override
    public void onBackPressed() {
        if (Jzvd.backPress()) {
            return;
        }
        super.onBackPressed();
    }

    @Override
    public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
        CommunityCommentQuickAdapter inforDetailQuickAdapter = (CommunityCommentQuickAdapter) adapter;
        int eventType = inforDetailQuickAdapter.getChildEventType(view);
        MultiItemEntity entity = inforDetailQuickAdapter.getItem(position);
        if (entity != null) {
            switch (eventType) {
                case InforConstant.ItemEvent.USER_COMMENT:
                    InformationPersonalActivityNew.startActivity(this, CommondUtil.fitEmpty(String.valueOf(((Topic) entity).getUserId())),InformationPersonalActivityNew.TYPE_COMMUNITY);
                    break;
                case InforConstant.ItemEvent.REPLIES_COMMENT:
                    onItemLongClick(adapter, view, position);
                    break;
                case InforConstant.ItemEvent.ROOT_SORT:
                    mPresenter.setHeatSort(mNewsAdapter.isHeat());
                    mPresenter.setFristPage(true);
                    mPresenter.initLoad();
                    showDialogLoading();
                    break;
                case InforConstant.ItemEvent.LIKE_COMMENT:
                    if (!((Topic) entity).getIsLike()) {
                        mPresenter.addCommitLike(((Topic) entity).getId(), position);
                        showLike(mPresenter.INFOR_COMMITS, ((Topic) entity).getId(), position, true);
                    }
                    break;
                default:
                    break;
            }
        }
    }

    @Override
    public boolean onItemLongClick(BaseQuickAdapter adapter, View view, int position) {
        CommunityCommentQuickAdapter inforDetailQuickAdapter = (CommunityCommentQuickAdapter) adapter;
        MultiItemEntity entity = inforDetailQuickAdapter.getItem(position);
        boolean ishandle = false;
        int itemType=entity!=null?entity.getItemType():-1;
        if (entity != null && (itemType == TYPE_TOPIC_COMMENT_TEXT || itemType == TYPE_TOPIC_COMMENT_VIDEO || itemType == TYPE_TOPIC_COMMENT_IMAGE || itemType == TYPE_TOPIC) && position > 0) {
            //int mediaType = inforDetailQuickAdapter.getMediaType((CommitBean) entity);
            // View achorView=inforDetailQuickAdapter.getAchorView(view, mediaType);
            parentCommit = (Topic) entity;
            showBubble(recyclerView, ((Topic) entity).getId());
            ishandle = true;
        }
        return ishandle;
    }


//    private void gotoPublish(int replyId) {
//        Intent intent = new Intent(this, PublishCommentActivity.class);
//       // intent.putExtra(PublishIntentParam.NEWS_ID, mPresenter.getNewsId());
//        intent.putExtra(PublishIntentParam.REPLY_ID, String.valueOf(replyId));
//        startActivityForResult(intent, PublishReqCode.REQ_CODE);
//    }

    private Observer topicObserver = (Observer<Topic>) topic -> {
        if (topic != null) {
            if (parentCommit != null && String.valueOf(parentCommit.getId()).equals(String.valueOf(topic.getReplyId()))) {
                topic.setParent(parentCommit);
            }
            myCommitList.add(topic.getId());
            UserInfo infor = LoginOrdinaryUtils.INSTANCE.getUserInfo();
            if (infor != null) {
                topic.setHeadImgUrl(infor.getImg());
            }

            mNewsAdapter.addData(mMultiList.size(), topic);
            if(commit!=null){
                commit.setSonNum(commit.getSonNum()+1);
                if(!mMultiList.isEmpty()) {
                    mNewsAdapter.changedCommentCount(commit.getSonNum());
                    mNewsAdapter.notifyItemChanged(mMultiList.size() - 1);
                }
            }
            mPresenter.setTotalcount(mPresenter.getTotalcount() + 1);
        }
    };

//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//
//    }

    @Override
    public void finish() {
        super.finish();
        LiveEventBus.get().with(LiveEventBusKey.KEY_INFOR_COMMENT_COUNT, InforCommentCountEvent.class).post(new InforCommentCountEvent(mPresenter.getTotalcount(), mPresenter.getCommentId()));
    }

    private BubbleTextView bubbleView;

    private void showBubble(View commitView, int carryId) {
        if (mBubblePopupWindow == null) {
            View rootView = LayoutInflater.from(this).inflate(R.layout.simple_text_bubble, null);
            bubbleView = rootView.findViewById(R.id.popup_bubble);
            mBubblePopupWindow = new BubblePopupWindow(rootView, bubbleView);
            bubbleView.setOnClickListener(v -> {
                v.setEnabled(false);
                NavigateToDetailUtil.navigateToPublishTopicComment(this, String.valueOf(commit.getMainPostId()), String.valueOf((Integer) v.getTag()));
                //  gotoPublish((Integer) v.getTag());
                v.setEnabled(true);
            });
            mBubblePopupWindow.setCancelOnTouch(true);
            mBubblePopupWindow.setCancelOnTouchOutside(true);
            mBubblePopupWindow.setCancelOnLater(3000);
        }
        bubbleView.setTag(carryId);
        mBubblePopupWindow.showArrowTo(commitView, new RelativePos(CENTER_HORIZONTAL, RelativePos.ABOVE), -clickX, -clickY);
        // mBubblePopupWindow.showAsDropDown(commitView,clickX,clickY, Gravity.NO_GRAVITY);
    }

    private int clickX;
    private int clickY;

    @Override
    public boolean onInterceptTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
        clickX = (int) e.getX();
        clickY = (int) e.getY();
        return false;
    }

    @Override
    public void onTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {

    }

    @Override
    public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

    }
}