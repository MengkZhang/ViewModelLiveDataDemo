package com.yb.ballworld.information.ui.detail;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.bfw.image.core.listener.OnImageListener;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.yb.ballworld.baselib.utils.ImageManager;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.widget.PhotoView;

import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public class ImagesAdapter extends PagerAdapter {
    private List<String> imagesList = new ArrayList<>();
    private LayoutInflater inflater;
    private int sltPosition=0;

    public ImagesAdapter(List<String> data, LayoutInflater inflater) {
        if (data != null && data.size() > 0) {
            imagesList.addAll(data);
        }
        this.inflater = inflater;
    }

    @Override
    public int getCount() {
        return imagesList.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view==object;
    }

    public int getSltPosition() {
        return sltPosition;
    }

    public void setSltPosition(int sltPosition) {
        this.sltPosition = sltPosition;
    }

    public String getItem(int position){
        return imagesList.get(position);
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        View view = inflater.inflate(R.layout.item_infor_img, null);
        PhotoView photoView = view.findViewById(R.id.photoView);
        PlaceholderView placeHolder =  view.findViewById(R.id.placeHolder);
        placeHolder.setBackgroundColor(inflater.getContext().getResources().getColor(R.color.transparent));
        placeHolder.getChildAt(0).setBackgroundColor(inflater.getContext().getResources().getColor(R.color.transparent));
        placeHolder.setPageErrorRetryListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                ImagesAdapter.this.loadImageOrGif(position, placeHolder, photoView);
                ImagesAdapter.this.loadImage(inflater.getContext(),position, placeHolder, photoView);
            }
        });
//        loadImageOrGif(position,placeHolder,photoView);
        loadImage(inflater.getContext(),position,placeHolder,photoView);
        container.addView(view);
        return view;
    }

    @SuppressLint("CheckResult")
    private void loadImage(Context context, int position, PlaceholderView placeHolder, PhotoView photoView) {
        placeHolder.showLoading();
        Glide.with(context).load(imagesList.get(position)).listener(new RequestListener<Drawable>() {
            @Override
            public boolean onLoadFailed(@androidx.annotation.Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                if(placeHolder.isLoading()) {
                    placeHolder.hideLoading();
                }
                placeHolder.showError("重新加载");
                return false;
            }

            @Override
            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                if(placeHolder.isLoading()) {
                    placeHolder.hideLoading();
                    photoView.enable();
                }
                return false;
            }
        }).into(photoView);
    }

    private void loadImageOrGif(int position, PlaceholderView placeHolder, PhotoView photoView){
        placeHolder.showLoading();
        ImageManager.INSTANCE.loadImageOrGif(imagesList.get(position), photoView, new OnImageListener() {
            @Override
            public void onSuccess(@Nullable Bitmap bitmap) {
                if(placeHolder.isLoading()) {
                    placeHolder.hideLoading();
                    photoView.enable();
                }
            }

            @Override
            public void onFail(@Nullable String msg) {
                if(placeHolder.isLoading()) {
                    placeHolder.hideLoading();
                }
                placeHolder.showError("重新加载");
            }
        });
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        if(object!=null&&object instanceof View) {
            container.removeView((View)object);
        }else{
            container.removeViewAt(position);
        }
    }
}
