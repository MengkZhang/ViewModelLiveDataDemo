package com.yb.ballworld.information.ui.home.constant;

import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Desc 资讯列表的头部banner 子弹推送 专栏的跳转类型
 *  0 资讯 1 视频 2 直播 3 赛事 4 h5
 * Date 2019/10/7
 * author mengk
 */
@IntDef({
        IndexJumpTypeConstant.TYPE_INFO,
        IndexJumpTypeConstant.TYPE_VIDEO,
        IndexJumpTypeConstant.TYPE_FACE_VIDEO,
        IndexJumpTypeConstant.TYPE_MATCH,
        IndexJumpTypeConstant.TYPE_H5
})

@Retention(RetentionPolicy.SOURCE)

public @interface IndexJumpTypeConstant {
    int TYPE_INFO = 0;
    int TYPE_VIDEO = 1;
    int TYPE_FACE_VIDEO = 2;
    int TYPE_MATCH = 3;
    int TYPE_H5 = 4;
}


