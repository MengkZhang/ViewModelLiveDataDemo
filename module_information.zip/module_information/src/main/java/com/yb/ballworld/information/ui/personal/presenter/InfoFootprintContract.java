package com.yb.ballworld.information.ui.personal.presenter;

import com.yb.ballworld.information.ui.personal.bean.CollectionEntity;

import java.util.List;

/**
 * Desc: <足迹列表Contract>
 * Author: JS-Barder
 * Created On: 2019/11/20 11:42
 */
public interface InfoFootprintContract {

    //--------------------------------View层----------------------------
    public interface FootprintView {
        //请求加载中
        void requestLoading();

        //请求成功
        void resultSuccess(List<CollectionEntity.ListBean> beanList);

        void setEnableLoadMore(boolean enableLoadMore);

        //请求失败
        void resultFail(int type);

        //刷新成功
        void resultRefreshSuccess();

        //刷新失败
        void resultRefreshFail(String errorMsg);
    }

    //--------------------------------Presenter层----------------------------
    public interface FootprintPresenter {

        //请求数据方法
        void loadData();

        //刷新
        void refreshData();

        //加载更多
        void loadMore();

        //绑定View
        void attachView(FootprintView view);

        //解绑View
        void detachView();
    }
}
