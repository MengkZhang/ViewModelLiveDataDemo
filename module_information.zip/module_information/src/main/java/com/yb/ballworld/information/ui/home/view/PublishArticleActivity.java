package com.yb.ballworld.information.ui.home.view;

import android.app.ProgressDialog;
import android.content.Intent;
import android.text.Editable;
import android.text.TextUtils;
import android.util.Log;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AlertDialog;
import androidx.lifecycle.Observer;

import com.bfw.util.ToastUtils;
import com.yb.ballworld.baselib.constant.Constant;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.widget.chat.EmojiLayout;
import com.yb.ballworld.baselib.widget.dialog.MaterialLoadingDialog;
import com.yb.ballworld.common.livedata.LiveDataObserver;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.bean.IndexLableLetterBean;
import com.yb.ballworld.information.ui.home.bean.PublishArticleUploadFilePostBean;
import com.yb.ballworld.information.ui.home.bean.PublishVideoDataBean;
import com.yb.ballworld.information.ui.home.constant.InsertImgType;
import com.yb.ballworld.information.ui.home.presenter.PublishArticlePresenter;
import com.yb.ballworld.information.ui.home.utils.EditDataUtil;
import com.yb.ballworld.information.ui.home.utils.ProgressDialogUtil;
import com.yb.ballworld.information.ui.home.widget.DeleteImgDialog;
import com.yb.ballworld.information.ui.home.widget.bfrich.RichTextEditor;

import java.util.ArrayList;
import java.util.Map;

import io.reactivex.disposables.Disposable;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;

/**
 * Desc
 * Date 2019/11/15
 * author mengk
 */
public class PublishArticleActivity extends PublishBaseActivity<PublishArticlePresenter> {

    private RichTextEditor mRichTextEditor;
    private ProgressDialog dialog;
    private Disposable subsInsert;
    //重写dialog的方法 为了解决上传过程中取消 再次点击上传不显示dialog的bug
    private AlertDialog mLoadingDialog = null;

    public void showDialogLoading() {
        showDialogLoading(getString(com.yb.ballworld.baselib.R.string.app_loading));
    }

    public void showDialogLoading(String msg) {
        if (mLoadingDialog != null && mLoadingDialog.isShowing()) return;
        if (mLoadingDialog == null) {
            mLoadingDialog = new MaterialLoadingDialog.Builder(this).show(msg);
        } else {
            mLoadingDialog.show();
        }
    }

    public void hideDialogLoading() {
        if (mLoadingDialog == null) return;
        if (mLoadingDialog.isShowing()) {
            mLoadingDialog.dismiss();
        }
    }

    @Override
    public int getContentLayoutId() {
        return R.layout.layout_article_content;
    }

    @Override
    public void setIconChoice(ImageView ivChoice) {
        ivChoice.setImageResource(R.drawable.icon_info_publish_img);
    }

    @Override
    protected void setEmojiLayout(EmojiLayout mEmojiLayout) {
        //判断标题是否获取了焦点  标题获取了焦点 不能点击表情
        EditText titleEditText = getTitleEditText();

        mEmojiLayout.setOnEmojiClickListener(s -> {

            //判断标题是否获取了焦点
            if (!titleEditText.hasFocus()) {//内容输入表情
                int selectionStart = mRichTextEditor.getEditText().getSelectionStart();
                Editable editableText = mRichTextEditor.getEditText().getEditableText();
                if (editableText != null) {
                    editableText.insert(selectionStart, s);
                }
                return null;

            } else {//标题输入表情
                int selectionStart = titleEditText.getSelectionStart();
                Editable editableText = titleEditText.getEditableText();
                if (editableText != null) {
                    editableText.insert(selectionStart, s);
                }
                return null;
            }

        });

    }

    @Override
    public void initPresenter() {
        super.initPresenter();
        mPresenter.setVM(this);
    }

    @Override
    protected void bindEvent() {
        super.bindEvent();

        //插入图片回调
        callBackInsertImg();

        //上传文件加载dialog
        callBackRequestLoadingDialog();

        //上传图片文件回调
        callBackUploadFile();

        //提交发布回调
        callBackCommit();
    }

    @Override
    public void initViews() {
        mRichTextEditor = F(R.id.et_new_content);
        mPresenter.getJsonArrayDataAndShowContent(mRichTextEditor);
    }


    /**
     * 确认按钮
     */
    @Override
    protected void sure() {
        // TODO: 2019/11/15 上传操作
        //获取标题
        //获取内容
        //获取标签
        mPresenter.ifUploadFile(getVideoOrArticleTitle(), EditDataUtil.getEditData(mRichTextEditor), getParamTagsList(), getChoiceCategoryId());
    }


    @Override
    public void onBackPressed() {
        closeLogic();
    }


    /**
     * 取消按钮
     */
    @Override
    public void cancel() {
        closeLogic();
    }

    /**
     * 取消处理
     */
    private void closeLogic() {
        //获取标题
        String articleTitle = getVideoOrArticleTitle();
        //获取富文本内容 //[]
        String richContentEditData = EditDataUtil.getEditDataJsonArrays(mRichTextEditor);
        boolean richContentNotEmpty = EditDataUtil.judgeRichContentNotEmpty(richContentEditData);
        //获取标签列表数据
        ArrayList<IndexLableLetterBean> paramTagsList = getParamTagsList();

        //如果三者都为空 则不显示保存草稿对话框
        if (TextUtils.isEmpty(articleTitle) && !richContentNotEmpty && (paramTagsList == null || paramTagsList.size() == 0)) {
            finish();
            return;
        }

        //显示对话框 保存草稿
        //显示保存草稿
        DeleteImgDialog dialog = new DeleteImgDialog(this, getResources().getString(R.string.info_detail_dialog_save_to_file));
        dialog.show();
        dialog.setSureOrCancelListener(new DeleteImgDialog.SureOrCancelListener() {
            @Override
            public void cancel() {
                dialog.dismiss();
                //2019/11/14 清理操作
                mPresenter.clearArticleData();
                finish();
            }

            @Override
            public void sure() {
                //保存数据
                mPresenter.saveArticleData(getVideoOrArticleTitle(), richContentEditData, "", "", getParamTagsList(), getCategoryChoiceDataBean());
                dialog.dismiss();
                finish();
            }
        });
    }


    @Override
    protected void onPause() {
        super.onPause();

        if (!mPresenter.isNeedClearData()) {
            //获取标题
            String articleTitle = getVideoOrArticleTitle();
            //获取富文本内容 //[]
            String richContentEditData = EditDataUtil.getEditDataJsonArrays(mRichTextEditor);
            boolean richContentNotEmpty = EditDataUtil.judgeRichContentNotEmpty(richContentEditData);
            //获取标签列表数据
            ArrayList<IndexLableLetterBean> paramTagsList = getParamTagsList();

            //如果三者都为空 则不显示保存草稿对话框
            if (TextUtils.isEmpty(articleTitle) && !richContentNotEmpty && (paramTagsList == null || paramTagsList.size() == 0)) {
                return;
            }
            mPresenter.saveArticleData(getVideoOrArticleTitle(), richContentEditData, "", "", getParamTagsList(), getCategoryChoiceDataBean());

        }

    }


    /**
     * 从缓存中获取数据 todo
     *
     * @return
     */
    @Override
    public PublishVideoDataBean getDataFromCache() {
        return mPresenter.getArticleWithoutContentFromCache();
    }

    /**
     * 打开多媒体 这里是打开视频
     */
    @Override
    public void openMedia() {
        mPresenter.openGallery(this,EditDataUtil.getEditData(mRichTextEditor));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (data != null) {
                if (requestCode == Constant.REQUEST_CODE_CHOOSE) { //插入图片回调
                    //异步方式插入图片
                    insertImagesSync(data);
                }
            }
        }
    }

    /**
     * 异步方式插入图片
     */
    private void insertImagesSync(final Intent data) {
        dialog = ProgressDialogUtil.initDialog(this, "正在插入图片...");
        mPresenter.insertImagesSync(data);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        dispose(subsInsert);
    }

    private void dispose(Disposable disposable) {
        if (disposable != null && disposable.isDisposed()) {
            disposable.dispose();
        }
    }

    /**
     * 提交发布回调
     */
    private void callBackCommit() {
        mPresenter.getCommitData().observe(this, aBoolean -> {
            hideDialogLoading();
            if (aBoolean) {
                ToastUtils.showToast("发布成功");

                //清理缓存
                mPresenter.clearArticleData();

                finish();
            } else {
                ToastUtils.showToast("发布失败");
            }
        });
    }

    /**
     * 上传文件回调
     */
    private void callBackUploadFile() {
        mPresenter.getFileUploadData().observe(this, new LiveDataObserver<PublishArticleUploadFilePostBean>() {
            @Override
            public void onSuccess(PublishArticleUploadFilePostBean data) {
                //hideDialogLoading();
                boolean uploadSuccess = data.isUploadSuccess();
                if (uploadSuccess) {
                    Map<String, String> imgUrlMap = data.getImgUrlMap();
                    LogUtils.INSTANCE.e("===z", "上传成功 map = " + imgUrlMap);
                    String uploadData = EditDataUtil.getUploadData(mRichTextEditor, imgUrlMap);
                    LogUtils.INSTANCE.e("===z", "上传成功 uploadData = " + uploadData);
                    //ToastUtils.INSTANCE.showToast("上传成功");

                    // TODO: 2019/11/15 走提交操作
                    //标题 内容 标签
                    mPresenter.publishArticle(getVideoOrArticleTitle(), uploadData, getParamTagsList(), getChoiceCategoryId());
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                LogUtils.INSTANCE.e("===z", "上传失败 errCode = " + errCode + "   ---errMsg = " + errMsg);
                ToastUtils.showToast("发布失败");
                hideDialogLoading();
            }
        });
    }


    /**
     * 上传文件展示 加载进度条
     * 该dialog是在文件上传完毕之后再隐藏的
     */
    private void callBackRequestLoadingDialog() {
        mPresenter.getReqLoading().observe(this, aBoolean -> {
            if (aBoolean) {
                showDialogLoading();
            }
        });
    }


    /**
     * 插入图片回调
     */
    private void callBackInsertImg() {
        mPresenter.getInsertImageBean().observe(this, insertImageBean -> {
            int state = insertImageBean.getState();
            LogUtils.INSTANCE.e("===z", "state = " + state);
            switch (state) {

                case InsertImgType.TYPE_EMITTER_ONNEXT:
                    mRichTextEditor.measure(0, 0);
                    break;

                case InsertImgType.TYPE_ONNEXT:
                    String data = (String) insertImageBean.getData();
                    mRichTextEditor.insertImage(data, mRichTextEditor.getMeasuredWidth(), false);
                    break;

                case InsertImgType.TYPE_ONCOMPLETE:
                    ProgressDialogUtil.dismissProgressDialog(dialog);
                    //ToastUtils.INSTANCE.showToast("图片插入成功");
                    break;

                case InsertImgType.TYPE_ONSUBSCRIBE:
                    subsInsert = (Disposable) insertImageBean.getData();
                    ProgressDialogUtil.dismissProgressDialog(dialog);
                    break;

                default:
                    ToastUtils.showToast("图片插入失败");
                    Throwable e = (Throwable) insertImageBean.getData();
                    LogUtils.INSTANCE.e("===z", "图片插入异常 e = " + e.getMessage());
                    break;
            }
        });
    }
}
