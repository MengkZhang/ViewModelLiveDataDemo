package com.yb.ballworld.information.ui.detail;

import android.content.Context;
import android.content.Intent;

import com.yb.ballworld.baselib.base.fragment.BaseFragment;
import com.yb.ballworld.baselib.utils.AppUtils;
import com.yb.ballworld.baselib.web.WebActivity;
import com.yb.ballworld.baselib.web.WebConstant;

import org.jetbrains.annotations.NotNull;

/**
 * @author ink
 */
public class InformationLinkNewActivity extends WebActivity {

    @NotNull
    @Override
    protected BaseFragment getContentFragment() {
        return  new NewWebFragment();
    }


    /**
     * 跳转暂时使用传统方法
     */
    public static void start(Context context, String url, String title, boolean showBack, boolean webBack, int sportType) {
        Context contextTemp = context;
        if (context == null) {
            contextTemp = AppUtils.INSTANCE.getContext();
        }
        Intent intent = new Intent(contextTemp, InformationLinkNewActivity.class);
        if (context == null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        intent.putExtra(WebConstant.KEY_WEB_URL, url);
        intent.putExtra(WebConstant.KEY_WEB_TITLE, title);
        intent.putExtra(WebConstant.KEY_WEB_BACK, webBack);
        intent.putExtra(WebConstant.KEY_WEB_SWIPE_BACK, false);
        intent.putExtra(WebConstant.KEY_WEB_SHOW_BACK, showBack);
        intent.putExtra(WebConstant.KEY_WEB_SPORT_TYPE,sportType);
        contextTemp.startActivity(intent);
    }
}
