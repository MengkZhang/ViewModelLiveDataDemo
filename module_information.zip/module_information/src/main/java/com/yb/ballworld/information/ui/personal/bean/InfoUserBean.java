package com.yb.ballworld.information.ui.personal.bean;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Desc 用户信息
 * Date 2019/10/10
 * author JS-Kylo
 */
public class InfoUserBean implements Parcelable {

    /**
     * articleCount : 0
     * attentionStatus : true
     * followerCount : 0
     * headImgUrl :
     * id : 0
     * nickname :
     * personalDesc :
     */

    private int articleCount;
    private boolean attentionStatus;
    private int followerCount;
    private String headImgUrl;
    private int id;
    private String nickname;
    private String personalDesc;

    public int getArticleCount() {
        return articleCount;
    }

    public void setArticleCount(int articleCount) {
        this.articleCount = articleCount;
    }

    public boolean isAttentionStatus() {
        return attentionStatus;
    }

    public void setAttentionStatus(boolean attentionStatus) {
        this.attentionStatus = attentionStatus;
    }

    public int getFollowerCount() {
        return followerCount;
    }

    public void setFollowerCount(int followerCount) {
        this.followerCount = followerCount;
    }

    public String getHeadImgUrl() {
        return headImgUrl;
    }

    public void setHeadImgUrl(String headImgUrl) {
        this.headImgUrl = headImgUrl;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getPersonalDesc() {
        return personalDesc;
    }

    public void setPersonalDesc(String personalDesc) {
        this.personalDesc = personalDesc;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.articleCount);
        dest.writeByte(this.attentionStatus ? (byte) 1 : (byte) 0);
        dest.writeInt(this.followerCount);
        dest.writeString(this.headImgUrl);
        dest.writeInt(this.id);
        dest.writeString(this.nickname);
        dest.writeString(this.personalDesc);
    }

    public InfoUserBean() {
    }

    protected InfoUserBean(Parcel in) {
        this.articleCount = in.readInt();
        this.attentionStatus = in.readByte() != 0;
        this.followerCount = in.readInt();
        this.headImgUrl = in.readString();
        this.id = in.readInt();
        this.nickname = in.readString();
        this.personalDesc = in.readString();
    }

    public static final Creator<InfoUserBean> CREATOR = new Creator<InfoUserBean>() {
        @Override
        public InfoUserBean createFromParcel(Parcel source) {
            return new InfoUserBean(source);
        }

        @Override
        public InfoUserBean[] newArray(int size) {
            return new InfoUserBean[size];
        }
    };
}
