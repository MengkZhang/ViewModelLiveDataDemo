package com.yb.ballworld.information.ui.home.bean;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

import com.chad.library.adapter.base.entity.MultiItemEntity;

import java.util.List;

/**
 * Desc 资讯列表数据结构
 * Date 2019/10/8
 * author mengk
 */
public class HomeInfoListBean implements Parcelable, MultiItemEntity {
    //id
    private String id;
    //标题
    private String title;
    //封面
    private String imgUrl;
    //?
    private String preview;
    //评论数
    private String commentNumber;
    //展示类型 0 正常 1 双图 2 三图 3 图集
    private int showType;
    //APP展示类型图文： 没有头像 （单图类型 图片居右） 1\n 有头像 单图 2\n 双图 3\n 三图 4\n 视频 没有头像 5\n 有头像 6
    private int appShowType;
    //1 代表视频资讯
    private int mediaType;
    //视频地址
    private String playUrl;
    private int likeCount;
    private int commentCount;
    private int itemViewType;
    private HomeIndexUserBean userBean;
    private List<HomeIndexImgBean> imgList;
    private boolean hasFocus;
    private String newsId;


    public HomeInfoListBean() {}

    protected HomeInfoListBean(Parcel in) {
        id = in.readString();
        title = in.readString();
        imgUrl = in.readString();
        preview = in.readString();
        commentNumber = in.readString();
        showType = in.readInt();
        mediaType = in.readInt();
        playUrl = in.readString();
        newsId = in.readString();
        likeCount = in.readInt();
        commentCount = in.readInt();
        itemViewType = in.readInt();
        appShowType = in.readInt();
    }

    public static final Creator<HomeInfoListBean> CREATOR = new Creator<HomeInfoListBean>() {
        @Override
        public HomeInfoListBean createFromParcel(Parcel in) {
            return new HomeInfoListBean(in);
        }

        @Override
        public HomeInfoListBean[] newArray(int size) {
            return new HomeInfoListBean[size];
        }
    };

    public String getNewsId() {
        return newsId;
    }

    public void setNewsId(String newsId) {
        this.newsId = newsId;
    }

    @Override
    public int getItemType() {
        return itemViewType;
    }

    public int getItemViewType() {
        return itemViewType;
    }

    public boolean isHasFocus() {
        return hasFocus;
    }

    public void setHasFocus(boolean hasFocus) {
        this.hasFocus = hasFocus;
    }

    public void setItemViewType(int itemViewType) {
        this.itemViewType = itemViewType;
    }

    public List<HomeIndexImgBean> getImgList() {
        return imgList;
    }

    public void setImgList(List<HomeIndexImgBean> imgList) {
        this.imgList = imgList;
    }

    public HomeIndexUserBean getUserBean() {
        return userBean;
    }

    public void setUserBean(HomeIndexUserBean userBean) {
        this.userBean = userBean;
    }

    public int getAppShowType() {
        return appShowType;
    }

    public void setAppShowType(int appShowType) {
        this.appShowType = appShowType;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getPreview() {
        return preview;
    }

    public void setPreview(String preview) {
        this.preview = preview;
    }

    public String getCommentNumber() {
        return commentNumber;
    }

    public void setCommentNumber(String commentNumber) {
        this.commentNumber = commentNumber;
    }

    public int getShowType() {
        return showType;
    }

    public void setShowType(int showType) {
        this.showType = showType;
    }

    public int getMediaType() {
        return mediaType;
    }

    public void setMediaType(int mediaType) {
        this.mediaType = mediaType;
    }

    public String getPlayUrl() {
        return playUrl;
    }

    public void setPlayUrl(String playUrl) {
        this.playUrl = playUrl;
    }

    public int getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(int likeCount) {
        this.likeCount = likeCount;
    }

    public int getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(int commentCount) {
        this.commentCount = commentCount;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(title);
        dest.writeString(imgUrl);
        dest.writeString(preview);
        dest.writeString(commentNumber);
        dest.writeInt(showType);
        dest.writeInt(mediaType);
        dest.writeString(playUrl);
        dest.writeString(newsId);
        dest.writeInt(likeCount);
        dest.writeInt(commentCount);
        dest.writeInt(itemViewType);
        dest.writeInt(appShowType);
    }
}
