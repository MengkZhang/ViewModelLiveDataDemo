package com.yb.ballworld.information.ui.home.utils;

import android.app.ProgressDialog;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Desc
 * Date 2019/11/2
 * author mengk
 */
public class ProgressDialogUtil {
    public static ProgressDialog initDialog(AppCompatActivity context,String title) {
        ProgressDialog dialog = new ProgressDialog(context);
        dialog.setMessage(title);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
        return dialog;
    }

    public static void dismissProgressDialog(ProgressDialog dialog) {
        if (dialog == null) return;
        dialog.dismiss();
    }
}
