package com.yb.ballworld.information.ui.personal.view.community;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bfw.util.ToastUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.utils.NetWorkUtils;
import com.yb.ballworld.baselib.utils.ViewUtils;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.common.base.mvp.BaseMvpFragment;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.constant.FailStateConstant;
import com.yb.ballworld.information.ui.home.constant.LoadMoreType;
import com.yb.ballworld.information.ui.home.utils.JZReleaseUtil;
import com.yb.ballworld.information.ui.personal.adapter.community.PostHistoryAdapter;
import com.yb.ballworld.information.ui.personal.bean.community.PostHistoryBean;
import com.yb.ballworld.information.ui.personal.presenter.community.PersonalPostHistoryPresenter;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc: 个人空间-社区-足迹
 * Author: JS-Kylo
 * Created On: 2019/11/12 16:53
 */
public class PersonalPostHistoryFragment extends BaseMvpFragment<PersonalPostHistoryPresenter> {
    private static final String USER_ID = "USER_ID";
    private SmartRefreshLayout smartRefreshLayout;
    private RecyclerView recyclerView;
    private PlaceholderView placeholder;
    private LinearLayoutManager layoutManager;
    private List<PostHistoryBean> dataList = new ArrayList<>();
    private PostHistoryAdapter adapter;
    private int userId;

    public static PersonalPostHistoryFragment newInstance(){
        PersonalPostHistoryFragment fragment = new PersonalPostHistoryFragment();
        return fragment;
    }

    public static PersonalPostHistoryFragment newInstance(int userId){
        PersonalPostHistoryFragment fragment = new PersonalPostHistoryFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(USER_ID,userId);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void initPresenter() {
        mPresenter.setVM(this);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_collect_post;
    }

    @Override
    protected void initView() {
        Bundle bundle = getArguments();
        if (bundle != null)
            userId = bundle.getInt(USER_ID);
        smartRefreshLayout = findView(R.id.smartRefreshLayout);
        recyclerView = findView(R.id.recyclerView);
        placeholder = findView(R.id.placeholder);
        smartRefreshLayout.setRefreshHeader(getRefreshHeader());
        smartRefreshLayout.setRefreshFooter(getRefreshFooter());
        layoutManager = new LinearLayoutManager(mContext);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new PostHistoryAdapter(getActivity(),dataList);
        recyclerView.setAdapter(adapter);
    }

    @Override
    protected void bindEvent() {
        initRefreshLoadMoreEvent();
        initReLoadEvent();
        adapter.setOnItemChildClickListener(new BaseQuickAdapter.OnItemChildClickListener(){
            @Override
            public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
                Object item = adapter.getItem(position);
                if (item instanceof PostHistoryBean) {
                    PostHistoryBean bean = (PostHistoryBean) item;
                    int id = bean.getId();
                    if (id == 0) {
                        ToastUtils.showToast("点赞失败");
                        return;
                    }
                    boolean hasFocus = bean.isIsLike();
                    int likeCount = bean.getLikeCount();
                    if (view.getId() == R.id.rl_praise_root) {
                        if (NetWorkUtils.INSTANCE.isNetworkNotConnected()) {
                            ToastUtils.showToast(R.string.app_recycler_error);
                            return;
                        }
                        if (ViewUtils.INSTANCE.isFastClick())
                            return;
                        if (!hasFocus) { //没有点赞过
                            mPresenter.postLike(bean,position);
                        } else {
                            //ToastUtils.INSTANCE.showToast("点赞成功");
                            //goodView.show(view);
                        }

                    }

                }
            }
        });


        //接收停止视频
        LiveEventBus.get()
                .with(LiveEventBusKey.KEY_INFO_PAUSE_PLAY, Boolean.class)
                .observe(this, aBoolean -> {
                    if (aBoolean) {
                        JZReleaseUtil.releaseAllVideos();
                    }
                });

        //recyclerView滑动停止播放
        JZReleaseUtil.releaseAllVideos(recyclerView);

    }

    @Override
    public void onPause() {
        super.onPause();
        JZReleaseUtil.releaseAllVideos();
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (!getUserVisibleHint()) {
            JZReleaseUtil.releaseAllVideos();
        }
    }

    @Override
    protected void initData() {
        mPresenter.loadDate(userId,1);
//        mPresenter.loadTestDate();
    }

    @Override
    protected void processClick(View view) {

    }

    /**
     * 请求中
     */
    public void requestLoading() {
        placeholder.showLoading();
        smartRefreshLayout.setEnableRefresh(false);
        smartRefreshLayout.setEnableLoadMore(false);
    }

    /**
     * 请求成功回调
     * @param data 列表数据
     */
    public void resultSuccess(List<PostHistoryBean> data,int page) {
        placeholder.hideLoading();
        smartRefreshLayout.setEnableRefresh(true);
        smartRefreshLayout.setEnableLoadMore(true);
        if (page <= 1) {
            dataList.clear();
        }
        dataList.addAll(data);
        adapter.notifyDataSetChanged();
    }

    /**
     * 请求失败回调
     */
    public void resultFail(int type,String errMsg) {
        switch (type) {
            case FailStateConstant.TYPE_ERROR:   //加载失败
                if (TextUtils.isEmpty(errMsg)||"null".equals(errMsg))
                    placeholder.showError("服务器连接失败~");
                else
                    placeholder.showError(errMsg);
                break;
            case FailStateConstant.TYPE_EMPTY:   //数据为空
                smartRefreshLayout.setEnableRefresh(true);
                placeholder.showEmpty("暂无数据");
                break;

            default:
                break;
        }
    }


    /**
     * 刷新成功
     */
    public void resultRefreshSuccess() {
        smartRefreshLayout.finishRefresh();
        //刷新成功清理存储的数组
        dataList.clear();
    }

    /**
     * 刷新失败
     */
    public void resultRefreshFail(String errorMsg) {
        smartRefreshLayout.finishRefresh();
    }

    /**
     * 加载更多成功
     */
    public void resultLoadMoreSuccess(int type) {
        smartRefreshLayout.finishLoadMore();
        switch (type) {
            case LoadMoreType.TYPE_SUCCESS:      //加载成功
                break;

            case LoadMoreType.TYPE_ALL_DATA:     //已经全部加载
                ToastUtils.showToast("已经全部加载");
                //已经全部加载 就不允许继续上拉加载了
                smartRefreshLayout.setEnableLoadMore(false);
                break;

            default:
                break;
        }
    }

    /**
     * 加载更多失败
     */
    public void resultLoadMoreFail(String errorMsg) {
        smartRefreshLayout.finishLoadMore();
    }

    /**
     * 点赞成功
     */
    public void postLikeSuccess(PostHistoryBean bean, int position){
        bean.setIsLike(true);
        int count = bean.getLikeCount()+1;
        bean.setLikeCount(count);
        adapter.notifyItemChanged(position);
    }

    /**
     * 点赞成功
     */
    public void postLikeFail(String msg){
        //ToastUtils.INSTANCE.showToast("点赞失败");
        ToastUtils.showToast(msg);
    }
    /**
     * 初始化刷新和加载更多
     */
    private void initRefreshLoadMoreEvent() {
        smartRefreshLayout.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                mPresenter.loadMoreData();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                mPresenter.refreshData();
            }
        });
    }

    /**
     * 初始化重新加载数据
     */
    private void initReLoadEvent() {
        placeholder.setPageErrorRetryListener(v -> mPresenter.loadDate(userId,1));
    }
}
