package com.yb.ballworld.information.ui.personal.bean.community;

import android.text.TextUtils;

import com.chad.library.adapter.base.entity.MultiItemEntity;

import java.util.List;

/**
 * Desc: 足迹
 * Author: JS-Kylo
 * Created On: 2019/11/12 11:46
 */
public class PostHistoryBean  implements MultiItemEntity {

    /**
     * content :
     * createdDate :
     * headImgUrl :
     * id : 0
     * isAttention : true
     * isLike : true
     * likeCount : 0
     * nickname :
     * pageViews : 0
     * postId : 0
     * postImgLists : []
     * sonNum : 0
     * title :
     * userId :
     * videoUrl :
     */

    private String content;
    private String createdDate;
    private String headImgUrl;
    private int id;
    private boolean isAttention;
    private boolean isLike;
    private int likeCount;
    private String nickname;
    private int pageViews;
    private int postId;
    private int sonNum;
    private String title;
    private int userId;
    private String videoUrl;
    private List<String> postImgLists;
    private String webShareUrl;
    private String postDate;
    private String imgUrl;
    private String postUserId;

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getPostDate() {
        return !TextUtils.isEmpty(postDate) ? postDate : "";
    }

    public void setPostDate(String postDate) {
        this.postDate = postDate;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getHeadImgUrl() {
        return headImgUrl;
    }

    public void setHeadImgUrl(String headImgUrl) {
        this.headImgUrl = headImgUrl;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public boolean isIsAttention() {
        return isAttention;
    }

    public void setIsAttention(boolean isAttention) {
        this.isAttention = isAttention;
    }

    public boolean isIsLike() {
        return isLike;
    }

    public void setIsLike(boolean isLike) {
        this.isLike = isLike;
    }

    public int getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(int likeCount) {
        this.likeCount = likeCount;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public int getPageViews() {
        return pageViews;
    }

    public void setPageViews(int pageViews) {
        this.pageViews = pageViews;
    }

    public int getPostId() {
        return postId;
    }

    public void setPostId(int postId) {
        this.postId = postId;
    }

    public int getSonNum() {
        return sonNum;
    }

    public void setSonNum(int sonNum) {
        this.sonNum = sonNum;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    public List<String> getPostImgLists() {
        return postImgLists;
    }

    public void setPostImgLists(List<String> postImgLists) {
        this.postImgLists = postImgLists;
    }

    public String getWebShareUrl() {
        return webShareUrl;
    }

    public void setWebShareUrl(String webShareUrl) {
        this.webShareUrl = webShareUrl;
    }

    public String getPostUserId() {
        return postUserId;
    }

    public void setPostUserId(String postUserId) {
        this.postUserId = postUserId;
    }

    private int itemViewType;

    @Override
    public int getItemType() {
        return itemViewType;
    }

    public void setItemViewType(int itemViewType) {
        this.itemViewType = itemViewType;
    }

    //测试用
    public PostHistoryBean(String content, String createdDate, String headImgUrl, int id, String nickname, int userId, String videoUrl, List<String> postImgLists) {
        this.content = content;
        this.createdDate = createdDate;
        this.headImgUrl = headImgUrl;
        this.id = id;
        this.nickname = nickname;
        this.userId = userId;
        this.videoUrl = videoUrl;
        this.postImgLists = postImgLists;
    }
}
