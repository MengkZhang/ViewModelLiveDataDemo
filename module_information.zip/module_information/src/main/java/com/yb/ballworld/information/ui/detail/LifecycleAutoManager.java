package com.yb.ballworld.information.ui.detail;

import androidx.annotation.NonNull;
import androidx.core.app.ComponentActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc: ComponentActivity,Fragment
 * 生命周期监听，页面容量管理，归零销毁
 * 请在页面中尽可能早的调用join，避免在多线程中使用
 * @author ink
 * created at 2019/10/19 14:27
 */
public class LifecycleAutoManager implements DefaultLifecycleObserver {
    private static LifecycleAutoManager sActivityManager;
    private List<LifecycleOwner> activities;
    private static final byte CAPACITY = 2;
    private static int sCapacity = CAPACITY;

    private LifecycleAutoManager() {

    }

    /**
     * 生命周期管理池容量
     *
     * @param capacity
     */
    public static void capacity(int capacity) {
        sCapacity = capacity;
    }

    /**
     * 添加需管理的页面
     *
     * @param owner ComponentActivity,Fragment
     */
    public static void join(LifecycleOwner owner) {
        if (sActivityManager == null) {
            sActivityManager = new LifecycleAutoManager();
        }
        if (sActivityManager.getActivities() == null) {
            sActivityManager.setActivities(new ArrayList<>(sCapacity));
        }
        if (owner instanceof ComponentActivity || owner instanceof Fragment) {
            sActivityManager.reregister(owner);
        }
    }

    private List<LifecycleOwner> getActivities() {
        return activities;
    }

    private void setActivities(List<LifecycleOwner> activities) {
        this.activities = activities;
    }


    /**
     * 添加与调整容量
     *
     * @param owner
     */
    private void reregister(LifecycleOwner owner) {
        owner.getLifecycle().addObserver(this);
        activities.add(owner);
        regulate();
    }

    /**
     * 调整池容量与过量页面回收
     */
    private void regulate() {
        while (activities.size() > sCapacity) {
            recycle(activities.remove(0));
        }

        //等于零时自动销毁
        if (activities.isEmpty()) {
            destory();
        }
    }

    /**
     * 回收页面
     * @param removedAct
     */
    private void recycle(LifecycleOwner removedAct) {
        boolean isNeedOpreate = removedAct != null;
        if (isNeedOpreate) {
            removedAct.getLifecycle().removeObserver(this);
            if (removedAct instanceof ComponentActivity) {
                //回收Activity
                ComponentActivity tempAct = (ComponentActivity) removedAct;
                if (!(tempAct.isFinishing() || tempAct.isDestroyed())) {
                    tempAct.finish();
                }
            } else if (removedAct instanceof Fragment) {
                //回收Fragment
                Fragment tempAct = (Fragment) removedAct;
                if (!(tempAct.isRemoving() || tempAct.isDetached())) {
                    FragmentManager fragmentManager = tempAct.getFragmentManager();
                    if (fragmentManager != null) {
                        fragmentManager.beginTransaction().detach(tempAct).remove(tempAct).commitAllowingStateLoss();
                    }
                }
            }
        }
    }

    /**
     * 全部移除，不回收页面
     */
    public static void clear() {
        LifecycleAutoManager manager = sActivityManager;
        if (manager != null) {
            List<LifecycleOwner> activities = manager.getActivities();
            LifecycleOwner removedAct;
            boolean isNeedOpreate;
            while (!activities.isEmpty()) {
                removedAct = activities.remove(0);
                isNeedOpreate = removedAct != null;
                if (isNeedOpreate) {
                    removedAct.getLifecycle().removeObserver(manager);
                }
            }
            manager.destory();
        }
    }

    /**
     * 全部移除,包括页面
     */
    public static void cleanUp() {
        LifecycleAutoManager manager = sActivityManager;
        if (manager != null) {
            List<LifecycleOwner> activities = manager.getActivities();
            while (!activities.isEmpty()) {
                manager.recycle(activities.remove(0));
            }
            manager.destory();
        }
    }

    /**
     * 移除与调整
     *
     * @param owner
     */
    private void unRegister(LifecycleOwner owner) {
        owner.getLifecycle().removeObserver(this);
        activities.remove(owner);
        regulate();
    }

    @Override
    public void onDestroy(@NonNull LifecycleOwner owner) {
        unRegister(owner);
    }

    /**
     * 销毁
     */
    private void destory() {
        activities = null;
        sActivityManager = null;
    }
}
