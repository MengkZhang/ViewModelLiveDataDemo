package com.yb.ballworld.information.ui.home.adapter;
import android.widget.ImageView;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.util.DensityUtil;
import com.yb.ballworld.common.baseapp.AppContext;
import com.yb.ballworld.common.utils.ScreenUtils;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.bean.InfoPublishImgBean;
import com.yb.ballworld.information.ui.home.utils.GlideLoadImgUtil;

import java.util.List;

/**
 * Desc 发表评论中的选中图片适配器
 * Date 2019/10/10
 * author mengk
 */
public class ChoiceImgAdapter extends BaseQuickAdapter<InfoPublishImgBean, BaseViewHolder> {

    private int screenWidth;

    public ChoiceImgAdapter(@Nullable List<InfoPublishImgBean> data) {
        super(R.layout.item_img_choice, data);
        screenWidth = ScreenUtils.getScreenWidth(AppContext.getAppContext());
    }

    @Override
    protected void convert(BaseViewHolder helper, InfoPublishImgBean item, int pos) {
        ImageView imageView = helper.getView(R.id.iv_img_multi_publish);
        GlideLoadImgUtil.loadImgWithCallback(mContext, item.getUri().toString(), imageView);
//        ImageManager.INSTANCE.loadImageOrGif(item.getUri().toString(),imageView,new OnImageListener() {
//            @Override
//            public void onSuccess(@org.jetbrains.annotations.Nullable Bitmap bitmap) {
//
//            }
//
//            @Override
//            public void onFail(@org.jetbrains.annotations.Nullable String msg) {
//                ToastUtils.INSTANCE.showToast("图片不存在");
//            }
//        });
        helper.addOnClickListener(R.id.rl_info_publish_del);

        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) (helper.getView(R.id.rl_info_publish_img_root)).getLayoutParams();
        layoutParams.width = (screenWidth - DensityUtil.dp2px(36)) / 3;

    }
}
