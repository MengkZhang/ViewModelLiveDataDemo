//package com.yb.ballworld.information.ui.profile.data;
//
//import com.chad.library.adapter.base.entity.MultiItemEntity;
//
///**
// * @author Gethin
// * @time 2019/11/9 10:21
// */
//
//public class PlayerBean implements MultiItemEntity {
//
//    public static final int COACH = 1;
//    public static final int SECTION = 2;
//    public static final int CONTENT = 3;
//
//    public static final int CONTENT_START = 1;
//    public static final int CONTENT_END = 2;
//
//    private int contentPos;
//    private int itemType;
//    private String position;// 球员位置，前锋，中场，后卫......
//
//
//    public PlayerBean(int itemType) {
//        this.itemType = itemType;
//    }
//
//    public int getContentPos() {
//        return contentPos;
//    }
//
//    public void setContentPos(int contentPos) {
//        this.contentPos = contentPos;
//    }
//
//    @Override
//    public int getItemType() {
//        return itemType;
//    }
//
//
//
//}
