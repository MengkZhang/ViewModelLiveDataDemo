package com.yb.ballworld.information.ui.personal.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.bfw.image.core.utils.RoundType;
import com.bfw.image.glide.transform.RoundedCornersTransformation;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.request.RequestOptions;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.yb.ballworld.baselib.utils.ImageManager;
import com.yb.ballworld.baselib.utils.TimeUtils;
import com.yb.ballworld.baselib.utils.ViewUtils;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.community.view.VeidoPlayerActivity;
import com.yb.ballworld.information.ui.detail.CommentImgQuickAdapter;
import com.yb.ballworld.information.ui.detail.InforCommentActivity;
import com.yb.ballworld.information.ui.detail.NewsVideoDetailActivity;
import com.yb.ballworld.information.ui.detail.NewsTextDetailActivity;
import com.yb.ballworld.information.ui.detail.NewsTextDetailActivityLollipop;
import com.yb.ballworld.information.ui.personal.bean.CommentBean;
import com.yb.ballworld.information.utils.CommondUtil;
import com.yb.ballworld.information.widget.TimerTextView;
import com.yb.ballworld.information.widget.listener.OnElementClickListener;

import java.util.ArrayList;
import java.util.List;

import cn.jzvd.JzvdStd;

/**
 * Desc:
 * Author: JS-Kylo
 * Created On: 2019/10/7 17:20
 */
public class CommentAdapter extends BaseQuickAdapter<CommentBean, BaseViewHolder> {
    private Context context;
    private String author;
    private String headUrl;
    public static final int ITEMTYPE_NO_MEDIA = 0;
    public static final int ITEMTYPE_IMGS = 1;
    public static final int ITEMTYPE_VIDEO = 2;
    private OnElementClickListener mOnElementClickListener;

    public CommentAdapter(@Nullable List<CommentBean> data, Context context) {
        super(R.layout.item_information_comment, data);
        this.context = context;
    }

    public CommentAdapter(@Nullable List<CommentBean> data, Context context, String author) {
        super(R.layout.item_information_comment, data);
        this.context = context;
        this.author = author;
    }

    public CommentAdapter(@Nullable List<CommentBean> data, Context context, String author, String hUrl) {
        super(R.layout.item_information_comment, data);
        this.context = context;
        this.author = author;
        this.headUrl = hUrl;
    }

    public void setOnElementClickListener(OnElementClickListener onElementClickListener) {
        mOnElementClickListener = onElementClickListener;
    }

    @Override
    protected void convert(BaseViewHolder helper, CommentBean item, int pos) {
        headUrl = TextUtils.isEmpty(item.getHeadImgUrl()) ? headUrl : item.getHeadImgUrl();
        ImageManager.INSTANCE.loadRoundIcon(headUrl, R.drawable.user_default_icon2, 0, helper.getView(R.id.ivUserHeader));
        helper.setText(R.id.tvUserName, item.getNickName());  //用户名
        //helper.setText(R.id.tvUserDesc, CommondUtil.convertTime(item.getCreatedDate(), context)); //时间
        ((TimerTextView)helper.getView(R.id.tvUserDesc)).setText(item.getCreatedDate() + "的回复");
        helper.setText(R.id.tvContent, item.getContent()); //内容
        TextView tvOriginal = helper.getView(R.id.tvOriginal);
        if (!TextUtils.isEmpty(item.getTitle()))
            helper.setText(R.id.tvOriginal, item.getTitle());
        setLines(tvOriginal);
        if (TextUtils.isEmpty(item.getContent()))
            helper.setGone(R.id.tvContent, false);
        helper.setText(R.id.tv_img, item.getMediaType() == 1 ? context.getString(R.string.func_commentVideo) : context.getString(R.string.func_commentImg));
        //点赞
        helper.setText(R.id.tvLikeCount, CommondUtil.likeCount(item.getLikeCount(), context));
        helper.addOnClickListener(R.id.lyPraise);
        helper.getView(R.id.iv_praise_icon).setSelected(item.isIsLike());

        //点击头像再次进入个人页
        helper.getView(R.id.ivUserHeader).setOnClickListener(v -> {
            String userId = item.getUserId();
            if (!TextUtils.isEmpty(userId)) {
                // InformationPersonalActivity.startActivity(mContext, userId);
            }
        });
        //跳转到文章该条的回复位置
        helper.getView(R.id.tvContent).setOnClickListener(v -> {
            gotoCommentPosition(item);
            //if (item.getCommentType() == 0)  //评论
            //    gotoInfoDetail(item);
            //else if (item.getCommentType() == 1)  //回复
            //    gotoCommentPosition(item);
        });
        helper.getView(R.id.tvUserDesc).setOnClickListener(v -> {
            gotoCommentPosition(item);
            //if (item.getCommentType() == 0)  //评论
            //    gotoInfoDetail(item);
            //else if (item.getCommentType() == 1)  //回复
            //    gotoCommentPosition(item);
        });

        //跳转到原文
        helper.getView(R.id.tvOriginal).setOnClickListener(v -> gotoInfoDetail(item));
        //helper.getView(R.id.singleCommit_frameLayout).setVisibility(View.GONE);
        int mediaType = getMediaType(item);
        if (mediaType == ITEMTYPE_VIDEO) {
            handleVideo(helper, item);
        } else if (mediaType == ITEMTYPE_IMGS) {
            handleImgs(helper, item);
        } else {
            helper.getView(R.id.singleCommit_frameLayout).setVisibility(View.GONE);
        }
    }

    /**
     * 跳转评论页
     */
    private void gotoCommentPosition(CommentBean bean) {
        Intent intent = new Intent(mContext, InforCommentActivity.class);
        intent.putExtra("NEWS_ID", bean.getNewsId());        //资讯ID
        intent.putExtra("COMMENT_ID", bean.getId());         //评论ID
        intent.putExtra("MAIN_COMMENT_ID", bean.getMainCommentId()); //主评论ID
        intent.putExtra("COMMENT_TYPE", bean.getCommentType());        //0.评论 1.回复
        mContext.startActivity(intent);
    }

    /**
     * 跳转到资讯详情页
     */
    private void gotoInfoDetail(CommentBean bean) {
        Intent intent = new Intent(mContext, bean.getMediaType() == 1 ? NewsVideoDetailActivity.class : Build.VERSION.SDK_INT>Build.VERSION_CODES.LOLLIPOP?NewsTextDetailActivity.class: NewsTextDetailActivityLollipop.class);
        intent.putExtra("NEWS_ID", bean.getNewsId());        //资讯ID
        intent.putExtra("NEWS_TYPE", bean.getMediaType() == 1);
        mContext.startActivity(intent);
    }

    /**
     * 处理评论中含有视频的扩展布局
     *
     * @param
     * @param
     */
    private void handleVideo(BaseViewHolder helper, CommentBean item) {
        ViewGroup viewGroup= helper.getView(R.id.singleCommit_frameLayout);
        viewGroup.setVisibility(View.VISIBLE);

        helper.getView(R.id.singleCommit_frameLayout).setVisibility(View.VISIBLE);
        helper.getView(R.id.cardViewLayout).setVisibility(View.VISIBLE);
        helper.getView(R.id.recycle_imgs).setVisibility(View.GONE);

        JzvdStd jzvdStd = helper.getView(R.id.item_comment_video);
        if (!TextUtils.isEmpty(item.getVideoUrl())) {
            jzvdStd.setUp(item.getVideoUrl(), "", JzvdStd.SCREEN_NORMAL);
            Glide.with(context).setDefaultRequestOptions(new RequestOptions()
                    .frame(1).transform(new CenterCrop(), new RoundedCornersTransformation(ViewUtils.dp2px(4), RoundType.ALL))).load(item.getVideoUrl())
                    .into(jzvdStd.thumbImageView);
            jzvdStd.thumbImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    gotoVideoPlayer(item);
                }
            });
            jzvdStd.startButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    gotoVideoPlayer(item);
                }
            });
        }
    }

    public long getCreatedTime(String createdTime) {
        long createdTimes;
            if (!TextUtils.isEmpty(createdTime)) {
                createdTimes = TimeUtils.INSTANCE.toTimestamp(createdTime);
            } else {
                createdTimes = System.currentTimeMillis();
            }
        return createdTimes;
    }

    /**
     * 处理评论中含有图片的扩展布局
     *
     * @param
     * @param
     */
    private void handleImgs(BaseViewHolder helper, CommentBean item) {
        ViewGroup viewGroup= helper.getView(R.id.singleCommit_frameLayout);
        viewGroup.setVisibility(View.VISIBLE);
        /*if(viewGroup.getChildCount()>0){
            viewGroup.removeAllViews();
        }*/

        helper.getView(R.id.singleCommit_frameLayout).setVisibility(View.VISIBLE);
        helper.getView(R.id.cardViewLayout).setVisibility(View.GONE);
        helper.getView(R.id.recycle_imgs).setVisibility(View.VISIBLE);

        RecyclerView recyclerView = helper.getView(R.id.recycle_imgs);
        CommentImgQuickAdapter commentImgQuickAdapter = new CommentImgQuickAdapter();
        recyclerView.setAdapter(commentImgQuickAdapter);

        commentImgQuickAdapter.autoFit(recyclerView, getImgList(item));
        commentImgQuickAdapter.setOnItemClickListener(onItemImgsClickListener);
    }


    public void gotoVideoPlayer(CommentBean item){
        Intent intent=new Intent(context, VeidoPlayerActivity.class);
        intent.putExtra("url",item.getVideoUrl());
        intent.putExtra("imageUrl",item.getVideoCoverUrl());
        context.startActivity(intent);
    }
    /**
     * 主要用在点击评论图片的事件转发
     *
     * @param adapter  the adpater
     * @param view     The itemView within the RecyclerView that was clicked (this
     * will be a view provided by the adapter)
     * @param position The position of the view in the adapter.
     */
    private OnItemClickListener onItemImgsClickListener = (adapter, view, position) -> {
        if (mOnElementClickListener != null) {
            mOnElementClickListener.onElementClick((String) adapter.getItem(position), ITEMTYPE_IMGS, position, adapter.getData());
        }
    };

    private String isNotNull(String string) {
        return !TextUtils.isEmpty(string) ? string : "";
    }

    private String getMediaPrompt(CommentBean simpleCommit, int parentMediaType) {
        String text = "";
        if (parentMediaType == ITEMTYPE_VIDEO) {
            text = context.getString(R.string.func_commentVideo);
        } else if (parentMediaType == ITEMTYPE_IMGS) {
            int size = getImgList(simpleCommit).size();
            if (size > 1) {
                text = context.getString(R.string.func_commentImgCount, size);
            } else {
                text = context.getString(R.string.func_commentImg);
            }
        }
        return text;
    }

    /**
     * 获取媒资类型
     *
     * @param item
     */
    public int getMediaType(CommentBean item) {
        int type;
        if (!TextUtils.isEmpty(item.getVideoUrl())) {
            type = ITEMTYPE_VIDEO;
        } else if (isHasImg(item)) {
            type = ITEMTYPE_IMGS;
        } else {
            type = ITEMTYPE_NO_MEDIA;
        }
        return type;
    }

    /**
     * 评论中是否含有图片
     *
     * @param item
     * @return
     */
    private boolean isHasImg(CommentBean item) {
        return !TextUtils.isEmpty(item.getImgUrl1()) || !TextUtils.isEmpty(item.getImgUrl2()) || !TextUtils.isEmpty(item.getImgUrl3());
    }

    /**
     * 评论中提取图片列表
     *
     * @param item
     * @return
     */
    public List<String> getImgList(CommentBean item) {
        List<String> imgList = new ArrayList<>();

        String imgUrl = item.getImgUrl1();
        if (!TextUtils.isEmpty(imgUrl)) {
            imgList.add(imgUrl);
        }
        imgUrl = item.getImgUrl2();
        if (!TextUtils.isEmpty(imgUrl)) {
            imgList.add(imgUrl);
        }
        imgUrl = item.getImgUrl3();
        if (!TextUtils.isEmpty(imgUrl)) {
            imgList.add(imgUrl);
        }
        return imgList;
    }

    /**
     * 设置textview 最大行数
     */
    private void setLines(TextView textView) {
        textView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                int lineCount = textView.getLineCount();
                if (lineCount > 2) {
                    textView.setMaxLines(1);
                    textView.setEllipsize(TextUtils.TruncateAt.END);
                }
                textView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            }
        });
    }
}
