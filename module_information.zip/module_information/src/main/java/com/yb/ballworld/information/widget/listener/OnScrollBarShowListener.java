package com.yb.ballworld.information.widget.listener;

/**
 * Desc: <功能简述>
 * Author: JS-Dugu
 * Created On: 2019/10/15 21:14
 */
public interface OnScrollBarShowListener {
    void onShow();
}
