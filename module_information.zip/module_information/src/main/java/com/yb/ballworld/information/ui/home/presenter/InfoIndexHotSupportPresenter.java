package com.yb.ballworld.information.ui.home.presenter;

import android.text.TextUtils;
import android.util.Log;

import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.im.ImPushParser;
import com.yb.ballworld.common.im.entity.QttName;
import com.yb.ballworld.information.ui.home.bean.HomeIndexBannerBean;
import com.yb.ballworld.information.ui.home.bean.HomeIndexHotRunBean;
import com.yb.ballworld.information.ui.home.bean.HomeIndexImgBean;
import com.yb.ballworld.information.ui.home.bean.HomeInfoListBean;
import com.yb.ballworld.information.ui.home.bean.IndexHotEntity;
import com.yb.ballworld.information.ui.home.constant.FailStateConstant;
import com.yb.ballworld.information.ui.home.constant.InfoSpecialPushParams;
import com.yb.ballworld.information.ui.home.constant.LoadMoreType;
import com.yb.ballworld.information.ui.home.service.InfoHttpApi;
import com.yb.ballworld.information.ui.home.utils.InfoHotToHomeBeanUtil;
import com.yb.ballworld.information.utils.CommondUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc 首页热门presenter 兼容old
 * Date 2019/10/7
 * author mengk
 */
public class InfoIndexHotSupportPresenter implements InfoIndexHotContract.IInfoIndexHotPresenter {

    private InfoHttpApi httpApi;
    private InfoIndexHotContract.IInfoIndexHotView mView;
    private List<IndexHotEntity.NewsBean.ListBean> mHomeInfoList;
    //    private List<IndexHotEntity.NewsBean.ListBean> mHomeInfoLastList;
//    private List<HomeIndexBannerBean> mHomeIndexBannerBeanList;
    //当前页数
    private int page = 1;
    //返回的总页数
    private int totalPage;
    private boolean isRefresh;
    private boolean isLoadMore;
    private int labelType;
    private String categoryId;
    private String mediaType;
    private String sportType;

    /**
     * 构造方法
     */
    public InfoIndexHotSupportPresenter(int labelType, String categoryId, String mediaType, String sportType) {
        this.labelType = labelType;
        this.categoryId = categoryId;
        this.mediaType = mediaType;
        this.sportType = sportType;
        httpApi = new InfoHttpApi();
        mHomeInfoList = new ArrayList<>();
    }

    public void setParams(int labelType, String categoryId, String mediaType, String sportType) {
        this.labelType = labelType;
        this.categoryId = categoryId;
        this.mediaType = mediaType;
        this.sportType = sportType;
    }

    /**
     * 刷新
     */
    @Override
    public void refreshData() {
        isRefresh = true;
        page = 1;
        loadData(page);
    }

    /**
     * 加载更多
     */
    @Override
    public void loadMoreData() {
        isLoadMore = true;
        page++;
        if (page <= totalPage) { //可以加载更多数据
            loadData(page);
        } else {                 //没有更多数据
            mView.resultLoadMoreSuccess(LoadMoreType.TYPE_ALL_DATA);
        }
    }

    /**
     * 加载数据
     *
     * @param page 当前页数
     */
    @Override
    public void loadData(int page) {
        //只有正常加载才有loading 加载更多和刷新是没有的
        if (!isRefresh && !isLoadMore) {
            mView.requestLoading();
        }
        //每页的数据条数
        int pageSize = 15;
        httpApi.getIndexHotData(labelType, categoryId, mediaType, sportType, page, pageSize, new LifecycleCallback<IndexHotEntity>(mView.getFragment()) {

            @Override
            public void onSuccess(IndexHotEntity data) {
                LogUtils.INSTANCE.e("===z", "hot data = " + data);
                if (data != null) {  //data数据
                    List<IndexHotEntity.BulletBlocksBean> bulletBlocks = data.getBulletBlocks();
                    List<IndexHotEntity.NewsTopBlocksBean> newsTopBlocks = data.getNewsTopBlocks();
                    IndexHotEntity.SpecialBlocksBean specialBlocks = data.getSpecialBlocks();
                    List<IndexHotEntity.TopBlocksBean> topBlocks = data.getTopBlocks();
                    IndexHotEntity.NewsBean news = data.getNews();

                    //banner数据
                    getBannerData(topBlocks);

                    //专栏数据
                    getSpecialData(specialBlocks);

                    //子弹推数据
                    getBullet(bulletBlocks);

                    //置顶数据
                    getTopData(newsTopBlocks);

                    //把置顶的数据添加到第一页
                    if (page == 1 && newsTopBlocks != null && newsTopBlocks.size() != 0) { //第一页且有置顶数据
                        List<IndexHotEntity.NewsBean.ListBean> topList = InfoHotToHomeBeanUtil.infoHotToHomeList(data.getNewsTopBlocks());
                        getNormalListData(news, topList);

                    } else {                                                               //不是第一页没有置顶数据

                        //列表数据 如果没有列表数据 其他数据都不会展示了
                        getNormalListData(news, null);
                    }


                } else {          //data为空
                    judgeStatusEmpty();
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                LogUtils.INSTANCE.e("===z", "hot fail");
                if (isRefresh) {         //刷新失败
                    isRefresh = false;
                    mView.resultRefreshFail("刷新失败");

                } else if (isLoadMore) { //加载更多失败
                    isLoadMore = false;
                    mView.resultLoadMoreFail("加载更多失败");

                } else {                 //正常加载数据失败
                    mView.resultFail(FailStateConstant.TYPE_ERROR);

                }
            }
        });
    }

    /**
     * 获取普通列表数据
     *
     * @param news
     * @param topList
     */
    private void getNormalListData(IndexHotEntity.NewsBean news, List<IndexHotEntity.NewsBean.ListBean> topList) {
        if (news != null) {   //news数据
            List<IndexHotEntity.NewsBean.ListBean> mHomeInfoLastList = new ArrayList<>();
            totalPage = news.getTotalPage();
            List<IndexHotEntity.NewsBean.ListBean> list = news.getList();
            if (list != null && list.size() != 0) { //list不为空

                //判断是否有置顶内容
                if (topList != null && topList.size() != 0) { //有置顶数据 添加到列表的第一个位置
                    list.addAll(0, topList);
                }

                List<HomeIndexImgBean> homeIndexImgBeanList = new ArrayList<>();
                for (IndexHotEntity.NewsBean.ListBean listBean : list) {
                    int itemType = listBean.getItemType();
                    LogUtils.INSTANCE.e("===z", "数据源中itemType = " + itemType);
                    IndexHotEntity.NewsBean.ListBean.UserBean user = listBean.getUser();

                    HomeInfoListBean infoListBean = new HomeInfoListBean();

                    //设置图片数组
                    List<IndexHotEntity.NewsBean.ListBean.NewsImgsBean> newsImgs = listBean.getNewsImgs();
                    if (newsImgs != null && newsImgs.size() != 0) {
                        for (IndexHotEntity.NewsBean.ListBean.NewsImgsBean newsImg : newsImgs) {
                            String newsId = newsImg.getNewsId();
                            String img = newsImg.getImgUrl();
                            String content = newsImg.getContent();
                            HomeIndexImgBean homeIndexImgBean = new HomeIndexImgBean();
                            homeIndexImgBean.setImgUrl(isNotNull(img));
                            homeIndexImgBean.setContent(isNotNull(content));
                            homeIndexImgBean.setNewsId(isNotNull(newsId));
                            homeIndexImgBeanList.add(homeIndexImgBean);
                        }
                    } else {
                        // TODO: 2019/10/12 test数组
                    }
                    infoListBean.setImgList(homeIndexImgBeanList);

                    mHomeInfoList.add(listBean);
                }

                if (mHomeInfoList.size() != 0) {
                    if (isRefresh) {
                        mHomeInfoLastList.clear();
                    }
                    mHomeInfoLastList.addAll(mHomeInfoList);
                    //还原刷新的状态
                    if (isRefresh) {
                        isRefresh = false;
                        mView.resultRefreshSuccess();
                    }
                    //还原加载更多的状态
                    if (isLoadMore) {
                        isLoadMore = false;
                        mView.resultLoadMoreSuccess(LoadMoreType.TYPE_SUCCESS);
                    }
                    LogUtils.INSTANCE.e("===z", "list mHomeInfoLastList = " + mHomeInfoLastList.size());
                    mView.resultSuccess(mHomeInfoLastList, page);
                    //执行成功完毕 清理中转数组 否则造成列表叠加
                    mHomeInfoList.clear();

                } else {
                    judgeStatusEmpty();
                }

            } else {                                //list为空
                judgeStatusEmpty();
            }

        } else {              //news为空
            judgeStatusEmpty();
        }
    }

    /**
     * 获取置顶数组
     *
     * @param newsTopBlocks
     */
    private void getTopData(List<IndexHotEntity.NewsTopBlocksBean> newsTopBlocks) {
        if (newsTopBlocks != null && newsTopBlocks.size() != 0) {  //置顶数据
            mView.resultTopSuccess(newsTopBlocks);
        } else {                                                   //置顶数据为空
            mView.resultTopFail(page);
        }
    }

    /**
     * 获取子弹推数组
     *
     * @param bulletBlocks
     */
    private void getBullet(List<IndexHotEntity.BulletBlocksBean> bulletBlocks) {
        if (bulletBlocks != null && bulletBlocks.size() != 0) {    //子弹推数组
            List<HomeIndexHotRunBean> homeIndexHotRunBeanList = new ArrayList<>();
            for (IndexHotEntity.BulletBlocksBean bulletBlock : bulletBlocks) {
                String id = bulletBlock.getId();
                String title = bulletBlock.getTitle();
                String imgUrl = bulletBlock.getImgUrl();
                String jumpUrl = bulletBlock.getJumpUrl();
                int jumpType = bulletBlock.getJumpType();
                String jumpId = bulletBlock.getJumpId();//这里也是matchID
                String sportId = bulletBlock.getSportId();
                int matchId = 0;
                int sportID = 0;
                try {
                    matchId = Integer.parseInt(jumpId);
                    sportID = Integer.parseInt(sportId);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                HomeIndexHotRunBean hotRunBean = new HomeIndexHotRunBean();
                hotRunBean.setId(isNotNull(id));
                hotRunBean.setTitle(isNotNull(title));
                hotRunBean.setImgUrl(isNotNull(imgUrl));
                hotRunBean.setJumpId(isNotNull(jumpId));
                hotRunBean.setJumpType(jumpType);
                hotRunBean.setJumpUrl(jumpUrl);
                hotRunBean.setMatchId(matchId);
                hotRunBean.setSportType(sportID);
                hotRunBean.setSportId(sportID);
                homeIndexHotRunBeanList.add(hotRunBean);
            }
            mView.resultHotRunSuccess(homeIndexHotRunBeanList);
        } else {                                                   //子弹推为空
            mView.resultHotRunFail(page);
        }
    }

    /**
     * 获取专栏数据
     *
     * @param specialBlocks 专栏数组
     */
    private void getSpecialData(IndexHotEntity.SpecialBlocksBean specialBlocks) {
        if (specialBlocks != null && specialBlocks.getSpecialBlockVo() != null) {
            mView.resultSpecialSuccess(specialBlocks);
        } else {
            mView.resultSpecialFail(page);
        }
    }

    /**
     * 获取banner数据
     *
     * @param topBlocks banner数组
     */
    private void getBannerData(List<IndexHotEntity.TopBlocksBean> topBlocks) {
        if (topBlocks != null && topBlocks.size() != 0) {         //banner数据
            List<HomeIndexBannerBean> mHomeIndexBannerBeanList = new ArrayList<>();
            mHomeIndexBannerBeanList.clear();
            for (IndexHotEntity.TopBlocksBean topBlock : topBlocks) {
                String id = topBlock.getId();
                String imgUrl = topBlock.getImgUrl();
                String title = topBlock.getTitle();
                String jumpId = topBlock.getJumpId();
                String jumpUrl = topBlock.getJumpUrl();
                String sportId = topBlock.getSportId();
                int jumpType = topBlock.getJumpType();
                HomeIndexBannerBean bannerBean = new HomeIndexBannerBean();
                bannerBean.setId(isNotNull(id));
                bannerBean.setTitle(isNotNull(title));
                bannerBean.setImgUrl(isNotNull(imgUrl));
                bannerBean.setJumpId(isNotNull(jumpId));
                bannerBean.setJumpUrl(isNotNull(jumpUrl));
                bannerBean.setJumpType(jumpType);
                int matchId = 0;
                int sportID = 0;
                try {
                    matchId = Integer.parseInt(jumpId);
                    sportID = Integer.parseInt(sportId);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                bannerBean.setMatchId(matchId);
                bannerBean.setSportId(sportID);
                mHomeIndexBannerBeanList.add(bannerBean);
            }
            mView.resultBannerSuccess(mHomeIndexBannerBeanList);
        } else {                                                   //banner为空
            mView.resultBannerFail(page);
        }
    }

    /**
     * 判断刷新 加载更多 和 正常加载
     */
    private void judgeStatusEmpty() {
        if (isRefresh) {
            isRefresh = false;
            mView.resultRefreshFail("刷新数据为空");
        } else if (isLoadMore) {
            isLoadMore = false;
            mView.resultRefreshFail("加载更多数据为空");
        } else {
            dataEmpty();
        }
    }

    /**
     * 判空
     *
     * @param s 目标串
     * @return 返回值
     */
    private String isNotNull(String s) {
        return !TextUtils.isEmpty(s) ? s : "";
    }

    /**
     * 数据为空
     */
    private void dataEmpty() {
        mView.resultFail(FailStateConstant.TYPE_EMPTY);
    }

    /**
     * 绑定View
     *
     * @param view 目标View
     */
    @Override
    public void attachView(InfoIndexHotContract.IInfoIndexHotView view) {
        this.mView = view;
    }

    /**
     * 解绑View
     */
    @Override
    public void detachView() {
        this.mView = null;
    }

    /**
     * 发送推送事件
     *
     * @param specialBeans
     */
    public void sendPush(IndexHotEntity.SpecialBlocksBean specialBeans) {
        //专栏接推送
        if (specialBeans != null) {
            //0: 专栏, 1: 赛事
            int type = specialBeans.getSpecialType();
            if (type == 1) {
                List<IndexHotEntity.SpecialBlocksBean.SpecialBlockVoBean> specialBlockVo = specialBeans.getSpecialBlockVo();
                if (specialBlockVo != null && specialBlockVo.size() != 0) {
                    for (IndexHotEntity.SpecialBlocksBean.SpecialBlockVoBean specialBlockVoBean : specialBlockVo) {
                        int specialType = specialBlockVoBean.getSpecialType();
                        String sportId = specialBlockVoBean.getSportId();
                        String matchId = specialBlockVoBean.getMatchId();

                        int sportIds = Integer.parseInt(!TextUtils.isEmpty(sportId) ? sportId : "0");
                        long matchIds = Long.parseLong(!TextUtils.isEmpty(matchId) ? matchId : "0");

                        //注册进球状态和比分的推送
                        //QttName.SCORE
                        ImPushParser.registerSingleMatch(sportIds, matchIds,
                                QttName.STATUS, InfoSpecialPushParams.RECEIPT_KEY_STATUS, getIdTag(ImPushParser.TYPE_STATUS, sportId, matchId));


                        if (sportIds == ImPushParser.SCORETYPE_FOOTBALL || sportIds == ImPushParser.SCORETYPE_BASKETBALL) {

                            ImPushParser.registerSingleMatch(sportIds, matchIds,
                                    QttName.SCORE, InfoSpecialPushParams.RECEIPT_KEY_SCORE, getIdTag(ImPushParser.TYPE_SCORE, sportId, matchId));

                        } else if (sportIds == ImPushParser.SCORETYPE_TENNISBALL) {

                            ImPushParser.registerSingleMatch(sportIds, matchIds,
                                    QttName.SCORE_TENNISBALL, InfoSpecialPushParams.RECEIPT_KEY_SCORE, getIdTag(ImPushParser.TYPE_SCORE, sportId, matchId));

                        } else if (sportIds == ImPushParser.SCORETYPE_BASEBALL) {

                            ImPushParser.registerSingleMatch(sportIds, matchIds,
                                    QttName.SCORE_BASEBALL, InfoSpecialPushParams.RECEIPT_KEY_SCORE, getIdTag(ImPushParser.TYPE_SCORE, sportId, matchId));
                        }
                    }
                }
            }
        }
    }

    /**
     * 测试发送推送的广播
     */
    public void testSendPush() {
        ImPushParser.registerSingleMatch(2, 1875264,
                QttName.STATUS, InfoSpecialPushParams.RECEIPT_KEY_STATUS, getIdTag(ImPushParser.TYPE_STATUS, 2 + "", String.valueOf(1875264)));

        ImPushParser.registerSingleMatch(2, 1875264,
                QttName.SCORE, InfoSpecialPushParams.RECEIPT_KEY_SCORE, getIdTag(ImPushParser.TYPE_SCORE, 2 + "", String.valueOf(1875264)));

        ImPushParser.registerSingleMatch(1, 1875784,
                QttName.SCORE, InfoSpecialPushParams.RECEIPT_KEY_SCORE, getIdTag(ImPushParser.TYPE_SCORE, 1 + "", 1875784 + ""));

        ImPushParser.registerSingleMatch(1, 1822371,
                QttName.SCORE, InfoSpecialPushParams.RECEIPT_KEY_SCORE, getIdTag(ImPushParser.TYPE_SCORE, 1 + "", 1822371 + ""));
    }

    private String getIdTag(int type, String sportId, String matchId) {
        return new StringBuffer(sportId).append(type).append(matchId).toString();
    }

    /**
     * 移除推送
     */
    public void unregisterPush(IndexHotEntity.SpecialBlocksBean mSpecialBlocksBean) {
        if (mSpecialBlocksBean != null && mSpecialBlocksBean.getSpecialType() == 1 && !CommondUtil.isEmpty(mSpecialBlocksBean.getSpecialBlockVo())) {
            for (IndexHotEntity.SpecialBlocksBean.SpecialBlockVoBean bean : mSpecialBlocksBean.getSpecialBlockVo()) {
                ImPushParser.resetSingleMatch(getIdTag(ImPushParser.TYPE_STATUS, bean.getSportId(), bean.getMatchId()));
                ImPushParser.resetSingleMatch(getIdTag(ImPushParser.TYPE_SCORE, bean.getSportId(), bean.getMatchId()));
            }
        }

    }


    public String changeTimePlay(int matchTime,long timePlayed) {
        try {
            long minute = 0;
            String statusString;
            if (timePlayed == 0) {
                long interval = System.currentTimeMillis();
                minute = (int) ((interval - matchTime) / 60000);
            } else {
                minute = timePlayed / 60;
            }

            statusString = String.valueOf(minute);
            return statusString;

        }catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }


}
