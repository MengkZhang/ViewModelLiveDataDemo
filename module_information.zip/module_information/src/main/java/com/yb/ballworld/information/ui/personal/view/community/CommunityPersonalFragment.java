package com.yb.ballworld.information.ui.personal.view.community;

import android.text.TextUtils;
import android.util.Log;
import android.view.View;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.viewpager.widget.ViewPager;

import com.alibaba.android.arouter.launcher.ARouter;
import com.bfw.util.ToastUtils;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.constant.Constant;
import com.yb.ballworld.baselib.core.RouterHub;
import com.yb.ballworld.baselib.data.UserInfo;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.baselib.widget.tab.XTabLayout;
import com.yb.ballworld.common.base.BaseFragmentAdapter;
import com.yb.ballworld.common.base.mvp.BaseMvpFragment;
import com.yb.ballworld.common.baseapp.AppContext;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.utils.ScreenUtils;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.community.CommunityHttpApi;
import com.yb.ballworld.information.ui.community.bean.Topic;
import com.yb.ballworld.information.ui.community.data.CommunityPost;
import com.yb.ballworld.information.ui.community.view.CommunityNewActivity;
import com.yb.ballworld.information.ui.personal.adapter.UserSpacePagerAdapter;
import com.yb.ballworld.information.ui.personal.bean.PersonalInfo;

import java.util.Arrays;
import java.util.List;
/**
 * Desc: 个人空间-社区
 * Author: JS-Kylo
 * Created On: 2019/11/9 14:11
 */
public class CommunityPersonalFragment extends BaseMvpFragment {
    private XTabLayout xTabLayout;
    private UserSpacePagerAdapter adapter;
    private ViewPager viewPager;
    private PersonalInfo personalInfo;
    private BaseFragmentAdapter fragmentAdapter;
    private List<String> titles;


    public static CommunityPersonalFragment newInstance(PersonalInfo personalInfo) {
        CommunityPersonalFragment fragment = new CommunityPersonalFragment();
        fragment.personalInfo = personalInfo;
        return fragment;
    }

    @Override
    public void initPresenter() {

    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_user_community_layout;
    }

    @Override
    protected void initView() {
        xTabLayout = findView(R.id.xTab);
        viewPager = findView(R.id.viewPager);
        float width = 0;
        if (isMySelf()) {
            width = ScreenUtils.getScreenWidth(AppContext.getAppContext()) / 4;
        } else {
            width = ScreenUtils.getScreenWidth(AppContext.getAppContext()) / 2;
        }
        xTabLayout.setIndicatorWidthNoChange(width);
        xTabLayout.setTabWidthNoChange(width);
        findView(R.id.iv_community_new).setOnClickListener(this);
        initTabView();
    }

    private void initTabView() {
        titles = getTabTitles();
        List<Fragment> fragments = getTabFragments();
        if (isNotEmpty(titles) && isNotEmpty(fragments) && titles.size() == fragments.size()) {

            fragmentAdapter = new BaseFragmentAdapter(getChildFragmentManager(), fragments, titles);
            viewPager.setAdapter(fragmentAdapter);
            viewPager.setOffscreenPageLimit(fragments.size());
            viewPager.setCurrentItem(0);
            viewPager.setOffscreenPageLimit(fragmentAdapter.getCount());

//            float tabWidth = DisplayUtil.getScreenWidth(getActivity()) * 1.0f / titles.size();
//            xTabLayout.setTabWidth(tabWidth);
            xTabLayout.setViewPager(viewPager, (String[]) titles.toArray());
            xTabLayout.setGradientIndicatorDrawable1();
        }
    }

    @Override
    protected void bindEvent() {
        eventIfIsMySelfRefreshTabPublishTie();
        eventIfIsMySelfRefreshTabCollectOrCancel();
        eventIfIsMySelfRefreshTabPublishComment();
    }

    /**
     * 接受回帖消息
     */
    private void eventIfIsMySelfRefreshTabPublishComment() {
        LiveEventBus.get().with(LiveEventBusKey.KEY_TOPIC_PUBLIC_COMMENT, Topic.class).observe(this, new Observer<Topic>() {
            @Override
            public void onChanged(Topic topic) {
                if (topic != null) {

                    if (isSelf()) {

                        if (fragmentAdapter != null) {

                            titles = getRefreshTabTitlesReturnTieNum();
                            if (xTabLayout != null && viewPager != null) {
                                xTabLayout.setViewPager(viewPager,(String[]) titles.toArray());
                            }
                            fragmentAdapter.notifyDataSetChanged();
                        }

                    }

                }
            }
        });
    }

    /**
     * 接受消息 如果是自己 刷新收藏或者取消收藏 数量加1或减1
     */
    private void eventIfIsMySelfRefreshTabCollectOrCancel() {
        //接受收藏事件
        LiveEventBus.get().with(LiveEventBusKey.KEY_TOPIC_COLLECT,String.class).observe(this, eventId -> {
            if (!TextUtils.isEmpty(eventId)) {

                if (isSelf()) {

                    if (fragmentAdapter != null) {
                        titles = getRefreshTabTitlesCollectNum(true);
                        if (xTabLayout != null && viewPager != null) {
                            xTabLayout.setViewPager(viewPager,(String[]) titles.toArray());
                        }
                        fragmentAdapter.notifyDataSetChanged();
                    }

                }

            }
        });

        //接收取消收藏事件
        LiveEventBus.get().with(LiveEventBusKey.KEY_TOPIC_REMOVE_COLLECT,String.class).observe(this, eventId -> {
            if (!TextUtils.isEmpty(eventId)) {

                if (isSelf()) {

                    if (fragmentAdapter != null) {
                        titles = getRefreshTabTitlesCollectNum(false);
                        if (xTabLayout != null && viewPager != null) {
                            xTabLayout.setViewPager(viewPager,(String[]) titles.toArray());
                        }
                        fragmentAdapter.notifyDataSetChanged();
                    }

                }

            }
        });

    }

    /**
     * 如果是自己 刷新社区tab
     */
    private void eventIfIsMySelfRefreshTabPublishTie() {
        // 是自己的时候才 刷新头部tab数据 测试数据 需要在发布成功后定义该广播事件
        LiveEventBus.get().with(LiveEventBusKey.KEY_AUTHOR_REPLAY_TIE,CommunityPost.class).observe(this, postBean -> {
            LogUtils.INSTANCE.e("===z","接收发帖数据");
            if (postBean != null) {
                //判断是否是自己
                if (isSelf()) {

                    //刷新社区tab
                    if (fragmentAdapter != null) {
                        //2019/11/12 数量+1
                        titles = getRefreshTabTitles();
                        if (xTabLayout != null && viewPager != null) {
                            xTabLayout.setViewPager(viewPager,(String[]) titles.toArray());
                        }
                        fragmentAdapter.notifyDataSetChanged();
                    }

                }
            }
        });
    }

    @Override
    protected void initData() {

    }

    @Override
    protected void processClick(View view) {
        if (view.getId()==R.id.iv_community_new){
            UserInfo userInfo = LoginOrdinaryUtils.INSTANCE.getUserInfo();
            if (userInfo == null) {
                toLogin();
                return;
            }
           // CommunityNewActivity.start(getContext());
            judgeUserState();
        }

    }

    /**
     * 刷新tab发帖数
     * @return
     */
    private List<String> getRefreshTabTitles() {
        if (personalInfo == null) {
           // return add("发帖", "回帖");
            return add("发帖", "回帖","收藏","足迹");
        }

        int count = personalInfo.getPostCount() + 1;
        personalInfo.setPostCount(count);

        if (isMySelf()) {
            return add("发帖(" + count + ")", "回帖(" + personalInfo.getCommentCount() + ")", "收藏(" + personalInfo.getFavoriteCount() + ")", "足迹(" + personalInfo.getFootprintCount() + ")");
        }

        return add("发帖(" + count + ")", "回帖(" + personalInfo.getCommentCount() + ")");

    }

    /**
     * 刷新tab回帖数
     * @return
     */
    private List<String> getRefreshTabTitlesReturnTieNum() {
        if (personalInfo == null) {
            //return add("发帖", "回帖");
            return add("发帖", "回帖","收藏","足迹");
        }

        int count = personalInfo.getCommentCount();
        count++;

        personalInfo.setCommentCount(count);

        if (isMySelf()) {
            return add("发帖(" + count + ")", "回帖(" + personalInfo.getCommentCount() + ")", "收藏(" + personalInfo.getFavoriteCount() + ")", "足迹(" + personalInfo.getFootprintCount() + ")");
        }

        return add("发帖(" + count + ")", "回帖(" + personalInfo.getCommentCount() + ")");

    }

    /**
     * 刷新tab收藏数
     * @return
     */
    private List<String> getRefreshTabTitlesCollectNum(boolean isCollect) {
        if (personalInfo == null) {
            //return add("发帖", "回帖");
            return add("发帖", "回帖","收藏","足迹");
        }

        int count = personalInfo.getFavoriteCount();

        if (isCollect) {//收藏
            count++;
        } else {        //取消收藏
            count--;
        }

        personalInfo.setFavoriteCount(count);

        if (isMySelf()) {
            return add("发帖(" + count + ")", "回帖(" + personalInfo.getCommentCount() + ")", "收藏(" + personalInfo.getFavoriteCount() + ")", "足迹(" + personalInfo.getFootprintCount() + ")");
        }

        return add("发帖(" + count + ")", "回帖(" + personalInfo.getCommentCount() + ")");

    }


    protected List<String> getTabTitles() {
        if (personalInfo == null) {
            //return add("发帖", "回帖");
            return add("发帖", "回帖","收藏","足迹");
        } else {
            if (isMySelf())
                return add("发帖(" + personalInfo.getPostCount() + ")", "回帖(" + personalInfo.getCommentCount() + ")", "收藏(" + personalInfo.getFavoriteCount() + ")", "足迹(" + personalInfo.getFootprintCount() + ")");
            else
                return add("发帖(" + personalInfo.getPostCount() + ")", "回帖(" + personalInfo.getCommentCount() + ")");
        }
    }

    private List<Fragment> getTabFragments() {
        //personalInfo.setId("999");
        if (isMySelf())
            return add(
                    PersonalPostReleaseFragment.newInstance(getUserId()),
                    PersonalPostReplyFragment.newInstance(getUserId()),
                    PersonalPostCollectionFragment.newInstance(getUserId()),
                    PersonalPostHistoryFragment.newInstance(getUserId())
            );
        else
            return add(
                    PersonalPostReleaseFragment.newInstance(getUserId()),
                    PersonalPostReplyFragment.newInstance(getUserId())
            );
    }


    /**
     * 判断是否是自己
     * @return
     *   todo 暂时开放所有
     */
    private boolean isMySelf() {
        /*if (personalInfo != null) {
            String id = personalInfo.getId();
            return String.valueOf(LoginOrdinaryUtils.INSTANCE.getUid()).equals(id);
        }
        return false;*/
        return true;
    }

    /**
     * 判断是否是自己
     * 动态刷新数据用
     * @return
     */
    private boolean isSelf() {
        if (personalInfo != null) {
            String id = personalInfo.getId();
            return String.valueOf(LoginOrdinaryUtils.INSTANCE.getUid()).equals(id);
        }
        return false;
    }
    private void judgeUserState() {
        new CommunityHttpApi().judgeUserFreeze(new LifecycleCallback<Boolean>(getActivity()) {
            @Override
            public void onSuccess(Boolean data) {
                if (!data) {
                    CommunityNewActivity.start(getContext());
                } else {
                    ToastUtils.showToast("用户已冻结");
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {

            }
        });
    }

    private int getUserId(){
        if (null == personalInfo)
            return -1;
        else if (TextUtils.isEmpty(personalInfo.getId()))
            return -1;
        try {
            return Integer.valueOf(personalInfo.getId());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
    /**
     * 跳转到登陆界面
     */
    private void toLogin() {
        ARouter.getInstance().build(RouterHub.USER_LOGIN_REGISTER_ACTIVITY)
                .navigation(getActivity(), Constant.COMMON_LOGIN_REQUEST);
    }

    private boolean isNotEmpty(List<?> list) {
        return list != null && !list.isEmpty();
    }

    private <T> List<T> add(T... t) {
        return Arrays.asList(t);
    }
}
