package com.yb.ballworld.information.ui.home.utils;

import android.text.InputFilter;
import android.text.Spanned;
import android.view.KeyEvent;
import android.widget.EditText;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import kotlin.text.Regex;

/**
 * Desc EditText相关限制的帮助类
 * Date 2019/11/22
 * author mengk
 */
public class EditTextLimitUtil {

    /**
     * EditText添加监听Enter事件
     * @param editText
     */
    public static void setEditTextLimitEnter(EditText editText) {
        editText.setOnKeyListener((v, keyCode, event) -> {
            if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN) {
                //d点击回车 没效果
                return true;
            }
            //记得返回false
            return false;
        });
    }


    /**
     * 禁止EditText输入空格和换行符
     *
     * @param editText EditText输入框
     */
    public static void setEditTextInputSpace(EditText editText) {
        try {
            InputFilter filter = (source, start, end, dest, dstart, dend) -> {
                if (source.equals(" ") || source.toString().contentEquals("\n")) {
                    return "";
                } else {
                    return null;
                }
            };
            editText.setFilters(new InputFilter[]{filter});

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 禁止EditText输入特殊字符
     *
     * @param editText EditText输入框
     */
    public static void setEditTextInputSpeChat(EditText editText) {
        try {
            InputFilter filter = (source, start, end, dest, dstart, dend) -> {
                //("[`~!@#$^&*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？]$");
                //!':;',.?！‘；：”“'。，、？
//                String speChat = "[\\u4e00-\\u9fa5a-zA-Z0-9]";
                String speChat = "[\\u4e00-\\u9fa5a-zA-Z0-9]";
                Pattern pattern = Pattern.compile(speChat);
                Matcher matcher = pattern.matcher(source.toString());
                if (!matcher.find()) {
                    return "";
                } else {
                    return null;
                }
            };
            editText.setFilters(new InputFilter[]{filter});

        } catch (Exception e) {
            e.printStackTrace();
        }
    }




}
