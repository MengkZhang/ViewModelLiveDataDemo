package com.yb.ballworld.information.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatImageView;

/**
 * Desc: 暂时添加后面再固定
 * @author ink
 * created at 2019/10/20 13:31
 */
public class RoundedImageView extends AppCompatImageView {
    private float mRadiusX,mRadiusY;
    private Path mRoundedRectPath;
    private RectF mRectF;

    public RoundedImageView(Context context) {
        super(context);
        init(context);
    }

    public RoundedImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public RoundedImageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        float density = context.getResources().getDisplayMetrics().density;
        mRadiusX=mRadiusY = 4.0f * density;
        mRoundedRectPath = new Path();
        mRectF = new RectF();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        mRectF.set(0.0f, 0.0f, getMeasuredWidth(), getMeasuredHeight());
        mRoundedRectPath.addRoundRect(mRectF, mRadiusX, mRadiusY, Path.Direction.CW);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.clipPath(mRoundedRectPath);
        super.onDraw(canvas);
    }

    public float getmRadiusX() {
        return mRadiusX;
    }

    public void setmRadiusX(float mRadiusX) {
        this.mRadiusX = mRadiusX;
    }

    public float getmRadiusY() {
        return mRadiusY;
    }

    public void setmRadiusY(float mRadiusY) {
        this.mRadiusY = mRadiusY;
    }
}
