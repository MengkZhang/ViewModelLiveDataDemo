package com.yb.ballworld.information.ui.profile.view;

import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.widget.TextView;

import com.jeremyliao.liveeventbus.LiveEventBus;
import com.yb.ballworld.baselib.utils.ImageManager;
import com.yb.ballworld.common.base.BaseFragment;
import com.yb.ballworld.common.livedata.LiveDataObserver;
import com.yb.ballworld.common.widget.MultTextView;
import com.yb.ballworld.common.widget.STRoundImageView;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.personal.view.InfoDynamicFragment;
import com.yb.ballworld.information.ui.profile.data.ClubBasicsInfoBean;
import com.yb.ballworld.information.ui.profile.data.ClubTeamSeasonIdBean;
import com.yb.ballworld.information.ui.profile.presenter.ProfileClubPresenter;
import com.yb.ballworld.information.ui.profile.view.fragments.ClubDatumFragment;
import com.yb.ballworld.information.ui.profile.view.fragments.MomentsFragment;
import com.yb.ballworld.information.ui.profile.view.fragments.PlayerFragment;
import com.yb.ballworld.information.ui.profile.view.fragments.RaceFragment;

import java.util.ArrayList;
import java.util.List;

/**
 * 俱乐部资料库
 * @author Gethin
 * @time 2019/11/7 17:36
 */

public class ProfileClubActivity extends ProfileBaseActivity<ProfileClubPresenter> {

    public static final String KEY_DISPATCH_CLUB_BASICS_INFO_EVENT = "KEY_DISPATCH_CLUB_BASICS_INF0_EVENT";

    private STRoundImageView ivClubLogo;
    private TextView tvClubName;
    private MultTextView mtTitle;
    private MultTextView mtClubBrief;
    private String teamId;
    private String seasonId;
    private String cnAlias;

    public static void launch(Context context, String teamId, String seasonId) {
        Intent intent = new Intent(context, ProfileClubActivity.class);
        intent.putExtra("teamId", teamId);
        intent.putExtra("seasonId", seasonId);
        context.startActivity(intent);
    }

    @Override
    protected int getHeaderLayoutId() {
        return R.layout.activity_profile_club;
    }

    @Override
    protected String[] getTitles() {
        return new String[]{"动态", "球员", "赛程", "资料"};
    }

    @Override
    protected List<BaseFragment> getFragments() {
        List<BaseFragment> list = new ArrayList<>();
        list.add(InfoDynamicFragment.newInstance(TextUtils.isEmpty(cnAlias) ? "" :cnAlias ));
        list.add(PlayerFragment.newInstance(teamId, seasonId));
        list.add(RaceFragment.newInstance(teamId, seasonId));
        list.add(new ClubDatumFragment());
        return list;
    }

    @Override
    protected void initView() {
        super.initView();
        ivClubLogo = findViewById(R.id.ivClubLogo);
        tvClubName = findViewById(R.id.tvClubName);
        mtTitle = findViewById(R.id.mtTitle);
        mtClubBrief = findViewById(R.id.mtClubBrief);
    }

    private void refreshUI(ClubBasicsInfoBean data) {
        loadDataFinish();
        mtTitle.setTexts("当前联赛排名", "当前联赛战绩", "最近六场");
        ClubBasicsInfoBean.TeamBean team = data.getTeam();
        ClubBasicsInfoBean.TeamRankBean teamRank = data.getTeamRank();
        if (team != null) {
            tvClubName.setText(team.getCnName());
        }
        if (teamRank != null) {
            ImageManager.INSTANCE.loadLogo(teamRank.getLogo(), ivClubLogo);
            int win = teamRank.getWin();
            int draw = teamRank.getDraw();
            int lost = teamRank.getLost();
            mtClubBrief.setTexts(""+teamRank.getTeamRank(), win + "胜" + draw + "平" + lost + "负", data.getRecentRecords());
        }
    }

    @Override
    protected void bindEvent() {
        super.bindEvent();
        // 球队赛季列表
        mPresenter.clubTeamSeasonId.observe(this, new LiveDataObserver<ClubTeamSeasonIdBean>() {
            @Override
            public void onSuccess(ClubTeamSeasonIdBean data) {
                hidePageLoading();
                if (data != null) {
                    teamId = data.getTeamId();
                    seasonId = data.getSeasonId();
                } else {
                    showPageError("");
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                hidePageLoading();
                showPageError("");
            }
        });
        // 球队基础信息
        mPresenter.clubBasicsInfoBean.observe(this, new LiveDataObserver<ClubBasicsInfoBean>() {
            @Override
            public void onSuccess(ClubBasicsInfoBean data) {
                hidePageLoading();
                if (data != null) {
                    ClubBasicsInfoBean.TeamBean team = data.getTeam();
                    if (team != null) {
                        cnAlias = team.getCnAlias();
                    }
                    showPageContent();
                    // 刷新UI
                     refreshUI(data);
                    // 将数据发送到俱乐部资料子页
                    LiveEventBus.get().with(KEY_DISPATCH_CLUB_BASICS_INFO_EVENT, ClubBasicsInfoBean.class).post(data);
                } else {
                    showPageEmpty("");
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                hidePageLoading();
                showPageError("");
            }
        });
    }

    @Override
    protected void initData() {
        Intent intent = getIntent();
        if (intent != null) {
            teamId = intent.getStringExtra("teamId");
            seasonId = intent.getStringExtra("seasonId");
        }
        super.initData();
    }

    @Override
    protected void loadData() {
        showPageLoading();
        mPresenter.loadClubTeamSeasonId(teamId);
    }

    @Override
    public void initPresenter() {
        mPresenter.setVM(this);
    }
}
