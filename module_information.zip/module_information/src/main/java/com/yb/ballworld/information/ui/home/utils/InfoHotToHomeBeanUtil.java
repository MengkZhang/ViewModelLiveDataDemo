package com.yb.ballworld.information.ui.home.utils;

import android.util.Log;

import com.yb.ballworld.baselib.utils.JsonUtils;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.information.ui.home.bean.IndexHotEntity;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc 置顶数据转列表数据帮助类
 * Date 2019/11/16
 * author mengk
 */
public class InfoHotToHomeBeanUtil {
    /**
     *
     * @param newsTopBlocks 源list
     */
    public static List<IndexHotEntity.NewsBean.ListBean> infoHotToHomeList(List<IndexHotEntity.NewsTopBlocksBean> newsTopBlocks) {

        if (newsTopBlocks != null && newsTopBlocks.size() != 0) {

            List<IndexHotEntity.NewsBean.ListBean> homeList = new ArrayList<>();

            for (IndexHotEntity.NewsTopBlocksBean topListBean : newsTopBlocks) {

                String json = JsonUtils.INSTANCE.toJson(topListBean);
                LogUtils.INSTANCE.e("=====z"," top json = " + json);
                IndexHotEntity.NewsBean.ListBean homeListBean = JsonUtils.INSTANCE.fromJson(json, IndexHotEntity.NewsBean.ListBean.class);

                homeListBean.setId(topListBean.getNewsId());
                homeListBean.setTop(true);
                String toJson = JsonUtils.INSTANCE.toJson(homeListBean);
                LogUtils.INSTANCE.e("=====z"," home json = " + toJson);

                homeList.add(homeListBean);

            }

            return homeList;

        }

        return null;
    }
}
