package com.yb.ballworld.information.ui.home.constant;

import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Desc
 * Date 2019/10/7
 * author mengk
 */
@IntDef({
        LengthLimit.LENGTH_LIMIT
})

@Retention(RetentionPolicy.SOURCE)

public @interface LengthLimit {
    //加载错误
    int LENGTH_LIMIT = 5000;
}


