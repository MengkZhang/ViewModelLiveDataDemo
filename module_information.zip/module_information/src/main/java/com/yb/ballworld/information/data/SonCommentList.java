package com.yb.ballworld.information.data;

import java.util.List;

public class SonCommentList {
    private CommitBean parent;
    private CommitBeanList sonComments;

    public CommitBean getParent() {
        return parent;
    }

    public void setParent(CommitBean parent) {
        this.parent = parent;
    }

    public CommitBeanList getSonComments() {
        return sonComments;
    }

    public void setSonComments(CommitBeanList sonComments) {
        this.sonComments = sonComments;
    }
}
