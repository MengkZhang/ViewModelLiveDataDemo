package com.yb.ballworld.information.ui.detail;

import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;

import java.util.ArrayList;
import java.util.List;

public class DetailActivityManager implements DefaultLifecycleObserver {
    private static final int SIZE = 2;
    List<LifecycleOwner> lifecycleOwnerList = new ArrayList<>();

    @Override
    public void onCreate(LifecycleOwner owner) {
        if (lifecycleOwnerList.size() > SIZE) {
            LifecycleOwner tempOwner=  lifecycleOwnerList.remove(0);

        }
        lifecycleOwnerList.add(owner);
    }

    @Override
    public void onStart(LifecycleOwner owner) {

    }

    @Override
    public void onResume(LifecycleOwner owner) {

    }

    @Override
    public void onPause(LifecycleOwner owner) {

    }

    @Override
    public void onStop(LifecycleOwner owner) {

    }

    @Override
    public void onDestroy(LifecycleOwner owner) {
        lifecycleOwnerList.remove(owner);
    }
}
