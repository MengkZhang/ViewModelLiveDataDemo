package com.yb.ballworld.information.ui.home.bean;

import java.io.File;

/**
 * Desc
 * Date 2019/10/23
 * author mengk
 */
public class VideoFileUploadBean {
    private File videoCoverFile;
    private File videoFile;

    public File getVideoCoverFile() {
        return videoCoverFile;
    }

    public void setVideoCoverFile(File videoCoverFile) {
        this.videoCoverFile = videoCoverFile;
    }

    public File getVideoFile() {
        return videoFile;
    }

    public void setVideoFile(File videoFile) {
        this.videoFile = videoFile;
    }
}
