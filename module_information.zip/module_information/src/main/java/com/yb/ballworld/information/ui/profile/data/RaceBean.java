//package com.yb.ballworld.information.ui.profile.data;
//
//import com.chad.library.adapter.base.entity.MultiItemEntity;
//
///**
// * @author Gethin
// * @time 2019/11/9 10:15
// */
//
//public class RaceBean implements MultiItemEntity {
//
//    public static final int HEADER = 1;
//    public static final int CONTENT = 2;
//
//    public static final int CONTENT_START = 1;
//    public static final int CONTENT_END = 2;
//
//    private int contentPos;
//    private int itemType = CONTENT;
//
//    public int getContentPos() {
//        return contentPos;
//    }
//
//    public void setContentPos(int contentPos) {
//        this.contentPos = contentPos;
//    }
//
//    public void setItemType(int itemType) {
//        this.itemType = itemType;
//    }
//
//    @Override
//    public int getItemType() {
//        return itemType;
//    }
//}
