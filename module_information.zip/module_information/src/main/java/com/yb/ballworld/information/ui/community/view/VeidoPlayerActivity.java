package com.yb.ballworld.information.ui.community.view;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.view.View;

import androidx.annotation.ColorRes;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.gyf.immersionbar.ImmersionBar;
import com.yb.ballworld.common.base.mvp.BaseMvpActivity;
import com.yb.ballworld.common.widget.CommonTitleBar;
import com.yb.ballworld.information.R;

import cn.jzvd.Jzvd;
import cn.jzvd.JzvdStd;

public class VeidoPlayerActivity extends BaseMvpActivity {
    private CommonTitleBar commonTitleBar;
    JzvdStd jzvdStd;

    public static void  start(Activity context, String videoUrl,String imageUrl){
        Intent intent=new Intent(context,VeidoPlayerActivity.class);
        intent.putExtra("url",videoUrl);
        intent.putExtra("imageUrl",imageUrl);
        context.startActivity(intent);
        context.overridePendingTransition(0,0);
    }

    /**
     * 获取StatusBar颜色，默认白色
     *
     * @return
     */
    protected @ColorRes
    int getStatusBarColor() {
        return com.yb.ballworld.baselib.R.color.black;
    }

    /**
     * 初始化沉浸式
     */
    protected void initImmersionBar() {
        // 设置共同沉浸式样式
        ImmersionBar.with(this)
                .statusBarDarkFont(false)
                .statusBarColor(getStatusBarColor())
                .navigationBarColor(getNavigationBarColor())
                .init();
    }

    @Override
    public void initPresenter() {

    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_videio_player_layout;
    }

    @Override
    protected void initView() {
        commonTitleBar=findViewById(R.id.commonTitleBar);
        jzvdStd = findViewById(R.id.item_comment_video);
    }

    @Override
    protected void bindEvent() {
        commonTitleBar.setListener(new CommonTitleBar.OnTitleBarListener() {
            @Override
            public void onClicked(View v, int action, String extra) {
                if (action == CommonTitleBar.ACTION_LEFT_BUTTON) {
                    finish();
                }
            }
        });
    }

    @Override
    protected void initData() {
        String url=getIntent().getStringExtra("url");
        String imageUrl=getIntent().getStringExtra("imageUrl");
        if(TextUtils.isEmpty(url)){
            showToastMsgShort("未找到视频");
        }else{
            jzvdStd.setUp(url, "", JzvdStd.SCREEN_NORMAL);
            if(!TextUtils.isEmpty(imageUrl)){
                Glide.with(this).load(imageUrl).into(jzvdStd.thumbImageView);
            }else{
                Glide.with(this).setDefaultRequestOptions(new RequestOptions()
                        .frame(1).centerCrop()).load(url)
                        .into(jzvdStd.thumbImageView);
            }
            jzvdStd.startVideo();
        }

    }

    @Override
    protected void processClick(View view) {

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Jzvd.releaseAllVideos();
    }
}
