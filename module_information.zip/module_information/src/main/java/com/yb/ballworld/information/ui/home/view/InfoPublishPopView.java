package com.yb.ballworld.information.ui.home.view;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;

import com.scwang.smartrefresh.layout.util.DensityUtil;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.home.widget.bfpop.BFPopupWindow;
import com.yb.ballworld.information.ui.personal.view.InfoAuditActivity;

/**
 * Desc 自定义资讯发布视频和图文的Popuwindow
 * Date 2019/11/18
 * author mengk
 */
public class InfoPublishPopView implements View.OnClickListener {

    private final View contentView;
    private BFPopupWindow mPopupWindow;
    private Activity context;
    private String userId;

    public InfoPublishPopView(Activity context,String userId) {
        this.context = context;
        this.userId=userId;
        if(this.userId==null){
            this.userId="";
        }
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        contentView = inflater.inflate(R.layout.pop_view_info_publish, null);
        contentView.findViewById(R.id.rl_publish_article).setOnClickListener(v -> {//发文章
            NavigateToDetailUtil.navigateToPublish(context, false);
            dismissPop();
        });
        contentView.findViewById(R.id.rl_publish_av).setOnClickListener(v -> {//发视频
            NavigateToDetailUtil.navigateToPublish(context, true);
            dismissPop();
        });
        contentView.findViewById(R.id.rl_publish_no_check).setOnClickListener(v -> {
            InfoAuditActivity.start(context,InfoPublishPopView.this.userId);
            dismissPop();
        });

    }

    public View showPop(View anchorView) {
        if (mPopupWindow == null) {
            mPopupWindow = new BFPopupWindow(context,
                    DensityUtil.dp2px(136), DensityUtil.dp2px(152)
            );
            mPopupWindow.setView(contentView, anchorView);
        }
        mPopupWindow.show();
        return contentView;
    }

    private void dismissPop() {
        if (mPopupWindow != null) {
            mPopupWindow.dismiss();
        }
    }

    @Override
    public void onClick(View v) {

    }
}
