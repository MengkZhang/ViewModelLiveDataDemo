package com.yb.ballworld.information.ui.home.utils;

import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;

/**
 * Desc
 * Date 2019/10/11
 * author mengk
 */
public class UidUtil {
    public static String getUid() {
        long uid = LoginOrdinaryUtils.INSTANCE.getUid();
        return uid + "";
    }
}
