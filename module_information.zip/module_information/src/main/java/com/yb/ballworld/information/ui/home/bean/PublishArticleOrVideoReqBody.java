package com.yb.ballworld.information.ui.home.bean;

import java.util.ArrayList;

/**
 * Desc
 * Date 2019/11/19
 * author mengk
 * 	"categoryId": 0,
 * 	"content": "",
 * 	"imgUrl": "",
 * 	"keywords": "",
 * 	"labels": "",
 * 	"mediaType": 0,
 * 	"pageViews": 0,
 * 	"playUrl": "",
 * 	"preview": "",
 * 	"releaseSource": "",
 * 	"sportType": 0,
 * 	"title": "",
 * 	"userId": 0
 */
public class PublishArticleOrVideoReqBody {
    private String categoryId;
    private String content;
    private String imgUrl;
    private String keywords;
    private ArrayList<IndexLableLetterBean> labels;
    private String mediaType;
    private String pageViews;
    private String playUrl;
    private String preview;
    private String releaseSource;
    private String sportType;
    private String title;
    private String userId;

    public PublishArticleOrVideoReqBody() {
    }


    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public ArrayList<IndexLableLetterBean> getLabels() {
        return labels;
    }

    public void setLabels(ArrayList<IndexLableLetterBean> labels) {
        this.labels = labels;
    }

    public String getMediaType() {
        return mediaType;
    }

    public void setMediaType(String mediaType) {
        this.mediaType = mediaType;
    }

    public String getPageViews() {
        return pageViews;
    }

    public void setPageViews(String pageViews) {
        this.pageViews = pageViews;
    }

    public String getPlayUrl() {
        return playUrl;
    }

    public void setPlayUrl(String playUrl) {
        this.playUrl = playUrl;
    }

    public String getPreview() {
        return preview;
    }

    public void setPreview(String preview) {
        this.preview = preview;
    }

    public String getReleaseSource() {
        return releaseSource;
    }

    public void setReleaseSource(String releaseSource) {
        this.releaseSource = releaseSource;
    }

    public String getSportType() {
        return sportType;
    }

    public void setSportType(String sportType) {
        this.sportType = sportType;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
