package com.yb.ballworld.information.ui.home.view;

import android.content.Intent;
import android.text.Editable;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ScrollView;

import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;

import com.bfw.util.ToastUtils;
import com.yb.ballworld.baselib.widget.chat.EmojiLayout;
import com.yb.ballworld.baselib.widget.dialog.MaterialLoadingDialog;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.bean.IndexLableLetterBean;
import com.yb.ballworld.information.ui.home.bean.InfoPublishCategoryBean;
import com.yb.ballworld.information.ui.home.bean.PublishVideoDataBean;
import com.yb.ballworld.information.ui.home.constant.MediaReqCodeType;
import com.yb.ballworld.information.ui.home.listener.OnMultiClickListener;
import com.yb.ballworld.information.ui.home.presenter.PublishVideoPresenter;
import com.yb.ballworld.information.ui.home.utils.GlideLoadImgUtil;
import com.yb.ballworld.information.ui.home.utils.JZReleaseUtil;
import com.yb.ballworld.information.ui.home.widget.DeleteImgDialog;

import java.util.ArrayList;

import cn.jzvd.Jzvd;
import cn.jzvd.JzvdStd;

/**
 * Desc 发布视频activity 继承公共发布页
 * Date 2019/11/11
 * author mengk
 */
public class PublishVideoActivity extends PublishBaseActivity<PublishVideoPresenter> {

    private CardView cvVideo;
    private ImageView ivClose;
    private JzvdStd player;
    private EditText etInput;
    //本地视频的path
    private String videoPath;
    //本地视频的uri
    private String videoUri;
    //重写dialog的方法 为了解决上传过程中取消 再次点击上传不显示dialog的bug
    private AlertDialog mLoadingDialog = null;

    public void showDialogLoading() {
        showDialogLoading(getString(com.yb.ballworld.baselib.R.string.app_loading));
    }

    public void showDialogLoading(String msg) {
        if (mLoadingDialog != null && mLoadingDialog.isShowing()) return;
        if (mLoadingDialog == null) {
            mLoadingDialog = new MaterialLoadingDialog.Builder(this).show(msg);
        } else {
            mLoadingDialog.show();
        }
    }

    public void hideDialogLoading() {
        if (mLoadingDialog == null) return;
        if (mLoadingDialog.isShowing()) {
            mLoadingDialog.dismiss();
        }
    }

    @Override
    public int getContentLayoutId() {
        return R.layout.activity_publish_video;
    }

    @Override
    public void setIconChoice(ImageView ivChoice) {
        ivChoice.setImageResource(R.drawable.icon_info_publish_video);
    }

    @Override
    protected void setEmojiLayout(EmojiLayout mEmojiLayout) {
        //判断标题是否获取了焦点  标题获取了焦点 不能点击表情
        EditText titleEditText = getTitleEditText();

        mEmojiLayout.setOnEmojiClickListener(s -> {
            //判断标题是否获取了焦点
            if (!titleEditText.hasFocus()) {//内容输入表情
                int selectionStart = etInput.getSelectionStart();
                Editable editableText = etInput.getEditableText();
                if (editableText != null) {
                    editableText.insert(selectionStart, s);
                }
                return null;

            } else {//标题输入表情
                int selectionStart = titleEditText.getSelectionStart();
                Editable editableText = titleEditText.getEditableText();
                if (editableText != null) {
                    editableText.insert(selectionStart, s);
                }
                return null;
            }
        });
    }

    @Override
    public void initViews() {
        ivClose = F(R.id.image_close_av);
        cvVideo = F(R.id.cv_publish_video);
        player = F(R.id.player_av_info_pub);
        etInput = F(R.id.et_input_av_content);
        getDatasFromCache();
    }


    private void getDatasFromCache() {
        PublishVideoDataBean videoFromCache = mPresenter.getVideoFromCache();
        if (videoFromCache == null) return;

        setJzPlayer(videoFromCache.getUri(), videoFromCache.getPath());

        etInput.setText(videoFromCache.getContent());

    }

    private void ifShowVideoView(boolean isShow) {
        if (isShow) {
            cvVideo.setVisibility(View.VISIBLE);
        } else {
            cvVideo.setVisibility(View.GONE);
        }
    }

    private void setJzPlayer(String uri, String path) {
        //显示并播放
        if (!TextUtils.isEmpty(path) && uri != null) {
            ifShowVideoView(true);
            player.setUp(path, "", Jzvd.SCREEN_NORMAL);
            GlideLoadImgUtil.loadPlayerFaceImg(mContext, uri, player.thumbImageView);
            videoUri = uri;
            videoPath = path;
        }
    }

    @Override
    public void initPresenter() {
        super.initPresenter();
        mPresenter.setVM(this);
    }

    @Override
    protected void bindEvent() {
        super.bindEvent();

        clickEvent();

        callBackObserverOpenVideo();

        callBackObserverLoading();

        callBackObserverIfUploadVideo();

        callBackObserverCommit();

    }

    /**
     * 点击事件
     */
    private void clickEvent() {

        //点击删除视频
        ivClose.setOnClickListener(new OnMultiClickListener() {
            @Override
            public void onMultiClick(View v) {
                ifShowVideoView(false);
                videoUri = "";
                videoPath = "";
            }
        });
    }

    /**
     * 确认按钮
     */
    @Override
    protected void sure() {
        //判断内容是否为空
        mPresenter.ifUploadFile(getVideoOrArticleTitle(), etInput.getText().toString().trim(), videoPath, videoUri, getParamTagsList(), getChoiceCategoryId());

    }

    @Override
    public void onBackPressed() {
        closeLogic();
    }

    /**
     * 取消按钮
     */
    @Override
    public void cancel() {
        closeLogic();
    }

    /**
     * 关闭处理
     */
    private void closeLogic() {
        //判断内容是否为空
        String content = etInput.getText().toString().trim();
        String title = getVideoOrArticleTitle();
        ArrayList<IndexLableLetterBean> paramTagsList = getParamTagsList();
        InfoPublishCategoryBean categoryBean = getCategoryChoiceDataBean();
        //标题 内容 和视频 标签和 分类都为空
        if (TextUtils.isEmpty(title)
                && TextUtils.isEmpty(content)
                && !(mPresenter.videoDataNotEmpty(videoPath, videoUri))
                && (paramTagsList == null || paramTagsList.size() == 0)
                && categoryBean == null) {
            //直接finish
            finish();
            return;
        }

        //显示保存草稿
        DeleteImgDialog dialog = new DeleteImgDialog(this, getResources().getString(R.string.info_detail_dialog_save_to_file));
        dialog.show();
        dialog.setSureOrCancelListener(new DeleteImgDialog.SureOrCancelListener() {
            @Override
            public void cancel() {
                dialog.dismiss();
                //2019/11/14 清理操作
                mPresenter.clearVideoData();
                finish();
            }

            @Override
            public void sure() {
                //保存数据
                mPresenter.saveVideoData(title, content, videoPath, videoUri, paramTagsList, categoryBean);
                dialog.dismiss();
                finish();
            }
        });
    }


    @Override
    protected void onPause() {
        super.onPause();
        JZReleaseUtil.releaseAllVideos();

        if(!mPresenter.isNeedClearData()) {
            //判断内容是否为空
            String content = etInput.getText().toString().trim();
            String title = getVideoOrArticleTitle();
            ArrayList<IndexLableLetterBean> paramTagsList = getParamTagsList();
            InfoPublishCategoryBean categoryBean = getCategoryChoiceDataBean();
            //标题 内容 和视频 标签和 分类都为空
            if (TextUtils.isEmpty(title)
                    && TextUtils.isEmpty(content)
                    && !(mPresenter.videoDataNotEmpty(videoPath, videoUri))
                    && (paramTagsList == null || paramTagsList.size() == 0)
                    && categoryBean == null) {
                return;
            }
            mPresenter.saveVideoData(title, content, videoPath, videoUri, paramTagsList, categoryBean);
        }
    }


    /**
     * 请求loading
     */
    private void callBackObserverLoading() {
        mPresenter.getReqLoading().observe(this, aBoolean -> {
            if (aBoolean) {
                showDialogLoading();
            }
        });
    }



    /**
     * 提交回调
     */
    private void callBackObserverCommit() {
        mPresenter.getCommitData().observe(this, aBoolean -> {
            hideDialogLoading();
            if (aBoolean) {
                //发布成功
                ToastUtils.showToast("发布成功");

                //清理缓存
                mPresenter.clearVideoData();

                finish();
            } else {
                ToastUtils.showToast("发布失败");
            }
        });
    }

    /**
     * 是否上传文件的回调
     */
    private void callBackObserverIfUploadVideo() {
        mPresenter.getInfoUploadFile().observe(this, infoUploadVideoFileBean -> {
            if (infoUploadVideoFileBean != null) {
                //hideDialogLoading();
                switch (infoUploadVideoFileBean.getState()) {
                    case 0:
                        //ToastUtils.INSTANCE.showToastInfo("上传视频成功");
                        break;
                    default:
                        hideDialogLoading();
                        ToastUtils.showToast("上传视频失败");
                        break;
                }
            }
        });
    }

    /**
     * 选择视频回调
     */
    private void callBackObserverOpenVideo() {
        mPresenter.getFileVideoUriPathLiveData().observe(this, fileVideoUriPathBean -> {
            if (fileVideoUriPathBean == null) return;
            videoPath = fileVideoUriPathBean.getPath();
            videoUri = fileVideoUriPathBean.getUri();

            setJzPlayer(videoUri, videoPath);

        });
    }


    /**
     * 从缓存中获取数据
     *
     * @return
     */
    @Override
    public PublishVideoDataBean getDataFromCache() {
        return mPresenter.getVideoFromCache();
    }

    /**
     * 打开多媒体 这里是打开视频
     */
    @Override
    public void openMedia() {
        mPresenter.openVideo(this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case MediaReqCodeType.REQUEST_CODE_VIDEO://选择视频回调
                mPresenter.openVideoCallBack(resultCode, data);
                break;
        }

    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        JZReleaseUtil.releaseAllVideos();
    }
}
