package com.yb.ballworld.information.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;

import com.yb.ballworld.common.widget.MultTextView;
import com.yb.ballworld.information.R;

/**
 * @author Gethin
 * @time 2019/11/14 18:05
 */

public class RvTeamRankHeader extends LinearLayout {
    public RvTeamRankHeader(Context context) {
        this(context, null);
    }

    public RvTeamRankHeader(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public RvTeamRankHeader(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        LayoutInflater.from(getContext()).inflate(R.layout.rv_item_team_rank_header, this);
        MultTextView mtTitle = findViewById(R.id.mtTitle);
        mtTitle.setTexts("进球数", "球员数量");

    }
}
