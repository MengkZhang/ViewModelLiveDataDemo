package com.yb.ballworld.information.ui.community.bean;

import android.text.TextUtils;

import com.chad.library.adapter.base.entity.MultiItemEntity;

import java.util.List;

/**
 * Desc: 帖子(社区)收藏实体类
 * Author: JS-Kylo
 * Created On: 2019/11/09 13:37
 */
public class PostCollectionEntity {

    /**
     * totalCount : 1
     * pageNum : 1
     * pageSize : 10
     * totalPage : 1
     * list : [{"id":"0060e019e5654a7bb2251a9d158efdc2","title":"格纳布里赛后本想带球回家 却被马丁内斯踢向了看台","imgUrl":"http://tu.duoduocdn.com/v/img/191003/274915_02092424336.jpg","preview":"格纳布里赛后本想带球回家 却被马丁内斯踢向了看台","mediaType":1,"playUrl":"http://1251542705.vod2.myqcloud.com/9665f9bfvodgzp1251542705/ab681f415285890794546965484/xfWZkDfgbksA.mp4","showType":0,"userId":"999","newsImgs":null,"likeCount":9,"commentCount":66,"appShowType":3,"user":{"id":"999","nickname":"fanatik","headImgUrl":"http://sta.5yqz2.com/static/avatar/73ff1f3e8f368b611986b9025b648471.jpg","personalDesc":null,"followerCount":null,"articleCount":null,"attentionStatus":null},"isLike":true,"createdDate":"2019-10-07 11:36:12"}]
     */

    private int totalCount;
    private int pageNum;
    private int pageSize;
    private int totalPage;
    private List<ListBean> list;

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    public static class ListBean implements MultiItemEntity{

        /**
         * content :
         * createdDate :
         * headImgUrl :
         * id : 0
         * isAttention : true
         * isLike : true
         * likeCount : 0
         * nickname :
         * pageViews : 0
         * postId : 0
         * postImgLists : []
         * sonNum : 0
         * title :
         * userId : 0
         * videoUrl :
         */

        private String content;
        private String createdDate;
        private String headImgUrl;
        private int id;
        private boolean isAttention;
        private boolean isLike;
        private int likeCount;
        private String nickname;
        private int pageViews;
        private int postId;
        private int sonNum;
        private String title;
        private int userId;
        private String postUserId;
        private String videoUrl;
        private List<String> postImgLists;
        private String webShareUrl;
        private String postDate;
        private String imgUrl;

        //测试用
        public ListBean(String content, String createdDate, String headImgUrl, int id, String nickname, int postId, String title, int userId, String videoUrl, List<String> postImgLists) {
            this.content = content;
            this.createdDate = createdDate;
            this.headImgUrl = headImgUrl;
            this.id = id;
            this.nickname = nickname;
            this.postId = postId;
            this.title = title;
            this.userId = userId;
            this.videoUrl = videoUrl;
            this.postImgLists = postImgLists;
        }

        public String getImgUrl() {
            return imgUrl;
        }

        public void setImgUrl(String imgUrl) {
            this.imgUrl = imgUrl;
        }

        public String getPostDate() {
            return !TextUtils.isEmpty(postDate) ? postDate : "";
        }

        public void setPostDate(String postDate) {
            this.postDate = postDate;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public String getCreatedDate() {
            return createdDate;
        }

        public void setCreatedDate(String createdDate) {
            this.createdDate = createdDate;
        }

        public String getHeadImgUrl() {
            return headImgUrl;
        }

        public void setHeadImgUrl(String headImgUrl) {
            this.headImgUrl = headImgUrl;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public boolean isIsAttention() {
            return isAttention;
        }

        public void setIsAttention(boolean isAttention) {
            this.isAttention = isAttention;
        }

        public boolean isIsLike() {
            return isLike;
        }

        public void setIsLike(boolean isLike) {
            this.isLike = isLike;
        }

        public int getLikeCount() {
            return likeCount;
        }

        public void setLikeCount(int likeCount) {
            this.likeCount = likeCount;
        }

        public String getNickname() {
            return nickname;
        }

        public void setNickname(String nickname) {
            this.nickname = nickname;
        }

        public int getPageViews() {
            return pageViews;
        }

        public void setPageViews(int pageViews) {
            this.pageViews = pageViews;
        }

        public int getPostId() {
            return postId;
        }

        public void setPostId(int postId) {
            this.postId = postId;
        }

        public int getSonNum() {
            return sonNum;
        }

        public void setSonNum(int sonNum) {
            this.sonNum = sonNum;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public int getUserId() {
            return userId;
        }

        public void setUserId(int userId) {
            this.userId = userId;
        }

        public String getPostUserId() {
            return postUserId;
        }

        public void setPostUserId(String postUserId) {
            this.postUserId = postUserId;
        }

        public String getVideoUrl() {
            return videoUrl;
        }

        public void setVideoUrl(String videoUrl) {
            this.videoUrl = videoUrl;
        }

        public List<String> getPostImgLists() {
            return postImgLists;
        }

        public void setPostImgLists(List<String> postImgLists) {
            this.postImgLists = postImgLists;
        }

        public String getWebShareUrl() {
            return webShareUrl;
        }

        public void setWebShareUrl(String webShareUrl) {
            this.webShareUrl = webShareUrl;
        }

        private int itemViewType;


        @Override
        public int getItemType() {
            return itemViewType;
        }

        public void setItemViewType(int itemViewType) {
            this.itemViewType = itemViewType;
        }

        public int getItemViewType() {
            return itemViewType;
        }
    }
}
