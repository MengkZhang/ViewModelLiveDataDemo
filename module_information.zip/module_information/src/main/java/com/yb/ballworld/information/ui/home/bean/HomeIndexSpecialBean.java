package com.yb.ballworld.information.ui.home.bean;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * Desc 专栏数据结构
 * Date 2019/10/8
 * author mengk
 */
public class HomeIndexSpecialBean implements Parcelable {
    //id
    private String id;
    //类型0 图片 1赛事
    private int specialType;
    //图片类型的图片
    private String specialImg;
    //比赛名称
    private List<HomeIndexSpecialMatchBean> matchList;

    public HomeIndexSpecialBean() {}

    protected HomeIndexSpecialBean(Parcel in) {
        id = in.readString();
        specialType = in.readInt();
        specialImg = in.readString();
    }

    public static final Creator<HomeIndexSpecialBean> CREATOR = new Creator<HomeIndexSpecialBean>() {
        @Override
        public HomeIndexSpecialBean createFromParcel(Parcel in) {
            return new HomeIndexSpecialBean(in);
        }

        @Override
        public HomeIndexSpecialBean[] newArray(int size) {
            return new HomeIndexSpecialBean[size];
        }
    };

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getSpecialType() {
        return specialType;
    }

    public void setSpecialType(int specialType) {
        this.specialType = specialType;
    }

    public String getSpecialImg() {
        return specialImg;
    }

    public void setSpecialImg(String specialImg) {
        this.specialImg = specialImg;
    }

    public List<HomeIndexSpecialMatchBean> getMatchList() {
        return matchList;
    }

    public void setMatchList(List<HomeIndexSpecialMatchBean> matchList) {
        this.matchList = matchList;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeInt(specialType);
        dest.writeString(specialImg);
    }
}
