package com.yb.ballworld.information.ui.home.utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.alibaba.android.arouter.launcher.ARouter;
import com.bfw.util.ToastUtils;
import com.yb.ballworld.baselib.constant.Constant;
import com.yb.ballworld.baselib.core.RouterHub;
import com.yb.ballworld.baselib.core.RouterIntent;
import com.yb.ballworld.baselib.data.UserInfo;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.baselib.web.WebActivity;
import com.yb.ballworld.common.sharesdk.ShareSdkParamBean;
import com.yb.ballworld.common.sharesdk.ShareSdkUtils;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.community.view.CollectionActivity;
import com.yb.ballworld.information.ui.detail.InforCommentActivity;
import com.yb.ballworld.information.ui.detail.NewsVideoDetailActivity;
import com.yb.ballworld.information.ui.detail.InformationGalleryActivity;
import com.yb.ballworld.information.ui.detail.NewsTextDetailActivity;
import com.yb.ballworld.information.ui.detail.NewsTextDetailActivityLollipop;
import com.yb.ballworld.information.ui.home.constant.IndexJumpTypeConstant;
import com.yb.ballworld.information.ui.home.constant.PublishIntentParam;
import com.yb.ballworld.information.ui.home.constant.PublishReqCode;
import com.yb.ballworld.information.ui.home.constant.TagParams;
import com.yb.ballworld.information.ui.home.constant.TagReqCode;
import com.yb.ballworld.information.ui.home.view.PublishArticleActivity;
import com.yb.ballworld.information.ui.home.view.PublishCommentActivity;
import com.yb.ballworld.information.ui.home.view.PublishVideoActivity;
import com.yb.ballworld.information.ui.home.view.TagSortActivity;
import com.yb.ballworld.information.ui.home.view.TagSortByIndexActivity;
import com.yb.ballworld.information.ui.home.view.TestActivity;
import com.yb.ballworld.information.ui.personal.view.InformationPersonalActivityNew;
import com.yb.ballworld.information.ui.profile.view.ProfileClubActivity;
import com.yb.ballworld.information.ui.profile.view.ProfileMatchActivity;
import com.yb.ballworld.information.ui.profile.view.ProfilePlayerActivity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Desc
 * Date 2019/10/11
 * author mengk
 */
public class NavigateToDetailUtil {
    /**
     * 到资讯详情页
     *
     * @param activity
     * @param newsId
     * @param isVideo
     */
    public static void navigateToDetail(Context activity, String newsId, boolean isVideo) {
        Intent intent = new Intent(activity, isVideo ? NewsVideoDetailActivity.class : Build.VERSION.SDK_INT>Build.VERSION_CODES.LOLLIPOP?NewsTextDetailActivity.class: NewsTextDetailActivityLollipop.class);
//         Intent intent = new Intent(activity, isVideo ? NewsVideoDetailActivity.class : InfoNewsDetailActivity.class);
        intent.putExtra("NEWS_ID", newsId);
        intent.putExtra("NEWS_TYPE", isVideo);

        LogUtils.INSTANCE.e("===z", "newsid == " + newsId);
        activity.startActivity(intent);
    }

    /**
     * 到评论列表
     *
     * @param activity
     * @param newsId
     * @param comment
     */
    public static void navigateToCommentList(Context activity, String newsId, Serializable comment) {
        Intent intent = new Intent(activity,  InforCommentActivity.class);
//         Intent intent = new Intent(activity, isVideo ? NewsVideoDetailActivity.class : InfoNewsDetailActivity.class);
        intent.putExtra("NEWS_ID", newsId);
        intent.putExtra("COMMENT", comment);

        LogUtils.INSTANCE.e("===z", "newsid == " + newsId);
        activity.startActivity(intent);
    }

    /**
     * 跳转到个人页面
     *
     * @param context
     */
    public static void navigateToPerson(Context context, String uid) {
        if (TextUtils.isEmpty(uid)) {
            ToastUtils.showToast("用户id不能为空");
            return;
        }
        Intent intent = new Intent(context, InformationPersonalActivityNew.class);
        intent.putExtra("userId", uid);
        context.startActivity(intent);
    }

    /**
     * 跳转到收藏页面
     *
     * @param context
     */
    public static void navigateToCollect(Context context,int index) {
        if (isLogin()) {
            CollectionActivity.startActivity(context,index);
        }else {
            toLogin((Activity) context);
        }
//        // TODO: 2019/11/5 需要删除
//        navigateToTagSort(context);
//        navigateToPublishArticles(context);
//        navigateToPublishVideo(context);
    }

    /**
     * 跳转到直播页面
     *
     * @param context
     */
    public static void navigateToLiveDetail(Context context, int matchId, int sportType) {
        // TODO: 2019/10/12
        RouterIntent.startMatchDetailActivity(context, matchId, sportType);
    }

    //LiveDetailsActivity   MAIN_MAIN_LIVE_DETAIL_INFO
    /**
     * 跳直播
     * @param context
     * @param authorId 主播id
     */
    public static void navigateToRightPlayDetail(Context context,String authorId){
        ARouter.getInstance()
                .build(RouterHub.MAIN_MAIN_LIVE_DETAIL_INFO)
                .withString("anchorId",authorId)
                .navigation((Activity) context, 0);
    }

    /**
     * 到转到h5页面
     *
     * @param context
     * @param jumpUrl
     * @param sportType
     */
    public static void navigateToH5(Context context, String jumpUrl, int sportType) {
        WebActivity.start(context, jumpUrl, "详情", true, sportType);
    }


    /**
     * 跳转类型
     *
     * @param context            context
     * @param jumpType           跳转类型 0 资讯 1 视频 2 直播 3 赛事 4 h5
     * @param detailJumpId       资讯和视频详情的id
     * @param H5JumpUrl          h5链接
     * @param matchIdOrJumpId    直播和赛事的matchId（头部的传jumpId）
     * @param matchSportIdOrType 直播和赛事的sportType(头部的传sportID)
     */
    public static void jumpType(Context context, int jumpType, String detailJumpId, String H5JumpUrl, int matchIdOrJumpId, int matchSportIdOrType) {
        switch (jumpType) {
            case IndexJumpTypeConstant.TYPE_INFO://跳资讯
                navigateToDetail(context, detailJumpId, false);
                break;
            case IndexJumpTypeConstant.TYPE_VIDEO://跳视频
                navigateToDetail(context, detailJumpId, true);
                break;
            case IndexJumpTypeConstant.TYPE_FACE_VIDEO://跳直播
//                navigateToLiveDetail(context, matchIdOrJumpId, matchSportIdOrType);
                navigateToRightPlayDetail(context,detailJumpId);
                break;
            case IndexJumpTypeConstant.TYPE_MATCH://跳比赛
                navigateToLiveDetail(context, matchIdOrJumpId, matchSportIdOrType);
                break;
            case IndexJumpTypeConstant.TYPE_H5://跳H5
                navigateToH5(context, H5JumpUrl, matchSportIdOrType);
                break;
            default:
                break;
        }
    }

    /**
     * 点赞帮助类
     *
     * @param view
     * @param mContext
     */
    public static void showShareToast(View view, Context mContext, ShareSdkParamBean bean) {
        String string = mContext.getResources().getString(R.string.prompt_coding);
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                ToastUitl.showShort(string);
                ShareSdkUtils.showShare((Activity)mContext,bean);
            }
        });
    }

    public static void showShareToast(View view, Context mContext) {
        String string = mContext.getResources().getString(R.string.prompt_coding);
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                ToastUitl.showShort(string);
                ShareSdkUtils.showShare((Activity)mContext);
            }
        });
    }

    /**
     * 分享帮助类
     *
     * @param view
     * @param mContext
     */
    public static void showShareToast(View view, Context mContext,String title,String titleUrl,String text,String imgUrl,String url) {
        String string = mContext.getResources().getString(R.string.prompt_coding);
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                ToastUitl.showShort(string);
                ShareSdkUtils.showShare((Activity)mContext,new ShareSdkParamBean(title,titleUrl,text,imgUrl,url));
            }
        });
    }

    public static void RVNavigateToH5(Context context, RecyclerView recyclerView, String newsId) {
        recyclerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent intent = new Intent(context, NewsVideoDetailActivity.class);
//                intent.putExtra("NEWS_ID",newsId);
//                intent.putExtra("NEWS_TYPE",false);
//                context.startActivity(intent);
                navigateToDetail(context, newsId, false);
            }
        });
    }


    /**
     * 跳转发表评论页
     * @param context context
     * @param id id
     * @param commentType 0.评论 1.回复
     * @param createdBy 创建人
     * @param createdDate 创建时间
     * @param lastModifiedBy 最近操作人
     * @param lastModifiedDate 更新时间
     * @param likeCount 点赞数
     * @param mainCommentId 主评论ID
     * @param nickName 用户昵称
     * @param userId 评论用户ID
     * @param newsId newsId
     * @param replyId 回复ID
     */
    public static void navigateToPublishComment(AppCompatActivity context,
                                                String id,
                                                String commentType,
                                                String createdBy,
                                                String createdDate,
                                                String lastModifiedBy,
                                                String lastModifiedDate,
                                                String likeCount,
                                                String mainCommentId,
                                                String nickName,
                                                String userId,
                                                String newsId,
                                                String replyId) {
        Intent intent = new Intent(context, PublishCommentActivity.class);
        intent.putExtra(PublishIntentParam.NEWS_ID,newsId);
        intent.putExtra(PublishIntentParam.REPLY_ID,replyId);
        intent.putExtra(PublishIntentParam.ID,id);
        intent.putExtra(PublishIntentParam.COMMENT_TYPE,commentType);
        intent.putExtra(PublishIntentParam.CREATED_BY,createdBy);
        intent.putExtra(PublishIntentParam.CREATED_DATE,createdDate);
        intent.putExtra(PublishIntentParam.LAST_MODIFIED_BY,lastModifiedBy);
        intent.putExtra(PublishIntentParam.LAST_MODIFIED_DATE,lastModifiedDate);
        intent.putExtra(PublishIntentParam.LIKE_COUNT,likeCount);
        intent.putExtra(PublishIntentParam.MAIN_COMMENT_ID,mainCommentId);
        intent.putExtra(PublishIntentParam.NICK_NAME,nickName);
        intent.putExtra(PublishIntentParam.USER_ID,userId);
        context.startActivityForResult(intent, PublishReqCode.REQ_CODE);
    }

    /**
     * 跳转到发表评论页
     * @param context context
     * @param newsId  newsId
     * @param replyId 回复id
     */
    public static void navigateToPublishComment(AppCompatActivity context, String newsId, String replyId) {
        if (isLogin()) { //已经登陆
            Intent intent = new Intent(context, PublishCommentActivity.class);
            intent.putExtra(PublishIntentParam.NEWS_ID,newsId);
            intent.putExtra(PublishIntentParam.REPLY_ID,replyId);
            context.startActivityForResult(intent, PublishReqCode.REQ_CODE);

        } else {         //没有登陆
            toLogin(context);

        }
    }

    /**
     * 跳转到发表评论页
     * @param context context
     * @param topicId  newsId
     * @param replyId 回复id
     */
    public static void navigateToPublishTopicComment(AppCompatActivity context, String topicId, String replyId) {
        if (isLogin()) { //已经登陆
            Intent intent = new Intent(context, PublishCommentActivity.class);
            intent.putExtra(PublishIntentParam.NEWS_ID, topicId);
            intent.putExtra(PublishIntentParam.REPLY_ID, replyId);
            intent.putExtra("type", Integer.MIN_VALUE);
            context.startActivityForResult(intent, PublishReqCode.REQ_CODE);
        } else {         //没有登陆
            toLogin(context);

        }
    }

    /**
     * 跳转到登录页面
     * @param activity
     */
    public static void toLogin(Activity activity) {
        ARouter.getInstance().build(RouterHub.USER_LOGIN_REGISTER_ACTIVITY)
                .navigation(activity, Constant.COMMON_LOGIN_REQUEST);
    }

    /**
     * 是否登录
     * @return
     */
    private static boolean isLogin(){
        UserInfo mUserInfo = LoginOrdinaryUtils.INSTANCE.getUserInfo();
        // 如果用户信息为空，说明用户为登陆，跳转到登陆界面
        if (mUserInfo == null) {
            return false;
        }
        return true;
    }

    /**
     * 跳转到发布文章页面
     * @param context
     */
    private static void navigateToPublishArticles(Context context) {
//        Intent intent = new Intent(context, PublishArticlesActivity.class);
        Intent intent = new Intent(context, PublishArticleActivity.class);
        context.startActivity(intent);
    }

    /**
     * 跳转到球队标签页
     * @param context
     */
    public static void navigateToTagSortByIndex(AppCompatActivity context, ArrayList<String> ids,int type,int position) {
        Intent intent = new Intent(context, TagSortByIndexActivity.class);
        intent.putStringArrayListExtra(TagParams.INTENT_PARAM,ids);
        intent.putExtra(TagParams.INTENT_PARAM_TYPE,type);
        intent.putExtra(TagParams.INTENT_PARAM_POSITION,position);
        context.startActivityForResult(intent, TagReqCode.REQ_CODE_PUBLISH_TO_TAG_TO_MORE);
    }

    /**
     * 跳转到标签库页面
     * @param context
     */
    public static void navigateToTagSort(AppCompatActivity context, ArrayList<String> ids) {
        Intent intent = new Intent(context, TagSortActivity.class);
        intent.putStringArrayListExtra(TagParams.INTENT_PARAM,ids);
        context.startActivityForResult(intent,TagReqCode.REQ_CODE_PUBLISH_TO_TAG);
    }

    /**
     * 跳转到发布视频页面
     * @param context
     */
    private static void navigateToPublishVideo(Context context) {
        Intent intent = new Intent(context, PublishVideoActivity.class);
        context.startActivity(intent);
    }

    /**
     * 到相册浏览详情页 有分享
     * @param context
     * @param peerList
     * @param position
     * @param title
     * @param titleUrl
     * @param text
     * @param url
     */
    public static void navigateToGalleryActivity(Context context, List<String> peerList,int position,String title,String titleUrl,String text,String url) {
        Intent intent = new Intent(context, InformationGalleryActivity.class);
        intent.putStringArrayListExtra("IMG_ARRAY", (ArrayList<String>) peerList);
        intent.putExtra("IMG_INDEX", position);
        intent.putExtra("HIDDEN_SHARE", false);
        intent.putExtra("TITLE", title);
        intent.putExtra("TITLE_URL", titleUrl);
        intent.putExtra("TEXT", text);
        intent.putExtra("URL", url);
        context.startActivity(intent);
    }

    /**
     * 到相册浏览详情页 没有分享
     * @param context
     * @param peerList
     * @param position
     */
    public static void navigateToGalleryActivityWithoutShare(Context context, List<String> peerList,int position) {
        Intent intent = new Intent(context, InformationGalleryActivity.class);
        intent.putStringArrayListExtra("IMG_ARRAY", (ArrayList<String>) peerList);
        intent.putExtra("IMG_INDEX", position);
        intent.putExtra("HIDDEN_SHARE", true);
        context.startActivity(intent);
    }

    public static void navigateTest(Context context) {
        Intent intent = new Intent(context, TestActivity.class);
        context.startActivity(intent);
    }

    /**
     * 到发布页面
     * @param context
     * @param isVideo
     */
    public static void navigateToPublish(Activity context,boolean isVideo) {
        if (isLogin()) { //已经登陆
            if (isVideo) { //发视频
                navigateToPublishVideo(context);
            } else {       //发文章
                navigateToPublishArticles(context);
            }
        } else {         //没有登陆
            toLogin(context);

        }
    }


    interface ProfileTagsType {
        int Player = 1;    // 球员
        int Club =   2;    // 球队
        int Country =  3;// 国家
        int Match =  4;// 赛事
    }

    /**
     * 跳转到资料库详情页
     * @param context
     * @param type 1 2 3
     * @param id
     * @param args2
     */
    public static void navigateToTagsBankDetail(Activity context, int type, String id, String args2) {
       switch (type) {
           case ProfileTagsType.Player:
               ProfilePlayerActivity.launch(context, id, args2);
               break;
           case ProfileTagsType.Club:
           case ProfileTagsType.Country:
               ProfileClubActivity.launch(context, id, args2);
               break;
           case ProfileTagsType.Match:
               ProfileMatchActivity.launch(context, id, args2);
               break;
       }
    }


}
