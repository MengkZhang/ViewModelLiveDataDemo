package com.yb.ballworld.information.ui.home.presenter;

import com.yb.ballworld.information.ui.home.listener.PraiseResultListener;
import com.yb.ballworld.information.widget.GoodView;

/**
 * Desc 资讯点赞协议类
 * Date 2019/10/7
 * author mengk
 */
public class InfoPraiseContract {


    //--------------------------------Presenter层----------------------------
    public interface IInfoPraisePresenter {

        //请求数据方法
        void loadData(String newsId, PraiseResultListener callBack);

    }


}
