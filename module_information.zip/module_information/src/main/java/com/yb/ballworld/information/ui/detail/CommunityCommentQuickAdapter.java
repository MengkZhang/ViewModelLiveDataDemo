package com.yb.ballworld.information.ui.detail;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bfw.image.core.utils.RoundType;
import com.bfw.image.glide.transform.RoundedCornersTransformation;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.request.RequestOptions;
import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.scwang.smartrefresh.layout.util.DensityUtil;
import com.yb.ballworld.baselib.utils.ImageManager;
import com.yb.ballworld.baselib.utils.ViewUtils;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.data.RootBean;
import com.yb.ballworld.information.ui.community.bean.Topic;
import com.yb.ballworld.information.utils.CommondUtil;
import com.yb.ballworld.information.utils.HtmlParseData;
import com.yb.ballworld.information.widget.ExpandTextView;
import com.yb.ballworld.information.widget.TimerTextView;
import com.yb.ballworld.information.widget.bubbleview.BubbleLinearLayout;
import com.yb.ballworld.information.widget.listener.OnElementClickListener;

import java.util.List;

import cn.jzvd.JzvdStd;

import static com.yb.ballworld.information.ui.detail.InforConstant.ItemType.DETAIL_HEADER_COMMENT;
import static com.yb.ballworld.information.ui.detail.InforConstant.SortType.ITEMTYPE_HEAT;
import static com.yb.ballworld.information.ui.detail.InforConstant.SortType.ITEMTYPE_TIME;
import static com.yb.ballworld.information.ui.detail.InforConstant.TopicDetailItemType.TYPE_TOPIC;
import static com.yb.ballworld.information.ui.detail.InforConstant.TopicDetailItemType.TYPE_TOPIC_COMMENT_IMAGE;
import static com.yb.ballworld.information.ui.detail.InforConstant.TopicDetailItemType.TYPE_TOPIC_COMMENT_TEXT;
import static com.yb.ballworld.information.ui.detail.InforConstant.TopicDetailItemType.TYPE_TOPIC_COMMENT_VIDEO;
import static com.yb.ballworld.information.utils.CommondUtil.fitEmpty;

public class CommunityCommentQuickAdapter extends BaseMultiItemQuickAdapter<MultiItemEntity, BaseViewHolder> {
    private Context context;
    private OnElementClickListener mOnElementClickListener;
    private boolean hasMore = false;
    private boolean isHeat = false;
    private int commentId = -1;

    public void setOnElementClickListener(OnElementClickListener onElementClickListener) {
        mOnElementClickListener = onElementClickListener;
    }

    /**
     * Same as QuickAdapter#QuickAdapter(Context,int) but with
     * some initialization data.
     *
     * @param data A new list is created out of this one to avoid mutable list
     */
    public CommunityCommentQuickAdapter(List data, Context context) {
        super(data);
        this.context = context;
        addItemType(DETAIL_HEADER_COMMENT, R.layout.item_detail_root1);
        addItemType(TYPE_TOPIC_COMMENT_TEXT, R.layout.item_replies_layout);
        addItemType(TYPE_TOPIC, R.layout.item_replies_layout);
        addItemType(TYPE_TOPIC_COMMENT_IMAGE, R.layout.item_replies_layout);
        addItemType(TYPE_TOPIC_COMMENT_VIDEO, R.layout.item_replies_layout);

    }

    public boolean hasMore() {
        return hasMore;
    }

    public void setHasMore(boolean hasMore) {
        this.hasMore = hasMore;
    }

    public boolean isHeat() {
        return isHeat;
    }

    public void setHeat(boolean heat) {
        isHeat = heat;
    }

    /**
     * 改变点赞的数量与状态
     *
     * @param item
     * @param baseViewHolder
     */
    public void changedLike(Topic item, BaseViewHolder baseViewHolder) {
        ImageView view = baseViewHolder.getView(R.id.singleCommit_like);
        if (view != null) {
            view.setImageResource(item.getIsLike() ? R.drawable.icon_priase_info : R.drawable.icon_priase_info_normal);
        }
        TextView textView = baseViewHolder.getView(R.id.singleCommit_likeCount);
        if (textView != null) {
            textView.setText(String.valueOf(item.getLikeCount()));
        }

    }


    /**
     * 改变点赞的数量与状态
     *
     * @param count
     */
    public void changedCommentCount(int count) {
        if (getItemCount() > 1) {
            TextView view = (TextView) getViewByPosition(getRecyclerView(), 1, R.id.inforDetail_title);
            if(view!=null) {
                view.setText(context.getResources().getString(R.string.func_allTopicNum, CommondUtil.commentCountOnlyNum(count, context)));
            }
            ((Topic)getItem(0)).setSonNum(count);
        }
    }

    /**
     * itemtype分类布局总处理处
     *
     * @param helper
     * @param item
     * @param pos
     */
    @Override
    protected void convert(BaseViewHolder helper, MultiItemEntity item, int pos) {
        int itemType = item.getItemType();
        if (itemType == TYPE_TOPIC_COMMENT_TEXT || itemType == TYPE_TOPIC_COMMENT_VIDEO || itemType == TYPE_TOPIC_COMMENT_IMAGE || itemType == TYPE_TOPIC) {
            proxyComment(helper, (Topic) item, pos);
        } else if (itemType == DETAIL_HEADER_COMMENT) {
            proxyCommentHeader(helper, (RootBean) item, pos);
        }

        int margin = 0;
        if (hasMore()) {
            margin = 0;
        } else if (pos > 0 && pos == getItemCount() - 1 && (itemType == TYPE_TOPIC_COMMENT_TEXT || itemType == TYPE_TOPIC_COMMENT_VIDEO || itemType == TYPE_TOPIC_COMMENT_IMAGE || itemType == TYPE_TOPIC)) {
            margin = DensityUtil.dp2px(20);
        } else {
            margin = 0;
        }
        View view = helper.itemView;
        if (view != null) {
            RecyclerView.LayoutParams params = (RecyclerView.LayoutParams) view.getLayoutParams();
            params.bottomMargin = margin;
        }

        if (itemType == TYPE_TOPIC_COMMENT_TEXT || itemType == TYPE_TOPIC_COMMENT_VIDEO || itemType == TYPE_TOPIC_COMMENT_IMAGE || itemType == TYPE_TOPIC) {
            View line = helper.getView(R.id.singleCommit_bottomLine);
            View line2 = helper.getView(R.id.singleCommit_bottomLine2);
            if ((getItemCount()-1 == pos) || pos == 0) {
                line.setVisibility(View.GONE);
                line2.setVisibility(View.VISIBLE);
            } else {
                line.setVisibility(View.VISIBLE);
                line2.setVisibility(View.GONE);
            }
        }
    }

    /**
     * 处理评论头
     *
     * @param helper
     * @param item
     * @param pos
     */
    private void proxyCommentHeader(BaseViewHolder helper, RootBean item, int pos) {
        helper.setText(R.id.inforDetail_sortTitle, R.string.txt_sortByTime);
        setOnItemChildClickListener(getOnItemChildClickListener());
        helper.setText(R.id.inforDetail_title, context.getResources().getString(R.string.func_allTopicNum, CommondUtil.commentCountOnlyNum(((Topic) getItem(0)).getSonNum(), context)));
        helper.getView(R.id.inforDetail_sortType_view).setOnClickListener(v -> {
            v.setClickable(false);
            item.setArgs(item.getArgs() == ITEMTYPE_HEAT ? ITEMTYPE_TIME : ITEMTYPE_HEAT);
            //item.getArgs() == ITEMTYPE_HEAT ? R.string.txt_sortByHeat :
            // helper.setText(R.id.inforDetail_sortTitle, item.getArgs() == ITEMTYPE_HEAT ? R.string.txt_sortByHeat : R.string.txt_sortByTime);
            helper.setText(R.id.inforDetail_sortTitle, R.string.txt_sortByTime);
            setHeat(item.getArgs() == ITEMTYPE_HEAT);
            if (getOnItemChildClickListener() != null) {
                getOnItemChildClickListener().onItemChildClick(CommunityCommentQuickAdapter.this, v, pos);
            }
            v.setClickable(true);
        });
    }


    /**
     * 处理资讯的评论Item
     *
     * @param helper
     * @param item
     * @param pos
     */
    private void proxyComment(BaseViewHolder helper, Topic item, int pos) {
        //头像、名称、时间
        ImageManager.INSTANCE.loadRoundIcon(item.getHeadImgUrl(), R.drawable.user_default_icon2, 0, helper.getView(R.id.singleCommit_photo));
        helper.setText(R.id.singleCommit_commiter, item.getNickname());
//        ((TimerTextView) helper.getView(R.id.singleCommit_time)).setDefiniteTime(item.getCreatedTime());
        ((TimerTextView) helper.getView(R.id.singleCommit_time)).setText(item.getPostDate());

        //点赞
        helper.setImageResource(R.id.singleCommit_like, item.getIsLike() ? R.drawable.icon_priase_info : R.drawable.icon_priase_info_normal);
        helper.setText(R.id.singleCommit_likeCount, CommondUtil.likeCount(item.getLikeCount(), context));

        //文字
        String text = fitEmpty(item.getContent());
        boolean isNonZero = text.length() > 0;
        if (isNonZero) {
            helper.setText(R.id.singleCommit_text, text);
        }
        helper.setGone(R.id.singleCommit_text, isNonZero);

        //评论数
//        isNonZero = item.getSonNum() > 0;
//        if (isNonZero) {
//            helper.setText(R.id.singleCommit_count, CommondUtil.commentCount(item.getSonNum(), context));
//        }
//        helper.setGone(R.id.singleCommit_countLayout, isNonZero);

        //添加单击事件
        helper.addOnClickListener(R.id.singleCommit_like, R.id.singleCommit_countLayout, R.id.singleCommit_photo, R.id.singleCommit_commiter);

        //媒体布局扩展
        int mediaType = getMediaType(item);
        if (mediaType == InforConstant.MediaType.ITEMTYPE_VIDEO) {
            handleVideo(helper, item);
        } else if (mediaType == InforConstant.MediaType.ITEMTYPE_IMGS) {
            handleImgs(helper, item);
        } else {
            helper.getView(R.id.singleCommit_frameLayout).setVisibility(View.GONE);
        }

        Topic simpleCommit = item.getParent();
        boolean isShow = simpleCommit != null && simpleCommit.getId() != getCommentId() && pos > 0;
        helper.setGone(R.id.singleCommit_countLayout, isShow);
        if (isShow) {
            BubbleLinearLayout bubbleLinearLayout = helper.getView(R.id.singleCommit_countLayout);
            bubbleLinearLayout.setVisibility(View.VISIBLE);
            isShow = !TextUtils.isEmpty(simpleCommit.getContent());
            helper.setGone(R.id.singleCommit_Content, isShow);
            ExpandTextView expandTextView = helper.getView(R.id.singleCommit_Content);
            if (isShow) {
                String atWho = context.getString(R.string.func_commentParent, "", CommondUtil.fitEmpty(simpleCommit.getNickname()));
//              SpannableString  spanStr=new SpannableString(atWho);
//                spanStr.setSpan(new ForegroundColorSpan(context.getResources().getColor(R.color.color_ff333333)), 0, atWho.length(), Spannable.SPAN_EXCLUSIVE_INCLUSIVE);
                expandTextView.initWidth(ViewUtils.dp2px(259));
                expandTextView.setMaxLines(3);
                expandTextView.setCloseText(atWho + simpleCommit.getContent());
                // helper.setText(R.id.singleCommit_Content, simpleCommit.getContent());
            }
            int parentMediaType = getMediaType(simpleCommit);
            isShow = parentMediaType != InforConstant.MediaType.ITEMTYPE_NO_MEDIA;
            helper.setGone(R.id.singleCommit_Link, isShow);
            if (isShow) {
                helper.setText(R.id.singleCommit_Link, getMediaPrompt(simpleCommit, parentMediaType));
                helper.getView(R.id.singleCommit_Link).setOnClickListener(v -> {
                    if (mOnElementClickListener != null) {
                        if (parentMediaType == InforConstant.MediaType.ITEMTYPE_IMGS) {
                            List<String> strings = getImgList(simpleCommit);
                            mOnElementClickListener.onElementClick(strings.get(0), InforConstant.WebMediaType.TYPE_IMG, 0, strings);
                        } else {
                            mOnElementClickListener.onElementClick(simpleCommit.getVideoUrl(), InforConstant.WebMediaType.TYPE_VIDEO, 0, null);
                        }
                    }
                });
            }
        }
//
//        //
//        helper.setImageResource(R.id.singleCommit_like, item.isLike() ? R.drawable.icon_priase_info : R.drawable.icon_priase_info_normal);
//        helper.setText(R.id.singleCommit_likeCount, CommondUtil.likeCount(item.getLikeCount(), context));
    }

    private String getMediaPrompt(Topic simpleCommit, int parentMediaType) {
        String text = "";
        if (parentMediaType == InforConstant.MediaType.ITEMTYPE_VIDEO) {
            text = context.getString(R.string.func_commentVideo);
        } else if (parentMediaType == InforConstant.MediaType.ITEMTYPE_IMGS) {
            int size = getImgList(simpleCommit).size();
            if (size > 1) {
                text = context.getString(R.string.func_commentImgCount, size);
            } else {
                text = context.getString(R.string.func_commentImg);
            }
        }
        return text;
    }

    /**
     * 获取媒资类型
     *
     * @param item
     */
    public int getMediaType(Topic item) {
        int type;
        if (!TextUtils.isEmpty(item.getVideoUrl())) {
            type = InforConstant.MediaType.ITEMTYPE_VIDEO;
        } else if (isHasImg(item)) {
            type = InforConstant.MediaType.ITEMTYPE_IMGS;
        } else {
            type = InforConstant.MediaType.ITEMTYPE_NO_MEDIA;
        }
        return type;
    }

    /**
     * 评论中是否含有图片
     *
     * @param item
     * @return
     */
    private boolean isHasImg(Topic item) {

        return item.getPostImgLists() != null && !CommondUtil.isEmpty(item.getPostImgLists());
    }

    /**
     * 评论中提取图片列表
     *
     * @param item
     * @return
     */
    public List<String> getImgList(Topic item) {

        return item.getPostImgLists();
    }

    /**
     * 处理评论中含有视频的扩展布局
     *
     * @param helper
     * @param item
     */
    private void handleVideo(BaseViewHolder helper, Topic item) {
        ViewGroup viewGroup = helper.getView(R.id.singleCommit_frameLayout);
        viewGroup.setVisibility(View.VISIBLE);
        if (viewGroup.getChildCount() > 0) {
            for(int i=viewGroup.getChildCount()-1;i>=0;i--){
                View child=viewGroup.getChildAt(i);
                if(child.getId()!=R.id.view_video){
                    viewGroup.removeView(child);
                }
            }
        }

        View v=helper.getView(R.id.view_video);
        if(v==null){
            LayoutInflater.from(context).inflate(R.layout.item_comment_video, helper.getView(R.id.singleCommit_frameLayout), true);
        }
        JzvdStd jzvdStd = helper.getView(R.id.item_comment_video);
        if (!TextUtils.isEmpty(item.getVideoUrl())) {
            jzvdStd.setUp(item.getVideoUrl(), "", JzvdStd.SCREEN_NORMAL);
            Glide.with(context).setDefaultRequestOptions(new RequestOptions()
                    .frame(1).transform(new CenterCrop(), new RoundedCornersTransformation(ViewUtils.dp2px(4), RoundType.ALL))).load(item.getVideoUrl())
                    .into(jzvdStd.thumbImageView);
        }
    }

    /**
     * 处理评论中含有图片的扩展布局
     *
     * @param helper
     * @param item
     */
    private void handleImgs(BaseViewHolder helper, Topic item) {
        ViewGroup viewGroup = helper.getView(R.id.singleCommit_frameLayout);
        viewGroup.setVisibility(View.VISIBLE);
        if (viewGroup.getChildCount() > 0) {
            for(int i=viewGroup.getChildCount()-1;i>=0;i--){
                View child=viewGroup.getChildAt(i);
                if(child.getId()!=R.id.recycle_imgs){
                    viewGroup.removeView(child);
                }
            }
        }

        View v=helper.getView(R.id.recycle_imgs);
        if(v==null){
            LayoutInflater.from(context).inflate(R.layout.item_comment_imglist, helper.getView(R.id.singleCommit_frameLayout), true);
        }
        RecyclerView recyclerView = helper.getView(R.id.recycle_imgs);
        CommentImgQuickAdapter commentImgQuickAdapter = new CommentImgQuickAdapter(null);
        recyclerView.setAdapter(commentImgQuickAdapter);
        commentImgQuickAdapter.autoFit(recyclerView, getImgList(item));
        commentImgQuickAdapter.setOnItemClickListener(onItemImgsClickListener);
    }

    /**
     * 主要用在点击评论图片的事件转发
     *
     * @param adapter  the adpater
     * @param view     The itemView within the RecyclerView that was clicked (this
     * will be a view provided by the adapter)
     * @param position The position of the view in the adapter.
     */
    private OnItemClickListener onItemImgsClickListener = (adapter, view, position) -> {
        if (mOnElementClickListener != null) {
            mOnElementClickListener.onElementClick((String) adapter.getItem(position), HtmlParseData.TYPE_IMG, position, adapter.getData());
        }
    };


    public int getChildEventType(View view) {
        int viewId = view.getId();
        int type = InforConstant.ItemEvent.NONE;
        if (viewId == R.id.singleCommit_photo || viewId == R.id.singleCommit_commiter) {
            type = InforConstant.ItemEvent.USER_COMMENT;
        } else if (viewId == R.id.singleCommit_countLayout) {
            type = InforConstant.ItemEvent.REPLIES_COMMENT;
        } else if (viewId == R.id.singleCommit_like) {
            type = InforConstant.ItemEvent.LIKE_COMMENT;
        } else if (viewId == R.id.inforDetail_sortType_view) {
            type = InforConstant.ItemEvent.ROOT_SORT;
        }
        return type;
    }

    /**
     * 布局更换注意替换
     *
     * @return
     */
    public int getVideoViewId() {
        return R.id.item_comment_video;
    }

    public void setCommentId(int commentId) {
        this.commentId = commentId;
    }

    public int getCommentId() {
        return commentId;
    }
}
