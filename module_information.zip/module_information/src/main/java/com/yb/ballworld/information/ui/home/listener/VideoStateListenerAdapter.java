package com.yb.ballworld.information.ui.home.listener;

/**
 * @description: 视频状态回调的适配器
 */
public class VideoStateListenerAdapter implements VideoStateListener {
    @Override
    public void onStateNormal() {

    }

    @Override
    public void onPreparing() {

    }

    @Override
    public void onStartClick() {

    }

    @Override
    public void onStart() {

    }

    @Override
    public void onPlaying() {

    }

    @Override
    public void onPause() {

    }

    @Override
    public void onProgressChanged(int progress) {

    }

    @Override
    public void onComplete() {

    }

    @Override
    public void onTouch() {

    }

    @Override
    public void onStartDismissControlViewTimer() {

    }
}
