package com.yb.ballworld.information.ui.personal.presenter;

import android.text.TextUtils;

import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.callback.OnUICallback;
import com.yb.ballworld.information.http.PersonalHttpApi;
import com.yb.ballworld.information.ui.personal.bean.PersonalInfo;
import com.yb.ballworld.information.ui.personal.view.InformationPersonalActivity;

import org.json.JSONException;
import org.json.JSONObject;


/**
 * Desc: 个人页面presenter
 * Author: JS-Kylo
 * Created On: 2019/10/13 20:01
 */
public class InfoPersonalPresenter extends BasePresenter<InformationPersonalActivity, VoidModel> {

    private PersonalHttpApi httpApi;

    @Override
    public void onStart() {
        super.onStart();
        httpApi = new PersonalHttpApi();
    }

    //加载用户信息
    public void loadUserInfo(String userId) {
        add(httpApi.getPersonalInfo(userId, new OnUICallback<PersonalInfo>() {
            @Override
            public void onUISuccess(PersonalInfo data) {
                mView.initUserInfo(data, "");
            }

            @Override
            public void onUIFailed(int errCode, String errMsg) {
                mView.initUserInfo(null, errMsg);
            }
        }));
    }

    public Integer getInt(JSONObject jsonObject, String key, Integer defaultValue) {
        if (jsonObject == null || TextUtils.isEmpty(key)) {
            return defaultValue;
        }

        try {
            return jsonObject.getInt(key);
        } catch (JSONException e) {
            e.printStackTrace();
            return defaultValue;
        }
    }
}
