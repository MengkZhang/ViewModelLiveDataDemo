package com.yb.ballworld.information.ui.community.view;

import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.common.base.mvp.BaseMvpActivity;
import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.widget.CommonTitleBar;
import com.yb.ballworld.information.R;

public abstract class RVBaseActivity<P extends BasePresenter> extends BaseMvpActivity<P> {
    protected CommonTitleBar commonTitleBar;
    protected SmartRefreshLayout smartRefreshLayout;
    protected RecyclerView recyclerView;
    protected PlaceholderView placeholder;
    protected BaseQuickAdapter adapter;


    protected abstract void loadData();

    protected abstract BaseQuickAdapter getAdapter();

    @Override
    public int getLayoutId() {
        return R.layout.activity_rv_base_layout;
    }

    @Override
    protected void initView() {
        commonTitleBar = findViewById(R.id.commonTitleBar);
        smartRefreshLayout = findViewById(R.id.smart_refresh_layout);
        recyclerView = findViewById(R.id.recyclerView);
        placeholder = findViewById(R.id.placeholder);

        initRefreshView();
        enableLoadMore(false);
        enableRefresh(true);
        placeholder.setPageErrorRetryListener(view -> loadData());

        adapter=getAdapter();
        recyclerView.setAdapter(adapter);

    }

    @Override
    protected void bindEvent() {

    }

    @Override
    protected void initData() {
        loadData();
    }


    @Override
    public SmartRefreshLayout getSmartRefreshLayout() {
        return smartRefreshLayout;
    }

    @Override
    protected void onRefreshData() {
        loadData();
    }

    @Override
    public PlaceholderView getPlaceholderView() {
        return placeholder;
    }
}
