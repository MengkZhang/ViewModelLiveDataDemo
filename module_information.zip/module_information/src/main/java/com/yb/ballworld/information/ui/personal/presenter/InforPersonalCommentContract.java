package com.yb.ballworld.information.ui.personal.presenter;

import com.yb.ballworld.information.data.CommitBean;
import com.yb.ballworld.information.ui.personal.bean.CommentBean;
import com.yb.ballworld.information.ui.personal.constant.PraiseCallbackListener;
import java.util.List;

/**
 * Desc: 个人页面-评论
 * Author: JS-Kylo
 * Created On: 2019/10/11 11:35
 */
public class InforPersonalCommentContract {
    //--------------------------------View层----------------------------
    public interface InfoCommentView {
        //请求加载中
        void requestLoading();

        //请求成功
        void resultSuccess(List<CommentBean> data,int page);

        //请求失败
        void resultFail(int type,String errMsg);

        //刷新成功
        void resultRefreshSuccess();

        //刷新失败
        void resultRefreshFail(String errorMsg);

        //加载更多成功
        void resultLoadMoreSuccess(int type);

        //加载更多失败
        void resultLoadMoreFail(String errorMsg);

        //点赞成功
        void praiseSuccess(int position,int commentId);
        //点赞失败
        void praiseFail(String errorMsg);
    }

    //--------------------------------Presenter层----------------------------
    public interface InfoCommentPresenter {

        //请求数据方法
        void loadData(int page);

        //刷新
        void refreshData();

        //加载更多
        void loadMoreData();

        //点赞
        void praiseComment(int position,int commentId);

        //绑定View
        void attachView(InfoCommentView view);

        //解绑View
        void detachView();
    }
}
