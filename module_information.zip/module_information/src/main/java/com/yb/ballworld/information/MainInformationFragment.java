package com.yb.ballworld.information;


import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager.widget.ViewPager;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.gyf.immersionbar.ImmersionBar;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.yb.ballworld.baselib.base.activity.BaseActivity;
import com.yb.ballworld.baselib.base.adapter.BaseFragmentPageAdapter;
import com.yb.ballworld.baselib.base.fragment.BaseFragment;
import com.yb.ballworld.baselib.base.fragment.BasePageFragment;
import com.yb.ballworld.baselib.core.RouterHub;
import com.yb.ballworld.baselib.utils.AppUtils;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.baselib.widget.placeholder.HomePlaceholderView;
import com.yb.ballworld.baselib.widget.tab.OnTabSelectListener;
import com.yb.ballworld.common.im.entity.PushScore;
import com.yb.ballworld.common.widget.InfoTabLayout;
import com.yb.ballworld.information.ui.community.view.CommunityFragment;
import com.yb.ballworld.information.ui.home.bean.TabEntity;
import com.yb.ballworld.information.ui.home.constant.FailStateConstant;
import com.yb.ballworld.information.ui.home.constant.InfoSpecialPushParams;
import com.yb.ballworld.information.ui.home.listener.OnMultiClickListener;
import com.yb.ballworld.information.ui.home.presenter.InfoTabContract;
import com.yb.ballworld.information.ui.home.presenter.InfoTabPresenter;
import com.yb.ballworld.information.ui.home.utils.InfoShareUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;;
import com.yb.ballworld.information.ui.home.view.InfoPublishPopView;
import com.yb.ballworld.information.ui.home.view.InfoWebNavFragment;
import com.yb.ballworld.information.ui.home.view.InformationIndexHotFragment;
import com.yb.ballworld.information.ui.home.view.InformationVideoFragment;
import com.yb.ballworld.information.ui.home.widget.InfoShareDialog;
import com.yb.ballworld.information.ui.home.widget.bfFab.FabAlphaAnimate;
import com.yb.ballworld.information.ui.home.widget.bfFab.FabAttributes;
import com.yb.ballworld.information.ui.home.widget.bfFab.SuspensionFab;

import java.util.ArrayList;
import java.util.List;

/**
 * 资讯主页
 *
 * @author ink
 */
@Route(path = RouterHub.INFORMATION_MAIN_FRAGMENT)
public class MainInformationFragment extends BasePageFragment implements InfoTabContract.IInfoTabView {

    //TabLayout
    private InfoTabLayout xTabLayout;
    //ViewPager
    private ViewPager viewPager;
    //加载状态缺省图
    private HomePlaceholderView placeholder;
    //右上角点击进入收藏
    private RelativeLayout rlRightCollect;
    //fragments
    private ArrayList<BaseFragment> fragments = new ArrayList<>();
    //titles
    private ArrayList<String> titles = new ArrayList<>();
    private List<TabEntity.CustomLablesBean> lablesBeans;
    private InfoTabPresenter presenter;
    private View fabTop;

    @Override
    public int getLayoutResID() {
        return R.layout.activityr_main_info;
    }

    @Override
    public void onSupportVisible() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ImmersionBar.with(this)
                    .statusBarDarkFont(true, 0.2f)
                    .statusBarColor(R.color.white)
                    .navigationBarColor(R.color.white)
                    .init();
        } else {
            ImmersionBar.with(this)
                    .statusBarDarkFont(true, 0.2f)
                    .statusBarColor(R.color.colorPrimaryDark)
                    .navigationBarColor(R.color.white)
                    .init();
        }
    }

    @Override
    public boolean isNeedStatusView() {
        return true;
    }

    @Override
    public void initView() {
        initViews();
        initPresenter();
    }

    @Override
    protected void initEvent() {
        super.initEvent();
        initReLoadEvent();
        initClickEvent();
        initTabLayoutEvent();
    }

    /**
     * tabLayout监听选中事件
     */
    private void initTabLayoutEvent() {

    }

    /**
     * 点击事件
     */
    private void initClickEvent() {
        rlRightCollect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lablesBeans.get(xTabLayout.getCurrentTab()).getLableType() == 3)
                    NavigateToDetailUtil.navigateToCollect(MainInformationFragment.this.getPageActivity(),1);
                else
                    NavigateToDetailUtil.navigateToCollect(MainInformationFragment.this.getPageActivity(),0);
//                NavigateToDetailUtil.navigateToPublishComment(getPageActivity(),"796a612560be4b4484f5eb6f7760a4e5","");
//                InfoShareUtil.share(getPageActivity());
            }
        });
    }

    /**
     * 初始化重新加载数据
     */
    private void initReLoadEvent() {
        placeholder.setPageErrorRetryListener(v -> presenter.loadData());
    }

    /**
     * 初始化presenter
     */
    private void initPresenter() {
        presenter = new InfoTabPresenter();
        presenter.attachView(this);
    }

    /**
     * 初始化数据
     */
    @Override
    protected void initData() {
        super.initData();
        presenter.loadData();
    }

    /**
     * 初始化Views
     */
    private void initViews() {
        // 设置状态栏高度
        View view = findView(R.id.statusView);
        if (isNeedStatusView()) {
            setStatusBarHeight(view, true);
            view.setBackgroundColor(getColor(R.color.color_d7d7d7));
        } else {
            view.setVisibility(View.GONE);
        }

        //返回键
        findView(R.id.tvTitle).setOnClickListener(v -> {
            if (getActivity() instanceof BaseActivity) {
                BaseActivity baseActivity = (BaseActivity) getActivity();
                //baseActivity.setStatusBar(baseActivity.getStatusBarColor());
            }
        });
        xTabLayout = findView(R.id.xtablayout_info);
        viewPager = findView(R.id.viewPager_info);
        placeholder = findView(R.id.placeholder);
        rlRightCollect = findView(R.id.rl_right_collect);
        xTabLayout.setGradientIndicatorDrawable(R.drawable.indicator_info_home);

        showPublishBtn();

    }

    private void showPublishBtn() {
        fabTop = findView(R.id.iv_publish_article_video);
        if ("com.yb.ballworld.dev".equals(AppUtils.getPackageName())) {
            fabTop.setVisibility(View.VISIBLE);
        } else {
            fabTop.setVisibility(View.GONE);
        }

        //todo 需要添加 显示只是为开发提供入口 实际没有这个需求
        fabTop.setVisibility(View.GONE);

        fabTop.setOnClickListener(new OnMultiClickListener() {
            @Override
            public void onMultiClick(View v) {
                initPopView(fabTop);
//                testInfoPush();
            }
        });


    }

    /**
     * 测试资讯推动
     */
    private void testInfoPush() {
        PushScore pushScore = new PushScore();
        pushScore.setHostTeamScore(50);
        pushScore.setGuestTeamScore(49);
        pushScore.setMatchId(100);
        LiveEventBus.get().with(InfoSpecialPushParams.RECEIPT_KEY_SCORE).post(pushScore);
    }

    private void initPopView(View anchorView) {
        FragmentActivity activity = getActivity();
        if (activity != null && !activity.isFinishing()) {
            InfoPublishPopView popView = new InfoPublishPopView(activity, ""+LoginOrdinaryUtils.INSTANCE.getUserId());
            popView.showPop(anchorView);

        }
    }


    @Override
    public void setTextSize(int id, Float size) {

    }

    @Override
    public void setTextSize(TextView textView, Float size) {

    }

    @Override
    public Fragment getFragment() {
        return this;
    }

    /**
     * 请求加载中
     */
    @Override
    public void requestLoading() {
        showLoading(placeholder);
    }

    /**
     * 请求失败
     *
     * @param type 失败的类型
     */
    @Override
    public void resultFail(int type) {
        switch (type) {
            case FailStateConstant.TYPE_ERROR:   //加载失败
                showError(placeholder, "网络出了小差，连接失败~");
                break;
            case FailStateConstant.TYPE_EMPTY:   //数据为空
                showEmpty(placeholder, "暂无数据");
                break;

            default:
                break;
        }
    }

    /**
     * 请求tab成功回调
     *
     * @param list tab数组
     */
    @Override
    public void resultTabSuccess(List<TabEntity.CustomLablesBean> list) {
        placeholder.hideLoading();
        adapterTab(list);
    }

    /**
     * 适配tab栏目数据
     * 目前栏目标签有改动， 根据lableType 判断，如果是0，则点击该标签时去调用 /qiutx-news/app/news/page 接口，
     * 参数带上我们返回的sportType,mediaType,categoryId
     * 如果是1，则根据jumpUrl跳转H5页面
     * 如果是2，则调用app首页接口
     * 即/qiutx-news/app/index
     *
     * @param list
     */
    private void adapterTab(List<TabEntity.CustomLablesBean> list) {
        this.lablesBeans = list;
        for (TabEntity.CustomLablesBean homeIndexTabBean : list) {
            String id = homeIndexTabBean.getId();
            String name = homeIndexTabBean.getName();
            int lableType = homeIndexTabBean.getLableType();
            String categoryId = homeIndexTabBean.getCategoryId();
            String mediaType = homeIndexTabBean.getMediaType();
            String sportType = homeIndexTabBean.getSportType();
            String jumpUrl = homeIndexTabBean.getJumpUrl();
            titles.add(isNotNull(name));
            if (lableType == 0) { //如果是0，则点击该标签时去调用 /qiutx-news/app/news/page
                if ("1".equals(mediaType)) { //视频
                    fragments.add(InformationVideoFragment.newInstance(isNotNull(categoryId), isNotNull(mediaType), isNotNull(sportType)));
                } else {//图文
                    fragments.add(InformationIndexHotFragment.newInstance(lableType,isNotNull(categoryId), isNotNull(mediaType), isNotNull(sportType)));
                }
            } else if (lableType == 1) {//如果是1，则根据jumpUrl跳转H5页面
                //2019/10/18 h5页面
                fragments.add(InfoWebNavFragment.newInstance(jumpUrl));
            } else if (lableType == 2) {//如果是2，则调用app首页接口
                fragments.add(InformationIndexHotFragment.newInstance(lableType,isNotNull(categoryId), isNotNull(mediaType), isNotNull(sportType)));
            } else if (lableType == 3) {
                fragments.add(CommunityFragment.newInstance());
            } else {
                // 2019/10/18
                fragments.add(InformationIndexHotFragment.newInstance(lableType, isNotNull(categoryId), isNotNull(mediaType), isNotNull(sportType)));
            }

        }
        LogUtils.INSTANCE.e("===z","title = " + titles.size());
        LogUtils.INSTANCE.e("===z","fragments = " + fragments.size());
        //适配tab栏目
        if (titles.size() != 0 && fragments.size() != 0) {
            BaseFragmentPageAdapter adapter = new BaseFragmentPageAdapter(getChildFragmentManager(), fragments, titles);
            viewPager.setAdapter(adapter);
            viewPager.setOffscreenPageLimit(fragments.size());
            xTabLayout.setViewPager(viewPager);
            xTabLayout.setGradientIndicatorDrawable(R.drawable.indicator_info_home);

            viewPagerEvent(viewPager);
        }
    }

    private void viewPagerEvent(ViewPager viewPager) {
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                BaseFragment fragment = fragments.get(position);
                if (fragment != null) {
                    if (fragment instanceof CommunityFragment) {//社区不显示资讯的发布按钮
                        fabTop.setVisibility(View.GONE);
                    } else {                                    //资讯显示资讯的发布按钮
//                        fabTop.setVisibility(View.VISIBLE); //必须注掉
                        fabTop.setVisibility(View.GONE);
                    }
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    private String isNotNull(String s) {
        return !TextUtils.isEmpty(s) ? s : "";
    }


}