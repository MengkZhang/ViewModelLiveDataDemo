package com.yb.ballworld.information.widget.listener;

import java.util.List;

public interface OnElementClickListener2<T> {
        public void onElementClick(T parentItem,String url, int type, int position, List<String> peerList);
    }