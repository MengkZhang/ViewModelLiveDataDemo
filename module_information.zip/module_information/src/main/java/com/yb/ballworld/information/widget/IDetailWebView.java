package com.yb.ballworld.information.widget;

import android.webkit.WebView;

import com.yb.ballworld.information.widget.listener.OnScrollBarShowListener;

/**
 * Desc: <功能简述>
 * Author: JS-Dugu
 * Created On: 2019/10/15 21:14
 */
public interface IDetailWebView {

    void setScrollView(DetailScrollView scrollView);

    boolean canScrollVertically(int direction);

    void customScrollBy(int dy);

    void customScrollTo(int toY);

    int customGetContentHeight();

    int customGetWebScrollY();

    int customComputeVerticalScrollRange();

    void startFling(int vy);

    void setOnScrollBarShowListener(OnScrollBarShowListener listener);

    WebView getView();
}
