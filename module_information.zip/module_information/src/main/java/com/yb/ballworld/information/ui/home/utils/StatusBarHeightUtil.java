package com.yb.ballworld.information.ui.home.utils;

import android.view.View;
import android.widget.LinearLayout;

/**
 * Desc
 * Date 2019/11/7
 * author mengk
 */
public class StatusBarHeightUtil {
    public static void getStatusBarHeight(View statusView,int statusHeight) {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) statusView.getLayoutParams();
        layoutParams.height = statusHeight;
        statusView.setLayoutParams(layoutParams);
    }
}
