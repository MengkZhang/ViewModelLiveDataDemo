package com.yb.ballworld.information.ui.detail;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.alibaba.android.arouter.launcher.ARouter;
import com.bfw.util.ToastUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.ethanhua.skeleton.Skeleton;
import com.ethanhua.skeleton.SkeletonScreen;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.constant.Constant;
import com.yb.ballworld.baselib.core.RouterHub;
import com.yb.ballworld.baselib.data.UserInfo;
import com.yb.ballworld.baselib.utils.JsonUtils;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.common.base.mvp.BaseMvpActivity;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.sharesdk.ShareSdkParamBean;
import com.yb.ballworld.common.widget.CommonTitleBar;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.data.ArticleBean;
import com.yb.ballworld.information.data.ArticleDetailBean;
import com.yb.ballworld.information.data.CommitBean;
import com.yb.ballworld.information.data.RootBean;
import com.yb.ballworld.information.ui.event.InforCommentCountEvent;
import com.yb.ballworld.information.ui.home.bean.IndexLableDetailBean;
import com.yb.ballworld.information.ui.home.bean.InfoDetailUserFollowBean;
import com.yb.ballworld.information.ui.home.bean.PublishCommentResBean;
import com.yb.ballworld.information.ui.home.constant.PublishIntentParam;
import com.yb.ballworld.information.ui.home.constant.PublishReqCode;
import com.yb.ballworld.information.ui.home.utils.JZReleaseUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.home.view.PublishCommentActivity;
import com.yb.ballworld.information.ui.home.widget.DeleteImgDialog;
import com.yb.ballworld.information.ui.home.widget.InfoDetailUserFollowView;
import com.yb.ballworld.information.ui.personal.view.InformationPersonalActivity;
import com.yb.ballworld.information.ui.personal.view.InformationPersonalActivityNew;
import com.yb.ballworld.information.utils.CommondUtil;
import com.yb.ballworld.information.utils.HtmlParseData;
import com.yb.ballworld.information.widget.FlowTagLayout;
import com.yb.ballworld.information.widget.GoodView;
import com.yb.ballworld.information.widget.MyLinearLayoutManager;
import com.yb.ballworld.information.widget.NewsDetailBottomLayout;
import com.yb.ballworld.information.widget.RichWebView2;
import com.yb.ballworld.information.widget.TagAdapter;
import com.yb.ballworld.information.widget.bubbleview.BubblePopupWindow;
import com.yb.ballworld.information.widget.bubbleview.BubbleTextView;
import com.yb.ballworld.information.widget.bubbleview.RelativePos;
import com.yb.ballworld.information.widget.listener.OnElementClickListener;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import cn.jzvd.Jzvd;

import static com.yb.ballworld.common.widget.CommonTitleBar.ACTION_LEFT_BUTTON;
import static com.yb.ballworld.information.widget.FlowTagLayout.FLOW_TAG_CHECKED_NONE;
import static com.yb.ballworld.information.widget.bubbleview.RelativePos.CENTER_HORIZONTAL;

/**
 * Desc: <功能简述>
 * Author: JS-Dugu
 * Created On: 2019/10/15 23:03
 */
@Route(path = RouterHub.INFORMATION_NEW_TEXT_DETAIL)
public class NewsTextDetailActivity extends BaseMvpActivity<NewsTextDetailPresenter>
        implements /*FlowTagLayout.OnTagClickListener,*/ OnElementClickListener,
        BaseQuickAdapter.OnItemClickListener, BaseQuickAdapter.OnItemChildClickListener, BaseQuickAdapter.OnItemLongClickListener, RecyclerView.OnItemTouchListener {
    private BubblePopupWindow mBubblePopupWindow;
    private NewsTextDetailQuickAdapter newsTextDetailQuickAdapter;
    private TextView tvPublisher, tvPublishTime;
    private TextView tvDetailTitle;
    // private GoodView goodView;
    private ImageView articleLike;
    private TextView articleLikeCount;
    private String newsId = "";
    private PlaceholderView placeholderView;
    private RecyclerView recyclerView;
    private RichWebView2 richWebView;
    private FlowTagLayout flowTagLayout;
//    private TagAdapter<IndexLableDetailBean> mTagAdapter;
    private TagAdapter mTagAdapter;
    private SkeletonScreen skeletonScreen;
    private SmartRefreshLayout mSmartRefreshLayout;
    private List<MultiItemEntity> mMultiList = new ArrayList<>();
    private NewsDetailBottomLayout newsDetailBottomLayout;
    private View tvAboutInfoLayout;
    private ShareSdkParamBean mShareSdkParamBean = null;
    private int parentCommitPosition;
    private List<Integer> myCommitList = new ArrayList<>();
    private boolean hasAddCommentHead;

    private androidx.lifecycle.Observer<InforCommentCountEvent> mObserver = new Observer<InforCommentCountEvent>() {
        @Override
        public void onChanged(InforCommentCountEvent inforCommentCountEvent) {
            if (parentCommit != null && parentCommit.getId() == inforCommentCountEvent.getCommentId() && parentCommit.getSonNum() < inforCommentCountEvent.getCommentCount()) {
                newsTextDetailQuickAdapter.updateCommentCount(parentCommitPosition, inforCommentCountEvent.getCommentCount());
            }
        }
    };
    private InfoDetailUserFollowView followView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LiveEventBus.get().with(LiveEventBusKey.KEY_INFOR_COMMENT_COUNT, InforCommentCountEvent.class).observe(this, mObserver);
    }

    @Override
    protected void getIntentData() {
        LifecycleAutoManager.join(this);
    }

    @Override
    protected SmartRefreshLayout getSmartRefreshLayout() {
        return mSmartRefreshLayout;
    }

    @Override
    public void initPresenter() {
        if (mPresenter != null) {
            mPresenter.setVM(this);
        }
        // newsId = "168977dc0d514b8a98261046d9c6941f";
        Intent intent = getIntent();
        if (intent != null) {
            newsId = intent.getStringExtra("NEWS_ID");
            mPresenter.init(newsId);
            // isVideo = intent.getBooleanExtra("NEWS_TYPE", false);
        }
        if (TextUtils.isEmpty(newsId)) {
            showToastMsgShort(getResources().getString(R.string.prompt_articleBeDeleted));
            finish();
        }
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_newstext_detail;
    }

    @Override
    public PlaceholderView getPlaceholderView() {
        return placeholderView;
    }

    @Override
    protected void initView() {
        recyclerView = F(R.id.recyclerView);
        mSmartRefreshLayout = F(R.id.smartRefreshLayout);
        mSmartRefreshLayout.setRefreshFooter(getRefreshFooter());
        mSmartRefreshLayout.setEnableAutoLoadMore(true);
        newsDetailBottomLayout = F(R.id.newsDetailBottomLayout);
        initRefreshView();
        enableRefresh(false);
        enableLoadMore(false);
        placeholderView = F(R.id.placeholderView);
        // goodView = new GoodView(this);
        // goodView.setImage(getResources().getDrawable(R.drawable.icon_priase_info));
    }

    @Override
    protected void bindEvent() {
        ((CommonTitleBar) F(R.id.infor_titlebar)).setListener((v, action, extra) -> {
            if (action == ACTION_LEFT_BUTTON) {
                finish();
            }
        });
        if (getPlaceholderView() != null) {
            getPlaceholderView().setPageErrorRetryListener(v -> initData());
        }

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
//           // 两者都可以 webSetting.setMixedContentMode(webSetting.getMixedContentMode());
//           if (richWebView != null) {
//               richWebView.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
//           }
            recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
                @Override
                public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                    super.onScrollStateChanged(recyclerView, newState);
                    LogUtils.INSTANCE.d("NewsTextDetailActivity", "newState:" + newState);
//                   try {
//                       if (newState == RecyclerView.SCROLL_STATE_IDLE
//                               || newState == RecyclerView.SCROLL_STATE_DRAGGING) {
//                           if (recyclerView.getLayerType() != View.LAYER_TYPE_SOFTWARE) {
//                               recyclerView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
//                               recyclerView.invalidate();
//                           }
//                           if (richWebView != null) {
//                               if (richWebView.getLayerType() != View.LAYER_TYPE_SOFTWARE) {
//                                   richWebView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
//                               }
//                           }
//                       } else if (newState > RecyclerView.SCROLL_STATE_DRAGGING) {
//                           if (recyclerView.getLayerType() != View.LAYER_TYPE_HARDWARE) {
//                               recyclerView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
//                               recyclerView.invalidate();
//                           }
//                           if (richWebView != null) {
//                               if (richWebView.getLayerType() != View.LAYER_TYPE_HARDWARE) {
//                                   richWebView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
//                               }
//                           }
//                       }
//                   } catch (Exception e) {
//                       e.printStackTrace();
//                   }
                }

                @Override
                public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                    super.onScrolled(recyclerView, dx, dy);
                }
            });
        } else {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED, WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
        }

        newsTextDetailQuickAdapter = new NewsTextDetailQuickAdapter(null, this);
        LinearLayoutManager linearLayoutManager = new MyLinearLayoutManager(this);
        linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);
        newsTextDetailQuickAdapter.bindToRecyclerView(recyclerView);
        newsTextDetailQuickAdapter.setOnItemClickListener(this);
        newsTextDetailQuickAdapter.setOnElementClickListener(this);
        newsTextDetailQuickAdapter.setOnItemChildClickListener(this);
        newsTextDetailQuickAdapter.setOnItemLongClickListener(this);
        recyclerView.addOnItemTouchListener(this);
        JZReleaseUtil.observeReleaseVideos(recyclerView, newsTextDetailQuickAdapter.getVideoViewId());
        setHeader(recyclerView);
    }

    /**
     * 判断是否显示相关视频或相关新闻
     *
     * @param isShow 是否显示
     */
    private void visibleAboutInfo(boolean isShow) {
        //显示\隐藏相关
        tvAboutInfoLayout.setVisibility(isShow ? View.VISIBLE : View.GONE);
    }

    private void setHeader(RecyclerView view) {
        View header = LayoutInflater.from(this).inflate(R.layout.item_detail_header2, view, false);
        richWebView = header.findViewById(R.id.richWebView2);
        richWebView.setOnElementClick(this);
        newsTextDetailQuickAdapter.setHeaderView(header);
        tvPublisher = header.findViewById(R.id.tvPublisher);
        tvPublishTime = header.findViewById(R.id.tvPublishTime);
        tvDetailTitle = header.findViewById(R.id.tvDetailTitle);
        articleLike = header.findViewById(R.id.articleLike);
        tvAboutInfoLayout = header.findViewById(R.id.inforDetail_titleLayout);
        articleLikeCount = header.findViewById(R.id.inforDetail_likeCount);
        flowTagLayout = header.findViewById(R.id.inforDetail_flowTagLayout);
        flowTagLayout.setTagCheckedMode(FLOW_TAG_CHECKED_NONE);
        flowTagLayout.setAdapter(mTagAdapter = new TagAdapter<>(this));
        flowTagLayout.setVisibility(View.GONE);

//        flowTagLayout.setOnTagClickListener(this);
        articleLike.setOnClickListener(this);
        header.findViewById(R.id.inforDetail_shareLayout).setOnClickListener(this);

        followView = header.findViewById(R.id.follow_view_info_news);
    }

    private void setFollowView(int userId,String name,String time,String headImgUrl,boolean isAttention) {
        InfoDetailUserFollowBean followBean = new InfoDetailUserFollowBean();
        followBean.setTime(time);
        followBean.setUserName(name);
        followBean.setUserHeadImg(headImgUrl);
        followBean.setHasFollow(isAttention);
        followBean.setUserId(String.valueOf(userId));
        followView.setUserInfo(followBean);
        followView.setOnFollowClickListener(view -> {
            if (followBean.isHasFollow()) { //已经关注了 点击取消关注
                DeleteImgDialog dialog = new DeleteImgDialog(NewsTextDetailActivity.this,
                        NewsTextDetailActivity.this.getResources().getString(R.string.info_detail_dialog_quit_follow));
                dialog.show();
                dialog.setSureOrCancelListener(new DeleteImgDialog.SureOrCancelListener() {
                    @Override
                    public void cancel() {
                        dialog.dismiss();
                    }

                    @Override
                    public void sure() {
                        dialog.dismiss();
                        // TODO: 2019/11/8 请求接口
                        reqFollowOrCancel(userId,false,view,followBean);
//                        followBean.setHasFollow(false);
//                        followView.changeFollow(view,followBean);
                    }
                });

            } else {                        //没有关注 点击关注
                // TODO: 2019/11/8 请求接口
                reqFollowOrCancel(userId,true,view,followBean);
//                followBean.setHasFollow(true);
//                followView.changeFollow(view,followBean);
            }

        });
    }

    /**
     * 关注或者取消关注
     * @param followUserId
     * @param isFollow
     * @param view
     * @param followBean
     */
    private void reqFollowOrCancel(int followUserId,boolean isFollow,View view,InfoDetailUserFollowBean followBean) {
        mPresenter.attentionAction(followUserId, isFollow, new LifecycleCallback(this) {
            @Override
            public void onSuccess(Object data) {
                //关注或者取消关注成功
                followBean.setHasFollow(isFollow);
                followView.changeFollow(view,followBean);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                ToastUtils.showToast(getResources().getString(R.string.prompt_followFailed));
            }
        });
    }

    @Override
    protected void initData() {
        // showDialogLoading();
        View rootView = F(R.id.rootView);
        skeletonScreen = Skeleton.bind(rootView)
                .load(R.layout.layout_place_detail_loading)
                .duration(1000)
                .shimmer(true)//是否开启动画
                .color(R.color.white)
                .angle(0)
                .show();
        mPresenter.loadInfor();
    }

    @Override
    protected void processClick(View view) {
        int viewId = view.getId();
        if (viewId == R.id.articleLike) {

            articleLike.setImageResource(R.drawable.icon_priase_info);
            // goodView.show(articleLike);
            if (!(Boolean) articleLike.getTag()) {
                articleLike.setTag(true);
                mPresenter.addArticleLike();
                showLike(mPresenter.INFOR_DETAIL, 0, 0, true);
            }
        } else if (viewId == R.id.inforDetail_shareLayout
                || (viewId == R.id.infor_titlebar_share)) {
            //分享
//            ToastUtils.INSTANCE.showToast(R.string.prompt_coding);
            if (mShareSdkParamBean != null) {
                NavigateToDetailUtil.showShareToast(view, this, mShareSdkParamBean);
            }
        } else if (viewId == R.id.infor_titlebar_back) {
            finish();
        }
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
        if (adapter.getItemCount() > position) {
            NewsTextDetailQuickAdapter inforDetailQuickAdapter = (NewsTextDetailQuickAdapter) adapter;
            MultiItemEntity entity = inforDetailQuickAdapter.getItem(position);
            if (entity instanceof CommitBean) {
                parentCommit = (CommitBean) entity;
                parentCommitPosition = position;
                NavigateToDetailUtil.navigateToCommentList(this, mPresenter.getNewsId(), (Serializable) entity);
            } else if (entity instanceof ArticleBean) {
                NavigateToDetailUtil.navigateToDetail(this, ((ArticleBean) adapter.getItem(position)).getId(), ((ArticleBean) adapter.getItem(position)).getMediaType() == 1);
            }

        }
    }

    @Override
    public void onElementClick(String url, int type, int position, List<String> peerList) {
        if (type == richWebView.getTYPE_IMG()) {
            if (!CommondUtil.isEmpty(peerList)) {
                if (mShareSdkParamBean != null) {

                        String title = mShareSdkParamBean.getTitle();
                        String titleUrl = mShareSdkParamBean.getTitleUrl();
                        String text = mShareSdkParamBean.getText();
                        String imageUrl = mShareSdkParamBean.getImageUrl();
                        String shareUrl = mShareSdkParamBean.getUrl();
                        NavigateToDetailUtil.navigateToGalleryActivity(this,peerList,position,
                                title,titleUrl,text,shareUrl);

                } else {
                    NavigateToDetailUtil.navigateToGalleryActivityWithoutShare(this,peerList,position);
                }
                // TODO: 2019/11/12 需要修改跳转
            }
        } else if (type == richWebView.getTYPE_LINK()) {
            InformationLinkNewActivity.start(this, url, "", true, true, 0);
        }
    }

//    @Override
//    public void onItemClick(FlowTagLayout parent, View view, int position) {
//        if (parent.getAdapter().getCount() > position) {
//            ToastUtils.INSTANCE.showToast(parent.getAdapter().getItem(position).toString());
//            Object item = parent.getAdapter().getItem(position);
//            if (item != null && item instanceof IndexLableDetailBean) {
//                int type = ((IndexLableDetailBean) item).getType();
//                String referId = ((IndexLableDetailBean) item).getReferId();
//            }
//        }
//    }

    /**
     * 显示文章详情
     *
     * @param detail
     */
    public void showInfor(ArticleDetailBean detail) {
        if (skeletonScreen != null) {
            skeletonScreen.hide();
        }
        hideDialogLoading();
        showPageContent();
        List<MultiItemEntity> itemEntities = new ArrayList<>();
        ArticleBean article = detail.getNews();
        HtmlParseData htmlParseData = detail.getHtmlParseData();
        if (article != null) {
            //mPresenter.loadMore();
            article.setHtmlParseData(htmlParseData);
            article.setItemType(InforConstant.ItemType.DETAIL_HEADER_NEWS);
            richWebView.setDocHtml(htmlParseData);

            System.out.println("DocHtml:" + htmlParseData.getDocHtml());

            tvPublisher.setText(htmlParseData.getPublisher());
            tvPublishTime.setText(htmlParseData.getPublishTime());
            tvDetailTitle.setText(htmlParseData.getDetailTitle());
            articleLikeCount.setText(String.valueOf(article.getLikeCount()));
            articleLike.setImageResource(article.isLike() ? R.drawable.icon_priase_info : R.drawable.icon_priase_info_normal);
            //articleLike.setClickable(!article.isLike());
            articleLike.setTag(article.isLike());
            mShareSdkParamBean = new ShareSdkParamBean(article.getTitle(), article.getWebShareUrl(), article.getPreview(), article.getImgUrl(), article.getWebShareUrl());
            newsDetailBottomLayout.setParam(article.getCommentStatus(), mPresenter.getNewsId(), "", article.isFavorites());
            newsDetailBottomLayout.setShareSdkParamBean(mShareSdkParamBean);
            //显示热门标签
            List<String> tags = CommondUtil.arrayToList(CommondUtil.splitBySign(article.getKeywords(), ","));
            List<IndexLableDetailBean> labels = article.getLabels();

            //判断是否有labels 如果没有 在判断是否有tags 有显示tag 没有则不显示
            if (labels != null && labels.size() != 0) { //新版本有labels
                flowTagLayout.setVisibility(View.VISIBLE);
                mTagAdapter.clearAndAddAll(labels);

            } else {                                    //兼容老版本的tags
                if (tags != null && tags.size() != 0) {
                    flowTagLayout.setVisibility(View.VISIBLE);
                    mTagAdapter.clearAndAddAll(tags);

                } else { //没有标签

                    flowTagLayout.setVisibility(View.GONE);
                }
            }

//            boolean needShow = (labels != null && labels.size() != 0);
////            boolean needShow = tags != null;
//            flowTagLayout.setVisibility(needShow ? View.VISIBLE : View.GONE);
//            if (needShow) {
////                mTagAdapter.clearAndAddAll(tags);
//                mTagAdapter.clearAndAddAll(labels);
//            }

            List<ArticleBean> articleBeanList = detail.getCurrentNews();
            if (!CommondUtil.isEmpty(articleBeanList)) {
                visibleAboutInfo(true);
                itemEntities.addAll(articleBeanList);
                // newsTextDetailQuickAdapter.addData(articleBeanList);
            } else {
                visibleAboutInfo(false);
            }

            //itemEntities.add(new RootBean(InforConstant.ItemType.DETAIL_HEADER_COMMENT, 0));
            mMultiList.addAll(itemEntities);
            newsTextDetailQuickAdapter.addData(itemEntities);
            // newsTextDetailQuickAdapter.notifyDataSetChanged();
            mPresenter.setFristPage(true);
            onLoadMoreData();

            setFollowView(article.getUserId(),article.getNickName(),article.getCreatedDate(),article.getHeadImgUrl(),article.isAttention());
        }

    }


    @Override
    protected void onLoadMoreData() {
        super.onLoadMoreData();
        mPresenter.loadMore();
    }

    public void showCommits(List<CommitBean> commitBeanList, boolean firstPage) {
        if (mPresenter.isFristPage()) {
            hideDialogLoading();
        }
        newsTextDetailQuickAdapter.setHasMore(mPresenter.hasMore());
        enableLoadMore(mPresenter.hasMore());
        stopLoadMore();
        if (commitBeanList != null) {
            if (firstPage) {
                List<MultiItemEntity> entityList = new ArrayList<>();
                setCommentHead();
                entityList.addAll(mMultiList);
                entityList.addAll(commitBeanList);
                newsTextDetailQuickAdapter.replaceData(entityList);
                mPresenter.setFristPage(false);
                myCommitList.clear();
            } else {
                int size = commitBeanList.size() - 1;
                for (int i = size; i >= 0; i--) {
                    if (myCommitList.contains(commitBeanList.get(i).getId())) {
                        commitBeanList.remove(i);
                    }
                }
                newsTextDetailQuickAdapter.addData(commitBeanList);

            }
            // mNewsAdapter.notifyDataSetChanged();
        }
    }

    private void setCommentHead() {
        if (!hasAddCommentHead) {
            mMultiList.add(new RootBean(InforConstant.ItemType.DETAIL_HEADER_COMMENT, 0));
            hasAddCommentHead = true;
        }
    }

    public void showEmpty(int area) {
        if (area == mPresenter.INFOR_COMMITS) {
            if (mPresenter.isFristPage()) {
                hideDialogLoading();
            }
            stopLoadMore();
            enableLoadMore(false);
        }
    }


    public void showError(int area) {
        if (skeletonScreen != null) {
            skeletonScreen.hide();
        }
        hideDialogLoading();
        hidePageLoading();
        if (area == mPresenter.INFOR_DETAIL) {
            showPageError("拉取文章失败");
            ToastUtils.showToast("拉取文章失败");
            //finish();
        } else if (area == mPresenter.INFOR_COMMITS) {
            stopLoadMore();
            ToastUtils.showToast("拉取评论失败");
        }
    }

    /**
     * 是否点赞成功/包括评论内的点赞
     *
     * @param area
     * @param id
     * @param isSuccess
     */
    public void showLike(int area, int id, int position, boolean isSuccess) {
        if (area == mPresenter.INFOR_DETAIL) {
            articleLike.setImageResource(isSuccess ? R.drawable.icon_priase_info : R.drawable.icon_priase_info_normal);
            if (isSuccess) {
                String likeCountstr = articleLikeCount.getText().toString();
                int likeCount = (TextUtils.isEmpty(likeCountstr) ? 0 : Integer.parseInt(likeCountstr)) + 1;
                articleLikeCount.setText(String.valueOf(likeCount));
                articleLike.setTag(true);
                LiveEventBus.get().with(LiveEventBusKey.KEY_NEWS_LIKE, String.class).post(mPresenter.getNewsId());
            } else {
                articleLike.setTag(false);
            }
        } else if (area == mPresenter.INFOR_COMMITS) {
            //评论区点赞
            List<MultiItemEntity> entityList = newsTextDetailQuickAdapter.getData();
            if (!CommondUtil.isEmpty(entityList) && position < entityList.size()) {
                MultiItemEntity bean = newsTextDetailQuickAdapter.getItem(position);
                //先用位置判断
                if (bean != null && bean instanceof CommitBean) {
                    CommitBean commitBean = ((CommitBean) bean);
                    if (commitBean.getId() == id) {
                        RecyclerView.ViewHolder viewHolder = recyclerView.findViewHolderForLayoutPosition(position + newsTextDetailQuickAdapter.getHeaderLayoutCount());
                        commitBean.setLike(isSuccess);
                        commitBean.setLikeCount(commitBean.getLikeCount() + (isSuccess ? 1 : 0));
                        if (viewHolder != null) {
                            newsTextDetailQuickAdapter.changedLike(commitBean, (BaseViewHolder) viewHolder);
                        } else {
                            newsTextDetailQuickAdapter.notifyItemChanged(position);
                        }
                    }
                } else {
                    //如果不匹配，用commitId去迭代匹配，都没有就放弃吧
                    boolean isMatched;
                    CommitBean commitBean = null;
                    int truthPos = 0;
                    for (MultiItemEntity entity : entityList) {
                        isMatched = entity instanceof CommitBean && (commitBean = (CommitBean) entity).getId() == id;
                        if (isMatched) {
                            RecyclerView.ViewHolder viewHolder = recyclerView.findViewHolderForLayoutPosition(truthPos + newsTextDetailQuickAdapter.getHeaderLayoutCount());
                            commitBean.setLike(isSuccess);
                            commitBean.setLikeCount(commitBean.getLikeCount() + (isSuccess ? 1 : 0));
                            if (viewHolder != null) {
                                newsTextDetailQuickAdapter.changedLike(commitBean, (BaseViewHolder) viewHolder);
                            } else {
                                newsTextDetailQuickAdapter.notifyItemChanged(position);
                            }
                            //mNewsAdapter.notifyItemChanged(truthPos);
                        }
                        truthPos++;
                    }
                }
            }
        }
        if (!isSuccess) {
            ToastUtils.showToast(R.string.prompt_likeFailed);
        }
    }

    /**
     * 跳转到登陆界面
     */
    private void toLogin() {
        ARouter.getInstance().build(RouterHub.USER_LOGIN_REGISTER_ACTIVITY)
                .navigation(this, Constant.COMMON_LOGIN_REQUEST);
    }


    @Override
    protected void onPause() {
        super.onPause();
        Jzvd.releaseAllVideos();
    }

    @Override
    public void onBackPressed() {
        if (Jzvd.backPress()) {
            return;
        }
        super.onBackPressed();
    }


    @Override
    public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
        NewsTextDetailQuickAdapter inforDetailQuickAdapter = (NewsTextDetailQuickAdapter) adapter;
        int eventType = inforDetailQuickAdapter.getChildEventType(view);
        MultiItemEntity entity = inforDetailQuickAdapter.getItem(position);
        if (entity != null) {
            switch (eventType) {
                case InforConstant.ItemEvent.USER_COMMENT:
                    InformationPersonalActivityNew.startActivity(this, CommondUtil.fitEmpty(((CommitBean) entity).getUserId()),InformationPersonalActivityNew.TYPE_NEWS);
                    break;
                case InforConstant.ItemEvent.REPLIES_COMMENT:
                    if (entity instanceof CommitBean) {
                        parentCommit = (CommitBean) entity;
                        parentCommitPosition = position;
                        NavigateToDetailUtil.navigateToCommentList(this, mPresenter.getNewsId(), (Serializable) entity);
                    }
                   // NavigateToDetailUtil.navigateToCommentList(this, mPresenter.getNewsId(), (Serializable) entity);
                    break;
                case InforConstant.ItemEvent.ROOT_SORT:
                    mPresenter.setHeatSort(newsTextDetailQuickAdapter.isHeat());
                    mPresenter.setFristPage(true);
                    showDialogLoading();
                    mPresenter.loadMore();
                    break;
                case InforConstant.ItemEvent.LIKE_COMMENT:
                    if (!((CommitBean) entity).isLike()) {
                        mPresenter.addCommitLike(((CommitBean) entity).getId(), position);
                        showLike(mPresenter.INFOR_COMMITS, ((CommitBean) entity).getId(), position, true);
                    }
                    break;
                default:
                    break;
            }
        }
    }

    private CommitBean parentCommit = null;

    @Override
    public boolean onItemLongClick(BaseQuickAdapter adapter, View view, int position) {
        NewsTextDetailQuickAdapter inforDetailQuickAdapter = (NewsTextDetailQuickAdapter) adapter;
        MultiItemEntity entity = inforDetailQuickAdapter.getItem(position);
        boolean ishandle = false;
        if (entity != null && entity.getItemType() == InforConstant.ItemType.DETAIL_COMMENT) {
            int mediaType = inforDetailQuickAdapter.getMediaType((CommitBean) entity);
            parentCommit = (CommitBean) entity;
            parentCommitPosition = position;
            // View achorView=inforDetailQuickAdapter.getAchorView(view, mediaType);
            showBubble(recyclerView, ((CommitBean) entity).getId());
            ishandle = true;
        }
        return ishandle;
    }

    private int replyId = 0;

    private void gotoPublish(int replyId) {
        Intent intent = new Intent(this, PublishCommentActivity.class);
        intent.putExtra(PublishIntentParam.NEWS_ID, mPresenter.getNewsId());
        intent.putExtra(PublishIntentParam.REPLY_ID, String.valueOf(this.replyId = replyId));
        startActivityForResult(intent, PublishReqCode.REQ_CODE);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data != null && PublishReqCode.REQ_CODE == resultCode && requestCode == PublishReqCode.REQ_CODE) {
            try {
                PublishCommentResBean resBean = data.getParcelableExtra(PublishIntentParam.RETURN_DATA);
                if (resBean != null) {
                    CommitBean bean = JsonUtils.INSTANCE.fromJson(JsonUtils.INSTANCE.toJson(resBean), CommitBean.class);
                    if (bean != null) {
                        if (replyId > 0 && String.valueOf(replyId).equals(bean.getReplyId()) && parentCommit != null) {
                            NavigateToDetailUtil.navigateToCommentList(this, mPresenter.getNewsId(), parentCommit);
                        } else {
                            UserInfo infor = LoginOrdinaryUtils.INSTANCE.getUserInfo();
                            if (infor != null) {
                                bean.setHeadImgUrl(infor.getImg());
                            }
                            myCommitList.add(bean.getId());
                            if (!hasAddCommentHead) {
                                mMultiList.add(new RootBean(InforConstant.ItemType.DETAIL_HEADER_COMMENT, 0));
                                List<MultiItemEntity> tempMulList = new ArrayList<>();
                                tempMulList.addAll(mMultiList);
                                tempMulList.add(bean);
                                newsTextDetailQuickAdapter.replaceData(tempMulList);
                                hasAddCommentHead = true;
                            } else {
                                if (newsTextDetailQuickAdapter.getData() != null
                                        && newsTextDetailQuickAdapter.getData().size() > mMultiList.size()) {
                                    newsTextDetailQuickAdapter.addData(mMultiList.size(), bean);
                                }
                            }
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private BubbleTextView bubbleView;

    private void showBubble(View commitView, int carryId) {
        if (mBubblePopupWindow == null) {
            View rootView = LayoutInflater.from(this).inflate(R.layout.simple_text_bubble, null);
            bubbleView = rootView.findViewById(R.id.popup_bubble);
            mBubblePopupWindow = new BubblePopupWindow(rootView, bubbleView);
            bubbleView.setOnClickListener(v -> {
                v.setEnabled(false);
                gotoPublish((Integer) v.getTag());
                v.setEnabled(true);
            });
            mBubblePopupWindow.setCancelOnTouch(true);
            mBubblePopupWindow.setCancelOnTouchOutside(true);
            mBubblePopupWindow.setCancelOnLater(3000);
        }
        bubbleView.setTag(carryId);
        mBubblePopupWindow.showArrowTo(commitView, new RelativePos(CENTER_HORIZONTAL, RelativePos.ABOVE), -clickX, -clickY);
        // mBubblePopupWindow.showAsDropDown(commitView,clickX,clickY, Gravity.NO_GRAVITY);
    }

    private int clickX;
    private int clickY;

    @Override
    public boolean onInterceptTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
        clickX = (int) e.getX();
        clickY = (int) e.getY();
        return false;
    }

    @Override
    public void onTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {

    }

    @Override
    public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

    }
}
