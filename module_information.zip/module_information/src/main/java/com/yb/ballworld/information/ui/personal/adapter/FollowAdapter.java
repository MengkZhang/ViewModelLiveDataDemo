package com.yb.ballworld.information.ui.personal.adapter;

import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.community.bean.Topic;
import com.yb.ballworld.information.ui.personal.bean.Follow;

public class FollowAdapter extends BaseQuickAdapter<Follow, BaseViewHolder> {
    public FollowAdapter(int layoutResId) {
        super(layoutResId);
    }

    @Override
    protected void convert(BaseViewHolder helper, Follow item, int pos) {
        ImageView ivHead = helper.itemView.findViewById(R.id.iv_head_image);
        ImageView ivAnchor = helper.itemView.findViewById(R.id.iv_anchor);
        ImageView ivWriter = helper.itemView.findViewById(R.id.iv_writer);

        TextView tvNick = helper.itemView.findViewById(R.id.tv_nick_name);
        TextView tvOther = helper.itemView.findViewById(R.id.tv_other);
        TextView tvFollow = helper.itemView.findViewById(R.id.tv_follow);

        Glide.with(ivHead.getContext())
                .load(item.getHeadImgUrl())
                .placeholder(R.drawable.user_default_icon2)
                .error(R.drawable.user_default_icon2)
                .into(ivHead);
        if (item.getIsAnchor()) {
            ivAnchor.setVisibility(View.VISIBLE);
        } else {
            ivAnchor.setVisibility(View.GONE);
        }

        if (item.getIsAuthor()) {
            ivWriter.setVisibility(View.VISIBLE);
        } else {
            ivWriter.setVisibility(View.GONE);
        }

        tvNick.setText(item.getNickname());

        tvFollow.setSelected(item.getIsAttention());
        tvOther.setText("粉丝" + item.getFansCount() + " |  帖子" + item.getPostCount());
        tvFollow.setTag(tvOther);

        helper.addOnClickListener(tvFollow.getId(),ivHead.getId(),tvNick.getId());

        if(isSelf(""+item.getUserId())){
            tvFollow.setVisibility(View.GONE);
        }else{
            tvFollow.setVisibility(View.VISIBLE);
        }

    }

    /**
     * 判断是否用户本人
     * @param userId
     * @return
     */
    private boolean isSelf(String userId){
        if(TextUtils.isEmpty(userId)){
            return false;
        }
        long uid= LoginOrdinaryUtils.INSTANCE.getUid();
        if(uid==0){
            return false;
        }
        return String.valueOf(uid).equals(userId);
    }
}
