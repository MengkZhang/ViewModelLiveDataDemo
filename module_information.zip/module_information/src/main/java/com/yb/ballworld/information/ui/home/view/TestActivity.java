package com.yb.ballworld.information.ui.home.view;

import android.view.View;

import androidx.viewpager.widget.ViewPager;

import com.yb.ballworld.baselib.base.adapter.BaseFragmentPageAdapter;
import com.yb.ballworld.baselib.base.fragment.BaseFragment;
import com.yb.ballworld.baselib.widget.tab.XTabLayout;
import com.yb.ballworld.common.base.SystemBarActivity;
import com.yb.ballworld.common.base.mvp.BaseMvpActivity;
import com.yb.ballworld.information.R;

import java.util.ArrayList;


/**
 * Desc 标签库 activity
 * Date 2019/11/7
 * author mengk
 */
public class TestActivity extends BaseMvpActivity {

    private XTabLayout tabLayout;
    private ViewPager viewPager;
    //fragments
    private ArrayList<BaseFragment> fragments = new ArrayList<>();
    //titles
    private ArrayList<String> titles = new ArrayList<>();

    @Override
    public int getLayoutId() {
        return R.layout.activity_publish_test;
    }

    @Override
    protected void initView() {
        tabLayout = findViewById(R.id.xTab);
        viewPager = findViewById(R.id.view_p);
        initFragments();
    }


    @Override
    protected void bindEvent() {

    }

    @Override
    protected void initData() {

    }

    @Override
    protected void processClick(View view) {

    }

    /**
     * 初始化Fragments
     */
    private void initFragments() {
        if (titles != null && titles.size() == 0) {
            titles.add("发帖");
            titles.add("发帖");
            titles.add("发帖");
            titles.add("发帖");
        }
        if (fragments != null && fragments.size() == 0) {
            fragments.add(InformationVideoFragment.newInstance("111", "111", "111"));
            fragments.add(InformationVideoFragment.newInstance("111", "111", "111"));
            fragments.add(InformationVideoFragment.newInstance("111", "111", "111"));
            fragments.add(InformationVideoFragment.newInstance("111", "111", "111"));
            BaseFragmentPageAdapter adapter = new BaseFragmentPageAdapter(getSupportFragmentManager(), fragments, titles);
            viewPager.setAdapter(adapter);
            viewPager.setOffscreenPageLimit(fragments.size());
            tabLayout.setViewPager(viewPager);
            tabLayout.setGradientIndicatorDrawable1();
        }
        viewPager.setCurrentItem(0, false);

    }

    @Override
    public void initPresenter() {

    }
}
