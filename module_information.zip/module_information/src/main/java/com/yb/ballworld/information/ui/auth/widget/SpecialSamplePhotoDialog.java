package com.yb.ballworld.information.ui.auth.widget;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;

import androidx.annotation.NonNull;

import com.yb.ballworld.information.R;

/**
 * 特约认证示例提示框
 */
public class SpecialSamplePhotoDialog extends Dialog {

    public SpecialSamplePhotoDialog(@NonNull Context context) {
        super(context, R.style.common_dialog);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_special_sample_photo);
        try {
            setCanceledOnTouchOutside(true);
            Window window = getWindow();
            WindowManager.LayoutParams attributes = window.getAttributes();
            attributes.gravity = Gravity.CENTER;
            attributes.width = WindowManager.LayoutParams.MATCH_PARENT;
            window.setAttributes(attributes);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
