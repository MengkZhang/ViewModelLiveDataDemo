package com.yb.ballworld.information.ui.home.constant;

import androidx.annotation.StringDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Desc 发表页参数类型
 * Date 2019/10/16
 * author mengk
 */
@StringDef({
        PublishIntentParam.NEWS_ID,
        PublishIntentParam.REPLY_ID,
        PublishIntentParam.ID,
        PublishIntentParam.COMMENT_TYPE,
        PublishIntentParam.CREATED_BY,
        PublishIntentParam.CREATED_DATE,
        PublishIntentParam.LAST_MODIFIED_BY,
        PublishIntentParam.LAST_MODIFIED_DATE,
        PublishIntentParam.LIKE_COUNT,
        PublishIntentParam.MAIN_COMMENT_ID,
        PublishIntentParam.NICK_NAME,
        PublishIntentParam.USER_ID,
        PublishIntentParam.RETURN_DATA
})

@Retention(RetentionPolicy.SOURCE)

public @interface PublishIntentParam {
    //资讯ID
    String NEWS_ID = "news_id";
    //回复ID
    String REPLY_ID = "reply_id";
    //唯一主键
    String ID = "id";
    //0.评论 1.回复
    String COMMENT_TYPE = "comment_type";
    //创建人
    String CREATED_BY = "created_by";
    //创建时间
    String CREATED_DATE = "created_date";
    //最近创建人
    String LAST_MODIFIED_BY = "last_modified_by";
    //更新时间
    String LAST_MODIFIED_DATE = "last_modified_date";
    //点赞数
    String LIKE_COUNT = "like_count";
    //主评论id
    String MAIN_COMMENT_ID = "main_comment_id";
    //昵称
    String NICK_NAME = "nick_name";
    //评论时用户id
    String USER_ID = "user_id";
    //视频链接
    String VIDEO_URL = "video_url";
    //返回数据
    String RETURN_DATA = "return_data";
}
