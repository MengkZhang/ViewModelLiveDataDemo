package com.yb.ballworld.information.ui.home.constant;

import androidx.annotation.StringDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Desc
 * Date 2019/10/16
 * author mengk
 */
@StringDef({
        RichTag.TXT,
        RichTag.IMG,
})

@Retention(RetentionPolicy.SOURCE)

public @interface RichTag {
    String TXT = "txt";
    String IMG = "img";


}
