package com.yb.ballworld.information.ui.home.constant;

import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Desc
 * Date 2019/10/16
 * author mengk
 */
@IntDef({
        TagReqCode.REQ_CODE_PUBLISH_TO_TAG,
        TagReqCode.REQ_CODE_PUBLISH_TO_TAG_TO_MORE
})

@Retention(RetentionPolicy.SOURCE)

public @interface TagReqCode {
    int REQ_CODE_PUBLISH_TO_TAG = 1001;
    int REQ_CODE_PUBLISH_TO_TAG_TO_MORE = 1002;
}
