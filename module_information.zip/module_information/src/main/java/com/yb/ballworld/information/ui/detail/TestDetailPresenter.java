package com.yb.ballworld.information.ui.detail;

import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.information.data.ArticleDetailBean;
import com.yb.ballworld.information.data.CommitBeanList;
import com.yb.ballworld.information.http.InforMationHttpApi;
import com.yb.ballworld.information.utils.CommondUtil;


/**
 * @author ink
 */
public class TestDetailPresenter extends BasePresenter<TestDetailActivity, VoidModel> {

    private InforMationHttpApi inforMationHttpApi = new InforMationHttpApi();
    private int pageNumber = 1;
    private final int pageSize = 15;
    private String newsId = null;
    final int INFOR_DETAIL = 0;
    final int INFOR_COMMITS = 1;
    final boolean isHost=true;

    public void init(String newsId) {
        this.newsId = newsId;
    }

    public String getNewsId(){
        return this.newsId;
    }

    public boolean isHost() {
        return isHost;
    }

    public void loadInfor() {
        add(inforMationHttpApi.getArticleDetail(newsId, new LifecycleCallback<ArticleDetailBean>(mView) {
            @Override
            public void onSuccess(ArticleDetailBean data) {
                showInfor(data);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                showError(INFOR_DETAIL);
            }
        }));
    }

    public void loadMore() {
        add(inforMationHttpApi.getCommitList(this.newsId, pageNumber, pageSize, isHost(), new LifecycleCallback<CommitBeanList>(mView) {
            @Override
            public void onSuccess(CommitBeanList data) {
                showCommits(data);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                showError(INFOR_COMMITS);
            }
        }));
    }

    public void addArticleLike() {
        add(inforMationHttpApi.submitArticleLike(this.newsId, new LifecycleCallback<String>(mView) {
            @Override
            public void onSuccess(String data) {
                showLike(INFOR_DETAIL, 0, true);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                showLike(INFOR_DETAIL, 0, errCode==200);
            }
        }));
    }

    public void addCommitLike(final int commitId) {
        add(inforMationHttpApi.submitCommitLike(commitId, new LifecycleCallback<String>(mView) {
            @Override
            public void onSuccess(String data) {
                showLike(INFOR_COMMITS, commitId, true);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                showLike(INFOR_COMMITS, commitId, errCode==200);
            }
        }));
    }

    /**
     * 显示错误
     */
    private void showLike(int area, int commitId, boolean isSuccess) {
        if (mView != null) {
//            mView.showLike(area, commitId, isSuccess);
        }
    }

    /**
     * 显示错误
     */
    private void showError(int area) {
        if (mView != null) {
//            mView.showError(area);
        }
    }

    /**
     * 显示评论列表
     *
     * @param commitList
     */
    private void showCommits(CommitBeanList commitList) {
        if (mView != null) {
            if (commitList == null || CommondUtil.isEmpty(commitList.getList())) {
//                mView.showEmpty(INFOR_COMMITS);
            } else {
//                mView.showCommits(commitList);
            }
        }
    }

    /**
     * 显示文章信息
     *
     * @param articleBean
     */
    private void showInfor(ArticleDetailBean articleBean) {
        if (mView != null) {
            if (articleBean == null || articleBean.getNews() == null) {
//                mView.showEmpty(INFOR_DETAIL);
            } else {
                mView.showInfor(articleBean);
            }
        }
    }


}
