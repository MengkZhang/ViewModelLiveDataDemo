package com.yb.ballworld.information.ui.profile.view.fragments;

import android.os.Bundle;
import android.view.View;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.yb.ballworld.common.livedata.LiveDataObserver;
import com.yb.ballworld.information.ui.profile.adapter.PlayerRankSubShooterAdapter;
import com.yb.ballworld.information.ui.profile.data.MatchPlayerBean;
import com.yb.ballworld.information.ui.profile.presenter.MatchPlayerPresenter;
import com.yb.ballworld.information.widget.RvPlayerRankHeader;

import java.util.ArrayList;
import java.util.List;

/**
 * 赛事资料库-球员榜-射手榜
 * @author Gethin
 * @time 2019/11/9 10:36
 */

public class PlayerRankDataFragment extends RvBaseFragment<MatchPlayerPresenter> {

    public static PlayerRankDataFragment newInstance(String seasonId, String type) {
        PlayerRankDataFragment fragment = new PlayerRankDataFragment();
        Bundle bundle = new Bundle();
        bundle.putString("seasonId", seasonId);
        bundle.putString("type", type);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected void initView() {
        super.initView();
        adapter.addHeaderView(new RvPlayerRankHeader(getContext()));
        smartRefreshLayout.setEnableLoadMore(false);
    }

    private PlayerRankSubShooterAdapter adapter = new PlayerRankSubShooterAdapter();

    @Override
    protected void loadData() {
        Bundle bundle = getArguments();
        if (bundle != null) {
            String seasonId = bundle.getString("seasonId");
            String type = bundle.getString("type");
            mPresenter.setSeasonId(seasonId);
            mPresenter.setStatType(type);
        }
    }

    @Override
    protected BaseQuickAdapter getAdapter() {
        return adapter;
    }

    @Override
    public void initPresenter() {
        mPresenter.setVM(this);
    }

    @Override
    protected void bindEvent() {
        mPresenter.getDataWrap().observe(this, new LiveDataObserver<List<MatchPlayerBean>>() {
            @Override
            public void onSuccess(List<MatchPlayerBean> data) {
                smartRefreshLayout.finishRefresh(true);
                if (data != null && data.size() > 0) {
                    showPageContent();
                    adapter.replaceData(data);
                } else {
                    showPageEmpty("");
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                smartRefreshLayout.finishRefresh(false);
                showPageError(errMsg);
            }
        });

    }

    @Override
    protected void processClick(View view) {

    }
}
