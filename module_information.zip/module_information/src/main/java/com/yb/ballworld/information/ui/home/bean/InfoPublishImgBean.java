package com.yb.ballworld.information.ui.home.bean;

import android.net.Uri;

/**
 * Desc
 * Date 2019/10/20
 * author mengk
 */
public class InfoPublishImgBean {
    private String path;
    private Uri uri;

    public InfoPublishImgBean(String path,Uri uri) {
        this.path = path;
        this.uri = uri;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public Uri getUri() {
        return uri;
    }

    public void setUri(Uri uri) {
        this.uri = uri;
    }
}
