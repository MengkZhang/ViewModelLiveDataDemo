package com.yb.ballworld.information.ui.profile.view;

import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.yb.ballworld.baselib.utils.ImageManager;
import com.yb.ballworld.common.base.BaseFragment;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.widget.MultTextView;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.personal.view.InfoDynamicFragment;
import com.yb.ballworld.information.ui.profile.data.Player;
import com.yb.ballworld.information.ui.profile.http.ProfileHttp;
import com.yb.ballworld.information.ui.profile.view.fragments.DataFragment;
import com.yb.ballworld.information.ui.profile.view.fragments.PlayerDatumFragment;
import com.yb.ballworld.information.ui.profile.view.fragments.MomentsFragment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 球员资料库
 *
 * @author Gethin
 * @time 2019/11/7 17:29
 */

public class ProfilePlayerActivity extends ProfileBaseActivity {

    private MultTextView mtTitle;
    private MultTextView mtInfo;
    private ProfileHttp profileHttp;
    private ImageView avatar;
    private String playerId;
    private TextView tvName;
    private Player player;

    public static void launch(Context context, String playerId, String seasonId) {
        if(TextUtils.isEmpty(playerId)) return;
        Intent intent=new Intent(context, ProfilePlayerActivity.class);
        intent.putExtra("playerId",playerId);
        context.startActivity(intent);
    }

    @Override
    protected int getHeaderLayoutId() {
        return R.layout.activity_profile_player;
    }

    @Override
    protected String[] getTitles() {
        return new String[]{"动态", "数据", "资料"};
    }

    @Override
    protected List<BaseFragment> getFragments() {
        List<BaseFragment> list = new ArrayList<>();
        list.add(InfoDynamicFragment.newInstance(player.getCnAlias()));
        list.add(DataFragment.newInstance(playerId));
        list.add(PlayerDatumFragment.newInstance(player));
        return list;
    }

    @Override
    protected void initView() {
        super.initView();
        playerId=getIntent().getStringExtra("playerId");
        profileHttp = new ProfileHttp();
        mtTitle = findViewById(R.id.mtTitle);
        mtInfo = findViewById(R.id.mtInfo);
        avatar = findViewById(R.id.ivPlayerAvatar);
        tvName = findViewById(R.id.tvPlayerName);
        mtTitle.setTexts("身高", "体重", "国家");
       // mtInfo.setTexts("187cm", "86kg", "中国");
    }

    @Override
    protected void loadData() {
        showDialogLoading();
        Map<String, String> map = new HashMap<>();
        map.put("playerId", playerId);
        profileHttp.getRequest(profileHttp.URL_PLAYER_INFO, map, Player.class, new LifecycleCallback<Player>(this) {
            @Override
            public void onSuccess(Player data) {
                hideDialogLoading();
                if (data == null) {
                    showPageEmpty("暂无数据");
                } else {
                    ProfilePlayerActivity.this.player=data;
                    mtInfo.setTexts("" + data.getHeight(), "" + data.getWeight(), data.getNationality());
                    ImageManager.INSTANCE.loadUserIcon(data.getPicUrl(), avatar);
                    // TODO 需确认名字取值字段
                    tvName.setText(data.getCnName());
                    loadDataFinish();
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                hideDialogLoading();
                showPageError("网络异常，请稍后再试");
            }
        });

    }

    @Override
    public void initPresenter() {

    }
}
