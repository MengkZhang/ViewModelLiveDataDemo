package com.yb.ballworld.information.ui.home.bean;

/**
 * Desc 专栏中的赛事数据结构
 * Date 2019/10/11
 * author mengk
 */
public class HomeIndexSpecialMatchBean {
    //id
    private int matchId;
    //比赛名称
    private String matchName;
    //开赛时间
    private String matchTime;
    //主队logo
    private String hostMatchLogo;
    //主队名称
    private String hostMatchName;
    //主队得分
    private String hostMatchScore;
    //客队logo
    private String gestMatchLogo;
    //客队名称
    private String gestMatchName;
    //客队得分
    private String gestMatchScore;

    public int getMatchId() {
        return matchId;
    }

    public void setMatchId(int matchId) {
        this.matchId = matchId;
    }

    public String getMatchName() {
        return matchName;
    }

    public void setMatchName(String matchName) {
        this.matchName = matchName;
    }

    public String getMatchTime() {
        return matchTime;
    }

    public void setMatchTime(String matchTime) {
        this.matchTime = matchTime;
    }

    public String getHostMatchLogo() {
        return hostMatchLogo;
    }

    public void setHostMatchLogo(String hostMatchLogo) {
        this.hostMatchLogo = hostMatchLogo;
    }

    public String getHostMatchName() {
        return hostMatchName;
    }

    public void setHostMatchName(String hostMatchName) {
        this.hostMatchName = hostMatchName;
    }

    public String getHostMatchScore() {
        return hostMatchScore;
    }

    public void setHostMatchScore(String hostMatchScore) {
        this.hostMatchScore = hostMatchScore;
    }

    public String getGestMatchLogo() {
        return gestMatchLogo;
    }

    public void setGestMatchLogo(String gestMatchLogo) {
        this.gestMatchLogo = gestMatchLogo;
    }

    public String getGestMatchName() {
        return gestMatchName;
    }

    public void setGestMatchName(String gestMatchName) {
        this.gestMatchName = gestMatchName;
    }

    public String getGestMatchScore() {
        return gestMatchScore;
    }

    public void setGestMatchScore(String gestMatchScore) {
        this.gestMatchScore = gestMatchScore;
    }
}
