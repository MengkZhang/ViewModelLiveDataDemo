package com.yb.ballworld.information.ui.community.data;

import com.yb.ballworld.information.ui.community.CommunityBestPost;

import java.util.List;

/**
 * Desc: <推荐作者与精贴返回结果>
 * Author: JS-Barder
 * Created On: 2019/11/8 17:20
 */
public class CommunityRecommendBean {
    public List<CommunityPostAuthor> postAuthorRecommends;
    public List<CommunityBestPost> postRecommends;
}
