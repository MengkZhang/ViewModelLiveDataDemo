package com.yb.ballworld.information.ui.community.view;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bfw.util.ToastUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.data.UserInfo;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.baselib.utils.ViewUtils;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.livedata.LiveDataResult;
import com.yb.ballworld.common.sharesdk.ShareSdkParamBean;
import com.yb.ballworld.common.sharesdk.ShareSdkUtils;
import com.yb.ballworld.common.widget.CommonTitleBar;
import com.yb.ballworld.common.widget.DialogInterface;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.data.CommitBean;
import com.yb.ballworld.information.ui.community.adapter.TopicDetailAdapter;
import com.yb.ballworld.information.ui.community.bean.Topic;
import com.yb.ballworld.information.ui.community.bean.TopicCommentGroup;
import com.yb.ballworld.information.ui.community.presenter.TopicDetailPresenter;
import com.yb.ballworld.information.ui.detail.CommunityCommentActivity;
import com.yb.ballworld.information.ui.detail.InforConstant;
import com.yb.ballworld.information.ui.detail.InforDetailQuickAdapter;
import com.yb.ballworld.information.ui.event.InforCommentCountEvent;
import com.yb.ballworld.information.ui.home.constant.PublishIntentParam;
import com.yb.ballworld.information.ui.home.constant.PublishReqCode;
import com.yb.ballworld.information.ui.home.utils.JZReleaseUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.home.view.PublishCommentActivity;
import com.yb.ballworld.information.ui.personal.bean.community.ReportAuthorReason;
import com.yb.ballworld.information.ui.personal.view.InformationPersonalActivityNew;
import com.yb.ballworld.information.utils.CommondUtil;
import com.yb.ballworld.information.utils.ShareTextUitl;
import com.yb.ballworld.information.widget.ConfirmDialog;
import com.yb.ballworld.information.widget.TipOffDialog;
import com.yb.ballworld.information.widget.TopicDetailBottomLayout;
import com.yb.ballworld.information.widget.TopicDetailWindow;
import com.yb.ballworld.information.widget.bubbleview.BubblePopupWindow;
import com.yb.ballworld.information.widget.bubbleview.BubbleTextView;
import com.yb.ballworld.information.widget.bubbleview.RelativePos;
import com.yb.ballworld.information.widget.listener.OnElementClickListener;
import com.yb.ballworld.information.widget.listener.OnElementClickListener2;

import java.util.ArrayList;
import java.util.List;

import static com.yb.ballworld.information.widget.bubbleview.RelativePos.CENTER_HORIZONTAL;
import static com.yb.ballworld.information.widget.bubbleview.RelativePos.TO_LEFT_OF;

/**
 * 社区视频帖子详情页
 */
public class TopicDetailActivity extends RVBaseActivity<TopicDetailPresenter> {
    private TopicDetailAdapter adapter;
    private int x;
    private int y;
    List<MultiItemEntity> list = new ArrayList<>();
    private TopicDetailBottomLayout newsDetailBottomLayout;
    private BubblePopupWindow mBubblePopupWindow;
    private boolean isChangeSort; // 是否改变排序状态

    private TipOffDialog dialog;
    private CommonTitleBar commonTitleBar;
    private TopicDetailWindow detailWindow;
    private ShareSdkParamBean mShareSdkParamBean;

    public static void start(Context context, String topicId) {
        start(context, topicId, false);
    }

    public static void start(Context context, String topicId, boolean isToFirst) {
        Intent intent = new Intent(context, TopicDetailActivity.class);
        intent.putExtra("topicId", topicId);
        intent.putExtra("isToFirst", isToFirst);
        context.startActivity(intent);
    }


    @Override
    public int getLayoutId() {
        return R.layout.activity_topic_detail_layout;
    }

    @Override
    public void initPresenter() {
        mPresenter.setVM(this);
        mPresenter.setTopicId(getIntent().getStringExtra("topicId"));
        mPresenter.setIsToFirst(getIntent().getBooleanExtra("isToFirst", false));
    }

    @Override
    protected void initView() {
        super.initView();
        smartRefreshLayout.setRefreshFooter(getRefreshFooter());
        smartRefreshLayout.setEnableAutoLoadMore(true);
        newsDetailBottomLayout = F(R.id.nbl_view_header2);
        initRefreshView();
        enableRefresh(false);
        enableLoadMore(false);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        commonTitleBar = findViewById(R.id.commonTitleBar);
        ((ImageView)commonTitleBar.getRightCustomView()).setImageResource(R.mipmap.ic_more_black);
        placeholder.setEmptyImage(R.mipmap.wushuju_02);
    }

    @Override
    protected void onPause() {
        super.onPause();
        JZReleaseUtil.releaseAllVideos();
    }

    @Override
    protected void bindEvent() {
        super.bindEvent();
        dialog = new TipOffDialog(mContext);
        dialog.setDialogInterface(new DialogInterface<ReportAuthorReason>() {
            @Override
            public void onItemClick(ReportAuthorReason reportAuthorReason, int position) {
                dialog.dismiss();
                UserInfo userInfo = LoginOrdinaryUtils.INSTANCE.getUserInfo();
                if (userInfo == null) {
                    NavigateToDetailUtil.toLogin(TopicDetailActivity.this);
                    return;
                }
                mPresenter.reportTopic(reportAuthorReason, Integer.valueOf(mPresenter.getTopicId()));
            }
        });
        detailWindow = new TopicDetailWindow(mContext);
        detailWindow.setClickListener(v -> {
            detailWindow.dismiss();
            if(LoginOrdinaryUtils.INSTANCE.isLogin()){
                if (v.getId() == R.id.tv_share) {//分享
                    if (mShareSdkParamBean != null) {
                        ShareSdkUtils.showShare(mContext,mShareSdkParamBean);
                    } else {
                        showToastMsgShort("网络异常,请稍后再试！");
                    }
                } else if (v.getId() == R.id.tv_report) {//举报
                    if (!dialog.isShowing()) {
                        List list=dialog.getList();
                        if(list!=null && list.size()>0){
                            dialog.show();
                        }else{
                            showToastMsgShort("网络异常,请稍后再试！");
                            mPresenter.getReasonForReport();
                        }

                    }
                }
            }else{
                NavigateToDetailUtil.toLogin(TopicDetailActivity.this);
            }
        });
        commonTitleBar.setListener((v, action, extra) -> {
            if (action == CommonTitleBar.ACTION_LEFT_BUTTON) {
                finish();
            }
        });
        commonTitleBar.getRightCustomView().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                detailWindow.showAsDropDown(v, -ViewUtils.dp2px(60), -ViewUtils.dp2px(16));
            }
        });

        newsDetailBottomLayout.setOnCollectListener(new TopicDetailBottomLayout.OnCollectListener() {
            @Override
            public void onClick(boolean collect) {
                adapter.updateFollow(collect);
            }
        });


        placeholder.setPageErrorRetryListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPresenter.getTopic();
            }
        });

        mPresenter.topicData.observe(this, new Observer<LiveDataResult<TopicCommentGroup>>() {
            @Override
            public void onChanged(LiveDataResult<TopicCommentGroup> topicLiveDataResult) {
                if (topicLiveDataResult.isSuccessed()) {
                    TopicCommentGroup topicCommentGroup=topicLiveDataResult.getData();
                    Topic topic=topicCommentGroup.getParent();
                    list.clear();
                    list.add(topic);
                    adapter.setNewData(list);
                    adapter.notifyDataSetChanged();
                    // 设置分享数据
                    setShareData(topic);
                    // 加载评论数据
                    if (mPresenter.hasMore()) {
                        mPresenter.getTopicComment(topicCommentGroup);
                    } else {
                        hidePageLoading();
                        showPageContent();
                        smartRefreshLayout.setEnableLoadMore(false);
                    }
                } else {
                    hidePageLoading();
                    if (topicLiveDataResult.getErrorCode() == Integer.MIN_VALUE) { ;
                        showPageError("网络异常，请稍后再试");
                    } else if(topicLiveDataResult.getErrorCode()==99500){
                        showPageEmpty("哎呀~内容不存在了");
                    }else{
                        showPageError(topicLiveDataResult.getErrorMsg());
                    }
                }
            }
        });

        mPresenter.commentData.observe(this, new Observer<LiveDataResult<List<Topic>>>() {
            @Override
            public void onChanged(LiveDataResult<List<Topic>> result) {
                hidePageLoading();
                showPageContent();
                smartRefreshLayout.finishLoadMore();
                // 更新了排序方式，删除原有的数据
                if (isChangeSort) {
                    // 移除除了头部的其他item
                    isChangeSort = false;
                    if(adapter.getData()!=null){
                        MultiItemEntity multiItemEntity = adapter.getData().get(0);
                        adapter.getData().clear();
                        adapter.getData().add(multiItemEntity);
                        adapter.notifyDataSetChanged();
                    }
                }

                if (result.isSuccessed()) {
                    List<Topic> data = result.getData();
                    if (!data.isEmpty()) {
                        int startIndex = list.size();
                        list.addAll(result.getData());
                        adapter.notifyItemRangeChanged(startIndex, data.size());
                    }
                    // 设置是否可以加载更多
                    smartRefreshLayout.setEnableLoadMore(mPresenter.hasMore());
                    if (mPresenter.isToFirst()) {
                        LinearLayoutManager manager = (LinearLayoutManager) recyclerView.getLayoutManager();
                        if (manager == null) {
                            return;
                        }
                        manager.scrollToPositionWithOffset(1, 0);
                    }
                } else {
                    showToastMsgShort(result.getErrorMsg());
                }
            }
        });

        // TODO 更多回复页添加回复后更新详情页
        LiveEventBus.get().with(LiveEventBusKey.KEY_INFOR_COMMENT_COUNT, InforCommentCountEvent.class).observe(this, new Observer<InforCommentCountEvent>() {
            @Override
            public void onChanged(InforCommentCountEvent inforCommentCountEvent) {

            }
        });
        // adapter item点击事件
        adapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                //TODO
                // 主贴不跳转
                if(position==0){
                    return;
                }
                try {
                    Topic topic = (Topic) adapter.getData().get(position);
                    onReplyClick(topic,view);
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
        // TODO 长按显示回复气泡
        adapter.setOnItemLongClickListener(new BaseQuickAdapter.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(BaseQuickAdapter adapter, View view, int position) {
                boolean ishandle = false;
                try {
                    MultiItemEntity entity = (MultiItemEntity) adapter.getData().get(position);
                    if (entity != null && entity.getItemType() != InforConstant.TopicDetailItemType.TYPE_TOPIC) {
                        parentCommit = (Topic) entity;
                        LogUtils.INSTANCE.i("arway0","id="+parentCommit.getId()+"/replayid=" +parentCommit.getReplyId());
                        parentCommitPosition = position;
                        showBubble(recyclerView, (Topic) entity);
                        ishandle = true;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

                return ishandle;
            }
        });
        // TODO item子view的事件处理
        adapter.setOnItemChildClickListener(new BaseQuickAdapter.OnItemChildClickListener() {
            @Override
            public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
                List<MultiItemEntity> items = adapter.getData();
                Topic topic = (Topic) items.get(position);
                if (view.getId() == R.id.iv_head_image || view.getId() == R.id.tv_nick_name){
                    InformationPersonalActivityNew.startActivity(mContext, topic.getUserId() + "",InformationPersonalActivityNew.TYPE_COMMUNITY);
                }else if (view.getId() == R.id.tv_follow) {
                    if(LoginOrdinaryUtils.INSTANCE.isLogin()){
                        onAttentionClick(topic, view);
                    }else{
                        NavigateToDetailUtil.toLogin(TopicDetailActivity.this);
                    }
                } else if (view.getId() == R.id.singleCommit_like) {
                    onLikeViewClick(topic, view);
                } else if (view.getId() == R.id.singleCommit_photo) {
                    onHeadPhotoClick(topic, view);
                } else if (view.getId() == R.id.iv_collection) {
                    if(LoginOrdinaryUtils.INSTANCE.isLogin()){
                        onFavoriteClick(topic, view);
                    }else{
                        NavigateToDetailUtil.toLogin(TopicDetailActivity.this);
                    }
                } else if (view.getId() == R.id.inforDetail_sortType_view) {
                    onSortByClick(topic, view);
                } else if (view.getId() == R.id.singleCommit_countLayout) {
                    onReplyClick(topic, view);
                } else if(view.getId()== R.id.item_comment_video){
                    onVideoClick(topic,view);
                }
            }
        });

        // TODO 获取在item上触摸的XY坐标，用来显示回复气泡
        recyclerView.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {
            @Override
            public boolean onInterceptTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
                x = (int) e.getX();
                y = (int) e.getY();
                return false;
            }

            @Override
            public void onTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {

            }

            @Override
            public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

            }
        });
        // TODO 多张图片的item点击事件
        adapter.setmOnElementClickListener(new OnElementClickListener2<Topic>() {
            @Override
            public void onElementClick(Topic parentItem, String url, int type, int position, List<String> peerList) {
                try{
                    NavigateToDetailUtil.navigateToGalleryActivity(TopicDetailActivity.this, peerList, position,ShareTextUitl.getShareTitle(parentItem.getContent()), parentItem.getWebShareUrl(), parentItem.getContent(), parentItem.getWebShareUrl());
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });

        // 发评论完返回
        LiveEventBus.get().with(LiveEventBusKey.KEY_TOPIC_PUBLIC_COMMENT, Topic.class).observe(this, new Observer<Topic>() {
            @Override
            public void onChanged(Topic topic) {

              /*  // 评论主贴
                LogUtils.INSTANCE.i("arway","更新数据id="+topic.getId()+"/parentId="+topic.getParent().getId());
                if(mPresenter.getTopicId().equals(""+topic.getReplyId())){
                    if(mPresenter.getOrderBy()==mPresenter.ORDER_BY_DESC){
                        adapter.getData().add(1,topic);
                    }else{
                        adapter.getData().add(topic);
                    }
                    adapter.notifyDataSetChanged();
                }else{
                    // 回复评论
                    onReplyClick(parentCommit,null);
                    LogUtils.INSTANCE.i("arway--","跳转ID="+parentCommit.getId());
                }*/
            }
        });

        // 回复列表回来更新数据
        LiveEventBus.get().with(LiveEventBusKey.KEY_INFOR_COMMENT_COUNT, InforCommentCountEvent.class).observe(this, new Observer<InforCommentCountEvent>() {
            @Override
            public void onChanged(InforCommentCountEvent commentCount) {
                try{
                    LogUtils.INSTANCE.i("arway--","返回ID="+commentCount.getCommentId());
                    if(commentCount!=null){
                        commentCount.getCommentId();
                        List<MultiItemEntity> topics=adapter.getData();
                        for(int i=0;i<topics.size();i++){
                            Topic t= (Topic) topics.get(i);
                            if(t.getId()==commentCount.getCommentId()){
                                LogUtils.INSTANCE.i("arway--","找到id设置count="+commentCount.getCommentCount());
                                View v= adapter.getViewByPosition(recyclerView,i,R.id.singleCommit_countLayout);
                                TextView tv= v.findViewById(R.id.singleCommit_count);
                                tv.setText( CommondUtil.commentCount(commentCount.getCommentCount(), TopicDetailActivity.this));
                                t.setSonNum(commentCount.getCommentCount());
                                if(commentCount.getCommentCount()<1){
                                    v.setVisibility(View.GONE);
                                }else{
                                    v.setVisibility(View.VISIBLE);
                                }
                                return;
                            }

                        }
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
        JZReleaseUtil.releaseAllVideos(recyclerView, R.id.item_comment_video);
    }



    private Topic parentCommit=null;
    private int parentCommitPosition=0;
    private BubbleTextView bubbleView;
    private void showBubble(View commitView, Topic topic) {
        if (mBubblePopupWindow == null) {
            View rootView = LayoutInflater.from(this).inflate(R.layout.simple_text_bubble, null);
            bubbleView = rootView.findViewById(R.id.popup_bubble);
            mBubblePopupWindow = new BubblePopupWindow(rootView, bubbleView);
            mBubblePopupWindow.setCancelOnTouch(true);
            mBubblePopupWindow.setCancelOnTouchOutside(true);
            mBubblePopupWindow.setCancelOnLater(3000);
        }
        bubbleView.setTag(topic.getReplyId());
        bubbleView.setOnClickListener(v -> {
            v.setEnabled(false);
            gotoPublish(topic);
            LogUtils.INSTANCE.i("arway","id="+topic.getId()+"/replayid=" +topic.getReplyId());
            v.setEnabled(true);
        });
        mBubblePopupWindow.showArrowTo(commitView,new RelativePos(CENTER_HORIZONTAL, RelativePos.ABOVE), -x,-y);
        // mBubblePopupWindow.showAsDropDown(commitView,clickX,clickY, Gravity.NO_GRAVITY);
    }


    @Override
    protected void initData() {
        showPageLoading();
        mPresenter.getTopic();
        mPresenter.getReasonForReport();
    }

    @Override
    protected void loadData() {
    }


    @Override
    protected void onLoadMoreData() {
        super.onLoadMoreData();
        if (mPresenter.hasMore()) {
            mPresenter.getTopicComment(null);
        } else {
            smartRefreshLayout.setEnableLoadMore(false);
        }

    }

    @Override
    protected BaseQuickAdapter getAdapter() {
        // TODO 设置布局及数据
        adapter = new TopicDetailAdapter(null);
        return adapter;
    }


    @Override
    protected void processClick(View view) {

    }


    private void attentionAction(View view, Topic topic) {
        mPresenter.attentionAction(topic.getUserId(), !view.isSelected(), new LifecycleCallback(TopicDetailActivity.this) {
            @Override
            public void onSuccess(Object data) {
                view.setSelected(!view.isSelected());
                topic.setIsAttention(view.isSelected());
                ToastUtils.showToast(view.isSelected()?"已关注":"已取消");
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                showToastMsgShort("网络异常，请稍后再试");
            }
        });
    }


    /**
     * 点赞更新
     *
     * @param topic
     * @param view
     */
    private void onLikeViewClick(Topic topic, View view) {
        // 点赞
        boolean isSelected = view.isSelected();
        if (!isSelected) {
            // 更新点赞状态
            view.setSelected(!isSelected);
            // 更新点赞数量
            int count = textAdd( view.getTag());
            // 更新数据源
            topic.setIsLike(view.isSelected());
            topic.setLikeCount(count);
            // 通知后台
            mPresenter.postLike(topic.getId());
            LiveEventBus.get().with(LiveEventBusKey.KEY_TOPIC_LIKE,String.class).post(String.valueOf(topic.getId()));
        }
    }

    /**
     * 关注点击
     *
     * @param topic
     * @param view
     */
    private void onAttentionClick(Topic topic, View view) {
        boolean isAttention = view.isSelected();
        if (isAttention) {
            new ConfirmDialog(TopicDetailActivity.this, ShareTextUitl.getMarksText(topic.getNickname()), "是否取消对ta的关注？", new ConfirmDialog.OnCloseListener() {
                @Override
                public void onClick(Dialog dialog, boolean confirm) {
                    if (confirm) {
                        //取消关注
                        attentionAction(view, topic);
                    }
                }
            }).show();
        } else {
            attentionAction(view, topic);
        }
    }

    /**
     * 头像点击
     *
     * @param topic
     * @param view
     */
    private void onHeadPhotoClick(Topic topic, View view) {
        InformationPersonalActivityNew.startActivity(this, "" + topic.getUserId(),InformationPersonalActivityNew.TYPE_COMMUNITY);
    }

    private int textAdd(Object view) {
        if (view != null && view instanceof TextView) {
            String text = ((TextView) view).getText().toString();
            try {
                int num = Integer.valueOf(text);
                ((TextView) view).setText(String.valueOf(++num));
                return num;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return 1;
    }


    /**
     * 点击收藏按钮
     * @param topic
     * @param view
     */
    private void onFavoriteClick(Topic topic,View view){
        view.setEnabled(false);
        mPresenter.favoriteAction(topic.getId(), view.isSelected(), new LifecycleCallback<String>(this) {
            @Override
            public void onSuccess(String data) {
                view.setEnabled(true);
                view.setSelected(!view.isSelected());
                if(view.isSelected()){
                    LiveEventBus.get().with(LiveEventBusKey.KEY_TOPIC_COLLECT,String.class).post(String.valueOf(topic.getId()));
                }else{
                    LiveEventBus.get().with(LiveEventBusKey.KEY_TOPIC_REMOVE_COLLECT,String.class).post(String.valueOf(topic.getId()));
                }
                topic.setFavorites(view.isSelected());
                newsDetailBottomLayout.updateCOllect(view.isSelected());
                ToastUtils.showToast(view.isSelected()?"已收藏":"已取消");
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                view.setEnabled(true);
                ToastUtils.showToast("网络异常，请稍后再试");
            }
        });
    }

    /**
     * 排序点击
     * @param topic
     * @param view
     */
    private void onSortByClick(Topic topic,View view){
       if(mPresenter.getOrderBy()==mPresenter.ORDER_BY_DESC){
           mPresenter.setOrderBy(mPresenter.ORDER_BY_ASC);
       }else{
           mPresenter.setOrderBy(mPresenter.ORDER_BY_DESC);
       }
        isChangeSort=true;
       mPresenter.resetPageStatus();
       if(mPresenter.hasMore()){
           showPageLoading();
           onLoadMoreData();
       }

    }


    private void onReplyClick(Topic topic,View view){
        Intent intent=new Intent(this, CommunityCommentActivity.class);
        intent.putExtra("TOPIC",topic);
        startActivity(intent);
    }

    private void onVideoClick(Topic topic,View view){
       VeidoPlayerActivity.start(this,topic.getVideoUrl(),topic.getImgUrl());
    }


    private void setShareData(Topic topic) {
        try{
            String imgUrl = topic.getImgUrl();
            if (imgUrl == null) {
                imgUrl = topic.getPostImgLists().get(0);
            }

            mShareSdkParamBean = new ShareSdkParamBean(ShareTextUitl.getShareTitle(topic.getContent()), topic.getWebShareUrl(), topic.getContent(), imgUrl, topic.getWebShareUrl());
            newsDetailBottomLayout.setParam(topic.getCommentStatus(), "" + topic.getId(), topic.getId() + "", topic.isFavorites());
            newsDetailBottomLayout.setShareSdkParamBean(mShareSdkParamBean);
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    private void gotoPublish(Topic topic) {
        Intent intent = new Intent(this, PublishCommentActivity.class);
        intent.putExtra(PublishIntentParam.NEWS_ID, ""+topic.getId() );
        intent.putExtra(PublishIntentParam.REPLY_ID, ""+topic.getId());
        intent.putExtra("type", Integer.MIN_VALUE);
        startActivityForResult(intent, PublishReqCode.REQ_CODE);
    }

    //获取举报原因
    public void initReport(List<ReportAuthorReason> reasonList){
        if (reasonList==null)
            return;
        if (reasonList.size()==0)
            return;
        // List<String> reasons = new ArrayList<>();
        // for (ReportAuthorReason reason:reasonList){
        //     reasons.add(reason.getReason());
        // }
        dialog.setDate(reasonList);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if(requestCode==PublishReqCode.REQ_CODE){
            if(intent!=null){
                try{
                    Topic topic= (Topic) intent.getSerializableExtra(PublishIntentParam.RETURN_DATA);
                    // 评论主贴
                    LogUtils.INSTANCE.i("arway","更新数据id="+topic.getId()+"/parentId="+topic.getParent().getId());
                    if(mPresenter.getTopicId().equals(""+topic.getReplyId())){
                        if(mPresenter.getOrderBy()==mPresenter.ORDER_BY_DESC){
                            adapter.getData().add(1,topic);
                        }else{
                            adapter.getData().add(topic);
                        }
                        adapter.notifyDataSetChanged();
                    }else{
                        // 回复评论
                        onReplyClick(parentCommit,null);
                        LogUtils.INSTANCE.i("arway--","跳转ID="+parentCommit.getId());
                    }

                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
    }



}
