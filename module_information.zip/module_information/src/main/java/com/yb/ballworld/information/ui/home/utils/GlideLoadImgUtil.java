package com.yb.ballworld.information.ui.home.utils;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;

import androidx.annotation.Nullable;

import com.bfw.util.ToastUtils;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.Target;
import com.yb.ballworld.common.utils.DisplayUtil;
import com.yb.ballworld.information.R;

/**
 * Desc 资讯列表加载图片工具类
 * Date 2019/10/11
 * author mengk
 */
public class GlideLoadImgUtil {
    /**
     * 加载圆角图片并采样压缩大图片 防止内存溢出
     * @param context
     * @param imgUrl
     * @param imageView
     */
    public static void loadImg(Context context, String imgUrl, ImageView imageView) {
//        Glide.with(context).load(imgUrl).error(R.mipmap.banner_bg).placeholder(R.mipmap.banner_bg).into(imageView);
        int width = (DisplayUtil.getScreenWidth(context) - (int) DisplayUtil.dip2px(12) * 3) / 2;
        // 设置图片圆角角度
        RoundedCorners roundedCorners = new RoundedCorners(DisplayUtil.dip2px(4));
        // 通过RequestOptions扩展功能,override:采样率,因为ImageView就这么大,可以压缩图片,降低内存消耗
        RequestOptions options = RequestOptions.bitmapTransform(roundedCorners)
                .placeholder(R.drawable.icon_default_info_ball)
                .error(R.drawable.icon_default_info_ball)
                .centerCrop()
                .override(width, DisplayUtil.dip2px(100));
        Glide.with(context).load(imgUrl)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .apply(options).into(imageView);
    }

    /**
     * 加载图片with回调
     * @param context
     * @param imgUrl
     * @param imageView
     */
    public static void loadImgWithCallback(Context context, String imgUrl, ImageView imageView) {
        int width = (DisplayUtil.getScreenWidth(context) - (int) DisplayUtil.dip2px(12) * 3) / 2;
        // 设置图片圆角角度
        RoundedCorners roundedCorners = new RoundedCorners(DisplayUtil.dip2px(4));
        // 通过RequestOptions扩展功能,override:采样率,因为ImageView就这么大,可以压缩图片,降低内存消耗
        RequestOptions options = RequestOptions.bitmapTransform(roundedCorners)
                .placeholder(R.drawable.icon_default_info_ball)
                .error(R.drawable.icon_default_info_ball)
                .centerCrop()
                .override(width, DisplayUtil.dip2px(100));
        Glide.with(context).load(imgUrl)
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        ToastUtils.showToast("图片不存在");
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        return false;
                    }
                })
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .apply(options).into(imageView);
    }

    /**
     * 加载球队logo
     * @param context
     * @param imgUrl
     * @param imageView
     */
    public static void loadTeamLogo(Context context, String imgUrl, ImageView imageView) {
//        Glide.with(context).load(imgUrl).error(R.mipmap.banner_bg).placeholder(R.mipmap.banner_bg).into(imageView);
        int width = (DisplayUtil.getScreenWidth(context) - (int) DisplayUtil.dip2px(12) * 3) / 2;
        // 设置图片圆角角度
        RoundedCorners roundedCorners = new RoundedCorners(DisplayUtil.dip2px(4));
        // 通过RequestOptions扩展功能,override:采样率,因为ImageView就这么大,可以压缩图片,降低内存消耗
        RequestOptions options = RequestOptions.bitmapTransform(roundedCorners)
                .placeholder(R.drawable.icon_default_match_event)
                .error(R.drawable.icon_default_match_event)
                .override(width, DisplayUtil.dip2px(100));
        Glide.with(context).load(imgUrl)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .apply(options).into(imageView);
    }

    public static void loadImgHead(Context context, String imgUrl, ImageView imageView) {
        Glide.with(context).load(imgUrl).error(R.drawable.user_default_icon2).placeholder(R.drawable.user_default_icon2).into(imageView);
    }

    /**
     * 加载播放器封面
     * @param context
     * @param imgUrl
     * @param imageView
     */
    public static void loadPlayerFaceImg(Context context, String imgUrl, ImageView imageView) {
        int width = (DisplayUtil.getScreenWidth(context) - (int) DisplayUtil.dip2px(12) * 3) / 2;
        // 设置图片圆角角度
        RoundedCorners roundedCorners = new RoundedCorners(DisplayUtil.dip2px(4));
        // 通过RequestOptions扩展功能,override:采样率,因为ImageView就这么大,可以压缩图片,降低内存消耗
        RequestOptions options = RequestOptions.bitmapTransform(roundedCorners)
                .placeholder(R.drawable.icon_default_hor)
                .error(R.drawable.icon_default_hor)
                .centerCrop()
                .override(width, DisplayUtil.dip2px(100));
        Glide.with(context).load(imgUrl)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .apply(options).into(imageView);
    }

}
