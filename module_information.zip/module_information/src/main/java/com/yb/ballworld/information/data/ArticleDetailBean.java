package com.yb.ballworld.information.data;

import com.yb.ballworld.information.utils.HtmlParseData;

import java.util.List;

/**
* Desc: 资讯详情页
* @author ink
* created at 2019/10/10 14:15
*/
public class ArticleDetailBean {

    private ArticleBean news;
    private List<ArticleBean> currentNews;
    private HtmlParseData htmlParseData;

    public ArticleBean getNews() {
        return news;
    }

    public void setNews(ArticleBean news) {
        this.news = news;
    }

    public List<ArticleBean> getCurrentNews() {
        return currentNews;
    }

    public void setCurrentNews(List<ArticleBean> currentNews) {
        this.currentNews = currentNews;
    }

    public HtmlParseData getHtmlParseData() {
        return htmlParseData;
    }

    public void setHtmlParseData(HtmlParseData htmlParseData) {
        this.htmlParseData = htmlParseData;
    }
}
