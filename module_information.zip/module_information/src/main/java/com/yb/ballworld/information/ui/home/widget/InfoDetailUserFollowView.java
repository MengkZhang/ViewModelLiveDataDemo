package com.yb.ballworld.information.ui.home.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.bean.InfoDetailUserFollowBean;
import com.yb.ballworld.information.ui.home.listener.OnMultiClickListener;
import com.yb.ballworld.information.ui.home.utils.GlideLoadImgUtil;
import com.yb.ballworld.information.ui.home.utils.InfoStringUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.widget.CircleImageView;
import com.yb.ballworld.information.widget.GoodView;

/**
 * Desc
 * Date 2019/11/8
 * author mengk
 */
public class InfoDetailUserFollowView extends RelativeLayout {
    private Context context;
    private CircleImageView ivHead;
    private TextView tvName;
    private TextView tvTime;
    private TextView tvFollowOrNot;

    public InfoDetailUserFollowView(Context context) {
        this(context,null);
    }

    public InfoDetailUserFollowView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
        initViews();
    }

    public void setUserInfo(@NonNull InfoDetailUserFollowBean bean) {
        tvName.setText(InfoStringUtil.isNotNull(bean.getUserName()));
        tvTime.setText(InfoStringUtil.isNotNull(bean.getTime()));
        GlideLoadImgUtil.loadImgHead(context,bean.getUserHeadImg(),ivHead);
        ivHead.setOnClickListener(new OnMultiClickListener() {
            @Override
            public void onMultiClick(View v) {
                NavigateToDetailUtil.navigateToPerson(context,bean.getUserId());
            }
        });
        tvFollowOrNot.setSelected(bean.isHasFollow());
//        tvFollowOrNot.setText(bean.isHasFollow() ? context.getResources().getString(R.string.info_detail_has_follow) :
//                context.getResources().getString(R.string.info_detail_follow));
    }

    public void changeFollow(View view,@NonNull InfoDetailUserFollowBean bean) {
        TextView tvFollow = view.findViewById(R.id.tv_follow_info_detail);
        GoodView goodView = new GoodView(context);
        if (bean.isHasFollow()) {
            goodView.setText("+1");
            goodView.showAttention(tvFollow);
        } else {
            goodView.reset();
        }
        tvFollow.setSelected(bean.isHasFollow());
//        tvFollow.setText(bean.isHasFollow() ? context.getResources().getString(R.string.info_detail_has_follow) :
//                context.getResources().getString(R.string.info_detail_follow));
    }

    private void initViews() {
        this.removeAllViews();
        View view = LayoutInflater.from(getContext()).inflate(R.layout.cell_detail_user_info_follow,this, false);
        this.addView(view);
        ivHead = view.findViewById(R.id.iv_user_head_info_detial);
        tvName = view.findViewById(R.id.tv_name_detail_info);
        tvTime = view.findViewById(R.id.tv_time_detail_info);
        tvFollowOrNot = view.findViewById(R.id.tv_follow_info_detail);
        tvFollowOrNot.setOnClickListener(v -> {
            if (mOnFollowClickListener != null) {
                mOnFollowClickListener.onFollowClick(v);
            }
        });
    }

    public interface OnFollowClickListener {
        void onFollowClick(View view);
    }

    private OnFollowClickListener mOnFollowClickListener;

    public void setOnFollowClickListener(OnFollowClickListener mOnFollowClickListener) {
        this.mOnFollowClickListener = mOnFollowClickListener;
    }
}
