package com.yb.ballworld.information.ui.profile.data;

/**
 * Desc: <赛事简略信息实体类>
 * Author: JS-Barder
 * Created On: 2019/11/21 16:01
 */
public class MatchLeagueInfo {
    public int id;
    public int sportId;
    public int categoryId;
    public int currentSeasonId;
    public String cnName;
    public String cnAlias;
    public String enName;
    public String enAlias;
    public String logoUrl;
    public int isHot;
    public int type;
}
