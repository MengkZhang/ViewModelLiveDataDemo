package com.yb.ballworld.information.ui.home.presenter;

import android.content.Intent;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.adapter.TagCommitAdapter;
import com.yb.ballworld.information.ui.home.bean.IndexLableLetterBean;
import com.yb.ballworld.information.ui.home.bean.InfoPublishCategoryBean;
import com.yb.ballworld.information.ui.home.constant.TagParams;
import com.yb.ballworld.information.ui.home.service.InfoHttpApi;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * Desc 获取发布选择分类的ViewModel
 * Date 2019/11/20
 * author mengk
 */
public class PublishBaseViewModel extends ViewModel {

    private MutableLiveData<List<InfoPublishCategoryBean>> category = new MutableLiveData<>();

    public MutableLiveData<List<InfoPublishCategoryBean>> getCategory() {
        return category;
    }

    public PublishBaseViewModel() {
    }

    /**
     * 获取分类数据
     *
     * @param activity
     */
    public void getCategoryViewModel(AppCompatActivity activity) {
        InfoHttpApi httpApi = new InfoHttpApi();
        httpApi.getCategoryList(new LifecycleCallback<String>(activity) {
            @Override
            public void onSuccess(String data) {
//                LogUtils.INSTANCE.e("===z","data = " + data);
                if (data != null) {
                    try {
                        Gson gson = new Gson();
                        Type listType = new TypeToken<List<InfoPublishCategoryBean>>() {
                        }.getType();
                        List<InfoPublishCategoryBean> dataBean = gson.fromJson(data, listType);
                        category.setValue(dataBean);

                    } catch (Exception e) {

                        e.printStackTrace();
                        category.setValue(null);
                    }
                } else {

                    category.setValue(null);
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                LogUtils.INSTANCE.e("===z", "获取失败 = ");
                category.setValue(null);
            }
        });
    }

    /**
     * 获取展示数据
     *
     * @param categoryListSourceData
     * @return
     */
    public List<Object> getCategoryList(List<InfoPublishCategoryBean> categoryListSourceData) {
        List<Object> categoryList = new ArrayList<>();
        for (InfoPublishCategoryBean categoryListSourceDatum : categoryListSourceData) {
            categoryList.add(categoryListSourceDatum.getName());
        }
        return categoryList;
    }

    /**
     * 获取选择的id数据
     *
     * @param categoryListSourceData
     * @return
     */
    public List<String> getCategoryIdList(List<InfoPublishCategoryBean> categoryListSourceData) {
        List<String> categoryIdList = new ArrayList<>();
        for (InfoPublishCategoryBean categoryListSourceDatum : categoryListSourceData) {
            categoryIdList.add(categoryListSourceDatum.getId());
        }
        return categoryIdList;
    }

    public void clearAllTagsAndIdsNotifyData(ArrayList<IndexLableLetterBean> listTag, ArrayList<String> ids) {
        listTag.clear();
        ids.clear();
    }

    public ArrayList<IndexLableLetterBean> getResultData(Intent data) {
        return ((ArrayList<IndexLableLetterBean>) data.getSerializableExtra(TagParams.INTENT_PARAM_DATA));
    }


    public void clearAndAddIds(ArrayList<IndexLableLetterBean> resultData, ArrayList<String> ids) {
        ids.clear();
        for (IndexLableLetterBean resultDatum : resultData) {
            ids.add(String.valueOf(resultDatum.getId()));
            LogUtils.INSTANCE.e("===z", "返回的数据 = " + resultDatum.getLable() + "");
        }
    }

    public void notifyTagListData(ArrayList<IndexLableLetterBean> resultData, ArrayList<IndexLableLetterBean> listTag) {
        listTag.clear();
        listTag.addAll(resultData);
    }

}
