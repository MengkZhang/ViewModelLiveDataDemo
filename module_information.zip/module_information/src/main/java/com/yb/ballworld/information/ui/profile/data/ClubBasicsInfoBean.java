package com.yb.ballworld.information.ui.profile.data;

/**
 * 球队基础信息数据模型
 * @author Gethin
 * @time 2019/11/20 13:02
 */

public class ClubBasicsInfoBean {

    /**
     * teamRank : {"teamId":44,"teamName":"利物浦","logo":"https://img.qiutianxia.com/imgs/teams/20190219230536728_100x100.png","teamRank":1,"matchCount":12,"win":11,"lost":0,"draw":1,"goal":28,"lostGoal":10,"point":34}
     * team : {"id":44,"sportId":1,"cnName":"利物浦","cnAlias":"利物浦","enName":"Liverpool FC","enAlias":"Liverpool FC","logoUrl":"https://img.qiutianxia.com/imgs/teams/20190219230536728_100x100.png","divisionId":null,"coachId":30443,"coachName":"Klopp, Jurgen","establishDate":"1892","stadiumName":"安菲尔德球场","coachPic":null,"cityId":null,"address":null}
     * recentRecords : 胜胜胜胜胜胜
     */

    private TeamRankBean teamRank;
    private TeamBean team;
    private String recentRecords;

    public TeamRankBean getTeamRank() {
        return teamRank;
    }

    public void setTeamRank(TeamRankBean teamRank) {
        this.teamRank = teamRank;
    }

    public TeamBean getTeam() {
        return team;
    }

    public void setTeam(TeamBean team) {
        this.team = team;
    }

    public String getRecentRecords() {
        return recentRecords;
    }

    public void setRecentRecords(String recentRecords) {
        this.recentRecords = recentRecords;
    }

    public static class TeamRankBean {
        /**
         * teamId : 44
         * teamName : 利物浦
         * logo : https://img.qiutianxia.com/imgs/teams/20190219230536728_100x100.png
         * teamRank : 1
         * matchCount : 12
         * win : 11
         * lost : 0
         * draw : 1
         * goal : 28
         * lostGoal : 10
         * point : 34
         */

        private int teamId;
        private String teamName;
        private String logo;
        private int teamRank;
        private int matchCount;
        private int win;
        private int lost;
        private int draw;
        private int goal;
        private int lostGoal;
        private int point;

        public int getTeamId() {
            return teamId;
        }

        public void setTeamId(int teamId) {
            this.teamId = teamId;
        }

        public String getTeamName() {
            return teamName;
        }

        public void setTeamName(String teamName) {
            this.teamName = teamName;
        }

        public String getLogo() {
            return logo;
        }

        public void setLogo(String logo) {
            this.logo = logo;
        }

        public int getTeamRank() {
            return teamRank;
        }

        public void setTeamRank(int teamRank) {
            this.teamRank = teamRank;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public int getWin() {
            return win;
        }

        public void setWin(int win) {
            this.win = win;
        }

        public int getLost() {
            return lost;
        }

        public void setLost(int lost) {
            this.lost = lost;
        }

        public int getDraw() {
            return draw;
        }

        public void setDraw(int draw) {
            this.draw = draw;
        }

        public int getGoal() {
            return goal;
        }

        public void setGoal(int goal) {
            this.goal = goal;
        }

        public int getLostGoal() {
            return lostGoal;
        }

        public void setLostGoal(int lostGoal) {
            this.lostGoal = lostGoal;
        }

        public int getPoint() {
            return point;
        }

        public void setPoint(int point) {
            this.point = point;
        }
    }

    public static class TeamBean {
        /**
         * id : 44
         * sportId : 1
         * cnName : 利物浦
         * cnAlias : 利物浦
         * enName : Liverpool FC
         * enAlias : Liverpool FC
         * logoUrl : https://img.qiutianxia.com/imgs/teams/20190219230536728_100x100.png
         * divisionId : null
         * coachId : 30443
         * coachName : Klopp, Jurgen
         * establishDate : 1892
         * stadiumName : 安菲尔德球场
         * coachPic : null
         * cityId : null
         * address : null
         */

        private int id;
        private int sportId;
        private String cnName;
        private String cnAlias;
        private String enName;
        private String enAlias;
        private String logoUrl;
        private Object divisionId;
        private int coachId;
        private String coachName;
        private String establishDate;
        private String stadiumName;
        private Object coachPic;
        private Object cityId;
        private String address;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getSportId() {
            return sportId;
        }

        public void setSportId(int sportId) {
            this.sportId = sportId;
        }

        public String getCnName() {
            return cnName;
        }

        public void setCnName(String cnName) {
            this.cnName = cnName;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getEnName() {
            return enName;
        }

        public void setEnName(String enName) {
            this.enName = enName;
        }

        public String getEnAlias() {
            return enAlias;
        }

        public void setEnAlias(String enAlias) {
            this.enAlias = enAlias;
        }

        public String getLogoUrl() {
            return logoUrl;
        }

        public void setLogoUrl(String logoUrl) {
            this.logoUrl = logoUrl;
        }

        public Object getDivisionId() {
            return divisionId;
        }

        public void setDivisionId(Object divisionId) {
            this.divisionId = divisionId;
        }

        public int getCoachId() {
            return coachId;
        }

        public void setCoachId(int coachId) {
            this.coachId = coachId;
        }

        public String getCoachName() {
            return coachName;
        }

        public void setCoachName(String coachName) {
            this.coachName = coachName;
        }

        public String getEstablishDate() {
            return establishDate;
        }

        public void setEstablishDate(String establishDate) {
            this.establishDate = establishDate;
        }

        public String getStadiumName() {
            return stadiumName;
        }

        public void setStadiumName(String stadiumName) {
            this.stadiumName = stadiumName;
        }

        public Object getCoachPic() {
            return coachPic;
        }

        public void setCoachPic(Object coachPic) {
            this.coachPic = coachPic;
        }

        public Object getCityId() {
            return cityId;
        }

        public void setCityId(Object cityId) {
            this.cityId = cityId;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }
    }
}
