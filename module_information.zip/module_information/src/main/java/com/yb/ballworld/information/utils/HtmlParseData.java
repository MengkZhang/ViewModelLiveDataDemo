package com.yb.ballworld.information.utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc: <功能简述>
 * Author: JS-Dugu
 * Created On: 2019/10/16 0:43
 */
public class HtmlParseData {

    public static int TYPE_OTHER = 0;
    public static int TYPE_LINK = 1;
    public static int TYPE_IMG = 2;

    private List<String> imgUrls = new ArrayList<String>();
    private List<String> aUrls = new ArrayList<String>();
    private String docHtml;
    private String publisher;
    private String publishTime;
    private String detailTitle;

    public List<String> getImgUrls() {
        return imgUrls;
    }

    public void setImgUrls(List<String> imgUrls) {
        this.imgUrls = imgUrls;
    }

    public List<String> getAUrls() {
        return aUrls;
    }

    public void setAUrls(List<String> aUrls) {
        this.aUrls = aUrls;
    }

    public String getDocHtml() {
        return docHtml;
    }

    public void setDocHtml(String docHtml) {
        this.docHtml = docHtml;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getPublishTime() {
        return publishTime;
    }

    public void setPublishTime(String publishTime) {
        this.publishTime = publishTime;
    }

    public String getDetailTitle() {
        return detailTitle;
    }

    public void setDetailTitle(String detailTitle) {
        this.detailTitle = detailTitle;
    }
}
