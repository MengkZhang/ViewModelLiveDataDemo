package com.yb.ballworld.information.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;

import com.yb.ballworld.common.widget.MultTextView;
import com.yb.ballworld.information.R;

/**
 * @author Gethin
 * @time 2019/11/14 18:05
 */

public class RvPlayerRankHeader extends LinearLayout {

    public RvPlayerRankHeader(Context context) {
        this(context, null);
    }

    public RvPlayerRankHeader(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public RvPlayerRankHeader(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        LayoutInflater.from(getContext()).inflate(R.layout.rv_item_player_rank_header, this);
        MultTextView mtTitle = findViewById(R.id.mtTitle);
        mtTitle.setTexts("场次", "进球数");

    }
}
