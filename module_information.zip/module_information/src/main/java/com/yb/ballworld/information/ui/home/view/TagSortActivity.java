package com.yb.ballworld.information.ui.home.view;

import android.content.Intent;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.gyf.immersionbar.ImmersionBar;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.widget.placeholder.HomePlaceholderView;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.common.base.mvp.BaseMvpActivity;
import com.yb.ballworld.common.livedata.LiveDataObserver;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.adapter.TagSortInSideGroupAdapter;
import com.yb.ballworld.information.ui.home.adapter.TagSortOutSideLabelGroupAdapter;
import com.yb.ballworld.information.ui.home.bean.IndexLableLetterBean;
import com.yb.ballworld.information.ui.home.bean.OutSideIndexListLableLetterBean;
import com.yb.ballworld.information.ui.home.bean.OutSideLableGroupBean;
import com.yb.ballworld.information.ui.home.constant.TagParams;
import com.yb.ballworld.information.ui.home.constant.TagReqCode;
import com.yb.ballworld.information.ui.home.listener.OnMultiClickListener;
import com.yb.ballworld.information.ui.home.presenter.TagSortGroupPresenter;
import com.yb.ballworld.information.ui.home.utils.IndexStringUtil;
import com.yb.ballworld.information.ui.home.utils.StatusBarHeightUtil;

import java.util.ArrayList;
import java.util.List;


/**
 * Desc 标签库 activity 一级页面
 * Date 2019/11/7
 * author mengk
 */
public class TagSortActivity extends BaseMvpActivity<TagSortGroupPresenter> {

    private RelativeLayout rlClose;
    private RelativeLayout rlRightSure;
    private EditText etInputSearch;
    private HomePlaceholderView placeholder;
    private RecyclerView rvTagList;
    private LinearLayoutManager layoutManager;
    private TagSortOutSideLabelGroupAdapter tagSortOutSideLabelGroupAdapter;
    private List<OutSideIndexListLableLetterBean> lebelGroupData = new ArrayList<>();
    private ArrayList<String> ids;
    private String type = "";
    private String searchKey = "";

    /**
     * 初始化沉浸式
     */
    protected void initImmersionBar() {
        // 设置共同沉浸式样式
        ImmersionBar.with(this).statusBarDarkFont(true, 0.2f).statusBarColor(getStatusBarColor()).navigationBarColor(R.color.white).init();
    }

    @Override
    public PlaceholderView getPlaceholderView() {
        return placeholder;
    }

    @Override
    public void initPresenter() {
        mPresenter.setVM(this);
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_tag_sort;
    }

    @Override
    protected void initView() {
        ((TextView) F(R.id.title_bar_title)).setText(getResources().getString(R.string.tag_title));
        StatusBarHeightUtil.getStatusBarHeight(F(R.id.status_bar_new_tag), getStatusHeight());
        placeholder = F(R.id.placeholder_lable_group);
        rlClose = F(R.id.rl_close_sort_tag);
        F(R.id.rl_left_back).setOnClickListener(v -> finish());
        rlRightSure = F(R.id.rl_right_sure);
        etInputSearch = F(R.id.et_input_search_data);
        rvTagList = F(R.id.rv_tag_side_list);
        layoutManager = new LinearLayoutManager(this);
        rvTagList.setLayoutManager(layoutManager);
        tagSortOutSideLabelGroupAdapter = new TagSortOutSideLabelGroupAdapter(lebelGroupData);
        rvTagList.setAdapter(tagSortOutSideLabelGroupAdapter);
        getIdsFromUp();
    }

    private void getIdsFromUp() {
        Intent intent = getIntent();
        if (intent == null) return;
        ids = mPresenter.getIds(intent);
    }


    /**
     * 初始化重新加载数据
     */
    private void initReLoadEvent() {
        placeholder.setPageErrorRetryListener(v -> mPresenter.getLableGroupData(type,searchKey));
    }

    /**
     * 搜索内容变化 请求网络
     */
    private void initSearchEvent() {
        etInputSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchKey = s.toString();
                mPresenter.getLableGroupData(type,searchKey);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }


    @Override
    protected void bindEvent() {
        //初始化重新加载数据
        initReLoadEvent();

        //监听搜索框内容变化
        initSearchEvent();

        //点击确认
        sureBtn();

        //删除搜索内容事件
        closeSearch();

        //多选事件
        choiceEvent();

        //到更多页面
        toMoreEvent();

        callBackGetLableGroupData();

        callBackRequestLoading();

    }

    private void closeSearch() {
        rlClose.setOnClickListener(new OnMultiClickListener() {
            @Override
            public void onMultiClick(View v) {
                if (!TextUtils.isEmpty(etInputSearch.getText().toString().trim())) {
                    etInputSearch.setText("");
                }
            }
        });
    }

    private void callBackRequestLoading() {
        mPresenter.getReqLoading().observe(this, aBoolean -> {
            if (aBoolean) {
                showPageLoading();
            }
        });
    }

    /**
     * 请求数据回调
     */
    private void callBackGetLableGroupData() {
        mPresenter.getmOutSideLableGroupBean().observe(this, new LiveDataObserver<OutSideLableGroupBean>() {
            @Override
            public void onSuccess(OutSideLableGroupBean data) {
                hidePageLoading();

                List<OutSideIndexListLableLetterBean> outSideListLabelGroupData = IndexStringUtil.getOutSideListLabelGroupData(data);
                LogUtils.INSTANCE.e("===z","一级页面的数组 data = " + outSideListLabelGroupData);

                if (outSideListLabelGroupData != null && outSideListLabelGroupData.size() != 0) {

                    //显示内容view
                    showPageContent();

                    //判断上个页面带过来的数据id是否选中
                    mPresenter.handleIfContainsChoiceData(lebelGroupData,outSideListLabelGroupData,ids);

                    //刷新adapter
                    lebelGroupData.addAll(outSideListLabelGroupData);
                    tagSortOutSideLabelGroupAdapter.notifyDataSetChanged();

                } else {//data为空

                    showPageEmpty(getResources().getString(R.string.info_place_holder_no_data));
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                hidePageLoading();
                showPageError(getResources().getString(R.string.info_place_holder_no_net));
            }
        });
    }


    /**
     * 点击到更多标签页面
     */
    private void toMoreEvent() {

        tagSortOutSideLabelGroupAdapter.setOnItemChildClickListener((adapter, view, position) -> {
            //到更多页面--二级页面
            if (view.getId() == R.id.tv_to_tag_more) {

                mPresenter.clickToMoreTags(TagSortActivity.this,position,lebelGroupData);

            }
        });
    }

    /**
     * 多选事件
     */
    private void choiceEvent() {
        tagSortOutSideLabelGroupAdapter.setOnClickTagListener((view, position, bean) -> {
            if (bean.isCheck()) {
                bean.setCheck(false);
            } else {
                bean.setCheck(true);
            }

            TagSortInSideGroupAdapter tagSortInSideAdapter = tagSortOutSideLabelGroupAdapter.getTagSortInSideAdapter();
            if (tagSortInSideAdapter == null) return;
            tagSortInSideAdapter.changeCheck(TagSortActivity.this,view,bean);
        });
    }

    /**
     * 确认
     */
    private void sureBtn() {
        rlRightSure.setOnClickListener(v -> mPresenter.sureClickResultHandleData(TagSortActivity.this,lebelGroupData));


    }


    @Override
    protected void initData() {
        mPresenter.getLableGroupData(type,searchKey);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case TagReqCode.REQ_CODE_PUBLISH_TO_TAG_TO_MORE:
                if (data != null) {
                    //处理回调数据 判断关闭的二级页面带过来的数据id是否选中 或者取消了哪些选中的标签
                    mPresenter.onActivityResultHandleData(data,lebelGroupData);

                    //刷新adapter
                    tagSortOutSideLabelGroupAdapter.notifyDataSetChanged();

                }
                break;
        }
    }

    @Override
    protected void processClick(View view) {

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

}
