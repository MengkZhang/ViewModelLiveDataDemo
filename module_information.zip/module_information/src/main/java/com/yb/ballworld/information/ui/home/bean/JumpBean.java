package com.yb.ballworld.information.ui.home.bean;

/**
 * Desc
 * Date 2019/11/2
 * author mengk
 */
public class JumpBean {
    private String newsId;
    private String imgUrl;

    public String getNewsId() {
        return newsId;
    }

    public void setNewsId(String newsId) {
        this.newsId = newsId;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }
}
