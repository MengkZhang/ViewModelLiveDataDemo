package com.yb.ballworld.information.ui.profile.view.fragments;

import android.view.View;

import com.chad.library.adapter.base.BaseQuickAdapter;

/**
 * 资料库-数据-杯赛
 * @author Gethin
 * @time 2019/11/9 10:29
 */

public class DataSubCupFragment extends RvBaseFragment {
    @Override
    protected void loadData() {

    }

    @Override
    protected BaseQuickAdapter getAdapter() {
        return null;
    }

    @Override
    public void initPresenter() {

    }

    @Override
    protected void bindEvent() {

    }

    @Override
    protected void processClick(View view) {

    }
}
