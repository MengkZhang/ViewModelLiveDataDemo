package com.yb.ballworld.information.ui.home.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;

import com.yb.ballworld.baselib.utils.ViewUtils;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.information.R;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Desc
 * Date 2019/10/14
 * author mengk
 */
public class PlaceholderViewInfoDetail extends PlaceholderView {
    public PlaceholderViewInfoDetail(@NotNull Context context) {
        super(context);
        setBackgroundColor(ViewUtils.INSTANCE.getColor(R.color.grey_f8));
        removeAllViews();
        LayoutInflater.from(context).inflate(R.layout.base_layout_place_holder_info_detail, this);
    }

    public PlaceholderViewInfoDetail(@NotNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        setBackgroundColor(ViewUtils.INSTANCE.getColor(R.color.grey_f8));
        removeAllViews();
        LayoutInflater.from(context).inflate(R.layout.base_layout_place_holder_info_detail, this);
    }

    public PlaceholderViewInfoDetail(@NotNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        setBackgroundColor(ViewUtils.INSTANCE.getColor(R.color.grey_f8));
        removeAllViews();
        LayoutInflater.from(context).inflate(R.layout.base_layout_place_holder_info_detail, this);
    }
}
