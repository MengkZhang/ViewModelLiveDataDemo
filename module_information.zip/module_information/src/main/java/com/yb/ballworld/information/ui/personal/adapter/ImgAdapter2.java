package com.yb.ballworld.information.ui.personal.adapter;

import android.view.View;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.util.DensityUtil;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.personal.bean.PostImage;

import java.util.List;

/**
 * Desc cell图片适配器
 * Date 2019/11/12
 * author JS-Kylo
 */
public class ImgAdapter2 extends BaseQuickAdapter<String, BaseViewHolder> {

    public ImgAdapter2(@Nullable List<String> data) {
        super(R.layout.item_img_face, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, String item, int pos) {

        View viewItemRoot = helper.getView(R.id.cv_img_face);
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) viewItemRoot.getLayoutParams();

        if (pos >= 0 && pos <= 6) {
            layoutParams.bottomMargin = DensityUtil.dp2px(5);
        } else {
            layoutParams.bottomMargin = 0;
        }

        ImageView imageView = helper.getView(R.id.iv_img_multi);

        Glide.with(mContext).load(item).placeholder(R.drawable.icon_default_info_ball).error(R.drawable.icon_default_info_ball).into(imageView);
    }

    @Override
    public int getItemCount() {
        return super.getItemCount();
    }
}
