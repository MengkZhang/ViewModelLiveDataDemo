package com.yb.ballworld.information.ui.home.adapter;

import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.util.DensityUtil;
import com.yb.ballworld.baselib.utils.TimeUtils;
import com.yb.ballworld.common.baseapp.AppContext;
import com.yb.ballworld.common.utils.ScreenUtils;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.bean.HomeIndexSpecialBean;
import com.yb.ballworld.information.ui.home.bean.HomeIndexSpecialMatchBean;
import com.yb.ballworld.information.ui.home.bean.HomeInfoListBean;
import com.yb.ballworld.information.ui.home.bean.IndexHotEntity;
import com.yb.ballworld.information.ui.home.utils.GlideLoadImgUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.home.utils.ScoreCompareUtil;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

/**
 * Desc 专栏adapter
 * Date 2019/10/9
 * author mengk
 */
public class IndexSpecialAdapter extends BaseQuickAdapter<IndexHotEntity.SpecialBlocksBean.SpecialBlockVoBean.MatchDataBean, BaseViewHolder> {

    SimpleDateFormat dataFormatter;
    int screenWidth;

    public IndexSpecialAdapter(@Nullable List<IndexHotEntity.SpecialBlocksBean.SpecialBlockVoBean.MatchDataBean> data) {
        super(R.layout.item_home_index_special, data);
        dataFormatter = new SimpleDateFormat("HH:mm", Locale.getDefault());
        screenWidth = ScreenUtils.getScreenWidth(AppContext.getAppContext());
    }

    @Override
    protected void convert(BaseViewHolder helper, IndexHotEntity.SpecialBlocksBean.SpecialBlockVoBean.MatchDataBean item, int pos) {
        String timeMatch;

        View viewItemRoot = helper.getView(R.id.ll_root_view_sp);
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) viewItemRoot.getLayoutParams();
        layoutParams.width = (screenWidth-DensityUtil.dp2px(32))/2;

        if (pos == getItemCount()-1){
            layoutParams.rightMargin = DensityUtil.dp2px(10);
        } else {
            layoutParams.rightMargin = 0;
        }

        //比赛名称
        TextView tvMatchName = helper.getView(R.id.tv_match_name_special);
        //比赛时间
        TextView tvMatchTime = helper.getView(R.id.tv_time_index_special);
        //主队logo
        ImageView ivHostLogo = helper.getView(R.id.iv_host_name_index_hot);
        //主队名称
        TextView tvHostName = helper.getView(R.id.tv_title01_index_special);
        //主队得分
        TextView tvHostScore = helper.getView(R.id.tv_host_score_special);
        //客队logo
        ImageView ivGuestLogo = helper.getView(R.id.iv_gest_name_index_hot);
        //客队名称
        TextView tvGuestName = helper.getView(R.id.tv_gest_name_special);
        //客队得分
        TextView tvGuestScore = helper.getView(R.id.tv_gest_score_special);
        //图标
        ImageView ivIcon = helper.getView(R.id.iv_icon_index_special);

        //1 未开始    2 比赛中  3 结束  4 异常
        int matchStatus = item.getMatchStatus();
        String matchStatusDesc = item.getMatchStatusDesc();
        String matchTime = item.getMatchTime();
        String matchName = item.getLeagueName();
        String hostMatchLogo = item.getHostTeamLogo();
        String hostMatchName = item.getHostTeamName();
        int hostMatchScore = item.getHostTeamScore();
        String gestMatchLogo = item.getGuestTeamLogo();
        String gestMatchName = item.getGuestTeamName();
        int gestMatchScore = item.getGuestTeamScore();
        tvMatchName.setText(isNotNull(matchName));
        GlideLoadImgUtil.loadTeamLogo(mContext, hostMatchLogo, ivHostLogo);
        tvHostName.setText(isNotNull(hostMatchName));
        GlideLoadImgUtil.loadTeamLogo(mContext, gestMatchLogo, ivGuestLogo);
        tvGuestName.setText(isNotNull(gestMatchName));

        //得分
        if (hostMatchScore > gestMatchScore) {//大于
            tvHostScore.setTextColor(mContext.getResources().getColor(R.color.color_1e1e1e));
            tvGuestScore.setTextColor(mContext.getResources().getColor(R.color.color_999999));
        } else if (hostMatchScore == gestMatchScore) {//等于
            tvHostScore.setTextColor(mContext.getResources().getColor(R.color.color_1e1e1e));
            tvGuestScore.setTextColor(mContext.getResources().getColor(R.color.color_1e1e1e));
        } else {//小于
            tvHostScore.setTextColor(mContext.getResources().getColor(R.color.color_999999));
            tvGuestScore.setTextColor(mContext.getResources().getColor(R.color.color_1e1e1e));
        }
        tvHostScore.setText(isNotNull(hostMatchScore + ""));
        tvGuestScore.setText(isNotNull(gestMatchScore + ""));

        //设置和计算时间  1 未开始    2 比赛中  3 结束  4 异常
        if (matchStatus == 1) {         //未开赛 显示开赛时间
            ivIcon.setVisibility(View.VISIBLE);
            try {
                long time = Long.parseLong(matchTime);
                timeMatch = TimeUtils.INSTANCE.getDateFormat(time, dataFormatter);
            } catch (Exception e) {
                e.printStackTrace();
                timeMatch = "";
            }
            tvMatchTime.setText(timeMatch);

        } else if (matchStatus == 2) {  //比赛中 显示matchStatusDesc
            ivIcon.setVisibility(View.VISIBLE);
            tvMatchTime.setText(!TextUtils.isEmpty(matchStatusDesc) ? matchStatusDesc : "");

        } else if (matchStatus == 3) {  //结束   显示结束
            ivIcon.setVisibility(View.GONE);
            tvMatchTime.setText("结束");

        } else {                        //异常   显示异常
            ivIcon.setVisibility(View.GONE);
            tvMatchTime.setText("");

        }


        int matchId = item.getMatchId();
        int sportId = item.getSportId();

        helper.getView(R.id.ll_root_view_sp).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavigateToDetailUtil.navigateToLiveDetail(mContext,matchId,sportId);
            }
        });
    }

    private String isNotNull(String string) {
        return !TextUtils.isEmpty(string) ? string : "";
    }
}
