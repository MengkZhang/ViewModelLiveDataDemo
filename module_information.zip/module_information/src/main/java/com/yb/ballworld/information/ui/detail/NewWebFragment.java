package com.yb.ballworld.information.ui.detail;

import android.os.Bundle;

import com.yb.ballworld.baselib.web.WebConstant;
import com.yb.ballworld.baselib.web.WebNavFragment;
import com.yb.ballworld.information.R;

import org.jetbrains.annotations.Nullable;

public class NewWebFragment extends WebNavFragment {

    @Override
    protected boolean isProgressBarLoading() {
        return true;
    }

    @Override
    protected boolean isShowToolBar() {
        return true;
    }

    @Override
    public int getLeftIcon() {
        return R.drawable.ic_infor_return;
    }

    @Override
    protected boolean isShowBackIcon() {
        return true;
    }

    @Nullable
    @Override
    protected String getWebTitle() {
        return "";
    }

    @Nullable
    @Override
    protected String getPageTitle() {
        return "";
    }

    @Override
    protected boolean isSwipeBackEnable() {
        return true;
    }

    @Override
    public int getContentResID() {
        return R.layout.base_fragment_web;
    }

    private static int FILE_CHOOSER_RESULT_CODE = 1001;

    static NewWebFragment newInstance(String url, String title, Boolean webBack, Boolean swipeBack, int sportType) {
        NewWebFragment fragment = new NewWebFragment();
        Bundle bundle = new Bundle();
        bundle.putString(WebConstant.KEY_WEB_URL, url);
        bundle.putString(WebConstant.KEY_WEB_TITLE, title);
        bundle.putBoolean(WebConstant.KEY_WEB_BACK, webBack);
        bundle.putBoolean(WebConstant.KEY_WEB_SWIPE_BACK, swipeBack);
        bundle.putInt(WebConstant.KEY_WEB_SPORT_TYPE, sportType);
        fragment.setArguments(bundle);
        return fragment;
    }
}
