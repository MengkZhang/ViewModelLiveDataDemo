package com.yb.ballworld.information.ui.detail;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bfw.image.core.utils.RoundType;
import com.bfw.image.glide.transform.RoundedCornersTransformation;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.request.RequestOptions;
import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.scwang.smartrefresh.layout.util.DensityUtil;
import com.yb.ballworld.baselib.utils.ImageManager;
import com.yb.ballworld.baselib.utils.ViewUtils;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.data.ArticleBean;
import com.yb.ballworld.information.data.CommitBean;
import com.yb.ballworld.information.data.RootBean;
import com.yb.ballworld.information.ui.home.bean.IndexLableDetailBean;
import com.yb.ballworld.information.utils.CommondUtil;
import com.yb.ballworld.information.utils.HtmlParseData;
import com.yb.ballworld.information.widget.FlowTagLayout;
import com.yb.ballworld.information.widget.TagAdapter;
import com.yb.ballworld.information.widget.TimerTextView;
import com.yb.ballworld.information.widget.listener.OnElementClickListener;

import java.util.ArrayList;
import java.util.List;

import cn.jzvd.JzvdStd;

import static com.yb.ballworld.information.ui.detail.InforConstant.SortType.ITEMTYPE_HEAT;
import static com.yb.ballworld.information.ui.detail.InforConstant.SortType.ITEMTYPE_TIME;
import static com.yb.ballworld.information.utils.CommondUtil.fitEmpty;

/**
 * Desc:
 *
 * @author ink
 * created at 2019/10/22 17:01
 */
public class NewsTextDetailQuickAdapter extends BaseMultiItemQuickAdapter<MultiItemEntity, BaseViewHolder> {
    private Context context;
    private FlowTagLayout.OnTagClickListener mOnTagClickListener;
    private OnShareOrLikeClickListener mOnShareOrLikeClickListener;
    private OnElementClickListener mOnElementClickListener;
    private boolean hasMore = false;
    private boolean isHeat = false;

    public void setOnTagClickListener(FlowTagLayout.OnTagClickListener onTagClickListener) {
        this.mOnTagClickListener = onTagClickListener;
    }

    public void setOnShareOrLikeClickListener(OnShareOrLikeClickListener onShareOrLikeClickListener) {
        mOnShareOrLikeClickListener = onShareOrLikeClickListener;
    }

    public void setOnElementClickListener(OnElementClickListener onElementClickListener) {
        mOnElementClickListener = onElementClickListener;
    }

    /**
     * Same as QuickAdapter#QuickAdapter(Context,int) but with
     * some initialization data.
     *
     * @param data A new list is created out of this one to avoid mutable list
     */
    public NewsTextDetailQuickAdapter(List data, Context context) {
        super(data);
        this.context = context;
        addItemType(InforConstant.ItemType.DETAIL_HEADER_NEWS, R.layout.item_detail_header2);
        addItemType(InforConstant.ItemType.DETAIL_NEWS, R.layout.item_relative_news);
        addItemType(InforConstant.ItemType.DETAIL_HEADER_COMMENT, R.layout.item_detail_root);
        addItemType(InforConstant.ItemType.DETAIL_COMMENT, R.layout.item_commit_layout);
    }

    public boolean hasMore() {
        return hasMore;
    }

    public void setHasMore(boolean hasMore) {
        this.hasMore = hasMore;
    }

    public boolean isHeat() {
        return isHeat;
    }

    public void setHeat(boolean heat) {
        isHeat = heat;
    }

    /**
     * 改变点赞的数量与状态
     *
     * @param isLiked
     * @param position
     */
    public void changedLike(boolean isLiked, int position) {
        MultiItemEntity entity = getItem(position);
        if (entity instanceof ArticleBean) {
            ArticleBean articleBean = (ArticleBean) entity;
            if (articleBean != null) {
                int likeCount = articleBean.getLikeCount() + 1;
                articleBean.setLikeCount(likeCount);
                articleBean.setLike(isLiked);
                notifyItemChanged(position);
            }
        }
    }

    /**
     * 改变点赞的数量与状态
     *
     * @param item
     * @param baseViewHolder
     */
    public void changedLike(CommitBean item, BaseViewHolder baseViewHolder) {
        ImageView view = baseViewHolder.getView(R.id.singleCommit_like);
        if (view != null) {
            view.setImageResource(item.isLike() ? R.drawable.icon_priase_info : R.drawable.icon_priase_info_normal);
        }
        TextView textView = baseViewHolder.getView(R.id.singleCommit_likeCount);
        if (textView != null) {
            textView.setText(String.valueOf(item.getLikeCount()));
        }

    }

    /**
     * itemtype分类布局总处理处
     *
     * @param helper
     * @param item
     * @param pos
     */
    @Override
    protected void convert(BaseViewHolder helper, MultiItemEntity item, int pos) {
        int itemType = item.getItemType();
        if (itemType == InforConstant.ItemType.DETAIL_NEWS) {
            proxyNews(helper, (ArticleBean) item, pos);
        } else if (itemType == InforConstant.ItemType.DETAIL_COMMENT) {
            proxyComment(helper, (CommitBean) item, pos);
        } else if (itemType == InforConstant.ItemType.DETAIL_HEADER_NEWS) {
            proxyNewsHeader(helper, (ArticleBean) item, pos);
        } else if (itemType == InforConstant.ItemType.DETAIL_HEADER_COMMENT) {
            proxyCommentHeader(helper, (RootBean) item, pos);
        }

        int margin=0;
        if (hasMore()) {
            margin = 0;
        } else if (pos > 0 && pos == getItemCount() - 1&&(itemType==InforConstant.ItemType.DETAIL_NEWS||itemType==InforConstant.ItemType.DETAIL_COMMENT)) {
            margin = DensityUtil.dp2px(20);
        }else{
             margin= 0;
        }
        RecyclerView.LayoutParams params = (RecyclerView.LayoutParams) helper.itemView.getLayoutParams();
        params.bottomMargin=margin;
    }

    /**
     * 处理相关新闻的头部、文章tags，分享等
     *
     * @param helper
     * @param item
     * @param pos
     */
    private void proxyNewsHeader(BaseViewHolder helper, ArticleBean item, int pos) {

        helper.setText(R.id.inforDetail_likeCount, String.valueOf(item.getLikeCount()));
        helper.setImageResource(R.id.inforDetail_like, item.isLike() ? R.drawable.icon_priase_info : R.drawable.icon_priase_info_normal);
        helper.getView(R.id.inforDetail_like).setTag(item.isLike());
        View.OnClickListener clickListener = v -> {
            if (mOnShareOrLikeClickListener != null) {
                int id = v.getId();
                int type;
                if (id == R.id.inforDetail_like) {
                    type = InforConstant.ItemEvent.LIKE_ARTICLE;
                } else if (id == R.id.inforDetail_shareLayout) {
                    type = InforConstant.ItemEvent.SHARE_ARTICLE;
                } else {
                    type = InforConstant.ItemEvent.NONE;
                }
                mOnShareOrLikeClickListener.onClick(type, v);
            }
        };
        helper.getView(R.id.inforDetail_like).setOnClickListener(clickListener);
        helper.getView(R.id.inforDetail_shareLayout).setOnClickListener(clickListener);

        //显示热门标签
        FlowTagLayout flowTagLayout = helper.getView(R.id.inforDetail_flowTagLayout);
        List<String> tags = CommondUtil.arrayToList(CommondUtil.splitBySign(item.getKeywords(), ","));
        List<IndexLableDetailBean> labels = item.getLabels();

        //判断是否有labels 如果没有 在判断是否有tags 有显示tag 没有则不显示
        if (labels != null && labels.size() != 0) { //新版本有labels
            flowTagLayout.setVisibility(View.VISIBLE);
            TagAdapter mTagAdapter = new TagAdapter<IndexLableDetailBean>(context);
            flowTagLayout.setAdapter(mTagAdapter);
            mTagAdapter.clearAndAddAll(labels);
            mTagAdapter.notifyDataSetChanged();
//            flowTagLayout.setOnTagClickListener(mOnTagClickListener);

        } else {                                    //兼容老版本的tags
            if (tags != null && tags.size() != 0) {
                TagAdapter mTagAdapter = new TagAdapter<String>(context);
                flowTagLayout.setVisibility(View.VISIBLE);
                mTagAdapter.clearAndAddAll(tags);
                mTagAdapter.notifyDataSetChanged();
//                flowTagLayout.setOnTagClickListener(mOnTagClickListener);
            } else { //没有标签

                flowTagLayout.setVisibility(View.GONE);
            }
        }

//        boolean needShow = (labels != null && labels.size() != 0);
////        boolean needShow = tags != null;
//        flowTagLayout.setVisibility(needShow ? View.VISIBLE : View.GONE);
//        if (needShow) {
//            TagAdapter mTagAdapter = new TagAdapter<String>(context);
//            flowTagLayout.setAdapter(mTagAdapter);
////            mTagAdapter.clearAndAddAll(tags);
//            mTagAdapter.clearAndAddAll(labels);
//            mTagAdapter.notifyDataSetChanged();
//            flowTagLayout.setOnTagClickListener(mOnTagClickListener);
//        }
    }

    /**
     * 处理评论头
     *
     * @param helper
     * @param item
     * @param pos
     */
    private void proxyCommentHeader(BaseViewHolder helper, RootBean item, int pos) {
        helper.setText(R.id.inforDetail_sortTitle, item.getArgs() == ITEMTYPE_HEAT ? R.string.txt_sortByHeat : R.string.txt_sortByTime);
        setOnItemChildClickListener(getOnItemChildClickListener());
        helper.getView(R.id.inforDetail_sortType_view).setOnClickListener(v -> {
            v.setClickable(false);
            item.setArgs(item.getArgs() == ITEMTYPE_HEAT ? ITEMTYPE_TIME : ITEMTYPE_HEAT);
            helper.setText(R.id.inforDetail_sortTitle, item.getArgs() == ITEMTYPE_HEAT ? R.string.txt_sortByHeat : R.string.txt_sortByTime);
            setHeat(item.getArgs() == ITEMTYPE_HEAT);
            if (getOnItemChildClickListener() != null) {
                getOnItemChildClickListener().onItemChildClick(NewsTextDetailQuickAdapter.this, v, pos);
            }
            v.setClickable(true);
        });
    }

    /**
     * 处理相关新闻或视频Item
     *
     * @param helper
     * @param item
     * @param pos
     */
    private void proxyNews(BaseViewHolder helper, ArticleBean item, int pos) {
        ((TextView) helper.getView(R.id.relativeNews_title)).setText(item.getTitle());
        ImageManager.INSTANCE.loadRoundIcon(item.getImgUrl(), R.drawable.icon_default_info_ball, ViewUtils.dp2px(4), ((ImageView) helper.getView(R.id.relativeNews_img)));
        helper.getView(R.id.relativeNews_play).setVisibility(item.getMediaType() > 0 ? View.VISIBLE : View.GONE);
    }

    /**
     * 处理资讯的评论Item
     *
     * @param helper
     * @param item
     * @param pos
     */
    private void proxyComment(BaseViewHolder helper, CommitBean item, int pos) {
        //头像、名称、时间
        ImageManager.INSTANCE.loadRoundIcon(item.getHeadImgUrl(), R.drawable.user_default_icon2, 0, helper.getView(R.id.singleCommit_photo));
        helper.setText(R.id.singleCommit_commiter, item.getNickName());
        ((TimerTextView)helper.getView(R.id.singleCommit_time)).setDefiniteTime(item.getCreatedTime());

        //点赞
        helper.setImageResource(R.id.singleCommit_like, item.isLike() ? R.drawable.icon_priase_info : R.drawable.icon_priase_info_normal);
        helper.setText(R.id.singleCommit_likeCount, CommondUtil.likeCount(item.getLikeCount(), context));

        //文字
        String text = fitEmpty(item.getContent());
        boolean isNonZero = text.length() > 0;
        if (isNonZero) {
            helper.setText(R.id.singleCommit_text, text);
        }
        helper.setGone(R.id.singleCommit_text, isNonZero);

        //评论数
        isNonZero = item.getSonNum() > 0;
        if (isNonZero) {
            helper.setText(R.id.singleCommit_count, CommondUtil.commentCount(item.getSonNum(), context));
        }
        helper.setGone(R.id.singleCommit_countLayout, isNonZero);

        //添加单击事件
        helper.addOnClickListener(R.id.singleCommit_like, R.id.singleCommit_countLayout, R.id.singleCommit_photo, R.id.singleCommit_commiter);

        //媒体布局扩展
        int mediaType = getMediaType(item);
        if (mediaType == InforConstant.MediaType.ITEMTYPE_VIDEO) {
            handleVideo(helper, item);
        } else if (mediaType == InforConstant.MediaType.ITEMTYPE_IMGS) {
            handleImgs(helper, item);
        } else {
            helper.getView(R.id.singleCommit_frameLayout).setVisibility(View.GONE);
        }
    }

    /**
     * 获取媒资类型
     *
     * @param item
     */
    public int getMediaType(CommitBean item) {
        int type;
        if (!TextUtils.isEmpty(item.getVideoUrl())) {
            type = InforConstant.MediaType.ITEMTYPE_VIDEO;
        } else if (isHasImg(item)) {
            type = InforConstant.MediaType.ITEMTYPE_IMGS;
        } else {
            type = InforConstant.MediaType.ITEMTYPE_NO_MEDIA;
        }
        return type;
    }


    /**
     * 评论中是否含有图片
     *
     * @param item
     * @return
     */
    private boolean isHasImg(CommitBean item) {

        return !TextUtils.isEmpty(item.getImgUrl1()) || !TextUtils.isEmpty(item.getImgUrl2()) || !TextUtils.isEmpty(item.getImgUrl3());
    }

    /**
     * 评论中提取图片列表
     *
     * @param item
     * @return
     */
    public List<String> getImgList(CommitBean item) {
        List<String> imgList = new ArrayList<>();

        String imgUrl = item.getImgUrl1();
        if (!TextUtils.isEmpty(imgUrl)) {
            imgList.add(imgUrl);
        }
        imgUrl = item.getImgUrl2();
        if (!TextUtils.isEmpty(imgUrl)) {
            imgList.add(imgUrl);
        }
        imgUrl = item.getImgUrl3();
        if (!TextUtils.isEmpty(imgUrl)) {
            imgList.add(imgUrl);
        }
        return imgList;
    }

    /**
     * 处理评论中含有视频的扩展布局
     *
     * @param helper
     * @param item
     */
    private void handleVideo(BaseViewHolder helper, CommitBean item) {
        ViewGroup viewGroup= helper.getView(R.id.singleCommit_frameLayout);
        viewGroup.setVisibility(View.VISIBLE);
        if (viewGroup.getChildCount() > 0) {
            for(int i=viewGroup.getChildCount()-1;i>=0;i--){
                View child=viewGroup.getChildAt(i);
                if(child.getId()!=R.id.view_video){
                    viewGroup.removeView(child);
                }
            }
        }

        View v=helper.getView(R.id.view_video);
        if(v==null){
            LayoutInflater.from(context).inflate(R.layout.item_comment_video, helper.getView(R.id.singleCommit_frameLayout), true);
        }
        JzvdStd jzvdStd = helper.getView(R.id.item_comment_video);
        if (!TextUtils.isEmpty(item.getVideoUrl())) {
            jzvdStd.setUp(item.getVideoUrl(), "", JzvdStd.SCREEN_NORMAL);
            Glide.with(context).setDefaultRequestOptions(new RequestOptions()
                    .frame(1).transform(new CenterCrop(), new RoundedCornersTransformation(ViewUtils.dp2px(4), RoundType.ALL))).load(item.getVideoUrl())
                    .into(jzvdStd.thumbImageView);
        }
    }

    /**
     * 处理评论中含有图片的扩展布局
     *
     * @param helper
     * @param item
     */
    private void handleImgs(BaseViewHolder helper, CommitBean item) {
        ViewGroup viewGroup= helper.getView(R.id.singleCommit_frameLayout);
        viewGroup.setVisibility(View.VISIBLE);
        if (viewGroup.getChildCount() > 0) {
            for(int i=viewGroup.getChildCount()-1;i>=0;i--){
                View child=viewGroup.getChildAt(i);
                if(child.getId()!=R.id.recycle_imgs){
                    viewGroup.removeView(child);
                }
            }
        }

        View v=helper.getView(R.id.recycle_imgs);
        if(v==null){
            LayoutInflater.from(context).inflate(R.layout.item_comment_imglist, helper.getView(R.id.singleCommit_frameLayout), true);
        }
        RecyclerView recyclerView = helper.getView(R.id.recycle_imgs);
        CommentImgQuickAdapter commentImgQuickAdapter = new CommentImgQuickAdapter(null);
        recyclerView.setAdapter(commentImgQuickAdapter);
        commentImgQuickAdapter.autoFit(recyclerView, getImgList(item));
        commentImgQuickAdapter.setOnItemClickListener(onItemImgsClickListener);
    }

    /**
     * 主要用在点击评论图片的事件转发
     *
     * @param adapter  the adpater
     * @param view     The itemView within the RecyclerView that was clicked (this
     * will be a view provided by the adapter)
     * @param position The position of the view in the adapter.
     */
    private OnItemClickListener onItemImgsClickListener = (adapter, view, position) -> {
        if (mOnElementClickListener != null) {
            mOnElementClickListener.onElementClick((String) adapter.getItem(position), HtmlParseData.TYPE_IMG, position, adapter.getData());
        }
    };


    public int getChildEventType(View view) {
        int viewId = view.getId();
        int type = InforConstant.ItemEvent.NONE;
        if (viewId == R.id.singleCommit_photo || viewId == R.id.singleCommit_commiter) {
            type = InforConstant.ItemEvent.USER_COMMENT;
        } else if (viewId == R.id.singleCommit_countLayout) {
            type = InforConstant.ItemEvent.REPLIES_COMMENT;
        } else if (viewId == R.id.singleCommit_like) {
            type = InforConstant.ItemEvent.LIKE_COMMENT;
        } else if (viewId == R.id.inforDetail_sortType_view) {
            type = InforConstant.ItemEvent.ROOT_SORT;
        }
        return type;
    }

    /**
     * 布局更换注意替换
     *
     * @return
     */
    public int getVideoViewId() {
        return R.id.item_comment_video;
    }

    public void updateCommentCount(int position,int count){
        MultiItemEntity entity= getItem(position);
        if(entity!=null&&entity instanceof CommitBean){
            ((CommitBean)entity).setSonNum(count);
        }
        View view= getViewByPosition(position+getHeaderLayoutCount(),R.id.singleCommit_countLayout);
        if(view!=null){
            //评论数
            boolean isNonZero = count > 0;
            if (isNonZero) {
                ((TextView)view.findViewById(R.id.singleCommit_count)).setText(CommondUtil.commentCount(count, context));
            }
            view.setVisibility(isNonZero?View.VISIBLE:View.GONE);
            //helper.setGone(R.id.singleCommit_countLayout, isNonZero);
        }
    }

}
