package com.yb.ballworld.information.ui.home.adapter;
import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

import com.bfw.util.ToastUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.yb.ballworld.common.baseapp.AppContext;
import com.yb.ballworld.common.utils.NetWorkUtils;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.bean.IndexHotEntity;
import com.yb.ballworld.information.ui.home.bean.InfoListEntity;
import com.yb.ballworld.information.ui.home.listener.PraiseResultListener;
import com.yb.ballworld.information.ui.home.presenter.InfoPraisePresenter;
import com.yb.ballworld.information.widget.GoodView;

/**
 * Desc 点赞帮助类
 * Date 2019/10/11
 * author mengk
 */
public class InfoPraiseAdapterHelper {
    /**
     * 初始化点赞事件 视频列表点赞
     *
     * @param adapter         adapter
     * @param praisePresenter 点赞presenter
     * @param goodView
     */
    public static void initPraise(RecyclerView recyclerView,InfoVideoAdapter adapter, InfoPraisePresenter praisePresenter, GoodView goodView) {
        try {
            adapter.setOnItemChildClickListener(new BaseQuickAdapter.OnItemChildClickListener() {
                @Override
                public void onItemChildClick(BaseQuickAdapter adapter1, View view, int position) {
                    Object item = adapter1.getItem(position);
                    if (item instanceof InfoListEntity.ListBean) {
                        String id = ((InfoListEntity.ListBean) item).getId();
                        boolean hasFocus = ((InfoListEntity.ListBean) item).isIsLike();
                        int commentCount = ((InfoListEntity.ListBean) item).getLikeCount();
                        if (view.getId() == R.id.rl_praise_root) {
                            //判断是否有网络
                            //V1.1.0版本除了没有网络 其他情况皆是点赞成功
                            boolean netConnected = NetWorkUtils.isNetConnected(AppContext.getAppContext());
                            if (!netConnected) {
                                ToastUtils.showToast("网络未连接");
                                return;
                            }

                            if (!hasFocus) { //没有点赞过

                                RecyclerView.ViewHolder viewHolder = recyclerView.findViewHolderForLayoutPosition(position);
                                //点赞 点击就改变状态 刷新列表 不管请求是否成功
                                goodView.show(view);
                                ((InfoListEntity.ListBean) item).setLikeCount(commentCount + 1);
                                ((InfoListEntity.ListBean) item).setIsLike(true);
                                if (viewHolder != null) {
                                    adapter.changeLike((BaseViewHolder) viewHolder,(InfoListEntity.ListBean)item);
                                } else {
                                    adapter1.notifyItemChanged(position);
                                }

//                                ToastUtils.INSTANCE.showToast("点赞成功");

                                praisePresenter.loadData(id, new PraiseResultListener() {
                                    @Override
                                    public void onSuccess() {
//                                        goodView.show(view);
//                                        ((InfoListEntity.ListBean) item).setLikeCount(commentCount + 1);
//
//                                        //根据id存储了点赞的状态和数量
//                                        ((InfoListEntity.ListBean) item).setIsLike(true);
//                                        adapter1.notifyItemChanged(position);
//
//                                        ToastUtils.INSTANCE.showToast("点赞成功");
                                    }

                                    @Override
                                    public void onFail() {
//                                        ToastUtils.INSTANCE.showToast("点赞失败");
                                    }
                                });
                            } else {
                                //ToastUtils.INSTANCE.showToast("点赞成功");
                                goodView.show(view);
                            }

                        }

                    }
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
//            ToastUtils.INSTANCE.showToast("点赞异常");
        }
    }

    /**
     * 首页热门点赞
     *
     * @param infoHotAdapter
     * @param praisePresenter
     */
    public static void initPraiseHot(InfoHotAdapter infoHotAdapter, InfoPraisePresenter praisePresenter, GoodView goodView) {
        try {
            infoHotAdapter.setOnItemChildClickListener(new BaseQuickAdapter.OnItemChildClickListener() {
                @Override
                public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
                    if (view.getId() == R.id.rl_praise_root) {
                        //判断是否有网络
                        //V1.1.0版本除了没有网络 其他情况皆是点赞成功
                        boolean netConnected = NetWorkUtils.isNetConnected(AppContext.getAppContext());
                        if (!netConnected) {
                            ToastUtils.showToast("网络未连接");
                            return;
                        }
                        final int finalPosition = position + 1;
                        final Object item = adapter.getItem(position);
                        if (item instanceof IndexHotEntity.NewsBean.ListBean) {
                            boolean like = ((IndexHotEntity.NewsBean.ListBean) item).isLike();
                            String newsId = ((IndexHotEntity.NewsBean.ListBean) item).getId();
                            int likeCount = ((IndexHotEntity.NewsBean.ListBean) item).getLikeCount();

                            if (!like) {

                                //点赞 点击就改变状态 刷新列表 不管请求是否成功
                                ((IndexHotEntity.NewsBean.ListBean) item).setLikeCount(likeCount + 1);
                                ((IndexHotEntity.NewsBean.ListBean) item).setLike(true);
                                if (view != null) {
                                    infoHotAdapter.changeLike(view,(IndexHotEntity.NewsBean.ListBean) item);
                                } else {
                                    adapter.notifyItemChanged(finalPosition);
                                }
//                                ToastUtils.INSTANCE.showToast("点赞成功");
                                goodView.show(view);

                                praisePresenter.loadData(newsId, new PraiseResultListener() {
                                    @Override
                                    public void onSuccess() {
//                                        ((IndexHotEntity.NewsBean.ListBean) item).setLikeCount(likeCount + 1);
//                                        ((IndexHotEntity.NewsBean.ListBean) item).setLike(true);
//                                        adapter.notifyItemChanged(finalPosition);
//                                        ToastUtils.INSTANCE.showToast("点赞成功");
//                                        goodView.show(view);
                                    }

                                    @Override
                                    public void onFail() {
//                                        ToastUtils.INSTANCE.showToast("点赞失败");
                                    }
                                });
                            } else {
//                                ToastUtils.INSTANCE.showToast("点赞成功");
//                                adapter.notifyItemChanged(finalPosition);
                                goodView.show(view);
                            }
                        }

                    }
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
//            ToastUtils.INSTANCE.showToast("点赞异常");
        }
    }

    /**
     * 初始化置顶中的点赞
     *
     * @param indexTopAdapter
     * @param praisePresenter
     * @param goodView
     */
    public static void initPraiseTop(IndexTopAdapter indexTopAdapter, InfoPraisePresenter praisePresenter, GoodView goodView) {
        try {
            indexTopAdapter.setOnItemChildClickListener(new BaseQuickAdapter.OnItemChildClickListener() {
                @Override
                public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
                    Object item = adapter.getItem(position);
                    if (item instanceof IndexHotEntity.NewsTopBlocksBean) {
                        //判断是否有网络
                        //V1.1.0版本除了没有网络 其他情况皆是点赞成功
                        boolean netConnected = NetWorkUtils.isNetConnected(AppContext.getAppContext());
                        if (!netConnected) {
                            ToastUtils.showToast("网络未连接");
                            return;
                        }

                        boolean hasFocus = ((IndexHotEntity.NewsTopBlocksBean) item).isLike();
                        int likeCount = ((IndexHotEntity.NewsTopBlocksBean) item).getLikeCount();
                        String newsId = ((IndexHotEntity.NewsTopBlocksBean) item).getNewsId();
                        if (!hasFocus) { //没有点过赞 请求


                            //点赞 点击就改变状态 刷新列表 不管请求是否成功
                            goodView.show(view);
                            ((IndexHotEntity.NewsTopBlocksBean) item).setLikeCount(likeCount + 1);
                            ((IndexHotEntity.NewsTopBlocksBean) item).setLike(true);
                            if (view != null) {
                                indexTopAdapter.changeLike(view,(IndexHotEntity.NewsTopBlocksBean) item);
                            } else {
                                adapter.notifyItemChanged(position);
                            }
//                            ToastUtils.INSTANCE.showToast("点赞成功");

                            praisePresenter.loadData(newsId, new PraiseResultListener() {
                                @Override
                                public void onSuccess() {
//                                    goodView.show(view);
//                                    ((IndexHotEntity.NewsTopBlocksBean) item).setLikeCount(likeCount + 1);
//                                    ((IndexHotEntity.NewsTopBlocksBean) item).setLike(true);
//                                    adapter.notifyItemChanged(position);
//                                    ToastUtils.INSTANCE.showToast("点赞成功");
                                }

                                @Override
                                public void onFail() {
//                                    ToastUtils.INSTANCE.showToast("点赞失败");
                                }
                            });

                        } else {         //点过赞 显示动画
                            //ToastUtils.INSTANCE.showToast("点赞成功");
                            goodView.show(view);
                        }
                    }
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
//            ToastUtils.INSTANCE.showToast("点赞失败");
        }
    }

}
