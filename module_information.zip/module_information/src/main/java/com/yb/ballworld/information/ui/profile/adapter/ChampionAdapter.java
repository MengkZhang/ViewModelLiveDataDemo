package com.yb.ballworld.information.ui.profile.adapter;


import android.widget.ImageView;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.yb.ballworld.baselib.utils.ImageManager;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.profile.data.ChampionBean;


/**
 * @author Gethin
 * @time 2019/11/18 14:45
 */

public class ChampionAdapter extends BaseQuickAdapter<ChampionBean, BaseViewHolder> {

    public ChampionAdapter() {
        super(R.layout.rv_item_champion);
    }

    @Override
    protected void convert(BaseViewHolder helper, ChampionBean item, int pos) {
        ImageView ivChampion = helper.getView(R.id.ivChampion);
        TextView tvTime = helper.getView(R.id.tvTime);

        ImageManager.INSTANCE.loadLogo("", ivChampion);
        tvTime.setText("2014/2015");
    }
}
