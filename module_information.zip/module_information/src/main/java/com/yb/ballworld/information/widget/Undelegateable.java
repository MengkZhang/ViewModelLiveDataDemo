package com.yb.ballworld.information.widget;

/**
* Desc:
* @author ink
* created at 2019/10/9 10:35
*/
interface Undelegateable {
     interface BubbleStyle {
          @SuppressWarnings("unused")
          void setPadding(int left, int top, int right, int bottom);
     }
}
