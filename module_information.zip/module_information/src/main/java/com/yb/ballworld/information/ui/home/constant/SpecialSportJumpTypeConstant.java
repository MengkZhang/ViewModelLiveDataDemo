package com.yb.ballworld.information.ui.home.constant;

import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Desc 专栏中赛事的跳转类型
 *  1 足球 2 篮球 3 棒球 5 网球
 * Date 2019/10/7
 * author mengk
 */
@IntDef({
        SpecialSportJumpTypeConstant.TYPE_FOOTBALL,
        SpecialSportJumpTypeConstant.TYPE_BASEKETBALL,
        SpecialSportJumpTypeConstant.TYPE_TENNISBALL,
        SpecialSportJumpTypeConstant.TYPE_BASEBALL
})

@Retention(RetentionPolicy.SOURCE)

public @interface SpecialSportJumpTypeConstant {
    int TYPE_FOOTBALL = 1;
    int TYPE_BASEKETBALL = 2;
    int TYPE_TENNISBALL = 5;
    int TYPE_BASEBALL = 3;
}


