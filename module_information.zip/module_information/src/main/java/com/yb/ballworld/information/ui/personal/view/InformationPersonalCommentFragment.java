package com.yb.ballworld.information.ui.personal.view;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bfw.util.ToastUtils;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshFooter;
import com.scwang.smartrefresh.layout.api.RefreshHeader;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.base.recycler.header.PlayBallHeader;
import com.yb.ballworld.baselib.base.recycler.header.RecyclerClassicsFooter;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.common.base.BaseRefreshFragment;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.personal.adapter.CommentAdapter;
import com.yb.ballworld.information.ui.personal.adapter.ItemPraiseAdapterHelper;
import com.yb.ballworld.information.ui.personal.bean.CommentBean;
import com.yb.ballworld.information.ui.personal.constant.FailStateConstant;
import com.yb.ballworld.information.ui.personal.constant.LoadMoreType;
import com.yb.ballworld.information.ui.personal.presenter.InfoPersonalCommentPresenter;
import com.yb.ballworld.information.ui.personal.presenter.InforPersonalCommentContract;
import com.yb.ballworld.information.ui.personal.presenter.ItemPraisePresenter;
import com.yb.ballworld.information.utils.CommondUtil;
import com.yb.ballworld.information.widget.GoodView;
import com.yb.ballworld.information.widget.listener.OnElementClickListener;

import java.util.ArrayList;
import java.util.List;

/**
 * 个人页-评论
 * Desc:
 * Author: JS-Kylo
 * Created On: 2019/10/10 11:12
 */
public class InformationPersonalCommentFragment extends BaseRefreshFragment implements InforPersonalCommentContract.InfoCommentView, OnElementClickListener {
    public static final String PERSONAL_ID = "personal_user_id";
    public static final String PERSONAL_NAME = "personal_user_name";
    public static final String PERSONAL_HEAD_URL = "personal_head_url";
    private SmartRefreshLayout smartRefreshLayout;
    private RecyclerView recyclerView;
    private PlaceholderView placeholder;
    private CommentAdapter commentAdapter;
    private LinearLayoutManager layoutManager;
    private InfoPersonalCommentPresenter presenter;
    private List<CommentBean> dataList = new ArrayList<>();
    private GoodView goodView;
    private String userId;
    private String userName;
    private String headUrl;

    public static InformationPersonalCommentFragment newInstance(String userId, String userName,String hUrl) {
        InformationPersonalCommentFragment commentFragment = new InformationPersonalCommentFragment();
        Bundle bundle = new Bundle();
        bundle.putString(PERSONAL_ID, userId);
        bundle.putString(PERSONAL_NAME, userName);
        bundle.putString(PERSONAL_HEAD_URL, hUrl);

        commentFragment.setArguments(bundle);
        return commentFragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.information_fragment_comment;
    }

    @Override
    protected void initView() {
        Bundle bundle = getArguments();
        if (null != bundle) {
            userId = bundle.getString(PERSONAL_ID);
            userName = bundle.getString(PERSONAL_NAME);
            headUrl = bundle.getString(PERSONAL_HEAD_URL);
        }
        smartRefreshLayout = findView(R.id.smartRefreshLayout);
        recyclerView = findView(R.id.recyclerView);
        placeholder = findView(R.id.placeholder);
        smartRefreshLayout.setRefreshHeader(getRefreshHeader());
        smartRefreshLayout.setRefreshFooter(getRefreshFooter());
        layoutManager = new LinearLayoutManager(mContext);
        recyclerView.setLayoutManager(layoutManager);
        commentAdapter = new CommentAdapter(dataList, getContext(),userName,headUrl);
        commentAdapter.setOnElementClickListener(this);
        recyclerView.setAdapter(commentAdapter);
        goodView = new GoodView(mContext);
        goodView.setText("+1");
        goodView.setImage(getResources().getDrawable(R.drawable.icon_priase_info));
    }

    @Override
    protected void initData() {
        if (TextUtils.isEmpty(userId)) {
            showPageEmpty("暂无数据");
            return;
        }
        //初始化presenter
        presenter = new InfoPersonalCommentPresenter(userId);
        presenter.attachView(this);
        presenter.loadData(1);
    }

    @Override
    protected void bindEvent() {
        initRefreshLoadMoreEvent();
        initReLoadEvent();
        smartRefreshLayout.setEnableLoadMore(false);
        ItemPraiseAdapterHelper.initCommentPraise(commentAdapter, new ItemPraisePresenter(), goodView);
        LiveEventBus.get().with(LiveEventBusKey.KEY_COMMIT_LIKE,String.class).observe(this, newsId -> {
            if (dataList.size() != 0) {
                for (int i = 0; i < dataList.size(); i++) {
                    CommentBean listBean = dataList.get(i);
                    String listBeanId = listBean.getId()+"";
                    if (newsId.equals(listBeanId)) {
                        listBean.setIsLike(true);
                        commentAdapter.notifyItemChanged(i);
                        break;
                    }
                }
            }
        });
    }

    @Override
    protected void processClick(View view) {

    }

    /**
     * 加载器显示加载框
     */
    @Override
    public void requestLoading() {
        //showPageLoading();
     /*   smartRefreshLayout.setEnableRefresh(false);
        smartRefreshLayout.setEnableLoadMore(false);*/
    }

    /**
     * 请求成功回调
     *
     * @param data 列表数据
     */
    @Override
    public void resultSuccess(List<CommentBean> data,int page) {
        LogUtils.INSTANCE.e("===z", "列表数据长度data = " + data.size());
        placeholder.hideLoading();
        smartRefreshLayout.setEnableRefresh(true);
        smartRefreshLayout.setEnableLoadMore(true);
        if(page<=1){
            dataList.clear();
        }
        dataList.addAll(data);
        //commentAdapter = new CommentAdapter(dataList, getContext(),userName);
        //ItemPraiseAdapterHelper.initCommentPraise(commentAdapter, new ItemPraisePresenter(), goodView);
        //recyclerView.setAdapter(commentAdapter);
        commentAdapter.notifyDataSetChanged();
    }

    /**
     * 加载失败
     *
     * @param type 失败的类型
     */
    @Override
    public void resultFail(int type,String errMsg) {
        switch (type) {
            case FailStateConstant.TYPE_ERROR:   //加载失败
                if (TextUtils.isEmpty(errMsg)||"null".equals(errMsg))
                    placeholder.showError("服务器连接失败~");
                else
                    placeholder.showError(errMsg);
                break;
            case FailStateConstant.TYPE_EMPTY:   //数据为空
                showPageEmpty("暂无数据");
                break;
            default:
                break;
        }
    }

    /**
     * 刷新成功回调
     */
    @Override
    public void resultRefreshSuccess() {
        //Toast.makeText(mContext, "刷新成功", Toast.LENGTH_SHORT).show();
        smartRefreshLayout.finishRefresh();
        //刷新成功清理存储的数组
        dataList.clear();
    }

    /**
     * 刷新失败回调
     *
     * @param errorMsg 失败信息
     */
    @Override
    public void resultRefreshFail(String errorMsg) {
        //ToastUtils.INSTANCE.showToastInfo("刷新失败");
        smartRefreshLayout.finishRefresh();
    }

    /**
     * 加载更多成功
     *
     * @param type 成功类型
     */
    @Override
    public void resultLoadMoreSuccess(int type) {
        smartRefreshLayout.finishLoadMore();
        switch (type) {
            case LoadMoreType.TYPE_SUCCESS:      //加载成功
                //Toast.makeText(mContext, "加载更多成功", Toast.LENGTH_SHORT).show();
                break;

            case LoadMoreType.TYPE_ALL_DATA:     //已经全部加载
                ToastUtils.showToast("已经全部加载");
                break;

            default:
                break;
        }
    }

    /**
     * 加载更多失败
     *
     * @param errorMsg 失败信息
     */
    @Override
    public void resultLoadMoreFail(String errorMsg) {
        ToastUtils.showToast("加载失败");
        smartRefreshLayout.finishLoadMore();
    }

    /**
     * 点赞成功回调
     */
    @Override
    public void praiseSuccess(int position, int commentId) {
        //dataList.get(position).setIsLike(true);
        commentAdapter.notifyItemChanged(position);
        //commentAdapter.refreshNotifyItemChanged(position);
//        ToastUtils.INSTANCE.showToast("点赞成功");
    }

    @Override
    public void praiseFail(String errorMsg) {

    }

    @Override
    public void onElementClick(String url, int type, int position, List<String> peerList) {
        if (type == CommentAdapter.ITEMTYPE_IMGS) {
            if (!CommondUtil.isEmpty(peerList)) {
                NavigateToDetailUtil.navigateToGalleryActivityWithoutShare(mContext,peerList,position);
            }
        }
    }

    /**
     * 初始化刷新和加载更多
     */
    private void initRefreshLoadMoreEvent() {
        smartRefreshLayout.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                presenter.loadMoreData();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                presenter.refreshData();
            }
        });
    }

    /**
     * 初始化重新加载数据
     */
    private void initReLoadEvent() {
        placeholder.setPageErrorRetryListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                presenter.loadData(1);
            }
        });
    }

    @Override
    protected RefreshHeader getRefreshHeader() {
        return new PlayBallHeader(mContext).createAnim(PlayBallHeader.FOOTBALL);
    }

    @Override
    protected RefreshFooter getRefreshFooter() {
        return new RecyclerClassicsFooter(mContext);
    }

    @Override
    public PlaceholderView getPlaceholderView() {
        return placeholder;
    }
}
