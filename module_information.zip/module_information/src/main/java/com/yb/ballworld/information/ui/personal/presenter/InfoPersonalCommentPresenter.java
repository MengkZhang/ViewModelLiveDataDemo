package com.yb.ballworld.information.ui.personal.presenter;

import android.util.Log;

import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.common.callback.OnUICallback;
import com.yb.ballworld.information.ui.personal.bean.CommentBean;
import com.yb.ballworld.information.ui.personal.bean.CommentBeanEntity;
import com.yb.ballworld.information.ui.personal.constant.FailStateConstant;
import com.yb.ballworld.information.ui.personal.constant.LoadMoreType;
import com.yb.ballworld.information.http.PersonalHttpApi;

import java.util.ArrayList;
import java.util.List;

import rxhttp.wrapper.entity.Response;

/**
 * Desc: 个人页-评论
 * Author: JS-Kylo
 * Created On: 2019/10/10 21:37
 */
public class InfoPersonalCommentPresenter implements InforPersonalCommentContract.InfoCommentPresenter {
    private PersonalHttpApi httpApi;
    private InforPersonalCommentContract.InfoCommentView mView;
    //private InfoContract.IInfoView mView;
    private List<CommentBean> mCommentList;
    private List<CommentBean> mCommentLastList;
    //当前页数
    private int page = 1;
    //返回的总页数
    private int totalPage;
    //资讯类型 0 请求新闻 1 请求视频
    private int mediaType;
    private boolean isRefresh;
    private boolean isLoadMore;
    private String mUserId;


    /**
     * 构造方法
     */
    public InfoPersonalCommentPresenter(String userId) {
        httpApi = new PersonalHttpApi();
        mCommentList = new ArrayList<>();
        mCommentLastList = new ArrayList<>();
        this.mUserId = userId;
    }


    @Override
    public void loadData(int page) {
        //只有正常加载才有loading 加载更多和刷新是没有的
        if (!isRefresh && !isLoadMore) {
            mView.requestLoading();
        }
        //每页的数据条数
        int pageSize = 15;
        httpApi.getCommentList(mUserId, page, pageSize, new OnUICallback<CommentBeanEntity>() {
            @Override
            public void onUISuccess(CommentBeanEntity data) {
                if (data!=null){
                    try {
                        totalPage = data.getTotalPage();
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                    }
                    List<CommentBean> list = data.getList();
                    if (list != null && list.size() !=0){
                        mCommentList = list;
                        //添加数据的操作
                        if (mCommentList.size() != 0) {      //添加数据
                            if (isRefresh) {
                                mCommentLastList.clear();
                            }
                            mCommentLastList.addAll(mCommentList);
                            //还原刷新的状态
                            if (isRefresh) {
                                isRefresh = false;
                                mView.resultRefreshSuccess();
                            }
                            //还原加载更多的状态
                            if (isLoadMore) {
                                isLoadMore = false;
                                mView.resultLoadMoreSuccess(LoadMoreType.TYPE_SUCCESS);
                            }
                            LogUtils.INSTANCE.e("===z", "list mCommentLastList = " + mCommentLastList.size());
                            mView.resultSuccess(mCommentLastList,page);
                            //执行成功完毕 清理中转数组 否则造成列表叠加
                            mCommentList.clear();
                        } else {                                //数据为空
                            judgeStatusEmpty();
                        }
                    }else {
                        judgeStatusEmpty();
                    }
                }else {
                    judgeStatusEmpty();
                }
            }

            @Override
            public void onUIFailed(int errCode, String errMsg) {
                if (isRefresh) {         //刷新失败
                    isRefresh = false;
                    mView.resultRefreshFail("刷新失败");
                } else if (isLoadMore) { //加载更多失败
                    isLoadMore = false;
                    mView.resultLoadMoreFail("加载更多失败");
                } else {                 //正常加载数据失败
                    mView.resultFail(FailStateConstant.TYPE_ERROR,errMsg);
                }
            }
        });
    }

    @Override
    public void refreshData() {
        isRefresh = true;
        page = 1;
        loadData(page);
    }

    @Override
    public void loadMoreData() {
        isLoadMore = true;
        page++;
        if (page <= totalPage) { //可以加载更多数据
            loadData(page);
        } else {                 //没有更多数据
            mView.resultLoadMoreSuccess(LoadMoreType.TYPE_ALL_DATA);
        }
    }

    @Override
    public void praiseComment(int position,int commentId) {
        httpApi.praiseComment(commentId, new OnUICallback<Response>() {
            @Override
            public void onUISuccess(Response data) {
                if (data.getCode() == 200) { //点赞成功
                    mView.praiseSuccess(position,commentId);
                } else {                     //点赞失败
                    mView.praiseFail(data.getMsg());
                }
            }

            @Override
            public void onUIFailed(int errCode, String errMsg) {
                mView.praiseFail(errMsg);
            }
        });
    }

    /**
     * 判断刷新 加载更多 和 正常加载
     */
    private void judgeStatusEmpty() {
        if (isRefresh) {
            isRefresh = false;
            mView.resultRefreshFail("刷新数据为空");
        } else if (isLoadMore) {
            isLoadMore = false;
            mView.resultRefreshFail("加载更多数据为空");
        } else {
            dataEmpty();
        }
    }

    /**
     * 数据为空
     */
    private void dataEmpty() {
        mView.resultFail(FailStateConstant.TYPE_EMPTY,"");
    }

    @Override
    public void attachView(InforPersonalCommentContract.InfoCommentView view) {
        this.mView = view;
    }

    @Override
    public void detachView() {
        this.mView = null;
    }
}
