package com.yb.ballworld.information.ui.detail;

import android.content.Intent;
import android.view.View;

import androidx.viewpager.widget.ViewPager;

import com.bfw.image.core.listener.OnImageSaveListener;
import com.bfw.util.ToastUtils;
import com.gyf.immersionbar.ImmersionBar;
import com.yb.ballworld.baselib.utils.ImageManager;
import com.yb.ballworld.common.base.SystemBarActivity;
import com.yb.ballworld.common.sharesdk.ShareSdkParamBean;
import com.yb.ballworld.common.sharesdk.ShareSdkUtils;
import com.yb.ballworld.common.widget.CommonTitleBar;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.utils.CommondUtil;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.util.List;

import static com.yb.ballworld.common.widget.CommonTitleBar.ACTION_LEFT_BUTTON;

public class InformationGalleryActivity extends SystemBarActivity implements OnImageSaveListener {
    private ImagesAdapter mImagesAdapter;
    private String title;
    private String titleUrl;
    private String text;
    private String url;
    private String imgUrl;
    private boolean hiddenShare;
    private View viewShare;

    /**
     * 初始化沉浸式
     */
    protected void initImmersionBar() {
        // 设置共同沉浸式样式
        ImmersionBar.with(this)
                .statusBarDarkFont(true, 0.2f)
                .statusBarColor(getStatusBarColor())
                .navigationBarColor(R.color.transparent_00)
                .init();
    }

    private void initIntent(){
        List<String> imgUrls = null;
        int position=0;
        Intent intent = getIntent();
        if (intent != null) {
            imgUrls = intent.getStringArrayListExtra("IMG_ARRAY");
            position=intent.getIntExtra("IMG_INDEX",0);
            position=getPosition(position,imgUrls);
            hiddenShare = intent.getBooleanExtra("HIDDEN_SHARE", false);
            title = intent.getStringExtra("TITLE");
            titleUrl = intent.getStringExtra("TITLE_URL");
            text = intent.getStringExtra("TEXT");
            if(imgUrls!=null&&imgUrls.size()>position) {
                imgUrl = imgUrls.get(position);
            }
            url = intent.getStringExtra("URL");
        }
        if (CommondUtil.isEmpty(imgUrls)) {
            ToastUtils.showToast(R.string.prompt_noImgs);
            finish();
        }else{
            mImagesAdapter=new ImagesAdapter(imgUrls,getLayouInflater());
            mImagesAdapter.setSltPosition(position);
        }
    }

    private int getPosition(int position,List<String> imgUrls){
        if(imgUrls!=null&&!imgUrls.isEmpty()){
            position=position>=imgUrls.size()?imgUrls.size()-1:position;
            position=position<0?0:position;
        }else{
            position=0;
        }
        return position;
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_infor_gallery;
    }

    @Override
    protected void initView() {
        initIntent();
        CommonTitleBar commonTitleBar= F(R.id.inforDetail_titlebar);
        commonTitleBar.setBackgroundColor(getResources().getColor(R.color.transparent));

        ViewPager viewPager= F(R.id.inforDetail_gallery);
        viewPager.setAdapter(mImagesAdapter);
        viewPager.setCurrentItem(mImagesAdapter.getSltPosition());
        StringBuffer stringBuffer=new StringBuffer(String.valueOf(mImagesAdapter.getSltPosition()+1));
        stringBuffer.append(File.separatorChar).append(mImagesAdapter.getCount());
        commonTitleBar.getCenterTextView().setText(stringBuffer);
        viewShare = F(R.id.rl_share_view_gallery);
        viewShare.setVisibility(!hiddenShare ? View.VISIBLE : View.GONE);
    }

    @Override
    protected void bindEvent() {
        ((CommonTitleBar)F(R.id.inforDetail_titlebar)).setListener((v, action, extra) -> {
            if (action == ACTION_LEFT_BUTTON) {
                finish();
            }
        });
        F(R.id.inforDetail_saveBtn).setOnClickListener(this);
        F(R.id.inforDetail_shareBtn).setOnClickListener(this);
        ((ViewPager)F(R.id.inforDetail_gallery)).addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                mImagesAdapter.setSltPosition(position);
                StringBuffer stringBuffer=new StringBuffer(String.valueOf(position+1));
                stringBuffer.append(File.separatorChar).append(mImagesAdapter.getCount());
                ((CommonTitleBar)F(R.id.inforDetail_titlebar)).getCenterTextView().setText(stringBuffer);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    @Override
    protected void initData() {

    }


    public void showEmpty() {

    }

    public void showError() {

    }

    @Override
    protected void processClick(View view) {
        int viewId = view.getId();
        if (viewId == R.id.inforDetail_saveBtn) {
            ImageManager.INSTANCE.saveImage(this,mImagesAdapter.getItem(mImagesAdapter.getSltPosition()),this);
        }
        else if (viewId == R.id.inforDetail_shareBtn) {
            //分享
            ShareSdkUtils.showShare(this,new ShareSdkParamBean(title,titleUrl,text,imgUrl,url));
        }
    }

    @Override
    public void onSaveStart() {

    }

    @Override
    public void onSaveSuccess(@org.jetbrains.annotations.Nullable String path, @NotNull String fileName) {
            ToastUtils.showToast("已保存到相册");
        }

    @Override
    public void onSaveFail(@org.jetbrains.annotations.Nullable String msg) {
        ToastUtils.showToast("保存失败");
    }
}
