package com.yb.ballworld.information.ui.profile.view.fragments;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.yb.ballworld.common.livedata.LiveDataObserver;
import com.yb.ballworld.information.ui.profile.adapter.TeamRankAdapter;
import com.yb.ballworld.information.ui.profile.data.MatchTeamBean;
import com.yb.ballworld.information.ui.profile.presenter.MatchTeamPresenter;
import com.yb.ballworld.information.widget.RvTeamRankHeader;

import java.util.List;

/**
 * 赛事资料库-球队榜
 * @author Gethin
 * @time 2019/11/7 18:25
 */

public class TeamRankFragment extends RvBaseFragment<MatchTeamPresenter> {

    public static TeamRankFragment newInstance(String seasonId) {
        TeamRankFragment fragment = new TeamRankFragment();
        Bundle bundle = new Bundle();
        bundle.putString("seasonId", seasonId);
        fragment.setArguments(bundle);
        return fragment;
    }

    private TeamRankAdapter adapter = new TeamRankAdapter();

    @Override
    protected void initView() {
        super.initView();
        rlRoot.setBackgroundColor(Color.parseColor("#ffffff"));
        adapter.addHeaderView(new RvTeamRankHeader(getContext()));
    }

    @Override
    protected void loadData() {
        Bundle bundle = getArguments();
        if (bundle != null) {
            String seasonId = bundle.getString("seasonId");
            mPresenter.setSeasonId(seasonId);
            mPresenter.setStatType("1");
        }
    }

    @Override
    protected BaseQuickAdapter getAdapter() {
        return adapter;
    }

    @Override
    public void initPresenter() {
        mPresenter.setVM(this);
    }

    @Override
    protected void bindEvent() {
        mPresenter.getDataWrap().observe(this, new LiveDataObserver<List<MatchTeamBean>>() {
            @Override
            public void onSuccess(List<MatchTeamBean> data) {
                smartRefreshLayout.finishRefresh(true);
                if (data != null && data.size() > 0) {
                    showPageContent();
                    adapter.setNewData(data);
                } else {
                    showPageEmpty("");
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                smartRefreshLayout.finishRefresh(false);
                showPageError(errMsg);
            }
        });
    }

    @Override
    protected void processClick(View view) {

    }
}
