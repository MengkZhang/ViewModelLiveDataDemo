package com.yb.ballworld.information.ui.home.bean;

/**
 * Desc
 * Date 2019/11/11
 * author mengk
 */
public class ParamTagBean {
    private String tag;
    private String tagId;

    public ParamTagBean() {
    }

    public ParamTagBean(String tag, String tagId) {
        this.tag = tag;
        this.tagId = tagId;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getTagId() {
        return tagId;
    }

    public void setTagId(String tagId) {
        this.tagId = tagId;
    }
}
