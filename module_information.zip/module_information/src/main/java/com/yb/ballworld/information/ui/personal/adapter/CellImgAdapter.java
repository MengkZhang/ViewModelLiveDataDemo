package com.yb.ballworld.information.ui.personal.adapter;

import android.view.View;
import android.widget.ImageView;

import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.personal.bean.PostEntity;
import com.yb.ballworld.information.ui.personal.bean.PostImage;

import java.util.List;

/**
 * Desc cell图片适配器
 * Date 2019/10/10
 * author JS-Kylo
 */
public class CellImgAdapter extends BaseQuickAdapter<PostImage, BaseViewHolder> {

    public CellImgAdapter(@Nullable List<PostImage> data) {
        super(R.layout.item_img_face, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, PostImage item, int pos) {
        ImageView imageView = helper.getView(R.id.iv_img_multi);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavigateToDetailUtil.navigateToDetail(mContext,item.getNewsId(),false);
            }
        });
        Glide.with(mContext).load(item.getImgUrl()).placeholder(R.drawable.icon_default_info_ball).error(R.drawable.icon_default_info_ball).into(imageView);
    }
}
