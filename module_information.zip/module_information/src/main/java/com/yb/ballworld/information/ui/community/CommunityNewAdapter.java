package com.yb.ballworld.information.ui.community;

import android.net.Uri;

import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.util.DensityUtil;
import com.yb.ballworld.baselib.utils.ImageManager;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.community.data.CommunityImageVideoItem;

import java.util.ArrayList;

/**
 * Desc: <>
 * Author: JS-Barder
 * Created On: 2019/11/10 11:06
 */
public class CommunityNewAdapter extends BaseMultiItemQuickAdapter<CommunityImageVideoItem, BaseViewHolder> {
    public static final int TYPE_IMAGE = 1001;
    public static final int TYPE_VIDEO = 1002;
    public static final int TYPE_ADD = 1003;

    public CommunityNewAdapter() {
        super(new ArrayList<>());
        addItemType(TYPE_VIDEO, R.layout.item_community_image_video);
        addItemType(TYPE_IMAGE, R.layout.item_community_image_video);
        addItemType(TYPE_ADD, R.layout.item_add);
    }

    public void removeAdd() {
        if (getItemCount() > 0) {
            for (int index = 0; index < getItemCount(); index++) {
                CommunityImageVideoItem item = getItem(index);
                if (item != null && item.type == TYPE_ADD) {
                    remove(index);
                    break;
                }
            }
        }
    }

    public void addAdd() {
        addData(new CommunityImageVideoItem(0, "", 0, 0, TYPE_ADD));
    }

    public boolean hasAdd() {
        if (getItemCount() > 0) {
            CommunityImageVideoItem item = getItem(getItemCount() - 1);
            if (item != null) {
                return item.type == TYPE_ADD;
            }
        }
        return false;
    }

    @Override
    protected void convert(BaseViewHolder helper, CommunityImageVideoItem item, int pos) {
        int type = item.getItemType();
        if (type == TYPE_VIDEO && item.type == TYPE_VIDEO) {
            helper.addOnClickListener(R.id.image_del);

            ImageManager.INSTANCE.loadReportRoundIcon(item.filePath, DensityUtil.dp2px(4), helper.getView(R.id.image));
        } else if (type == TYPE_IMAGE && item.type == TYPE_IMAGE) {
            helper.addOnClickListener(R.id.image_del);
            Uri uri = item.getItem().uri;
            if (uri == null) {
                uri = Uri.parse("content://media" + item.filePath);

                ImageManager.INSTANCE.loadReportRoundIcon(item.filePath, DensityUtil.dp2px(4), helper.getView(R.id.image));
              //  Glide.with(mContext).load(((CommunityNewImage) item).filePath).into((ImageView) helper.getView(R.id.image));
            } else {
               // Glide.with(mContext).load(((CommunityNewImage) item).filePath).into((ImageView) helper.getView(R.id.image));
                ImageManager.INSTANCE.loadReportRoundIcon(item.filePath, DensityUtil.dp2px(4), helper.getView(R.id.image));
            }
//            GlideLoadImgUtil.loadImg(mContext, ((CommunityNewImage) item).filePath, helper.getView(R.id.image));
        } else if (type == TYPE_ADD) {
            helper.addOnClickListener(R.id.image_add);
        }
    }
}
