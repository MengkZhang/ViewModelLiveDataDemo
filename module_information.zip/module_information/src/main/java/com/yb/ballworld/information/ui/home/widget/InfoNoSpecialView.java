package com.yb.ballworld.information.ui.home.widget;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.bean.IndexHotEntity;
import com.yb.ballworld.information.ui.home.listener.OnMultiClickListener;
import com.yb.ballworld.information.ui.home.utils.CommentHotUtil;
import com.yb.ballworld.information.ui.home.utils.GlideLoadImgUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;

/**
 * Desc 自定义首页条目-非特约
 *     单图0
 *     双图1
 *     三图2
 *     图集3
 * Date 2019/10/22
 * author mengk
 */
public class InfoNoSpecialView extends RelativeLayout {
    private Context mContext;
    private View iv_info_player_icon;
    private TextView tvTitle;
    private TextView tvTopTag;
    private ImageView ivFace;
    private View rootView;
    private ImageView iv_comment_icon;
    private TextView tv_comment_count_top;

    public InfoNoSpecialView(Context context) {
        this(context, null);
    }

    public InfoNoSpecialView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public InfoNoSpecialView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.mContext = context;
        initView();
    }

    /**
     * 设置具体数据
     * @param item 数据
     */
    public void setDetailData(IndexHotEntity.NewsBean.ListBean item) {
        if (item == null) return;
        int mediaType = item.getMediaType();
        if (mediaType == 1) {//显示视频图标
            iv_info_player_icon.setVisibility(View.VISIBLE);
        } else {//不显示视频播放
            iv_info_player_icon.setVisibility(View.GONE);
        }

        //隐藏置顶
        tvTopTag.setVisibility(item.isTop() ? View.VISIBLE : View.GONE);
        String imgUrl = item.getImgUrl();
        String title = item.getTitle();
        tvTitle.setText(isNotNull(title));
        GlideLoadImgUtil.loadImg(mContext,imgUrl, ivFace);

        //点击事件调详情
        rootView.setOnClickListener(v -> {
            String id = item.getId();
            int mediaType1 = item.getMediaType();
            NavigateToDetailUtil.navigateToDetail(mContext,id, mediaType1 == 1);
        });

        //设置评论
        CommentHotUtil.setHotComment(mContext,iv_comment_icon,
                tv_comment_count_top,
                item.getCommentCount());

    }

    /**
     * 初始化views
     */
    private void initView() {
        this.removeAllViews();
        View view = LayoutInflater.from(getContext()).inflate(R.layout.item_info_type_img,this, false);
        this.addView(view);
        //视频图标
        iv_info_player_icon = view.findViewById(R.id.iv_info_player_icon);
        tvTitle = view.findViewById(R.id.tv_title_top);
        tvTopTag = view.findViewById(R.id.tv_top_tag);
        ivFace = view.findViewById(R.id.iv_img_top);
        rootView = view.findViewById(R.id.rl_root_view_img);
        iv_comment_icon = view.findViewById(R.id.iv_comment_icon);
        tv_comment_count_top = view.findViewById(R.id.tv_comment_count_top);
        ivFace.setOnClickListener(new OnMultiClickListener() {
            @Override
            public void onMultiClick(View v) {
                if (onFaceClickListener != null) {
                    onFaceClickListener.faceClick();
                }
            }
        });
    }

    public interface OnFaceClickListener {
        void faceClick();
    }

    private OnFaceClickListener onFaceClickListener;

    public void setOnFaceClickListener(OnFaceClickListener onFaceClickListener) {
        this.onFaceClickListener = onFaceClickListener;
    }

    private String isNotNull(String string) {
        return !TextUtils.isEmpty(string) ? string : "";
    }
}
