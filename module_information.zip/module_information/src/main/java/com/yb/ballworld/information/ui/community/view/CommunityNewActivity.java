package com.yb.ballworld.information.ui.community.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.gyf.immersionbar.ImmersionBar;
import com.yb.ballworld.baselib.utils.SpUtils;
import com.yb.ballworld.baselib.widget.chat.EmojiLayout;
import com.yb.ballworld.common.base.mvp.BaseMvpActivity;
import com.yb.ballworld.common.utils.UriUtils;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.community.CommunityNewAdapter;
import com.yb.ballworld.information.ui.community.CommunityNewPresenter;
import com.yb.ballworld.information.ui.home.utils.ClickQuitUtil;
import com.yb.ballworld.information.ui.home.utils.softkey.KPSwitchFSPanelLinearLayout;
import com.yb.ballworld.information.ui.home.utils.softkey.KeyboardUtil;
import com.yb.ballworld.information.widget.GridSpacingItemDecoration;
import com.zhihu.matisse.Matisse;
import com.zhihu.matisse.internal.entity.Item;

import java.io.File;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import static android.text.TextUtils.isEmpty;

public class CommunityNewActivity extends BaseMvpActivity<CommunityNewPresenter> {

    private ConstraintLayout layoutCommunityRoot;
    private Button btnSure;
    private ImageView imgEmoji;
    private EditText mEdit;
    private TextView mCount;
    private RecyclerView mRecyclerImagesVideo;
    private CommunityNewAdapter adapter;

    public static void start(Context context) {
        context.startActivity(new Intent(context, CommunityNewActivity.class));
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_community_new;
    }

    /**
     * 初始化沉浸式
     */
    protected void initImmersionBar() {
        // 设置共同沉浸式样式
        ImmersionBar.with(this)
                .statusBarDarkFont(true, 0.2f)
                .statusBarColor(getStatusBarColor())
                .navigationBarColor(R.color.white)
                .init();
    }

    @Override
    protected boolean isTouchHideSoftInput() {
        return true;
    }


    @Override
    protected void initView() {
        layoutCommunityRoot = findViewById(R.id.layout_root_community);
        layoutCommunityRoot.setOnClickListener(this);
        mCount = findViewById(R.id.tv_count);
        mEdit = findViewById(R.id.et_community_content);
        mRecyclerImagesVideo = findViewById(R.id.recycler_images_video);
        mRecyclerImagesVideo.setLayoutManager(new GridLayoutManager(mContext, 3));
        mRecyclerImagesVideo.addItemDecoration(new GridSpacingItemDecoration(3, 6, false));
        adapter = mPresenter.getAdapter();
        mRecyclerImagesVideo.setAdapter(adapter);
        decorRootView = getWindow().getDecorView().findViewById(android.R.id.content);
        imgEmoji = findViewById(R.id.iv_emoji);
        imgEmoji.setOnClickListener(this);
        layoutEmoji = findViewById(R.id.layout_emoji);
        emojiRootView = findViewById(R.id.emoji_root_view);
        mEmojiLayout = findViewById(R.id.emoji_info_publish);
        TextView title = findViewById(R.id.title_bar_title);
        title.setText("发帖");
        btnSure = findViewById(R.id.title_bar_sure);
        autoShowSoftKey();
    }

    private void autoShowSoftKey() {
        mEdit.setFocusable(true);
        mEdit.requestFocus();
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                InputMethodManager manager = (InputMethodManager) CommunityNewActivity.this.getSystemService(Context.INPUT_METHOD_SERVICE);
                manager.showSoftInput(mEdit,0);
            }
        },200);
    }


    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void bindEvent() {
        bindAdapterItemClick();
        mEdit.setOnTouchListener((v, event) -> {
            if (event.getAction()== MotionEvent.ACTION_DOWN){
                if (layoutEmoji.getVisibility() == View.GONE) {
                    layoutEmoji.setVisibility(View.VISIBLE);
                }
            }
            return false;
        });
        mRecyclerImagesVideo.setOnTouchListener((v, event) -> {
            if (event.getAction()== MotionEvent.ACTION_DOWN) {
                if (layoutEmoji.getVisibility() == View.VISIBLE) {
                    layoutEmoji.setVisibility(View.GONE);
                }
            }
            return false;
        });
        findViewById(R.id.title_bar_back).setOnClickListener(v -> {
            if (mPresenter.isHasData()) {
                mPresenter.showSaveDialog();
            } else {
                finish();
            }
        });
        btnSure.setOnClickListener(v -> {
            if (!ClickQuitUtil.isFastClick()) {
                mPresenter.post(getInputText());
            }
        });
        mEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                mCount.setText(s.length() + "/300");
                checkRightEnable();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        mEmojiLayout.setOnEmojiClickListener(s -> {
            int selectionStart = mEdit.getSelectionStart();
            Editable editableText = mEdit.getEditableText();
            if (editableText != null) {
                editableText.insert(selectionStart, s);
            }
            return null;
        });
    }

    private void bindAdapterItemClick() {
        mPresenter.setAddImageListener(v -> {
            if (layoutEmoji.getVisibility() == View.VISIBLE) {
                layoutEmoji.setVisibility(View.GONE);
            }
        });

    }

    @Override
    protected void initData() {
        mPresenter.initData();
        boolean hasData = SpUtils.INSTANCE.getBoolean(CommunityNewPresenter.COMMUNITY_DRAFT_BOX_HAS_DATA);
        if (hasData) {
            String content = SpUtils.INSTANCE.getString(CommunityNewPresenter.COMMUNITY_INPUT_TEXT_CONTENT, "");
            if (!isEmpty(content)) {
                mEdit.setText(content);
                mEdit.setSelection(content.length());
            }
            boolean isVideo = SpUtils.INSTANCE.getBoolean(CommunityNewPresenter.IS_VIDEO);
//            List<CommunityImageVideoItem> items = mPresenter.readImageVideo();
            String json = SpUtils.INSTANCE.getString(CommunityNewPresenter.COMMUNITY_IMAGE_VIDEO_ITEMS_JSON, "");
//            int imageCaptureSize = SpUtils.INSTANCE.getInt(CommunityNewPresenter.COMMUNITY_IMAGE_CAPTURE_SIZE, 0);
            if (!isEmpty(json)) {
                List<String> paths = new Gson().fromJson(json, new TypeToken<List<String>>() {}.getType());
                if (paths != null && !paths.isEmpty()) {
                    mPresenter.setInitData(paths, isVideo);
//                    if (items != null && !items.isEmpty()) {
//                        mPresenter.setItemSelected(mPresenter.getItems(items), paths, isVideo);
//                    }
                }
            }
        }
        keyboardOnGlobalChangeListener = new KeyboardOnGlobalChangeListener();
        checkRightEnable();
    }

    @Override
    protected void onResume() {
        super.onResume();
        decorRootView.getViewTreeObserver().addOnGlobalLayoutListener(keyboardOnGlobalChangeListener);
    }

    @Override
    protected void onPause() {
        super.onPause();
        removeOnGlobalLayoutListener();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        removeOnGlobalLayoutListener();
    }

    private void removeOnGlobalLayoutListener() {
        if (keyboardOnGlobalChangeListener != null) {
            decorRootView.getViewTreeObserver().removeOnGlobalLayoutListener(keyboardOnGlobalChangeListener);
        }

        //如果显示了软键盘 则隐藏
        if (mIsShowSoftKeyBoard) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(mEdit.getWindowToken(), 0);
        }
    }

    @Override
    protected void processClick(View view) {

        if (view.getId() == R.id.iv_emoji) {

            //判断软键盘是否显示
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (mIsShowSoftKeyBoard) {//显示了软键盘 需要隐藏
                imm.hideSoftInputFromWindow(mEdit.getWindowToken(), 0);
                imgEmoji.setImageResource(R.mipmap.icon_info_softkeybord);
            } else {//没显示软键盘 需要打开
                imgEmoji.setImageResource(R.drawable.icon_info_emoji);
                imm.showSoftInput(mEdit, InputMethodManager.RESULT_SHOWN);
                imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);
            }

        }

    }

    public String getInputText() {
        return mEdit.getText().toString();
    }

    @Override
    public void onBackPressed() {
        hideEmoji();
        if (mPresenter.isHasData()) {
            mPresenter.showSaveDialog();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean hasPermissionDismiss = false;//有权限没有通过
        if (grantResults.length > 0) {
            for (int grantResult : grantResults) {
                if (grantResult == -1) {
                    hasPermissionDismiss = true;
                }
            }
            if (requestCode == CommunityNewPresenter.REQUEST_CODE_PERMISSION_IMAGE) {
                if (!hasPermissionDismiss) {
                    mPresenter.openGallery();
                }
            } else if (requestCode == CommunityNewPresenter.REQUEST_CODE_PERMISSION_CAPTURE_IMAGE) {
                if (!hasPermissionDismiss) {
                    mPresenter.openCaptureImage();
                }
            }
        }
        if (hasPermissionDismiss) {
            showToastMsgShort("未成功授权");
        }
    }

    public void checkRightEnable() {
        btnSure.setEnabled(mEdit.getText().length() > 0 || mPresenter.isHasData());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            List<Item> uris;
            List<String> paths;
            switch (requestCode) {
                case CommunityNewPresenter.REQUEST_CODE_CAPTURE_VIDEO:
                    if (data != null) {
                        Uri uri = data.getData();
                        String path = UriUtils.getPath(mContext, uri);
                        mPresenter.addCaptureVideo(path);
                    }
                    break;
                case CommunityNewPresenter.REQUEST_CODE_CAPTURE_IMAGE:
                    File file = mPresenter.getImageFile();
                    mPresenter.addCapturePhoto(file.getAbsolutePath());
                    break;
                case CommunityNewPresenter.REQUEST_CODE_IMAGE:
                    if (data != null) {
                        uris = Matisse.obtainItem(data);
                        paths = Matisse.obtainPathResult(data);
                        boolean isVideo = false;
                        for (Item item : uris) {
                            if (item.isVideo()) {
                                isVideo = true;
                                break;
                            }
                        }
                        btnSure.setEnabled(paths.size() > 0 || getInputText().length() > 0);
                        mPresenter.setItemSelected(uris, paths, isVideo);
                    }
                    break;
            }
        }
        checkRightEnable();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        return super.dispatchKeyEvent(event);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void initPresenter() {
        mPresenter.setVM(this);
    }

    private RelativeLayout layoutEmoji;
    private KPSwitchFSPanelLinearLayout emojiRootView;
    private EmojiLayout mEmojiLayout;
    private View decorRootView;
    private KeyboardOnGlobalChangeListener keyboardOnGlobalChangeListener;
    private boolean mIsShowSoftKeyBoard;

    public void hideEmoji() {
        layoutEmoji.setVisibility(View.GONE);
    }

    /**
     * 监听软键盘
     */
    private class KeyboardOnGlobalChangeListener implements ViewTreeObserver.OnGlobalLayoutListener {

        @Override
        public void onGlobalLayout() {
            //判断是否显示了软键盘
            boolean keyboardShown = mPresenter.isKeyboardShown(decorRootView);
            if (keyboardShown) {
                imgEmoji.setImageResource(R.drawable.icon_info_emoji);
                if (mEmojiLayout.getVisibility() == View.VISIBLE) {
                    mEmojiLayout.setVisibility(View.GONE);
                }
                mIsShowSoftKeyBoard = true;
            } else {
                mIsShowSoftKeyBoard = false;
            }

            //测量键盘高度
            KeyboardUtil.attach(CommunityNewActivity.this, emojiRootView);
            int mKeyboardHeight = KeyboardUtil.getKeyboardHeight(CommunityNewActivity.this);

            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) mEmojiLayout.getLayoutParams();
            layoutParams.height = mKeyboardHeight;
            mEmojiLayout.setVisibility(View.VISIBLE);
        }
    }
}
