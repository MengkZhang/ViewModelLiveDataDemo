package com.yb.ballworld.information.ui.home.presenter;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.MutableLiveData;

import com.bfw.util.ToastUtils;
import com.yb.ballworld.baselib.utils.Glide4Engine;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.bean.FileDataBean;
import com.yb.ballworld.information.ui.home.bean.FileVideoUriPathBean;
import com.yb.ballworld.information.ui.home.bean.IndexLableLetterBean;
import com.yb.ballworld.information.ui.home.bean.InfoPublishCategoryBean;
import com.yb.ballworld.information.ui.home.bean.InfoUploadVideoFileBean;
import com.yb.ballworld.information.ui.home.bean.PublishArticleOrVideoReqBody;
import com.yb.ballworld.information.ui.home.bean.PublishVideoDataBean;
import com.yb.ballworld.information.ui.home.constant.LengthLimit;
import com.yb.ballworld.information.ui.home.constant.MediaReqCodeType;
import com.yb.ballworld.information.ui.home.constant.TagParams;
import com.yb.ballworld.information.ui.home.service.InfoHttpApi;
import com.yb.ballworld.information.ui.home.utils.MediaUtils;
import com.yb.ballworld.information.ui.home.utils.cache.OutputUtil;
import com.zhihu.matisse.Matisse;
import com.zhihu.matisse.MimeType;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import rxhttp.wrapper.entity.Response;

/**
 * Desc
 * Date 2019/11/5
 * author mengk
 */
public class PublishVideoPresenter extends BasePresenter<LifecycleOwner, VoidModel> {
    private boolean needClearData;//是否需要清理数据

    private InfoHttpApi httpApi = new InfoHttpApi();

    private MutableLiveData<Boolean> reqLoading = new MutableLiveData<>();

    private MutableLiveData<InfoUploadVideoFileBean> infoUploadFile = new MutableLiveData<>();

    private MutableLiveData<FileVideoUriPathBean> fileVideoUriPathLiveData = new MutableLiveData<>();

    private MutableLiveData<Boolean> commitData = new MutableLiveData<>();

    public MutableLiveData<Boolean> getCommitData() {
        return commitData;
    }

    public MutableLiveData<InfoUploadVideoFileBean> getInfoUploadFile() {
        return infoUploadFile;
    }

    public MutableLiveData<Boolean> getReqLoading() {
        return reqLoading;
    }

    public MutableLiveData<FileVideoUriPathBean> getFileVideoUriPathLiveData() {
        return fileVideoUriPathLiveData;
    }

    /**
     * 打开视频
     *
     * @param context
     */
    public void openVideo(AppCompatActivity context) {
        Matisse.from(context)
                .choose(MimeType.of(MimeType.MPEG, MimeType.MP4, MimeType.QUICKTIME, MimeType.THREEGPP,
                        MimeType.THREEGPP2, MimeType.MKV, MimeType.WEBM, MimeType.TS, MimeType.AVI), true)
                .theme(R.style.Matisse_Zhihu)
                .countable(true)
                .setSelectionItems(new ArrayList<>())
                .showSingleMediaType(true)
                .maxSelectable(1)
                .originalEnable(false)
                .maxOriginalSize(10)
                .imageEngine(new Glide4Engine())
                .forResult(MediaReqCodeType.REQUEST_CODE_VIDEO);
    }

    /**
     * 打开视频回调
     *
     * @param resultCode
     * @param data
     */
    public void openVideoCallBack(int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            if (data != null) {   //data
                List<Uri> uris = Matisse.obtainResult(data);
                List<String> paths = Matisse.obtainPathResult(data);
                if (uris != null && uris.size() != 0 && paths != null && paths.size() != 0) {
                    fileVideoUriPathLiveData.setValue(new FileVideoUriPathBean(uris.get(0).toString(), paths.get(0)));
                } else {//数据为空
                    fileVideoUriPathLiveData.setValue(null);
                }

            } else {              //data为空
                fileVideoUriPathLiveData.setValue(null);
            }
        } else {
            LogUtils.INSTANCE.e("===z", "没有选择视频av");
            fileVideoUriPathLiveData.setValue(null);
        }
    }

    /**
     * 保存视频数据
     *
     * @param publishTitle
     * @param content
     * @param videoPath
     * @param videoUri
     */
    public void saveVideoData(String publishTitle, String content, String videoPath, String videoUri, ArrayList<IndexLableLetterBean> paramTagsList, InfoPublishCategoryBean categoryBean) {
        PublishVideoDataBean publishVideoDataBean = new PublishVideoDataBean();
        if (!TextUtils.isEmpty(publishTitle)) {
            publishVideoDataBean.setTitle(publishTitle);
        }
        publishVideoDataBean.setContent(content);
        publishVideoDataBean.setPath(!TextUtils.isEmpty(videoPath) ? videoPath : "");
        publishVideoDataBean.setUri(!TextUtils.isEmpty(videoUri) ? videoUri : "");
        //设置标签
        if (paramTagsList != null && paramTagsList.size() != 0) {
            publishVideoDataBean.setTagList(paramTagsList);
        }
        //缓存分类
        if (categoryBean != null) {
            publishVideoDataBean.setCategoryBean(categoryBean);
        }
        //存储视频数据
        OutputUtil.writeObject(TagParams.PUBLISH_VIDEO_DATA, publishVideoDataBean);

    }

    /**
     * 读取视频数据
     *
     * @return
     */
    public PublishVideoDataBean getVideoFromCache() {
        Object object = OutputUtil.getObject(TagParams.PUBLISH_VIDEO_DATA);
        LogUtils.INSTANCE.e("===z", "读取对象为data = " + object);
        return (PublishVideoDataBean) object;
    }

    /**
     * 清空视频数据
     */
    public void clearVideoData() {
        //设置需要删除数据
        needClearData = true;

        OutputUtil.clearFile(TagParams.PUBLISH_VIDEO_DATA);
    }

    /**
     * 判断视频数据是否为空
     *
     * @param videoPath
     * @param videoUri
     * @return
     */
    public boolean videoDataNotEmpty(String videoPath, String videoUri) {
        return (!TextUtils.isEmpty(videoPath) && !TextUtils.isEmpty(videoUri));
    }

    /**
     * 是否上传文件
     *  @param content
     * @param videoPath
     * @param videoUri
     * @param paramTagsList
     */
    public void ifUploadFile(String title, String content, String videoPath, String videoUri, ArrayList<IndexLableLetterBean> paramTagsList,String categoryId) {
        //判断是否有标题
        if (TextUtils.isEmpty(title)) {
            ToastUtils.showToast("请输入标题");
            return;
        }

        //判断是否有内容
        if (TextUtils.isEmpty(content)) {
            ToastUtils.showToast("请输入内容");
            return;
        }

        //判断内容是否超过5000字
        if (content.length() > LengthLimit.LENGTH_LIMIT) {
            ToastUtils.showToast("内容超过限制");
            return;
        }

        //判断是否上传了视频 否则不让通过 必须上传视频
        if (TextUtils.isEmpty(videoPath) || TextUtils.isEmpty(videoUri)) {
            ToastUtils.showToast("请上传视频");
            return;
        }

        //判断标签 是否为空 为空 return
        if (paramTagsList == null || paramTagsList.size() == 0) {
            ToastUtils.showToast("请选择标签");
            return;
        }

        //判断分类是否为空
        if (TextUtils.isEmpty(categoryId)) {
            ToastUtils.showToast("请选择分类");
            return;
        }

        //判断是否有视频文件
        //判断视频文件长度  是否大于50M
        MediaUtils.getImageForVideo(videoPath, videoFaceFile -> {
            //这个file是返回的视频封面图片

            //创建视频文件
            File videoFile = new File(videoPath);
            long fileSizes = MediaUtils.getFileSizes(videoFile);
            boolean sizeIsLimit = MediaUtils.checkFileSizeIsLimit(fileSizes, 50, "M");
            if (sizeIsLimit) {
                //没超过限制
                uploadVideoFaceAndVideoFile(title, content, videoFaceFile, videoFile, "image",paramTagsList,categoryId);
            } else {
                //超过了限制
                //2019/11/18 提示上传不能
                ToastUtils.showToast("视频超过50M");
            }

        });


    }

    /**
     * 上传视频封面和视频文件
     *  @param videoFaceFile
     * @param videoFile
     * @param paramTagsList
     */
    private void uploadVideoFaceAndVideoFile(String title, String content, File videoFaceFile, File videoFile, String type, ArrayList<IndexLableLetterBean> paramTagsList,String categoryId) {
        reqLoading.setValue(true);
        add(httpApi.uploadFile(videoFaceFile, type,1, new LifecycleCallback<FileDataBean>(mView) {
            @Override
            public void onSuccess(FileDataBean data) {
                if (data != null) {
                    String videoFaceImgUrl = data.getImgUrl();
                    if (videoFaceImgUrl != null) {
                        // 视频封面上传成功 上传视频文件
                        //reqLoading.setValue(true);
                        add(httpApi.uploadFile(videoFile, type,0, new LifecycleCallback<FileDataBean>(mView) {
                            @Override
                            public void onSuccess(FileDataBean data) {
                                if (data != null) {
                                    String videoUrl = data.getImgUrl();
                                    LogUtils.INSTANCE.e("===z", "视频地址url = " + videoUrl);
                                    if (!TextUtils.isEmpty(videoUrl)) {
                                        // TODO: 2019/11/18 走提交操作
                                        infoUploadFile.setValue(new InfoUploadVideoFileBean(0, videoUrl));

                                        publishVideo(title, content, videoFaceImgUrl, videoUrl, paramTagsList,categoryId);

                                    } else {
                                        //返回视频url为空
                                        infoUploadFile.setValue(new InfoUploadVideoFileBean(5, "返回视频url为空"));
                                    }
                                } else {
                                    //上传视频文件data为空
                                    infoUploadFile.setValue(new InfoUploadVideoFileBean(4, "上传视频文件data为空"));
                                }
                            }

                            @Override
                            public void onFailed(int errCode, String errMsg) {
                                //上传视频文件失败
                                infoUploadFile.setValue(new InfoUploadVideoFileBean(3, errMsg));
                            }
                        }));

                    } else {//返回视频封面为空
                        infoUploadFile.setValue(new InfoUploadVideoFileBean(2, "返回视频封面为空"));
                    }
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                //上传封面失败
                infoUploadFile.setValue(new InfoUploadVideoFileBean(1, errMsg));
            }
        }));
    }

    private void publishVideo(String title, String content, String videoFaceImgUrl, String videoUrl, ArrayList<IndexLableLetterBean> tags,String categoryId) {
        //reqLoading.setValue(true);
        PublishArticleOrVideoReqBody body = new PublishArticleOrVideoReqBody();
        body.setCategoryId(categoryId);//not null
        body.setKeywords("");//not null
        body.setPreview("");//not null
        body.setImgUrl(videoFaceImgUrl);
        body.setPlayUrl(videoUrl);
        body.setReleaseSource("");
        body.setPageViews("");
        body.setContent(content);
        body.setLabels(tags);
        body.setMediaType("1");
        body.setSportType("1");
        body.setTitle(title);
        add(httpApi.publishArticleOrVideo(body, new LifecycleCallback<Response>(mView) {
            @Override
            public void onSuccess(Response data) {
                if (data != null) {
                    LogUtils.INSTANCE.e("===z", "发表成功onSuccess data = " + data.toString());
                    commitData.setValue(200 == data.getCode());

                    //设置需要删除数据
                    needClearData = true;
                } else {
                    commitData.setValue(false);
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                LogUtils.INSTANCE.e("===z", "发表失败");
                commitData.setValue(false);
            }
        }));
    }

    /**
     * 是否需要删除数据
     * @return
     */
    public boolean isNeedClearData() {
        return needClearData;
    }

}
