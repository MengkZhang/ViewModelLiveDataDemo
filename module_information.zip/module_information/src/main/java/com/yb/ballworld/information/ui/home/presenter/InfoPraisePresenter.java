package com.yb.ballworld.information.ui.home.presenter;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

import com.alibaba.android.arouter.launcher.ARouter;
import com.yb.ballworld.baselib.constant.Constant;
import com.yb.ballworld.baselib.core.RouterHub;
import com.yb.ballworld.baselib.data.UserInfo;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.common.callback.OnUICallback;
import com.yb.ballworld.common.utils.NetWorkUtils;
import com.yb.ballworld.information.ui.home.listener.PraiseResultListener;
import com.yb.ballworld.information.ui.home.service.InfoHttpApi;

import rxhttp.wrapper.entity.Response;

/**
 * Desc  点赞presenter
 * Date 2019/10/10
 * author mengk
 */
public class InfoPraisePresenter implements InfoPraiseContract.IInfoPraisePresenter {
    private InfoHttpApi httpApi;
    private Activity activity;
    public InfoPraisePresenter(Activity activity) {
        httpApi = new InfoHttpApi();
        this.activity=activity;
    }

    /**
     * 跳转到登陆界面
     */
    private void toLogin(Activity activity) {
        ARouter.getInstance().build(RouterHub.USER_LOGIN_REGISTER_ACTIVITY)
                .navigation(activity, Constant.COMMON_LOGIN_REQUEST);
    }
    @Override
    public void loadData(String newsId, PraiseResultListener callBack) {
        //判断是否登录
//        UserInfo userInfo = LoginOrdinaryUtils.INSTANCE.getUserInfo();
//        if (userInfo == null) {//用户未登录
//            if(activity!=null) {
//                toLogin(activity);
//            }
//            return;
//        }

        httpApi.praiseInfo(newsId, new OnUICallback<Response>() {
            @Override
            public void onUISuccess(Response data) {
                LogUtils.INSTANCE.e("===z", "点赞 data = " + data.getCode());
                if (data.getCode() == 200) { //点赞成功
                    callBack.onSuccess();
                } else {                     //点赞失败
                    callBack.onFail();
                }
            }

            @Override
            public void onUIFailed(int errCode, String errMsg) {
                LogUtils.INSTANCE.e("===z", "点赞 data = shibai");
                callBack.onFail();
            }
        });


    }


}
