//package com.yb.ballworld.information.ui.home.view.newdetail;
//
//import android.annotation.SuppressLint;
//import android.content.Context;
//import android.os.Build;
//import android.util.AttributeSet;
//import android.view.View;
//import android.webkit.WebChromeClient;
//import android.webkit.WebView;
//import android.webkit.WebViewClient;
//import android.widget.FrameLayout;
//import android.widget.Toast;
//
//import com.yb.ballworld.information.R;
//
///**
// * Desc 图文详情头部页
// * Date 2019/10/19
// * author mengk
// */
//public class NewsDetailHeaderView extends FrameLayout {
//    private Context mContext;
//    private WebView mWvContent;
//
//    public NewsDetailHeaderView(Context context) {
//        this(context, null);
//    }
//
//    public NewsDetailHeaderView(Context context, AttributeSet attrs) {
//        this(context, attrs, 0);
//    }
//
//    public NewsDetailHeaderView(Context context, AttributeSet attrs, int defStyleAttr) {
//        super(context, attrs, defStyleAttr);
//        mContext = context;
//        initView();
//    }
//
//    private void initView() {
//        View view = View.inflate(mContext, R.layout.info_news_detail_header, this);
//        mWvContent = view.findViewById(R.id.wv_content);
//    }
//
//    @SuppressLint({"SetJavaScriptEnabled", "ObsoleteSdkInt"})
//    public void setDetail(String content, LoadWebListener listener) {
//        //设置(关闭硬件加速)
//        try {
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
//                mWvContent.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        mWebListener = listener;
//        mWvContent.getSettings().setJavaScriptEnabled(true);//设置JS可用
//        mWvContent.addJavascriptInterface(new ShowPicRelation(mContext),"bifen");//绑定JS和Java的联系类，以及使用到的
//        String htmlPart1 = "<!DOCTYPE HTML html>\n" +
//                "<head><meta charset=\"utf-8\"/>\n" +
//                "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no\"/>\n" +
//                "</head>\n" +
//                "<body>\n" +
//                "<style> \n" +
//                "img{width:100%!important;height:auto!important}\n" +
//                " </style>";
//        String htmlPart2 = "</body></html>";
//
//        String html = htmlPart1 + content + htmlPart2;
//        mWvContent.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
//        mWvContent.setWebViewClient(new WebViewClient() {
//            @Override
//            public void onPageFinished(WebView view, String url) {
//                super.onPageFinished(view, url);
//                //所有图片都加载完成 页面都finish时 才用js跟Java交互 否则导致图片传递重复
//                addJs(view);//添加多JS代码，为图片绑定点击函数
//            }
//        });
//        mWvContent.setWebChromeClient(new WebChromeClient() {
//            @Override
//            public void onProgressChanged(WebView view, int newProgress) {
//                super.onProgressChanged(view, newProgress);
//                if (newProgress == 100) {
//                    if (mWebListener != null){
//                        mWebListener.onLoadFinished();
//                        //load完成 开启硬件加速
//                        try {
//                            mWvContent.setLayerType(View.LAYER_TYPE_HARDWARE, null);
//                        } catch (Exception e) {
//                            e.printStackTrace();
//                        }
//                    }
//                }
//            }
//        });
//
//    }
//
//    /**添加JS代码，获取所有图片的链接以及为图片设置点击事件*/
//    private void addJs(WebView wv) {
//        wv.loadUrl("javascript:(function  pic(){"+
//                "var imgList = \"\";"+
//                "var imgs = document.getElementsByTagName(\"img\");"+
//                "for(var i=0;i<imgs.length;i++){"+
//                "var img = imgs[i];"+
//                "imgList = imgList + img.src +\";\";"+
//                "img.onclick = function(){"+
//                "window.bifen.openImg(this.src);"+
//                "}"+
//                "}"+
//                "window.bifen.getImgArray(imgList);"+
//                "})()");
//    }
//
//    private LoadWebListener mWebListener;
//
//    /**页面加载的回调*/
//    public interface LoadWebListener{
//        void onLoadFinished();
//    }
//}
