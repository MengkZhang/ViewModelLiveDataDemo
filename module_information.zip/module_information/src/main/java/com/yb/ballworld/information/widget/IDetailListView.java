package com.yb.ballworld.information.widget;

import com.yb.ballworld.information.widget.listener.OnScrollBarShowListener;

/**
 * Desc: <功能简述>
 * Author: JS-Dugu
 * Created On: 2019/10/15 21:12
 */
public interface IDetailListView {

    void setScrollView(DetailScrollView scrollView);

    boolean canScrollVertically(int direction);

    void customScrollBy(int dy);

    boolean startFling(int vy);

    void setOnScrollBarShowListener(OnScrollBarShowListener listener);

    /**
     * 滑到第一项
     */
    void scrollToFirst();
}
