package com.yb.ballworld.information.ui.profile.adapter;

import android.graphics.Color;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.yb.ballworld.baselib.utils.ImageManager;
import com.yb.ballworld.common.widget.MultTextView;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.profile.data.PointsBean;

import java.util.List;

/**
 * @author Gethin
 * @time 2019/11/9 10:32
 */

public class PointsAdapter extends BaseMultiItemQuickAdapter<PointsBean, BaseViewHolder> {


    public PointsAdapter(List<PointsBean> data) {
        super(data);
        addItemType(PointsBean.HEADER, R.layout.rv_item_points_header);
        addItemType(PointsBean.CONTENT, R.layout.rv_item_points_content);
    }

    @Override
    protected void convert(BaseViewHolder helper, PointsBean item, int pos) {
        switch (item.getItemType()) {
            case PointsBean.HEADER:
                MultTextView mtPointHeader = helper.getView(R.id.mtPointHeader);
                helper.setText(R.id.tvName, "球队(" + item.groupName + ")");
                mtPointHeader.setTexts("胜平负", "积分");
                mtPointHeader.setDefTextColor(Color.parseColor("#333333"));
                break;
            case PointsBean.CONTENT:
                LinearLayout llRoot = helper.getView(R.id.llRoot);
                TextView tvRank = helper.getView(R.id.tvRank);
                ImageView ivTeamLogo = helper.getView(R.id.ivTeamLogo);
                TextView tvTeamName = helper.getView(R.id.tvTeamName);
                MultTextView mtPointsInfo = helper.getView(R.id.mtPointsInfo);
                if (item.getContentPos() == PointsBean.CONTENT_START) {
                    llRoot.setBackgroundResource(R.drawable.rectangle_white_top_radius_bg);
                } else if (item.getItemType() == PointsBean.CONTENT_END) {
                    llRoot.setBackgroundResource(R.drawable.rectangle_white_bottom_radius_bg);
                } else {
                    llRoot.setBackgroundResource(R.drawable.rectangle_white_bg);
                }
                helper.setTextColor(R.id.tvRank, item.isNormal ? Color.parseColor("#333333") : Color.parseColor("#f55b5b"));
                helper.setTextColor(R.id.tvTeamName, item.isNormal ? Color.parseColor("#333333") : Color.parseColor("#f55b5b"));
                tvRank.setText(String.valueOf(item.rank));
                ImageManager.INSTANCE.loadLogo("", ivTeamLogo);
                tvTeamName.setText(item.teamName);
                mtPointsInfo.setTexts( item.winNum + "/" + item.drawNum + "/" + item.loseNum, String.valueOf(item.score));
                mtPointsInfo.setDefTextColor(item.isNormal ? Color.parseColor("#333333") : Color.parseColor("#f55b5b"));
                break;
        }
    }
}
