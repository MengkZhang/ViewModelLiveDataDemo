package com.yb.ballworld.information.ui.home.widget.bfFab;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

/**
 * Desc 按钮的点击事件
 * Date 2019/11/17
 * author mengk
 */
public interface OnFabClickListener {
    void onFabClick(FloatingActionButton fab, Object tag);
}
