package com.yb.ballworld.information.ui.profile.presenter;

import androidx.lifecycle.LifecycleOwner;

import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.livedata.LiveDataWrap;
import com.yb.ballworld.information.ui.profile.data.MatchLeagueInfo;
import com.yb.ballworld.information.ui.profile.data.SeasonData;
import com.yb.ballworld.information.ui.profile.data.SeasonIdFromTeamId;
import com.yb.ballworld.information.ui.profile.http.ProfileHttp;

/**
 * Desc: <>
 * Author: JS-Barder
 * Created On: 2019/11/21 16:27
 */
public class ProfileMatchPresenter extends BasePresenter<LifecycleOwner, VoidModel> {

    private ProfileHttp http = new ProfileHttp();

    LiveDataWrap<MatchLeagueInfo> dataWrap = new LiveDataWrap<>();

    private String seasonId;

    public LiveDataWrap<MatchLeagueInfo> getDataWrap() {
        return dataWrap;
    }

    public String getSeasonId() {
        return seasonId;
    }

    public void setLeagueId(String leagueId) {
        http.getMatchSeasons(leagueId, new LifecycleCallback<SeasonData>(mView) {
            @Override
            public void onSuccess(SeasonData data) {
                if (data.seasons != null && !data.seasons.isEmpty()) {
                    seasonId = data.seasons.get(0).seasonId;
                    initLeagueId(leagueId);
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                dataWrap.setError(errCode, errMsg);
            }
        });
    }

    public void initLeagueId(String leagueId) {
        add(http.getMatchInfo(leagueId, new LifecycleCallback<MatchLeagueInfo>(mView) {
            @Override
            public void onSuccess(MatchLeagueInfo data) {
                dataWrap.setData(data);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                dataWrap.setError(errCode, errMsg);
            }
        }));
    }
}
