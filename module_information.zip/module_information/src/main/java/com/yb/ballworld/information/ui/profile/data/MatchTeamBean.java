package com.yb.ballworld.information.ui.profile.data;

import com.chad.library.adapter.base.entity.MultiItemEntity;

/**
 * Desc: <球队榜实体类>
 * Author: JS-Barder
 * Created On: 2019/11/21 17:30
 */
public class MatchTeamBean implements MultiItemEntity {
    public static final int HEADER = 1;
    public static final int CONTENT = 2;

    public static final int CONTENT_START = 1;
    public static final int CONTENT_END = 2;

    private int contentPos;
    private int itemType = CONTENT;

    public int teamId;
    public int total;
    public String logoUrl;
    public String cnName;
    public String penaltyKick;
    public String playerNum;
    public String redCard;
    public String yellowCard;
    public int shotOnGoal;

    public void setItemType(int itemType) {
        this.itemType = itemType;
    }

    @Override
    public int getItemType() {
        return itemType;
    }

    public int getContentPos() {
        return contentPos;
    }

    public void setContentPos(int contentPos) {
        this.contentPos = contentPos;
    }
}
