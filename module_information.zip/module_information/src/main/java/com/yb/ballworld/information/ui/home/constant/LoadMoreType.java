package com.yb.ballworld.information.ui.home.constant;

import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Desc 区分加载更多成功和全部加载的类型
 * Date 2019/10/9
 * author mengk
 */
@IntDef({
        LoadMoreType.TYPE_SUCCESS,
        LoadMoreType.TYPE_ALL_DATA
})

@Retention(RetentionPolicy.SOURCE)

public @interface LoadMoreType {
    //0 加载成功
    int TYPE_SUCCESS = 0;
    //1 已经全部加载
    int TYPE_ALL_DATA = 1;
}
