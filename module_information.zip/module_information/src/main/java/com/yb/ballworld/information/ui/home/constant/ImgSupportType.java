package com.yb.ballworld.information.ui.home.constant;

import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Desc
 * Date 2019/11/21
 * author mengk
 */
@IntDef({
        ImgSupportType.ONE,
        ImgSupportType.TWO,
        ImgSupportType.THREE,
        ImgSupportType.MUCH
})

@Retention(RetentionPolicy.SOURCE)

public @interface ImgSupportType {
    int ONE = 0;
    int TWO = 1;
    int THREE= 2;
    int MUCH= 3;
}


