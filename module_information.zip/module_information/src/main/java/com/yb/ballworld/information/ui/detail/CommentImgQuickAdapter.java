package com.yb.ballworld.information.ui.detail;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.widget.ImageView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bfw.image.core.listener.OnImageListener;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.yb.ballworld.baselib.base.recycler.decorate.GridItemSpaceDecoration;
import com.yb.ballworld.baselib.utils.ImageManager;
import com.yb.ballworld.baselib.utils.ViewUtils;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.utils.CommondUtil;

import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CommentImgQuickAdapter extends BaseQuickAdapter<String, BaseViewHolder> {
    private final int ITEMTYPE_ONE = 1;
    private final int ITEMTYPE_TWO = 2;
    private final int ITEMTYPE_GRID = 3;
    private final int ITEMTYPE_COMMUNITY = 4;
    private int currentType = ITEMTYPE_ONE;
    private boolean isCustom=false;
    private int padding=5;

    @SuppressLint("UseSparseArrays")
    private HashMap<Integer, Boolean> loadResult = new HashMap<>();

    public CommentImgQuickAdapter(@androidx.annotation.Nullable List<String> data) {
        super(data);
    }

    public CommentImgQuickAdapter() {
        super(new ArrayList<String>());
    }

    public void setLayout(int currentType) {
        if (currentType == ITEMTYPE_ONE) {
            mLayoutResId = R.layout.item_comment_img2;
        } else if (currentType == ITEMTYPE_TWO) {
            mLayoutResId = R.layout.item_comment_img1;
        }else if(ITEMTYPE_COMMUNITY==currentType){
            mLayoutResId = R.layout.item_community_comment_img;
        } else {
            mLayoutResId = R.layout.item_comment_img;
        }
    }

    @Override
    protected void convert(BaseViewHolder helper, String item, int pos) {
        ImageView imageView = helper.getView(R.id.item_comment_img);
        loadImg(imageView, pos);
    }


    public void loadImg(ImageView view, int pos) {
        ImageManager.INSTANCE.loadImageOrGif(getItem(pos), view, new OnImageListener() {
            @Override
            public void onSuccess(@Nullable Bitmap bitmap) {
                loadResult.put(pos, true);
            }

            @Override
            public void onFail(@Nullable String msg) {
                loadResult.put(pos, false);
            }
        });
    }

    public void reloadImg(ImageView view, int pos) {
        Boolean tempObj = loadResult.get(pos);
        boolean needLoad = tempObj == null || (tempObj != null && !tempObj);
        if (needLoad) {
            ImageManager.INSTANCE.loadImageOrGif(getItem(pos), view, new OnImageListener() {
                @Override
                public void onSuccess(@Nullable Bitmap bitmap) {
                    loadResult.put(pos, true);
                }

                @Override
                public void onFail(@Nullable String msg) {
                    loadResult.put(pos, false);
                }
            });

        }
    }

    public void autoFit(List<String> imgs) {
        if (!CommondUtil.isEmpty(imgs)) {
            if(!isCustom) {
                currentType = calcColumn(imgs.size());
            }
            setLayout(currentType);
            setNewData(imgs);
            notifyDataSetChanged();
        }
    }

    public void autoFit(RecyclerView recyclerView, List<String> imgs) {
        if (!CommondUtil.isEmpty(imgs)) {
            if(!isCustom) {
                currentType = calcColumn(imgs.size());
            }
            if(recyclerView.getItemDecorationCount()>0) {
                recyclerView.removeItemDecorationAt(0);
            }
            recyclerView.addItemDecoration(new GridItemSpaceDecoration(currentType, ViewUtils.dp2px(padding), ViewUtils.dp2px(padding), 0));
            recyclerView.setLayoutManager(new GridLayoutManager(recyclerView.getContext(), currentType));
            setLayout(currentType);
            setNewData(imgs);
            notifyDataSetChanged();
        }
    }

    public void customTypeAndPadding(int type,int padding){
        isCustom=true;
        currentType=type;
        this.padding=padding;
    }

    private int calcColumn(int size) {
        if (size <= ITEMTYPE_ONE) {
            size = ITEMTYPE_ONE;
        } else if (size <= ITEMTYPE_TWO) {
            size = ITEMTYPE_TWO;
        } else {
            size = ITEMTYPE_GRID;
        }
        return size;
    }

}
