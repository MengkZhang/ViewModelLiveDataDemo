package com.yb.ballworld.information.ui.profile.data;

import com.chad.library.adapter.base.entity.MultiItemEntity;

/**
 * @author Gethin
 * @time 2019/11/9 10:32
 */

public class PointsBean implements MultiItemEntity {

    public static final int HEADER = 1;
    public static final int CONTENT = 2;

    public static final int CONTENT_START = 1;
    public static final int CONTENT_END = 2;

    public int id;
    public int leagueId;
    public String enName;
    public int teamId;
    public String teamName;
    public String teamLogo;
    public int rank;
    public int winNum;
    public int drawNum;
    public int loseNum;
    public double goalAvg;
    public int totalNum;
    public int goals;
    public int loseGoals;
    public int score;
    public double winRate;
    public String gameBehind;

    public String groupName;
    public boolean isNormal;

    private int contentPos;
    private int itemType = CONTENT;

    public void setItemType(int itemType) {
        this.itemType = itemType;
    }

    @Override
    public int getItemType() {
        return itemType;
    }

    public int getContentPos() {
        return contentPos;
    }

    public void setContentPos(int contentPos) {
        this.contentPos = contentPos;
    }
}
