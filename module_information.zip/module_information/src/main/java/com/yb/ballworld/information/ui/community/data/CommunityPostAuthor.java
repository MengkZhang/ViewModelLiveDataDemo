package com.yb.ballworld.information.ui.community.data;

import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.yb.ballworld.information.ui.community.CommunityAdapter;

/**
 * Desc: <推荐作者实体类>
 * Author: JS-Barder
 * Created On: 2019/11/8 17:18
 */
public class CommunityPostAuthor implements MultiItemEntity {
    public boolean attentionStatus;//关注状态
    public int focusCount;//
    public int followerCount;//粉丝数
    public String headImgUrl;//粉丝数
    public String id;//主键id
    public String nickname;//昵称
    public int postCount;//帖子数
    public int sex;//0 未设置 1 男 2 女
    public int sorted;//排序值（ASC)
    public String userId;//用户ID

    @Override
    public int getItemType() {
        return CommunityAdapter.TYPE_POST_AUTHOR;
    }
}
