package com.yb.ballworld.information.ui.home.bean;

import java.io.Serializable;

/**
 * Desc
 * Date 2019/11/19
 * author mengk
 */
public class InfoPublishCategoryBean implements Serializable {
    private String id;
    private String sort;
    private String imgUrl;
    private String name;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSort() {
        return sort;
    }

    public void setSort(String sort) {
        this.sort = sort;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
