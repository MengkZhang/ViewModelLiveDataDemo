package com.yb.ballworld.information.ui.detail;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.util.DensityUtil;
import com.yb.ballworld.baselib.utils.ImageManager;
import com.yb.ballworld.baselib.utils.ViewUtils;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.data.ArticleBean;

import java.util.List;


public class NewsQuickAdapter extends BaseMultiItemQuickAdapter<ArticleBean, BaseViewHolder> {
    /**
     * Same as QuickAdapter#QuickAdapter(Context,int) but with
     * some initialization data.
     *
     * @param data A new list is created out of this one to avoid mutable list
     */
    public NewsQuickAdapter(List data) {
        super(data);
        addItemType(0, R.layout.item_relative_news);
    }

    @Override
    protected void convert(BaseViewHolder helper, ArticleBean item, int pos) {
        ((TextView) helper.getView(R.id.relativeNews_title)).setText(item.getTitle());
        ImageManager.INSTANCE.loadRoundIcon(item.getImgUrl(), R.drawable.icon_default_info_ball, ViewUtils.dp2px(4), ((ImageView) helper.getView(R.id.relativeNews_img)));
        helper.getView(R.id.relativeNews_play).setVisibility(item.getMediaType() > 0 ? View.VISIBLE : View.GONE);

        if (pos > 0 && pos == getItemCount() - 1) {
            RecyclerView.LayoutParams params = (RecyclerView.LayoutParams) helper.itemView.getLayoutParams();
            params.bottomMargin = DensityUtil.dp2px(20);
        } else {
            RecyclerView.LayoutParams params = (RecyclerView.LayoutParams) helper.itemView.getLayoutParams();
            params.bottomMargin = 0;
        }
    }
}
