package com.yb.ballworld.information.ui.home.bean;

import android.net.Uri;

/**
 * Desc
 * Date 2019/11/11
 * author mengk
 */
public class FileVideoUriPathBean {
    private String uri;
    private String path;

    public FileVideoUriPathBean() {
    }

    public FileVideoUriPathBean(String uri, String path) {
        this.uri = uri;
        this.path = path;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
