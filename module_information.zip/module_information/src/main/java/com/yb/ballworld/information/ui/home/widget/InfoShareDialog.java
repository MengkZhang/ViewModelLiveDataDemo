package com.yb.ballworld.information.ui.home.widget;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bfw.util.ToastUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.yb.ballworld.common.sharesdk.ShareSdkUtils;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.adapter.InfoShareAdapter;
import com.yb.ballworld.information.ui.home.bean.InfoShareBean;

import java.util.ArrayList;
import java.util.List;


/**
 * Desc 分享的dialog
 * Date 2019/10/19
 * author mengk
 */
public class InfoShareDialog extends Dialog {

    private TextView tvCancel;
    private Context context;
    private InfoShareAdapter adapter;

    public InfoShareDialog(@NonNull Context context) {
        super(context, R.style.common_dialog);
        this.context = context;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_share_info);
        try {
            setCanceledOnTouchOutside(true);
            Window window = getWindow();
            WindowManager.LayoutParams attributes = window.getAttributes();
            attributes.gravity = Gravity.BOTTOM;
            attributes.width = WindowManager.LayoutParams.MATCH_PARENT;
            window.setAttributes(attributes);
            window.setWindowAnimations(R.style.dialog_bottom);
            initView();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initView() {
        RecyclerView rvShareItem = findViewById(R.id.rv_share_item_info);
        tvCancel = findViewById(R.id.tv_cancel_info_share);
        GridLayoutManager layoutManager = new GridLayoutManager(context, 4);
        rvShareItem.setLayoutManager(layoutManager);
        List<InfoShareBean> shareList = getShareList();
        adapter = new InfoShareAdapter(shareList);
        rvShareItem.setAdapter(adapter);
        initEvent();
    }

    private void initEvent() {
        adapter.setOnItemChildClickListener((adapter, view, position) -> {
            if (view.getId() == R.id.ll_share_root_view) {
                Object item = adapter.getItem(position);
                if (item instanceof InfoShareBean) {
                    int id = ((InfoShareBean) item).getId();
                    switch (id) {
                        case 1:
                            ToastUtils.showToast(context, "微信好友分享", Toast.LENGTH_SHORT);
                            break;
                        case 2:
                            ToastUtils.showToast(context, "朋友圈分享", Toast.LENGTH_SHORT);
                            break;
                        case 3:
                            ToastUtils.showToast(context, "QQ好友分享", Toast.LENGTH_SHORT);
                            break;
                        case 4:
                            ToastUtils.showToast(context, "QQ空间分享", Toast.LENGTH_SHORT);
                            break;
                        default:
                            ToastUtils.showToast(context, "新浪微博分享", Toast.LENGTH_SHORT);
                            break;
                    }
                }
            }
        });
        tvCancel.setOnClickListener(v -> InfoShareDialog.this.dismiss());
    }

    private List<InfoShareBean> getShareList() {
        List<InfoShareBean> list = new ArrayList<>();
        for (int i = 1; i <= 5; i++) {
            InfoShareBean infoShareBean = new InfoShareBean();
            infoShareBean.setId(i);
            list.add(infoShareBean);
        }
        return list;
    }

}
