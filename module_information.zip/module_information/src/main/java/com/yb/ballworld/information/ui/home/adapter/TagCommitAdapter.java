package com.yb.ballworld.information.ui.home.adapter;

import android.widget.TextView;

import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.bean.IndexLableLetterBean;
import com.yb.ballworld.information.ui.home.utils.GlideLoadImgUtil;

import java.util.ArrayList;

/**
 * Desc 标签adapter
 * Date 2019/11/7
 * author mengk
 */
public class TagCommitAdapter extends BaseQuickAdapter<IndexLableLetterBean, BaseViewHolder> {

    public TagCommitAdapter(@Nullable ArrayList<IndexLableLetterBean> data) {
        this(data, false);
    }

    public TagCommitAdapter(@Nullable ArrayList<IndexLableLetterBean> data, boolean isInside) {
        super(isInside ? R.layout.item_tag_side_in_put : R.layout.item_tag_in_side, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, IndexLableLetterBean item, int pos) {
        if (item == null) return;
        TextView tvTitle = helper.getView(R.id.tv_title_in_side);
        String cnAlias = item.getLable();
        tvTitle.setText(cnAlias);

        GlideLoadImgUtil.loadTeamLogo(mContext,item.getPicUrl(),helper.getView(R.id.iv_icon_in_side));

        helper.addOnClickListener(R.id.rl_tag_root_view);


    }


}
