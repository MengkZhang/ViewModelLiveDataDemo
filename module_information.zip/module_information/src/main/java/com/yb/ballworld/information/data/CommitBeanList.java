package com.yb.ballworld.information.data;

import java.util.List;

/**
 * Desc:评论列表
 *
 * @author ink
 * created at 2019/10/9 20:51
 */
public class CommitBeanList {
    //总记录数
    private int totalCount;
    //总页数
    private int totalPage;
    private long newsId;
    //每页条数
    private int pageSize;
    //当前页
    private int pageNum;

    private List<CommitBean> list;

    public long getNewsId() {
        return newsId;
    }

    public void setNewsId(long newsId) {
        this.newsId = newsId;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public List<CommitBean> getList() {
        return list;
    }

    public void setList(List<CommitBean> list) {
        this.list = list;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }
}
