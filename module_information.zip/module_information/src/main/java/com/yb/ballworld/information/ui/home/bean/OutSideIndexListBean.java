package com.yb.ballworld.information.ui.home.bean;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * Desc
 * Date 2019/11/7
 * author mengk
 */


public class OutSideIndexListBean implements Parcelable {
    private String title;
    private List<OutSideIndexNewBean.IndexBean> list;

    public OutSideIndexListBean() {

    }

    protected OutSideIndexListBean(Parcel in) {
        title = in.readString();
    }

    public static final Creator<OutSideIndexListBean> CREATOR = new Creator<OutSideIndexListBean>() {
        @Override
        public OutSideIndexListBean createFromParcel(Parcel in) {
            return new OutSideIndexListBean(in);
        }

        @Override
        public OutSideIndexListBean[] newArray(int size) {
            return new OutSideIndexListBean[size];
        }
    };

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<OutSideIndexNewBean.IndexBean> getList() {
        return list;
    }

    public void setList(List<OutSideIndexNewBean.IndexBean> list) {
        this.list = list;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
    }
}
