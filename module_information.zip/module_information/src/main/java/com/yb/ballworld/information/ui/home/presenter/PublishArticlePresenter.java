package com.yb.ballworld.information.ui.home.presenter;

import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.MutableLiveData;

import com.bfw.util.ToastUtils;
import com.yb.ballworld.baselib.constant.Constant;
import com.yb.ballworld.baselib.utils.AppUtils;
import com.yb.ballworld.baselib.utils.Glide4Engine;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.utils.SpUtils;
import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.livedata.LiveDataWrap;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.bean.FileDataBean;
import com.yb.ballworld.information.ui.home.bean.IndexLableLetterBean;
import com.yb.ballworld.information.ui.home.bean.InfoPublishCategoryBean;
import com.yb.ballworld.information.ui.home.bean.InsertImageBean;
import com.yb.ballworld.information.ui.home.bean.PublishArticleOrVideoReqBody;
import com.yb.ballworld.information.ui.home.bean.PublishArticleUploadFilePostBean;
import com.yb.ballworld.information.ui.home.bean.PublishVideoDataBean;
import com.yb.ballworld.information.ui.home.constant.InsertImgType;
import com.yb.ballworld.information.ui.home.constant.LengthLimit;
import com.yb.ballworld.information.ui.home.constant.RichTag;
import com.yb.ballworld.information.ui.home.constant.TagParams;
import com.yb.ballworld.information.ui.home.service.InfoHttpApi;
import com.yb.ballworld.information.ui.home.utils.HtmlImgUtil;
import com.yb.ballworld.information.ui.home.utils.cache.OutputUtil;
import com.yb.ballworld.information.ui.home.widget.bfrich.RichTextEditor;
import com.zhihu.matisse.Matisse;
import com.zhihu.matisse.MimeType;
import com.zhihu.matisse.internal.entity.CaptureStrategy;
import com.zhihu.matisse.internal.entity.Item;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import io.reactivex.Observable;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import rxhttp.wrapper.entity.Response;

/**
 * Desc
 * Date 2019/11/5
 * author mengk
 */
public class PublishArticlePresenter extends BasePresenter<LifecycleOwner, VoidModel> {
    private InfoHttpApi httpApi = new InfoHttpApi();
    private int count = 0;
    private int successCount = 0;
    private boolean needClearData;//是否需要清理数据
    private boolean isUploadFileFail;//是否有文件上传失败

    private LiveDataWrap<PublishArticleUploadFilePostBean> fileUploadData = new LiveDataWrap<>();
    private MutableLiveData<InsertImageBean> insertImage = new MutableLiveData<>();
    private MutableLiveData<Boolean> reqLoading = new MutableLiveData<>();
    private MutableLiveData<Boolean> commitData = new MutableLiveData<>();

    public MutableLiveData<Boolean> getCommitData() {
        return commitData;
    }

    public LiveDataWrap<PublishArticleUploadFilePostBean> getFileUploadData() {
        return fileUploadData;
    }

    public MutableLiveData<InsertImageBean> getInsertImageBean() {
        return insertImage;
    }

    public MutableLiveData<Boolean> getReqLoading() {
        return reqLoading;
    }

    /**
     * 通过HashSet踢除重复元素
     * @param list
     * @return
     */
    private List removeDuplicate(List<File> list) {
        HashSet h = new HashSet(list);
        list.clear();
        list.addAll(h);
        return list;
    }

    /**
     * 上传文件
     *
     * @param files
     * @param type
     */
    public void uploadFiles(List<File> files, String type) {
        isUploadFileFail = false;
        reqLoading.setValue(true);
        Map<String, String> imgUrlMap = new HashMap<>();
        Map<String, String> tagMap = new HashMap<>();

        files = removeDuplicate(files);
        int length = files.size();
        for (File file : files) {
            add(httpApi.uploadFile(file, type,1, new LifecycleCallback<FileDataBean>(mView) {
                        @Override
                        public void onSuccess(FileDataBean data) {
                            LogUtils.INSTANCE.e("===z", "PublishArticlePresenter data成功");
                            if (data != null) { //data数据
                                String imgUrl = data.getImgUrl();
                                if (!TextUtils.isEmpty(imgUrl)) { //图片URL
                                    imgUrlMap.put(file.getAbsolutePath(), imgUrl);
//                                    countImgs(length, true, imgUrlMap);
                                    judgeResult(tagMap,imgUrlMap,length);

                                } else {                          //图片URL为空
                                    tagMap.put(file.getAbsolutePath(),"");
                                    judgeResult(tagMap,imgUrlMap,length);
                                }


                            } else {            //data为空
                                tagMap.put(file.getAbsolutePath(),"");
                                judgeResult(tagMap,imgUrlMap,length);
                            }
                        }

                        @Override
                        public void onFailed(int errCode, String errMsg) {
                            tagMap.put(file.getAbsolutePath(),"");
                            judgeResult(tagMap,imgUrlMap,length);
                            LogUtils.INSTANCE.e("===z", "PublishArticlePresenter data失败 errCode = " + errCode + " --errMsg = " + errMsg);
                        }
                    })
            );
        }
    }

    /**
     *
     * @param imgUrlMap
     * @param tagMap
     * @param length
     */
    private void judgeResult(Map<String, String> tagMap, Map<String, String> imgUrlMap, int length) {
        int size = imgUrlMap.size();
        int tagSize = tagMap.size();
        if (length == (size + tagSize)) {
            if (tagSize != 0) {
                //最终失败
                fileUploadData.setError(0, "请求服务器失败");
            } else {
                //最终成功
                LogUtils.INSTANCE.e("===z", "全部上传成功 走提交接口 successCount = " + successCount);
                fileUploadData.setData(new PublishArticleUploadFilePostBean(true, imgUrlMap));
            }
        }
    }

    /**
     * 统计了上传的张数 只有全部上传成功之后 才会走提交接口
     *
     * @param total
     * @param success
     * @param imgUrlMap
     */
    private void countImgs(int total, boolean success, Map<String, String> imgUrlMap) {
        count += 1;
        if (success) {
            successCount += 1;
        }
        if (count >= total) {
            if (successCount >= total) {
                LogUtils.INSTANCE.e("===z", "全部上传成功 走提交接口 successCount = " + successCount);
//                publishComment(newsId, content, replyId, images);
                fileUploadData.setData(new PublishArticleUploadFilePostBean(true, imgUrlMap));
            }
            count = 0;
            successCount = 0;
        }
    }

    /**
     * 异步插入图片
     * Note: 必须要从主线程调用setValue(T) 方法来更新LiveData 对象. 如果代码在工作线程中执行, 你可以使用postValue(T) 方法来更新LiveData对象.
     * @param data
     */
    public void insertImagesSync(Intent data) {
        Observable.create((ObservableOnSubscribe<String>) emitter -> {
            try {
                insertImage.postValue(new InsertImageBean(InsertImgType.TYPE_EMITTER_ONNEXT,null));
                List<Uri> mSelected = Matisse.obtainResult(data);
                List<String> paths = Matisse.obtainPathResult(data);
                // 可以同时插入多张图片
                for (String path : paths) {
                    LogUtils.INSTANCE.e("===z", "onNext = " + path);
                    emitter.onNext(path);
                }

                // 测试插入网络图片 http://pics.sc.chinaz.com/files/pic/pic9/201904/zzpic17414.jpg
                //emitter.onNext("http://pics.sc.chinaz.com/files/pic/pic9/201903/zzpic16838.jpg");
                emitter.onComplete();
            } catch (Exception e) {
                e.printStackTrace();
                emitter.onError(e);
            }
        })
                .subscribeOn(Schedulers.io())//生产事件在io
                .observeOn(AndroidSchedulers.mainThread())//消费事件在UI线程
                .subscribe(new Observer<String>() {
                    @Override
                    public void onComplete() {
                        LogUtils.INSTANCE.e("===z", "3 完成");
                        insertImage.setValue(new InsertImageBean(InsertImgType.TYPE_ONCOMPLETE,null));
                    }

                    @Override
                    public void onError(Throwable e) {
                        insertImage.setValue(new InsertImageBean(InsertImgType.TYPE_ONERROR,e));
                    }

                    @Override
                    public void onSubscribe(Disposable d) {
                        insertImage.setValue(new InsertImageBean(InsertImgType.TYPE_ONSUBSCRIBE,d));
                    }

                    @Override
                    public void onNext(String imagePath) {
                        LogUtils.INSTANCE.e("===z", "2 接收onNext imagePath = " + imagePath);
                        insertImage.setValue(new InsertImageBean(InsertImgType.TYPE_ONNEXT,imagePath));
                    }
                });
    }

    /**
     * 删除文章缓存数据
     *
     */
    public void clearArticleData() {
        //设置需要删除数据
        needClearData = true;
        //删除富文本缓存数据
        SpUtils.INSTANCE.putString(TagParams.PUBLISH_ARTICLE_DATA, "");

        //删除其他文章数据
        OutputUtil.clearFile(TagParams.PUBLISH_ARTICLE_DATA_WITHOUT_CONTENT);
    }

    /**
     * 保存文章数据到文件
     * @param publishTitle
     * @param content
     * @param videoPath
     * @param videoUri
     */
    public void saveArticleData(String publishTitle, String content, String videoPath, String videoUri, ArrayList<IndexLableLetterBean> paramTagsList, InfoPublishCategoryBean categoryBean) {
        PublishVideoDataBean publishVideoDataBean = new PublishVideoDataBean();
        if (!TextUtils.isEmpty(publishTitle)) {
            publishVideoDataBean.setTitle(publishTitle);
        }
        //publishVideoDataBean.setContent(content);

        //缓存富文本
        saveRichContentDataToFile(content);

        publishVideoDataBean.setPath(!TextUtils.isEmpty(videoPath) ? videoPath : "");
        publishVideoDataBean.setUri(!TextUtils.isEmpty(videoUri) ? videoUri : "");
        //设置标签
        if (paramTagsList != null && paramTagsList.size() != 0) {
            publishVideoDataBean.setTagList(paramTagsList);
        }

        //缓存分类
        if (categoryBean != null) {
            publishVideoDataBean.setCategoryBean(categoryBean);
        }

        //存储文章数据
        OutputUtil.writeObject(TagParams.PUBLISH_ARTICLE_DATA_WITHOUT_CONTENT, publishVideoDataBean);

    }

    /**
     * 读取文章数据
     * @return
     */
    public PublishVideoDataBean getArticleWithoutContentFromCache() {
        Object object = OutputUtil.getObject(TagParams.PUBLISH_ARTICLE_DATA_WITHOUT_CONTENT);
        LogUtils.INSTANCE.e("===z","读取对象为data = " + object);
        return (PublishVideoDataBean) object;
    }

    /**
     * 保存富文本到文件
     * @param richContentEditData
     */
    private void saveRichContentDataToFile(String richContentEditData) {
        if (!TextUtils.isEmpty(richContentEditData)) {
            SpUtils.INSTANCE.putString(TagParams.PUBLISH_ARTICLE_DATA,richContentEditData);
        }
//        ToastUtils.INSTANCE.showToastInfo("保存成功");
    }

    /**
     * 从缓存中读取jsonArray数据并展示在富文本
     * @param richTextEditor
     */
    public void getJsonArrayDataAndShowContent(RichTextEditor richTextEditor) {
        String data = SpUtils.INSTANCE.getString(TagParams.PUBLISH_ARTICLE_DATA, "");
        if (!TextUtils.isEmpty(data)) {

            LogUtils.INSTANCE.e("===z","缓存的数据 data = " + data);
            try {
                JSONArray jsonArray= new JSONArray(data);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    if(jsonObject.has(RichTag.TXT)){
                        String txt = jsonObject.getString(RichTag.TXT);
                        richTextEditor.addEditTextAtIndex(i,txt);
                    }else if(jsonObject.has(RichTag.IMG)){
                        String img = jsonObject.getString(RichTag.IMG);
                        richTextEditor.insertImage(img, richTextEditor.getMeasuredWidth(),true);
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            //读取数组中的最后一个元素 如果是图片 则不删除FirstEditText 如果不是图片 则删除FirstEditText
            try {
                JSONArray jsonArray= new JSONArray(data);
                int length = jsonArray.length();
                if (length != 0) {
                    //获取最后一个元素
                    JSONObject jsonObject = jsonArray.getJSONObject(length - 1);
                    if (jsonObject.has(RichTag.TXT)) {
                        richTextEditor.removeFirstEditText();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 打开相册
     */
    public void openGallery(AppCompatActivity context, String editData) {
        //获取富文本中的图片
        List<String> pathList = HtmlImgUtil.getImgStrList(editData);
        int maxSize = 30;
        if (pathList != null && pathList.size() != 0) {
            maxSize = maxSize - pathList.size();
        }
        if (maxSize == 0) {
            ToastUtils.showToast("图片已到上限");
            return;
        }
        Matisse.from(context)
                .choose(MimeType.of(MimeType.JPEG, MimeType.PNG, MimeType.GIF), false)
                .theme(R.style.Matisse_Zhihu)
                .countable(false)
                .setSelectionItems(new ArrayList<>())
                .showSingleMediaType(true)
                .maxSelectable(maxSize)
                .thumbnailScale(0.8f)
                .originalEnable(false)
                .maxOriginalSize(10)
                .capture(true)//选择照片时，是否显示拍照
                //参数1 true表示拍照存储在共有目录，false表示存储在私有目录；参数2与 AndroidManifest中authorities值相同，用于适配7.0系统 必须设置
                .captureStrategy(new CaptureStrategy(true, AppUtils.getPackageName()+".fileProvider"))
                .imageEngine(new Glide4Engine())
                .forResult(Constant.REQUEST_CODE_CHOOSE);
    }


    /**
     * 判断是否上传文件
     * @param title
     * @param editData
     * @param paramTagsList
     */
    public void ifUploadFile(String title, String editData, ArrayList<IndexLableLetterBean> paramTagsList,String categoryId) {
        //判断标题 是否为空
        if (TextUtils.isEmpty(title)) {
            ToastUtils.showToast("请输入标题");
            return;
        }

        //判断内容 是否为空 为空 则return
        if (TextUtils.isEmpty(editData)) {
            ToastUtils.showToast("请输入内容");
            return;
        }

        //判断内容的长度是否大于5000
        if (editData.length() > LengthLimit.LENGTH_LIMIT) {
            ToastUtils.showToast("内容超过限制");
            return;
        }

        //判断标签是否为空 为空 则return
        if (paramTagsList == null || paramTagsList.size() == 0) {
            ToastUtils.showToast("请选择标签");
            return;
        }

        //判断分类是否为空
        if (TextUtils.isEmpty(categoryId)) {
            ToastUtils.showToast("请选择分类");
            return;
        }

        //获取富文本中的图片
        List<String> pathList = HtmlImgUtil.getImgStrList(editData);

        //如果没有图片 则不做上传操作 直接走提交
        if (pathList == null || pathList.size() == 0) {//没有图片上传 传内容
            // TODO: 2019/11/5 走提交操作
            publishArticle(title,editData,paramTagsList,categoryId);
            return;
        }

        //判断图片是否超过30张
        if (pathList.size() > 30) {
            ToastUtils.showToast("图片超过限制");
            return;
        }

        //有图片 先上传图片 传完图片再替换imgURL 最后走提交
        List<File> files = new ArrayList<>();
        for (String path : pathList) {
            File file = new File(path);
            files.add(file);
        }
        uploadFiles(files, "image");
    }

    /**
     * 发布文章提交操作
     * @param title
     * @param content
     * @param tags
     */
    public void publishArticle(String title,String content,ArrayList<IndexLableLetterBean> tags,String categoryId) {
        //reqLoading.setValue(true);
        PublishArticleOrVideoReqBody body = new PublishArticleOrVideoReqBody();
        body.setCategoryId(categoryId);//not null
        body.setKeywords("");//not null
        body.setPreview("");//not null
        body.setImgUrl("");
        body.setPlayUrl("");
        body.setReleaseSource("");
        body.setPageViews("");
        body.setContent(content);
        body.setLabels(tags);
        body.setMediaType("0");
        body.setSportType("1");
        body.setTitle(title);
        add(httpApi.publishArticleOrVideo(body, new LifecycleCallback<Response>(mView) {
            @Override
            public void onSuccess(Response data) {
                if (data != null) {
                    LogUtils.INSTANCE.e("===z","发表成功onSuccess data = " + data.toString());
                    commitData.setValue(200 == data.getCode());

                    //设置需要删除数据
                    needClearData = true;
                } else {
                    commitData.setValue(false);
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                LogUtils.INSTANCE.e("===z","发表失败");
                commitData.setValue(false);
            }
        }));
    }

    /**
     * 是否需要删除数据
     * @return
     */
    public boolean isNeedClearData() {
        return needClearData;
    }

}
