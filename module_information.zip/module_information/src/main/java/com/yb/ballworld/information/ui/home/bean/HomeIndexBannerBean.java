package com.yb.ballworld.information.ui.home.bean;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Desc Banner数据结构
 * Date 2019/10/8
 * author mengk
 */
public class HomeIndexBannerBean implements Parcelable {
    private String id;
    private String title;
    private String imgUrl;
    private int jumpType;
    private String jumpId;
    private String jumpUrl;
    private int matchId;
    private int sportId;

    public HomeIndexBannerBean() {}

    protected HomeIndexBannerBean(Parcel in) {
        id = in.readString();
        title = in.readString();
        imgUrl = in.readString();
        jumpType = in.readInt();
        jumpId = in.readString();
        jumpUrl = in.readString();
    }

    public static final Creator<HomeIndexBannerBean> CREATOR = new Creator<HomeIndexBannerBean>() {
        @Override
        public HomeIndexBannerBean createFromParcel(Parcel in) {
            return new HomeIndexBannerBean(in);
        }

        @Override
        public HomeIndexBannerBean[] newArray(int size) {
            return new HomeIndexBannerBean[size];
        }
    };

    public int getMatchId() {
        return matchId;
    }

    public void setMatchId(int matchId) {
        this.matchId = matchId;
    }

    public int getSportId() {
        return sportId;
    }

    public void setSportId(int sportId) {
        this.sportId = sportId;
    }

    public static Creator<HomeIndexBannerBean> getCREATOR() {
        return CREATOR;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public int getJumpType() {
        return jumpType;
    }

    public void setJumpType(int jumpType) {
        this.jumpType = jumpType;
    }

    public String getJumpId() {
        return jumpId;
    }

    public void setJumpId(String jumpId) {
        this.jumpId = jumpId;
    }

    public String getJumpUrl() {
        return jumpUrl;
    }

    public void setJumpUrl(String jumpUrl) {
        this.jumpUrl = jumpUrl;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(title);
        dest.writeString(imgUrl);
        dest.writeInt(jumpType);
        dest.writeString(jumpId);
        dest.writeString(jumpUrl);
    }
}
