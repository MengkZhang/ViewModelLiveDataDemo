package com.yb.ballworld.information.ui.personal.presenter.community;

import android.text.TextUtils;

import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.information.http.PersonalHttpApi;
import com.yb.ballworld.information.ui.home.constant.FailStateConstant;
import com.yb.ballworld.information.ui.home.constant.LoadMoreType;
import com.yb.ballworld.information.ui.personal.adapter.community.PostAdapterType;
import com.yb.ballworld.information.ui.personal.bean.community.PostReleaseBean;
import com.yb.ballworld.information.ui.personal.bean.community.PostReleaseEntity;

import com.yb.ballworld.information.ui.personal.view.community.PersonalPostReplyFragment;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc: 个人-社区-回帖
 * Author: JS-Kylo
 * Created On: 2019/11/11 16:54
 */
public class PersonalPostReplyPresenter extends BasePresenter<PersonalPostReplyFragment, VoidModel> {
    private PersonalHttpApi httpApi = new PersonalHttpApi();
    private int page = 1;
    //返回的总页数
    private int totalPage;
    private boolean isRefresh;
    private boolean isLoadMore;
    private int mUserId;
    List<PostReleaseBean> mBeanLastList = new ArrayList<>();

    /**
     * 刷新
     */
    public void refreshData() {
        isRefresh = true;
        page = 1;
        loadDate(mUserId,page);
    }

    /**
     * 加载更多
     */
    public void loadMoreData() {
        isLoadMore = true;
        page++;
        if (page <= totalPage) { //可以加载更多数据
            loadDate(mUserId,page);
        } else {                 //没有更多数据
            mView.resultLoadMoreSuccess(LoadMoreType.TYPE_ALL_DATA);
        }
    }

    /**
     * 收藏列表
     * @param page 当前页
     */
    public void loadDate(int userId,int page){
        if (mUserId == 0)
            mUserId = userId;
        //只有正常加载才有loading 加载更多和刷新是没有的
        if (!isRefresh && !isLoadMore) {
            mView.requestLoading();
        }
        int pageSize = 15;
        List<PostReleaseBean> beanLastList = new ArrayList<>();
        add(httpApi.getPostReplyList(userId,page, pageSize,new LifecycleCallback<PostReleaseEntity>(mView) {
            @Override
            public void onSuccess(PostReleaseEntity data) {
                if (data == null){
                    judgeStatusEmpty();
                    return;
                }
                if (data.getList()==null){
                    judgeStatusEmpty();
                    return;
                }

                if (data.getList().size()==0){
                    judgeStatusEmpty();
                    return;
                }
                List<PostReleaseBean> beanList = data.getList();
                //List<PostReleaseBean> beanList = getTestDate();
                totalPage = data.getTotalPage();
                for (PostReleaseBean listBean:beanList){
                    if (!TextUtils.isEmpty(listBean.getVideoUrl())){
                        listBean.setItemViewType(PostAdapterType.TYPE_POST_VIDEOO);
                    }else {
                        listBean.setItemViewType(PostAdapterType.TYPE_POST_IMG);
                    }
                    beanLastList.add(listBean);
                }

                if (beanLastList.size()>0){
                    if (isRefresh){
                        mBeanLastList.clear();
                    }
                    mBeanLastList.addAll(beanLastList);
                    if (isRefresh){
                        isRefresh = false;
                        mView.resultRefreshSuccess();
                    }

                    //还原加载更多的状态
                    if (isLoadMore) {
                        isLoadMore = false;
                        mView.resultLoadMoreSuccess(LoadMoreType.TYPE_SUCCESS);
                    }
                    mView.resultSuccess(mBeanLastList,page);
                    //执行成功完毕 清理中转数组 否则造成列表叠加
                    mBeanLastList.clear();
                }else {
                    judgeStatusEmpty();
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                if (isRefresh) {         //刷新失败
                    isRefresh = false;
                    mView.resultRefreshFail("刷新失败");
                } else if (isLoadMore) { //加载更多失败
                    isLoadMore = false;
                    mView.resultLoadMoreFail("加载更多失败");
                } else {                 //正常加载数据失败
                    mView.resultFail(FailStateConstant.TYPE_ERROR,errMsg);
                    //mBeanLastList.addAll(getTestDate());
                    // mView.resultSuccess(mBeanLastList);
                }
            }
        }));
    }

    /**
     * 帖子点赞
     */
    public void postLike(PostReleaseBean bean,int position){
        add(httpApi.postLike(bean.getId(), new LifecycleCallback<String>(mView) {
            @Override
            public void onSuccess(String data) {
                mView.postLikeSuccess(bean,position);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                mView.postLikeFail(errMsg);
                //mView.postLikeSuccess(bean,position);
            }
        }));
    }

    /**
     * 判断刷新 加载更多 和 正常加载
     */
    private void judgeStatusEmpty() {
        if (isRefresh) {
            isRefresh = false;
            mView.resultRefreshFail("刷新数据为空");
        } else if (isLoadMore) {
            isLoadMore = false;
            mView.resultRefreshFail("加载更多数据为空");
        } else {
            dataEmpty();
        }
    }

    /**
     * 数据为空
     */
    private void dataEmpty() {
        mView.resultFail(FailStateConstant.TYPE_EMPTY,"");
    }

    private List<PostReleaseBean> getTestDate(){
        List<PostReleaseBean> beanList = new ArrayList<>();
        List<String> imgs = new ArrayList<>();
        imgs.add("http://sta.5yqz2.com/static/avatar/1-1P5220S634.jpg");
        imgs.add("http://sta.5yqz2.com/static/avatar/27ae9913238a0779d5cbe336409ff7dc.jpg");
        imgs.add("http://sta.5yqz2.com/static/avatar/9d94de112c1cfda980c3b97d56d27830.jpg");
        imgs.add("http://sta.5yqz2.com/static/avatar/9d94de112c1cfda980c3b97d56d27830.jpg");
        imgs.add("http://sta.5yqz2.com/static/avatar/9d94de112c1cfda980c3b97d56d27830.jpg");
        PostReleaseBean bean = new PostReleaseBean("你磨蹭啥呢\"？瓜帅当众暴怒 拍打座椅+抱头抓狂","2019-10-28 17:55:15",
                "http://sta.5yqz2.com/static/avatar/3c4a9a55ebaf3f4c00662adc631e1678.jpg",1,"张三",1,
                "http://1251542705.vod2.myqcloud.com/9665f9bfvodgzp1251542705/d537f9f25285890794509403078/SECHJhU3ADYA.mp4",imgs);

        List<String> imgs1 = new ArrayList<>();
        imgs1.add("http://sta.5yqz2.com/static/avatar/1-1P5220S634.jpg");
        imgs1.add("http://sta.5yqz2.com/static/avatar/27ae9913238a0779d5cbe336409ff7dc.jpg");
        imgs1.add("http://sta.5yqz2.com/static/avatar/9d94de112c1cfda980c3b97d56d27830.jpg");
        PostReleaseBean bean1 = new PostReleaseBean("你磨蹭啥呢\"？瓜帅当众暴怒 拍打座椅+抱头抓狂","2019-10-28 17:55:15",
                "http://sta.5yqz2.com/static/avatar/3c4a9a55ebaf3f4c00662adc631e1678.jpg",1,"张三1",1,
                "",imgs1);
        List<String> imgs2 = new ArrayList<>();
        imgs2.add("http://sta.5yqz2.com/static/avatar/1-1P5220S634.jpg");
        imgs2.add("http://sta.5yqz2.com/static/avatar/27ae9913238a0779d5cbe336409ff7dc.jpg");
        PostReleaseBean bean2 = new PostReleaseBean("你磨蹭啥呢\"？瓜帅当众暴怒 拍打座椅+抱头抓狂","2019-10-28 17:55:15",
                "http://sta.5yqz2.com/static/avatar/3c4a9a55ebaf3f4c00662adc631e1678.jpg",1,"张三2",1,
                "",imgs2);
        List<String> imgs3 = new ArrayList<>();
        imgs3.add("http://sta.5yqz2.com/static/avatar/1-1P5220S634.jpg");
        PostReleaseBean bean3 = new PostReleaseBean("你磨蹭啥呢\"？瓜帅当众暴怒 拍打座椅+抱头抓狂","2019-10-28 17:55:15",
                "http://sta.5yqz2.com/static/avatar/3c4a9a55ebaf3f4c00662adc631e1678.jpg",1,"张三3",1,
                "",imgs3);

        List<String> imgs4 = new ArrayList<>();
        imgs.add("http://sta.5yqz2.com/static/avatar/1-1P5220S634.jpg");
        imgs.add("http://sta.5yqz2.com/static/avatar/27ae9913238a0779d5cbe336409ff7dc.jpg");
        imgs.add("http://sta.5yqz2.com/static/avatar/27ae9913238a0779d5cbe336409ff7dc.jpg");
        imgs.add("http://sta.5yqz2.com/static/avatar/9d94de112c1cfda980c3b97d56d27830.jpg");
        imgs.add("http://sta.5yqz2.com/static/avatar/9d94de112c1cfda980c3b97d56d27830.jpg");
        imgs.add("http://sta.5yqz2.com/static/avatar/9d94de112c1cfda980c3b97d56d27830.jpg");
        PostReleaseBean bean4 = new PostReleaseBean("你磨蹭啥呢\"？瓜帅当众暴怒 拍打座椅+抱头抓狂","2019-11-11 14:55:1",
                "http://sta.5yqz2.com/static/avatar/3c4a9a55ebaf3f4c00662adc631e1678.jpg",1,"张三8",1,
                "",imgs4);

        beanList.add(bean);
        beanList.add(bean1);
        beanList.add(bean2);
        beanList.add(bean3);
        beanList.add(bean2);
        beanList.add(bean3);
        beanList.add(bean4);
        beanList.add(bean);
        return beanList;
    }
}
