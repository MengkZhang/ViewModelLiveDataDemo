package com.yb.ballworld.information.ui.profile.data;

import java.util.List;

/**
 * Desc: <>
 * Author: JS-Barder
 * Created On: 2019/11/21 21:53
 */
public class SeasonData {
    public List<SeasonBean> seasons;
}
