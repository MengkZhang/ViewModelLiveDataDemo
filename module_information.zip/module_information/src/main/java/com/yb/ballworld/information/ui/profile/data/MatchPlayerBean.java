package com.yb.ballworld.information.ui.profile.data;

/**
 * Desc: <球员榜实体类>
 * Author: JS-Barder
 * Created On: 2019/11/21 17:31
 */
public class MatchPlayerBean {
    public int playerId;
    public String playerName;
    public String playerLogo;
    public String teamName;
    public int goals;
    public int penalties;
    public int presence;
    public int playingTime;
    public String assist;
    public String nationality;
}
