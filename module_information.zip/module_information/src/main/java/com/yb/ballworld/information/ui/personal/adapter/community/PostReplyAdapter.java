package com.yb.ballworld.information.ui.personal.adapter.community;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bfw.image.core.utils.RoundType;
import com.bfw.image.glide.transform.RoundedCornersTransformation;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.request.RequestOptions;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.util.DensityUtil;
import com.yb.ballworld.baselib.base.recycler.decorate.GridItemSpaceDecoration;
import com.yb.ballworld.baselib.utils.ImageManager;
import com.yb.ballworld.baselib.utils.TimeUtils;
import com.yb.ballworld.baselib.utils.ViewUtils;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.community.CommunityImageAdapter;
import com.yb.ballworld.information.ui.community.view.TopicDetailActivity;
import com.yb.ballworld.information.ui.community.view.VeidoPlayerActivity;
import com.yb.ballworld.information.ui.detail.CommentImgQuickAdapter;
import com.yb.ballworld.information.ui.detail.CommunityCommentActivity;
import com.yb.ballworld.information.ui.detail.ImagesAdapter;
import com.yb.ballworld.information.ui.detail.ReplyQuickAdapter;
import com.yb.ballworld.information.ui.home.adapter.CellImgAdapter;
import com.yb.ballworld.information.ui.home.utils.GlideLoadImgUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.home.utils.softkey.IFSPanelConflictLayout;
import com.yb.ballworld.information.ui.personal.adapter.ImgAdapter;
import com.yb.ballworld.information.ui.personal.bean.PostImage;
import com.yb.ballworld.information.ui.personal.bean.community.PostReleaseBean;
import com.yb.ballworld.information.ui.personal.view.InformationPersonalActivity;
import com.yb.ballworld.information.ui.personal.view.InformationPersonalActivityNew;
import com.yb.ballworld.information.utils.CommondUtil;
import com.yb.ballworld.information.utils.ShareTextUitl;
import com.yb.ballworld.information.widget.GridSpacingItemDecoration;
import com.yb.ballworld.information.widget.TimerTextView;
import com.yb.ballworld.information.widget.listener.OnElementClickListener;

import java.util.ArrayList;
import java.util.List;

import cn.jzvd.JzvdStd;

import static android.text.TextUtils.isEmpty;

/**
 * Desc: 个人页-社区-回帖
 * Author: JS-Kylo
 * Created On: 2019/11/11 17:20
 */
public class PostReplyAdapter extends BaseQuickAdapter<PostReleaseBean, BaseViewHolder> {
    private Context context;
    private String author;
    private String headUrl;
    public static final int ITEMTYPE_NO_MEDIA = 0;
    public static final int ITEMTYPE_IMGS = 1;
    public static final int ITEMTYPE_VIDEO = 2;
    private OnElementClickListener mOnElementClickListener;

    public PostReplyAdapter(@Nullable List<PostReleaseBean> data, Context context) {
        super(R.layout.item_personal_post_reply, data);
        this.context = context;
    }

    public PostReplyAdapter(@Nullable List<PostReleaseBean> data, Context context, String author) {
        super(R.layout.item_personal_post_reply, data);
        this.context = context;
        this.author = author;
    }

    public PostReplyAdapter(@Nullable List<PostReleaseBean> data, Context context, String author, String hUrl) {
        super(R.layout.item_personal_post_reply, data);
        this.context = context;
        this.author = author;
        this.headUrl = hUrl;
    }

    public void setOnElementClickListener(OnElementClickListener onElementClickListener) {
        mOnElementClickListener = onElementClickListener;
    }

    @Override
    protected void convert(BaseViewHolder helper, PostReleaseBean item, int pos) {
        headUrl = isEmpty(item.getHeadImgUrl()) ? headUrl : item.getHeadImgUrl();
        ImageManager.INSTANCE.loadRoundIcon(headUrl, R.drawable.user_default_icon2, 0, helper.getView(R.id.ivUserHeader));
        helper.setText(R.id.tvUserName, item.getNickname());  //用户名
        //helper.setText(R.id.tvUserDesc, CommondUtil.convertTime(item.getCreatedDate(), context)); //时间

        ((TextView)helper.getView(R.id.tv_desc_info)).setText(item.getPostDate());
        helper.setText(R.id.tvContent, item.getContent()); //内容
        if (null!=item.getParent()) {
            if (!isEmpty(item.getParent().getContent()))
                helper.setText(R.id.tvOriginal, " 【原文】 " + item.getParent().getContent());
            else {
                if (!isEmpty(item.getParent().getVideoUrl())) {
                    helper.setText(R.id.tvOriginal, getMediaStr("[视频]"));
                } else if (item.getParent().getPostImgLists() != null) {
                    if (item.getParent().getPostImgLists().size() > 0) {
                        helper.setText(R.id.tvOriginal, getMediaStr("[图片]"));
                    } else
                        helper.setText(R.id.tvOriginal, " 【原文】 ");
                } else
                    helper.setText(R.id.tvOriginal, " 【原文】 ");
            }
        }else {
            helper.setText(R.id.tvOriginal, " 【原文】 ");
        }
        helper.setGone(R.id.tvContent, !isEmpty(item.getContent()));
        //helper.setText(R.id.tv_img, item.getMediaType() == 1 ? context.getString(R.string.func_commentVideo) : context.getString(R.string.func_commentImg));
        //点赞
        helper.setText(R.id.tvLikeCount, CommondUtil.likeCount(item.getLikeCount(), context));
        helper.addOnClickListener(R.id.lyPraise);
        helper.getView(R.id.iv_praise_icon).setSelected(item.isIsLike());

        //点击头像再次进入个人页
        helper.getView(R.id.ivUserHeader).setOnClickListener(v -> InformationPersonalActivityNew.startActivity(mContext,String.valueOf(item.getUserId()),InformationPersonalActivityNew.TYPE_COMMUNITY));
        helper.getView(R.id.tvUserName).setOnClickListener(v -> InformationPersonalActivityNew.startActivity(mContext,String.valueOf(item.getUserId()),InformationPersonalActivityNew.TYPE_COMMUNITY));
        helper.getView(R.id.tv_desc_info).setOnClickListener(v -> InformationPersonalActivityNew.startActivity(mContext,String.valueOf(item.getUserId()),InformationPersonalActivityNew.TYPE_COMMUNITY));

        //跳转到原文
        helper.getView(R.id.layout_reply).setOnClickListener(v -> gotoCommentAct(item));
        helper.getView(R.id.tvOriginal).setOnClickListener(v -> gotoInfoDetail(item));
        helper.getView(R.id.tvContent).setOnClickListener(v -> gotoCommentAct(item));
        int mediaType = getMediaType(item);
        if (mediaType == ITEMTYPE_VIDEO) {
            handleVideo(helper, item);
        } else if (mediaType == ITEMTYPE_IMGS) {
            handleImgs(helper, item);
        } else {
            helper.getView(R.id.singleCommit_frameLayout).setVisibility(View.GONE);
        }
    }

    /**
     * 跳转评论页
     */
    private void gotoCommentAct(PostReleaseBean bean) {
        if (bean.getPostType()==0){ //评论
           gotoInfoDetail(bean);
        }else {
            Intent intent = new Intent(mContext, CommunityCommentActivity.class);
            intent.putExtra("TOPIC_ID", bean.getReplyId()); // commentId  主帖id
            intent.putExtra("MAIN_TOPIC_ID", bean.getId()); // targetId  回复内容id
            mContext.startActivity(intent);
        }
    }

    /**
     * 跳转到资讯详情页
     */
    private void gotoInfoDetail(PostReleaseBean bean) {
        TopicDetailActivity.start(mContext,String.valueOf(bean.getMainPostId()));
    }

    /**
     * 处理评论中含有视频的扩展布局
     *
     * @param
     * @param
     */
    private void handleVideo(BaseViewHolder helper, PostReleaseBean item) {
        ViewGroup viewGroup= helper.getView(R.id.singleCommit_frameLayout);
        viewGroup.setVisibility(View.VISIBLE);
//        if(viewGroup.getChildCount()>0){
//            viewGroup.removeAllViews();
//        }
        helper.getView(R.id.singleCommit_frameLayout).setVisibility(View.VISIBLE);
        // LayoutInflater.from(context).inflate(R.layout.item_comment_video, helper.getView(R.id.singleCommit_frameLayout), true);
        helper.getView(R.id.singleCommit_frameLayout).setVisibility(View.VISIBLE);
        helper.getView(R.id.cardViewLayout).setVisibility(View.VISIBLE);
        helper.getView(R.id.recycle_imgs).setVisibility(View.GONE);

        JzvdStd jzvdStd = helper.getView(R.id.item_comment_video);
        if (!isEmpty(item.getVideoUrl())) {
            //helper.setText(R.id.tvContent, item.getVideoUrl()); //调试用
            jzvdStd.setUp(item.getVideoUrl(), "", JzvdStd.SCREEN_NORMAL);
            if (isEmpty(item.getImgUrl()))
                Glide.with(context).setDefaultRequestOptions(new RequestOptions()
                    .frame(1).transform(new CenterCrop(), new RoundedCornersTransformation(ViewUtils.dp2px(4), RoundType.ALL))).load(item.getVideoUrl())
                    .into(jzvdStd.thumbImageView);
            else
                GlideLoadImgUtil.loadPlayerFaceImg(mContext,item.getImgUrl(),jzvdStd.thumbImageView);
            jzvdStd.thumbImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    gotoVideoPlayer(item);
                }
            });
            jzvdStd.startButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    gotoVideoPlayer(item);
                }
            });
        }
    }

    public long getCreatedTime(String createdTime) {
        long createdTimes;
            if (!isEmpty(createdTime)) {
                createdTimes = TimeUtils.INSTANCE.toTimestamp(createdTime);
            } else {
                createdTimes = System.currentTimeMillis();
            }
        return createdTimes;
    }

    /**
     * 处理评论中含有图片的扩展布局
     *
     * @param
     * @param
     */
    private void handleImgs(BaseViewHolder helper, PostReleaseBean item) {
        ViewGroup viewGroup= helper.getView(R.id.singleCommit_frameLayout);
        viewGroup.setVisibility(View.VISIBLE);

        helper.getView(R.id.singleCommit_frameLayout).setVisibility(View.VISIBLE);
        helper.getView(R.id.cardViewLayout).setVisibility(View.GONE);
        helper.getView(R.id.recycle_imgs).setVisibility(View.VISIBLE);
        // LayoutInflater.from(context).inflate(R.layout.item_comment_imglist, helper.getView(R.id.singleCommit_frameLayout), true); cardViewLayout

        RecyclerView recyclerView = helper.getView(R.id.recycle_imgs);
//        ReplyQuickAdapter commentImgQuickAdapter = new ReplyQuickAdapter();
//        recyclerView.setAdapter(commentImgQuickAdapter);
//        //if (recyclerView.getItemDecorationCount() == 0) {
//        //    recyclerView.addItemDecoration(new GridSpacingItemDecoration(3, 10, false));
//        //}
//        commentImgQuickAdapter.autoFit(recyclerView, getImgList(item));
//        //commentImgQuickAdapter.setOnItemClickListener(onItemImgsClickListener);
//        commentImgQuickAdapter.setOnItemClickListener(new OnItemClickListener() {
//            @Override
//            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
//                if (TextUtils.isEmpty(item.getWebShareUrl()))
//                    NavigateToDetailUtil.navigateToGalleryActivityWithoutShare(mContext,getImgList(item),position);
//                else
//                    NavigateToDetailUtil.navigateToGalleryActivity(mContext,getImgList(item),position, ShareTextUitl.getShareTitle(item.getContent())
//                            ,item.getWebShareUrl(),item.getContent(),item.getWebShareUrl());
//            }
//        });

        List<String> imgList = getImgList(item);
        GridLayoutManager manager = new GridLayoutManager(mContext, 3);
        recyclerView.setLayoutManager(manager);

        if (recyclerView.getItemDecorationCount() == 0) {
            recyclerView.addItemDecoration(new GridSpacingItemDecoration(3, DensityUtil.dp2px(6), false));
        }
        CommunityImageAdapter adapter = new CommunityImageAdapter(imgList, false);
        recyclerView.setAdapter(adapter);

        adapter.setOnItemChildClickListener((adapter1, view, position) -> {
            if (view.getId() == R.id.iv_image) {
                if (isEmpty(item.getWebShareUrl())) {
                    NavigateToDetailUtil.navigateToGalleryActivityWithoutShare(mContext,getImgList(item),position);
                } else {
                    NavigateToDetailUtil.navigateToGalleryActivity(mContext,getImgList(item),position, ShareTextUitl.getShareTitle(item.getContent())
                            ,item.getWebShareUrl(),item.getContent(),item.getWebShareUrl());
                }
            }
        });

    }

    public void gotoVideoPlayer(PostReleaseBean bean){
        Intent intent=new Intent(context, VeidoPlayerActivity.class);
        intent.putExtra("url",bean.getVideoUrl());
        intent.putExtra("imageUrl",bean.getImgUrl());
        context.startActivity(intent);
    }

    private SpannableString getMediaStr(String type){
        SpannableString  spanStr=new SpannableString(" 【原文】 "+type);
        spanStr.setSpan(new ForegroundColorSpan(context.getResources().getColor(R.color.color_1d94df)), 6, 10, Spannable.SPAN_EXCLUSIVE_INCLUSIVE);
        return spanStr;
    }

    /**
     * 主要用在点击评论图片的事件转发
     *
     * @param adapter  the adpater
     * @param view     The itemView within the RecyclerView that was clicked (this
     * will be a view provided by the adapter)
     * @param position The position of the view in the adapter.
     */
    private OnItemClickListener onItemImgsClickListener = (adapter, view, position) -> {
        if (mOnElementClickListener != null) {
            mOnElementClickListener.onElementClick((String) adapter.getItem(position), ITEMTYPE_IMGS, position, adapter.getData());
        }
    };

    private String isNotNull(String string) {
        return !isEmpty(string) ? string : "";
    }

    private String getMediaPrompt(PostReleaseBean simpleCommit, int parentMediaType) {
        String text = "";
        if (parentMediaType == ITEMTYPE_VIDEO) {
            text = context.getString(R.string.func_commentVideo);
        } else if (parentMediaType == ITEMTYPE_IMGS) {
            int size = getImgList(simpleCommit).size();
            if (size > 1) {
                text = context.getString(R.string.func_commentImgCount, size);
            } else {
                text = context.getString(R.string.func_commentImg);
            }
        }
        return text;
    }

    /**
     * 获取媒资类型
     *
     * @param item
     */
    public int getMediaType(PostReleaseBean item) {
        int type;
        if (!isEmpty(item.getVideoUrl())) {
            type = ITEMTYPE_VIDEO;
        } else if (isHasImg(item)) {
            type = ITEMTYPE_IMGS;
        } else {
            type = ITEMTYPE_NO_MEDIA;
        }
        return type;
    }

    /**
     * 评论中是否含有图片
     *
     * @param item
     * @return
     */
    private boolean isHasImg(PostReleaseBean item) {
        if (null == item.getPostImgLists())
            return false;
        return item.getPostImgLists().size()>0;
    }

    /**
     * 评论中提取图片列表
     *
     * @param item
     * @return
     */
    public List<String> getImgList(PostReleaseBean item) {
        List<String> imgList = new ArrayList<>();

        /*String imgUrl = item.getImgUrl();
        if (!TextUtils.isEmpty(imgUrl)) {
            imgList.add(imgUrl);
        }
        imgUrl = item.getImgUrl2();
        if (!TextUtils.isEmpty(imgUrl)) {
            imgList.add(imgUrl);
        }
        imgUrl = item.getImgUrl3();
        if (!TextUtils.isEmpty(imgUrl)) {
            imgList.add(imgUrl);
        }*/
        imgList = item.getPostImgLists();
        return imgList;
    }

    /**
     * 评论中提取图片列表
     *
     * @param item
     * @return
     */
    public List<PostImage> getPostImgList(PostReleaseBean item) {
        List<PostImage> imgList = new ArrayList<>();

        List<String> imgUrls = item.getPostImgLists();
        if (imgUrls!=null) {
            for (String img:imgUrls) {
                PostImage postImage = new PostImage();
                postImage.setImgUrl(img);
                imgList.add(postImage);
            }
        }
        return imgList;
    }

    /**
     * 设置textview 最大行数
     */
    private void setLines(TextView textView) {
        textView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                int lineCount = textView.getLineCount();
                if (lineCount > 2) {
                    textView.setMaxLines(1);
                    textView.setEllipsize(TextUtils.TruncateAt.END);
                }
                textView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            }
        });
    }
}
