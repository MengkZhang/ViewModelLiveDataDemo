package com.yb.ballworld.information.ui.home.constant;

import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Desc 资讯列表的item的类型itemType区分
 * 图文
 *   非特约
 *     单图0
 *     双图1
 *     三图2
 *     图集3
 *   特约
 *     单图4
 *     双图5
 *     三图6
 *     图集7
 * 视频
 *   非特约8
 *   特约9
 *
 *   01238 不显示头像
 *   45679去USER对象里取名称和头像
 * Date 2019/10/7
 * author mengk
 */
@IntDef({
        ItemTypeConstant.TYPE_IMG_WITHOUT_HEAD,
        ItemTypeConstant.TYPE_IMGS_WITH_HEAD,
        ItemTypeConstant.TYPE_VIDEO_WITHOUT_HEAD,
        ItemTypeConstant.TYPE_IMG_WITH_HEAD,
        ItemTypeConstant.TYPE_VIDEO_WITH_HEAD,
        ItemTypeConstant.TYPE_IMGS3_WITH_HEAD
})

@Retention(RetentionPolicy.SOURCE)

public @interface ItemTypeConstant {
    //单图 普通没有头像类型
    int TYPE_IMG_WITHOUT_HEAD = 1;

    //单图 有头像
    int TYPE_IMG_WITH_HEAD = 2;
    //双图 有头像
    int TYPE_IMGS_WITH_HEAD = 3;
    //三图 有头像
    int TYPE_IMGS3_WITH_HEAD = 4;

    //视频 没有头像
    int TYPE_VIDEO_WITHOUT_HEAD = 5;
    //视频 有头像
    int TYPE_VIDEO_WITH_HEAD = 6;

}


