package com.yb.ballworld.information.ui.community.view;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bfw.util.ToastUtils;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.common.base.mvp.BaseMvpFragment;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.community.presenter.PostIndexCollectionPresenter;
import com.yb.ballworld.information.ui.home.constant.FailStateConstant;
import com.yb.ballworld.information.ui.home.constant.LoadMoreType;
import com.yb.ballworld.information.ui.community.adapter.PostCollectionAdapter;
import com.yb.ballworld.information.ui.community.bean.PostCollectionEntity;
import com.yb.ballworld.information.ui.home.utils.JZReleaseUtil;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;

/**
 * Desc:  收藏-帖子
 * Author: JS-Kylo
 * Created On: 2019/11/8 10:49
 */
public class PostIndexCollectionFragment extends BaseMvpFragment<PostIndexCollectionPresenter> {
    private static final String USER_ID = "USER_ID";
    private SmartRefreshLayout smartRefreshLayout;
    private RecyclerView recyclerView;
    private PlaceholderView placeholder;
    private LinearLayoutManager layoutManager;
    private int userId;
    private List<PostCollectionEntity.ListBean> dataList = new ArrayList<>();
    private PostCollectionAdapter adapter;
    private CompositeDisposable compositeDisposable;

    public static PostIndexCollectionFragment newInstance(){
        PostIndexCollectionFragment fragment = new PostIndexCollectionFragment();
        return fragment;
    }

    public static PostIndexCollectionFragment newInstance(int userId){
        PostIndexCollectionFragment fragment = new PostIndexCollectionFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(USER_ID,userId);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void initPresenter() {
        mPresenter.setVM(this);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_collect_post;
    }

    @Override
    protected void initView() {
        Bundle bundle = getArguments();
        if (bundle != null) {
            userId = bundle.getInt(USER_ID);
        }
        smartRefreshLayout = findView(R.id.smartRefreshLayout);
        recyclerView = findView(R.id.recyclerView);
        placeholder = findView(R.id.placeholder);
        smartRefreshLayout.setRefreshHeader(getRefreshHeader());
        smartRefreshLayout.setRefreshFooter(getRefreshFooter());
        layoutManager = new LinearLayoutManager(mContext);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new PostCollectionAdapter(getActivity(),dataList);
        recyclerView.setAdapter(adapter);
    }

    @Override
    protected void bindEvent() {
        compositeDisposable = new CompositeDisposable();
        initRefreshLoadMoreEvent();
        initReLoadEvent();
        //recyclerView滑动停止播放
        JZReleaseUtil.releaseAllVideos(recyclerView);
        //取消收藏
        LiveEventBus.get().with(LiveEventBusKey.KEY_TOPIC_REMOVE_COLLECT, String.class)
                .observe(this, new Observer<String>() {
                    @Override
                    public void onChanged(String newId) {
                        compositeDisposable.add(PostIndexCollectionFragment.this.loadPostPosition(newId)
                                .subscribeOn(AndroidSchedulers.mainThread())
                                .subscribe(integer -> {
                                    PostIndexCollectionFragment.this.removeData(integer);
                                })
                        );
                    }
                });
    }

    @Override
    protected void initData() {
        mPresenter.loadDate(userId,1);
    }

    @Override
    protected void processClick(View view) {

    }

    @Override
    public void onPause() {
        super.onPause();
        JZReleaseUtil.releaseAllVideos();
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (!getUserVisibleHint()) {
            JZReleaseUtil.releaseAllVideos();
        }
    }

    /**
     * 请求中
     */
    public void requestLoading() {
        placeholder.showLoading();
        smartRefreshLayout.setEnableRefresh(false);
        smartRefreshLayout.setEnableLoadMore(false);
    }

    /**
     * 请求成功回调
     * @param data 列表数据
     */
    public void resultSuccess(List<PostCollectionEntity.ListBean> data,int page) {
        placeholder.hideLoading();
        placeholder.setVisibility(View.GONE);
        smartRefreshLayout.setEnableRefresh(true);
        smartRefreshLayout.setEnableLoadMore(true);
        if (page <= 1) {
            dataList.clear();
        }
        dataList.addAll(data);
        adapter.notifyDataSetChanged();
    }

    /**
     * 请求失败回调
     */
    public void resultFail(int type,String errMsg) {
        switch (type) {
            case FailStateConstant.TYPE_ERROR:   //加载失败
                if (TextUtils.isEmpty(errMsg)||"null".equals(errMsg))
                    placeholder.showError("服务器连接失败~");
                else
                    placeholder.showError(errMsg);
                break;
            case FailStateConstant.TYPE_EMPTY:   //数据为空
                smartRefreshLayout.setEnableRefresh(true);
                placeholder.showEmpty("暂无数据");
                break;

            default:
                break;
        }
    }


    /**
     * 刷新成功
     */
    public void resultRefreshSuccess() {
        smartRefreshLayout.finishRefresh();
        //刷新成功清理存储的数组
        dataList.clear();
    }

    /**
     * 刷新失败
     */
    public void resultRefreshFail(String errorMsg) {
        smartRefreshLayout.finishRefresh();
    }

    /**
     * 加载更多成功
     */
    public void resultLoadMoreSuccess(int type) {
        smartRefreshLayout.finishLoadMore();
        switch (type) {
            case LoadMoreType.TYPE_SUCCESS:      //加载成功
                break;

            case LoadMoreType.TYPE_ALL_DATA:     //已经全部加载
                ToastUtils.showToast("已经全部加载");
                //已经全部加载 就不允许继续上拉加载了
                smartRefreshLayout.setEnableLoadMore(false);
                break;

            default:
                break;
        }
    }

    /**
     * 加载更多失败
     */
    public void resultLoadMoreFail(String errorMsg) {
        smartRefreshLayout.finishLoadMore();
    }

    /**
     * 初始化刷新和加载更多
     */
    private void initRefreshLoadMoreEvent() {
        smartRefreshLayout.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                mPresenter.loadMoreData();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                mPresenter.refreshData();
            }
        });
    }

    /**
     * 初始化重新加载数据
     */
    private void initReLoadEvent() {
        placeholder.setPageErrorRetryListener(v -> mPresenter.loadDate(userId,1));
    }

    /**
     * 删除收藏的数据
     *
     * @param position
     */
    private void removeData(int position) {
        if (null == dataList || dataList.size() < position)
            return;
        PostCollectionEntity.ListBean bean = dataList.get(position);
        if (dataList.contains(bean)) {
            dataList.remove(bean);
        }
        adapter.notifyDataSetChanged();

        if (dataList.size() == 0)
            placeholder.showEmpty( "暂无数据");
    }

    /**
     * 根据Id查找贴子的位置
     * @return
     */
    private Observable<Integer> loadPostPosition(String postId) {
        return Observable.create(emitter -> {
            List<PostCollectionEntity.ListBean> list = dataList;
            for (int i = 0; i < list.size(); i++) {
                PostCollectionEntity.ListBean listBean = list.get(i);
                if (postId.equals(String.valueOf(listBean.getPostId()))) {
                    emitter.onNext(i);
                }
            }
            emitter.onNext(-1);
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        compositeDisposable.clear();
    }
}
