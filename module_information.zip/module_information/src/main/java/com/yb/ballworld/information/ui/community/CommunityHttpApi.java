package com.yb.ballworld.information.ui.community;

import com.jeremyliao.liveeventbus.LiveEventBus;
import com.rxjava.rxlife.RxLife;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.common.api.BaseHttpApi;
import com.yb.ballworld.common.api.OnError;
import com.yb.ballworld.common.callback.ApiCallback;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.information.ui.community.bean.Topic;
import com.yb.ballworld.information.ui.community.data.CommunityNew;
import com.yb.ballworld.information.ui.community.data.CommunityPost;
import com.yb.ballworld.information.ui.community.data.CommunityPostBean;
import com.yb.ballworld.information.ui.community.data.CommunityRecommendBean;
import com.yb.ballworld.information.ui.home.bean.PublishCommentReqBean;

import io.reactivex.disposables.Disposable;
import rxhttp.RxHttp;

/**
 * Desc: <社区接口>
 * Author: JS-Barder
 * Created On: 2019/11/8 16:09
 */
public class CommunityHttpApi extends BaseHttpApi {
    public static final int SIZE_POST = 20;

    private static final String COMMUNITY_RECOMMEND_LIST_URL = "/qiutx-news/app/post/index";
    private static final String COMMUNITY_TOPIC_LIST_URL = "/qiutx-news/app/post/index/list";
    private static final String COMMUNITY_LIKE_URL = "/qiutx-news/app/post/like/";
    private static final String COMMUNITY_POST_NEW_URL = "/qiutx-news/app/post/posting";
    private static final String USER_FREEZE_STATE_URL = "/qiutx-news/app/post/freezeStatus";

    private RxHttp getMyApi(RxHttp http) {
        return getApi(http)
                .addHeader("deviceId", getDeviceId())
                .addHeader("x-user-header", getUidJson());
    }

    public Disposable getCommunityRecommend(LifecycleCallback<CommunityRecommendBean> callback) {
        return getMyApi(RxHttp.get(COMMUNITY_RECOMMEND_LIST_URL))
                .asResponse(CommunityRecommendBean.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess,
                        ((OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg())));
    }

    public Disposable getCommunityList(int page, LifecycleCallback<CommunityPostBean> callback) {
        return getMyApi(RxHttp.get(COMMUNITY_TOPIC_LIST_URL))
                .add("pageNum", page)
                .add("pageSize", SIZE_POST)
                .asResponse(CommunityPostBean.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess,
                        ((OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg())));
    }

    public Disposable communityLike(String postId, LifecycleCallback<String> callback) {
        return getMyApi(RxHttp.postJson(COMMUNITY_LIKE_URL + postId))
                .asString()
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess,
                        ((OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg())));
    }

    public Disposable communityPost(CommunityNew community, LifecycleCallback<CommunityPost> callback) {
        RxHttp http = getMyApi(RxHttp.postJson(COMMUNITY_POST_NEW_URL))
                .add("content", community.content)
                .add("imgUrl", community.imgUrl)
                .add("postImgLists", community.postImgLists)
                .add("userId", community.userId)
                .add("videoUrl", community.videoUrl);
        if (community.replyId > 0) {
            http.add("replyId", community.replyId);
        }
        return http.asResponse(CommunityPost.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(data -> {
                            callback.onSuccess(data);
                            if (community.replyId <= 0) {//标志是发帖
                                LiveEventBus.get().with(LiveEventBusKey.KEY_AUTHOR_REPLAY_TIE).post(data);
                            }
                        },
                        ((OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg())));
    }

    public Disposable judgeUserFreeze(LifecycleCallback<Boolean> callback) {
        return getMyApi(RxHttp.postForm(USER_FREEZE_STATE_URL))
                .asResponse(Boolean.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess,
                        ((OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg())));
    }


    public Disposable communityPostComment(CommunityNew community, LifecycleCallback<Topic> callback) {
        RxHttp http = getMyApi(RxHttp.postJson(COMMUNITY_POST_NEW_URL))
                .add("content", community.content)
                .add("imgUrl", community.imgUrl)
                .add("postImgLists", community.postImgLists)
                .add("userId", community.userId)
                .add("videoUrl", community.videoUrl)
                .add("replyId", community.replyId);
        return http.asResponse(Topic.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(data -> {
                            callback.onSuccess(data);
                        },
                        ((OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg())));
    }
}
