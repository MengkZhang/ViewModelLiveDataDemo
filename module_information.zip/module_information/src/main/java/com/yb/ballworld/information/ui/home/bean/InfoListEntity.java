package com.yb.ballworld.information.ui.home.bean;

import java.util.List;

/**
 * Desc 资讯列表返回值
 * Date 2019/10/8
 * author mengk
 */
public class InfoListEntity {


    /**
     * totalCount : 1
     * pageNum : 1
     * pageSize : 15
     * totalPage : 1
     * list : [{"id":"6503b82ba10045719739c23ed577bfeb","title":"Btest逆流成河","imgUrl":"http://sta.5yqz2.com/static/avatar/bdf08e4e8e5b01faf609fc143a95d3fd.jpg","preview":"文学：社会意识形态之一。是运用虚构和想象，使用语言塑造形象，反映社会生活，表达思想感情的艺术。文学体裁可分为诗歌、小说、散文、戏剧等。","mediaType":1,"playUrl":"http://sta.5yqz2.com/static/avatar/42eb5a2de601980383d47e283d161b8f.mp4","showType":0,"userId":"5790","newsImgs":null,"likeCount":5,"commentCount":0,"appShowType":8,"user":{"id":"5790","nickname":"小短腿1590012","headImgUrl":"http://sta.5yqz2.com/static/avatar/1f751ad5dc5f6668072a741cddfc403b.jpg","personalDesc":"小短腿159002","followerCount":null,"articleCount":null,"attentionStatus":null},"isLike":false,"createdDate":"2019-10-16 22:53:11"}]
     */

    private int totalCount;
    private int pageNum;
    private int pageSize;
    private int totalPage;
    private List<ListBean> list;

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    public static class ListBean {
        /**
         * id : 6503b82ba10045719739c23ed577bfeb
         * title : Btest逆流成河
         * imgUrl : http://sta.5yqz2.com/static/avatar/bdf08e4e8e5b01faf609fc143a95d3fd.jpg
         * preview : 文学：社会意识形态之一。是运用虚构和想象，使用语言塑造形象，反映社会生活，表达思想感情的艺术。文学体裁可分为诗歌、小说、散文、戏剧等。
         * mediaType : 1
         * playUrl : http://sta.5yqz2.com/static/avatar/42eb5a2de601980383d47e283d161b8f.mp4
         * showType : 0
         * userId : 5790
         * newsImgs : null
         * likeCount : 5
         * commentCount : 0
         * appShowType : 8
         * user : {"id":"5790","nickname":"小短腿1590012","headImgUrl":"http://sta.5yqz2.com/static/avatar/1f751ad5dc5f6668072a741cddfc403b.jpg","personalDesc":"小短腿159002","followerCount":null,"articleCount":null,"attentionStatus":null}
         * isLike : false
         * createdDate : 2019-10-16 22:53:11
         */

        private String id;
        private String title;
        private String imgUrl;
        private String preview;
        private int mediaType;
        private String playUrl;
        private int showType;
        private String userId;
        private Object newsImgs;
        private int likeCount;
        private int commentCount;
        private int appShowType;
        private UserBean user;
        private boolean isLike;
        private String createdDate;
        private String webShareUrl;

        public boolean isLike() {
            return isLike;
        }

        public void setLike(boolean like) {
            isLike = like;
        }

        public String getWebShareUrl() {
            return webShareUrl;
        }

        public void setWebShareUrl(String webShareUrl) {
            this.webShareUrl = webShareUrl;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getImgUrl() {
            return imgUrl;
        }

        public void setImgUrl(String imgUrl) {
            this.imgUrl = imgUrl;
        }

        public String getPreview() {
            return preview;
        }

        public void setPreview(String preview) {
            this.preview = preview;
        }

        public int getMediaType() {
            return mediaType;
        }

        public void setMediaType(int mediaType) {
            this.mediaType = mediaType;
        }

        public String getPlayUrl() {
            return playUrl;
        }

        public void setPlayUrl(String playUrl) {
            this.playUrl = playUrl;
        }

        public int getShowType() {
            return showType;
        }

        public void setShowType(int showType) {
            this.showType = showType;
        }

        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public Object getNewsImgs() {
            return newsImgs;
        }

        public void setNewsImgs(Object newsImgs) {
            this.newsImgs = newsImgs;
        }

        public int getLikeCount() {
            return likeCount;
        }

        public void setLikeCount(int likeCount) {
            this.likeCount = likeCount;
        }

        public int getCommentCount() {
            return commentCount;
        }

        public void setCommentCount(int commentCount) {
            this.commentCount = commentCount;
        }

        public int getAppShowType() {
            return appShowType;
        }

        public void setAppShowType(int appShowType) {
            this.appShowType = appShowType;
        }

        public UserBean getUser() {
            return user;
        }

        public void setUser(UserBean user) {
            this.user = user;
        }

        public boolean isIsLike() {
            return isLike;
        }

        public void setIsLike(boolean isLike) {
            this.isLike = isLike;
        }

        public String getCreatedDate() {
            return createdDate;
        }

        public void setCreatedDate(String createdDate) {
            this.createdDate = createdDate;
        }

        public static class UserBean {
            /**
             * id : 5790
             * nickname : 小短腿1590012
             * headImgUrl : http://sta.5yqz2.com/static/avatar/1f751ad5dc5f6668072a741cddfc403b.jpg
             * personalDesc : 小短腿159002
             * followerCount : null
             * articleCount : null
             * attentionStatus : null
             */

            private String id;
            private String nickname;
            private String headImgUrl;
            private String personalDesc;
            private Object followerCount;
            private Object articleCount;
            private Object attentionStatus;

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public String getNickname() {
                return nickname;
            }

            public void setNickname(String nickname) {
                this.nickname = nickname;
            }

            public String getHeadImgUrl() {
                return headImgUrl;
            }

            public void setHeadImgUrl(String headImgUrl) {
                this.headImgUrl = headImgUrl;
            }

            public String getPersonalDesc() {
                return personalDesc;
            }

            public void setPersonalDesc(String personalDesc) {
                this.personalDesc = personalDesc;
            }

            public Object getFollowerCount() {
                return followerCount;
            }

            public void setFollowerCount(Object followerCount) {
                this.followerCount = followerCount;
            }

            public Object getArticleCount() {
                return articleCount;
            }

            public void setArticleCount(Object articleCount) {
                this.articleCount = articleCount;
            }

            public Object getAttentionStatus() {
                return attentionStatus;
            }

            public void setAttentionStatus(Object attentionStatus) {
                this.attentionStatus = attentionStatus;
            }
        }
    }
}
