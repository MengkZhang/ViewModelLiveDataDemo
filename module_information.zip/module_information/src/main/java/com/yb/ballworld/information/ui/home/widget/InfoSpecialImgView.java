package com.yb.ballworld.information.ui.home.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.yb.ballworld.common.sharesdk.ShareSdkParamBean;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.adapter.CellImgAdapter;
import com.yb.ballworld.information.ui.home.bean.IndexHotEntity;
import com.yb.ballworld.information.ui.home.bean.JumpBean;
import com.yb.ballworld.information.ui.home.utils.CommentHotUtil;
import com.yb.ballworld.information.ui.home.utils.GlideLoadImgUtil;
import com.yb.ballworld.information.ui.home.utils.ListImgUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.home.utils.UidUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc 自定义首页条目-特约
 *     单图
 *     双图
 *     三图
 * Date 2019/10/22
 * author mengk
 */
public class InfoSpecialImgView extends RelativeLayout {
    private Context mContext;
    private ImageView iv_comment_icon;
    private TextView tv_comment_count;
    private TextView tv_name_info;
    private TextView tv_desc_info;
    private TextView tv_praise_info;
    private TextView tv_title_top;
    private TextView tv_top_tag;
    private View rl_share_root_view;
    private View ll_root_view_multi;
    private ImageView iv_user_head_info;
    private ImageView iv_praise_icon;
    private RecyclerView rv_imgs_list;

    public InfoSpecialImgView(Context context) {
        this(context, null);
    }

    public InfoSpecialImgView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        this.mContext = context;
        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.InfoSpecialImgView);
        int itemType = typedArray.getInteger(R.styleable.InfoSpecialImgView_itemViewType,0);
        initView(itemType);
        typedArray.recycle();
    }


    /**
     * 初始化views
     * @param itemViewType
     */
    private void initView(int itemViewType) {
        //获取类型
        View view;
        if (itemViewType == 0) {//单图
            view = LayoutInflater.from(getContext()).inflate(R.layout.item_info_type_imgs_just_one,this, false);
        } else {//其他
            view = LayoutInflater.from(getContext()).inflate(R.layout.item_info_type_imgs,this, false);
        }

        this.removeAllViews();
        this.addView(view);

        iv_comment_icon = view.findViewById(R.id.iv_comment_icon);
        tv_comment_count = view.findViewById(R.id.tv_comment_count);
        rl_share_root_view = view.findViewById(R.id.rl_share_root_view);
        iv_user_head_info = view.findViewById(R.id.iv_user_head_info);
        tv_name_info = view.findViewById(R.id.tv_name_info);
        tv_desc_info = view.findViewById(R.id.tv_desc_info);
        ll_root_view_multi = view.findViewById(R.id.ll_root_view_multi);
        tv_praise_info = view.findViewById(R.id.tv_praise_info);
        iv_praise_icon = view.findViewById(R.id.iv_praise_icon);
        tv_title_top = view.findViewById(R.id.tv_title_top);
        tv_top_tag = view.findViewById(R.id.tv_top_tag);
        rv_imgs_list = view.findViewById(R.id.rv_imgs_list);
    }


    /**
     * 设置具体数据
     * @param item 数据
     */
    public void setDetailData(int type,BaseViewHolder helper, IndexHotEntity.NewsBean.ListBean item) {
        if (item == null) return;

        //首页热门列表这里是Id 不是newsId 不知后台在搞啥
        String id = item.getId();
        if (TextUtils.isEmpty(id)) return;

        //用户信息
        setUserInfo(item);

        //设置基本信息
        setBaseInfo(item, id, item.getMediaType());

        //点赞的状态和数量
        setPraiseInfo(helper, item);

        //图片列表
        setImgList(type, item, id);

    }

    /**
     * 设置基本信息
     * @param item
     * @param id
     * @param mediaType
     */
    private void setBaseInfo(IndexHotEntity.NewsBean.ListBean item, String id, int mediaType) {
        tv_top_tag.setVisibility(item.isTop() ? View.VISIBLE : View.GONE);

        //设置评论
        CommentHotUtil.setHotComment(mContext,iv_comment_icon,tv_comment_count,item.getCommentCount());

        //分享按钮
        NavigateToDetailUtil.showShareToast(rl_share_root_view,mContext,new ShareSdkParamBean(item.getTitle(),item.getWebShareUrl(),item.getPreview(),item.getImgUrl(),item.getWebShareUrl()));

        //标题
        String title = item.getTitle();
        tv_title_top.setText(isNotNull(title));

        //点击事件
        ll_root_view_multi.setOnClickListener(v -> NavigateToDetailUtil.navigateToDetail(mContext,id,mediaType == 1));
    }

    /**
     * 设置点赞信息
     * @param helper
     * @param item
     */
    private void setPraiseInfo(BaseViewHolder helper, IndexHotEntity.NewsBean.ListBean item) {
        int praiseCount = item.getLikeCount();
        String like = praiseCount + "";
        tv_praise_info.setText(like);
        //点赞状态
        boolean hasFocus = item.isLike();
//        helper.addOnClickListener(R.id.iv_praise_icon);
        helper.addOnClickListener(R.id.rl_praise_root);
        iv_praise_icon.setSelected(hasFocus);
    }

    /**
     * 设置图片列表
     * @param type
     * @param item
     * @param id
     */
    private void setImgList(int type, IndexHotEntity.NewsBean.ListBean item, String id) {
        GridLayoutManager layoutManager;
        switch (type) {
            case 1:
                layoutManager = new GridLayoutManager(mContext, 2);
                break;
            case 2:
                layoutManager = new GridLayoutManager(mContext, 3);
                break;
            default:
                layoutManager = new GridLayoutManager(mContext, 1);
                break;
        }
        rv_imgs_list.setLayoutManager(layoutManager);

        List<JumpBean> list = new ArrayList<>();
        if (type == 0) {//单图
            String imgUrl = item.getImgUrl();
            JumpBean jumpBean = new JumpBean();
            jumpBean.setImgUrl(imgUrl);
            jumpBean.setNewsId(id);
            list.add(jumpBean);

            CellImgAdapter cellImgAdapter = new CellImgAdapter(list);
            rv_imgs_list.setAdapter(cellImgAdapter);

            setClick(cellImgAdapter);

        } else {//双图和多图

            List<IndexHotEntity.NewsBean.ListBean.NewsImgsBean> newsImgs = item.getNewsImgs();
//            newsImgs = testData();
            if (newsImgs != null && newsImgs.size() != 0) {

                if (type == 1) { //双图
                    for (int i = 0; i < 2; i++) {
                        IndexHotEntity.NewsBean.ListBean.NewsImgsBean newsImgsBean = newsImgs.get(i);
                        String imgUrl = newsImgsBean.getImgUrl();
                        JumpBean jumpBean = new JumpBean();
                        jumpBean.setImgUrl(imgUrl);
                        jumpBean.setNewsId(id);
                        list.add(jumpBean);

                    }

                } else {         //三图和多图
                    for (int i = 0; i < newsImgs.size(); i++) {
                        IndexHotEntity.NewsBean.ListBean.NewsImgsBean newsImgsBeanX = newsImgs.get(i);
                        String imgUrl = newsImgsBeanX.getImgUrl();
                        JumpBean jumpBean = new JumpBean();
                        jumpBean.setImgUrl(imgUrl);
                        jumpBean.setNewsId(id);
                        list.add(jumpBean);

                    }

                }

                CellImgAdapter cellImgAdapter = new CellImgAdapter(list);
                rv_imgs_list.setAdapter(cellImgAdapter);

                setClick(cellImgAdapter);
            } else {//图片数组为空

                //根据type判断是双图还是多图 （三图）
                List<JumpBean> testImgList;
                if (type == 1) { //双图
                    testImgList = ListImgUtil.getTestImgList(mContext,id,true);

                } else {         //三图和多图

                    testImgList = ListImgUtil.getTestImgList(mContext,id,false);
                }

                CellImgAdapter cellImgAdapter = new CellImgAdapter(testImgList);
                rv_imgs_list.setAdapter(cellImgAdapter);

                setClick(cellImgAdapter);
            }
        }

    }

    private List<IndexHotEntity.NewsBean.ListBean.NewsImgsBean> testData() {
        List<IndexHotEntity.NewsBean.ListBean.NewsImgsBean> list = new ArrayList<>();
        for (int i = 0; i < 9; i++) {
            IndexHotEntity.NewsBean.ListBean.NewsImgsBean newsImgsBean = new IndexHotEntity.NewsBean.ListBean.NewsImgsBean();
            newsImgsBean.setNewsId("959f679887e249cba3be5034f4f988dc");
            newsImgsBean.setImgUrl("http://sta.5yqz2.com/static/avatar/f5a48302cb6769e0d82879f93f68f2a6.png");
            list.add(newsImgsBean);
        }
        return list;
    }

    /**
     * 图片点击事件
     * @param cellImgAdapter
     */
    private void setClick(CellImgAdapter cellImgAdapter) {
        cellImgAdapter.setOnItemChildClickListener((adapter, view, position) -> {
            if (view.getId() == R.id.iv_img_multi) {
                if (onFaceClickListener != null) {
                    onFaceClickListener.onFaceClick(position);
                }
            }
        });
    }

    public interface OnFaceClickListener {
        void onFaceClick(int position);
    }

    private OnFaceClickListener onFaceClickListener;

    public void setOnFaceClickListener(OnFaceClickListener onFaceClickListener) {
        this.onFaceClickListener = onFaceClickListener;
    }

    /**
     * 设置用户信息
     * @param item
     */
    private void setUserInfo(IndexHotEntity.NewsBean.ListBean item) {
        IndexHotEntity.NewsBean.ListBean.UserBean user = item.getUser();
        if (user != null) {
            String headImgUrl = user.getHeadImgUrl();
            GlideLoadImgUtil.loadImgHead(mContext,headImgUrl,iv_user_head_info);
            String nickname = user.getNickname();
            String personalDesc = user.getPersonalDesc();
            tv_name_info.setText(isNotNull(nickname));
            tv_desc_info.setText(isNotNull(personalDesc));
            //点击头像
            iv_user_head_info.setOnClickListener(v -> NavigateToDetailUtil.navigateToPerson(mContext,user.getId()));
        } else {
            GlideLoadImgUtil.loadImgHead(mContext,"",iv_user_head_info);
        }

    }

    private String isNotNull(String string) {
        return !TextUtils.isEmpty(string) ? string : "";
    }
}
