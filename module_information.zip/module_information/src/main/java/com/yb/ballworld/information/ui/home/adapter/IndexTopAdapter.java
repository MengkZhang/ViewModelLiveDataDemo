package com.yb.ballworld.information.ui.home.adapter;

import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.common.sharesdk.ShareSdkParamBean;
import com.yb.ballworld.common.widget.STCircleImageView;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.bean.IndexHotEntity;
import com.yb.ballworld.information.ui.home.bean.InfoListEntity;
import com.yb.ballworld.information.ui.home.bean.JumpBean;
import com.yb.ballworld.information.ui.home.constant.ItemTypeConstant;
import com.yb.ballworld.information.ui.home.utils.CommentHotUtil;
import com.yb.ballworld.information.ui.home.utils.GlideLoadImgUtil;
import com.yb.ballworld.information.ui.home.utils.ListImgUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.home.utils.UidUtil;
import com.yb.ballworld.information.ui.home.widget.InfoNoSpecialView;

import java.util.ArrayList;
import java.util.List;

import cn.jzvd.Jzvd;
import cn.jzvd.JzvdStd;

/**
 * Desc 置顶adapter
 * Date 2019/10/9
 * author mengk
 */
public class IndexTopAdapter extends BaseMultiItemQuickAdapter<IndexHotEntity.NewsTopBlocksBean, BaseViewHolder> {

    private List<IndexHotEntity.NewsTopBlocksBean> data;
    private boolean hasRefreshComment;
    private boolean hasRefreshLike;
    private LiveEventBus.Observable<String> observable;

    public IndexTopAdapter(@Nullable List<IndexHotEntity.NewsTopBlocksBean> data) {
        super(data);
        this.data = data;
        addItemType(ItemTypeConstant.TYPE_IMG_WITHOUT_HEAD, R.layout.item_info_type_img);
//        addItemType(ItemTypeConstant.TYPE_IMG_WITHOUT_HEAD, R.layout.item_info_type_img_new);

        addItemType(ItemTypeConstant.TYPE_IMG_WITH_HEAD, R.layout.item_info_type_imgs_just_one);
        addItemType(ItemTypeConstant.TYPE_IMGS_WITH_HEAD, R.layout.item_info_type_imgs);
        addItemType(ItemTypeConstant.TYPE_IMGS3_WITH_HEAD, R.layout.item_info_type_imgs);

//        addItemType(ItemTypeConstant.TYPE_IMG_WITH_HEAD, R.layout.item_info_type_imgs_new1);
//        addItemType(ItemTypeConstant.TYPE_IMGS_WITH_HEAD, R.layout.item_info_type_imgs_new2);
//        addItemType(ItemTypeConstant.TYPE_IMGS3_WITH_HEAD, R.layout.item_info_type_imgs_new3);

        addItemType(ItemTypeConstant.TYPE_VIDEO_WITH_HEAD, R.layout.item_info_type_video_with_head_or_not);
//        addItemType(ItemTypeConstant.TYPE_VIDEO_WITH_HEAD, R.layout.item_info_type_video_with_head_or_not_new);

        addItemType(ItemTypeConstant.TYPE_VIDEO_WITHOUT_HEAD, R.layout.item_info_type_video_with_head_or_not);
//        addItemType(ItemTypeConstant.TYPE_VIDEO_WITHOUT_HEAD, R.layout.item_info_type_video_with_head_or_not_new);
    }

    @Override
    protected void convert(BaseViewHolder helper, IndexHotEntity.NewsTopBlocksBean item, int pos) {
        int itemViewType = helper.getItemViewType();
        LogUtils.INSTANCE.e("===z","置顶adapter中受到的类型type = " + itemViewType);
        switch (itemViewType) {
            case ItemTypeConstant.TYPE_IMG_WITHOUT_HEAD: // item类型 单图 普通没有头像类型
                adapterItem(helper, item,pos);
//                adapterItem(helper, item);
                break;

            case ItemTypeConstant.TYPE_IMG_WITH_HEAD:  // item类型 单图有头像类型
                adapterItemMultiImgWithHead(0, helper, item,pos);
                break;

            case ItemTypeConstant.TYPE_IMGS_WITH_HEAD:               //item类型 双图
                adapterItemMultiImgWithHead(1, helper, item,pos);
                break;

            case ItemTypeConstant.TYPE_IMGS3_WITH_HEAD:              //item类型 三图
                adapterItemMultiImgWithHead(2, helper, item,pos);
                break;

            case ItemTypeConstant.TYPE_VIDEO_WITH_HEAD:               //item类型 视频有头像
                adapterItemVideo(0, helper, item,pos);
                break;

            case ItemTypeConstant.TYPE_VIDEO_WITHOUT_HEAD:            //item类型 视频没有头像
                adapterItemVideo(1, helper, item,pos);
                break;

            default:
                adapterItem(helper, item,pos);
                break;

        }
//        notifyData();
    }

    /**
     *
     * @param helper
     * @param item
     */
    private void adapterItem(BaseViewHolder helper, IndexHotEntity.NewsTopBlocksBean item) {
        InfoNoSpecialView infoNoSpecialView = helper.getView(R.id.insv_info);

    }

    /**
     * 组装数据
     * @param bean
     * @return
     */
//    private IndexHotEntity.NewsBean.ListBean getItem(IndexHotEntity.NewsTopBlocksBean bean) {
//        IndexHotEntity.NewsBean.ListBean listBean = new IndexHotEntity.NewsBean.ListBean();
//        String newsId = bean.getNewsId();
//        listBean.setId(isNotNull(newsId));
//        listBean.setTitle(isNotNull(bean.getTitle()));
//        listBean.setImgUrl(isNotNull(bean.getImgUrl()));
//        listBean.setPreview(isNotNull(bean.getPreview()));
//        listBean.setMediaType(bean.getMediaType());
//        listBean.set
//        return listBean;
//    }

    /**
     * 接收详情点赞事件
     */
    private void notifyData() {
        //接收评论事件
        observable.observe((LifecycleOwner) mContext, new Observer<String>() {
            @Override
            public void onChanged(String newsId) {
                if (data.size() != 0) {
                    for (int i = 0; i < data.size(); i++) {
                        IndexHotEntity.NewsTopBlocksBean newsTopBlocksBean = data.get(i);
                        if (newsTopBlocksBean != null) {
                            String newsIds = newsTopBlocksBean.getNewsId();
                            int commentCount = newsTopBlocksBean.getCommentCount();
                            if (newsId.equals(newsIds)) {
                                newsTopBlocksBean.setCommentCount(commentCount + 1);
                                notifyItemChanged(i);
                                observable.removeObserver(this);
                                break;
                            }
                        }
                    }
                }
            }
        });

        //接收来自详情页的点赞事件 LiveEventBusKey.KEY_NEWS_LIKE
        LiveEventBus.Observable<String> stringObservable = LiveEventBus.get().with(LiveEventBusKey.KEY_NEWS_LIKE, String.class);
        stringObservable.observe((LifecycleOwner) mContext, id -> {
            if (data.size() != 0) {
                for (int i = 0; i < data.size(); i++) {
                    IndexHotEntity.NewsTopBlocksBean newsTopBlocksBean = data.get(i);
                    if (newsTopBlocksBean != null) {
                        String newsId = newsTopBlocksBean.getNewsId();
                        int likeCount = newsTopBlocksBean.getLikeCount();
                        if (id.equals(newsId)) {
                            newsTopBlocksBean.setLike(true);
                            newsTopBlocksBean.setLikeCount(likeCount + 1);
                            notifyItemChanged(i);
                            break;
                        }
                    }
                }
            }
        });
    }

    /**
     * 最普通的item
     * @param helper
     * @param item
     * @param pos
     */
    private void adapterItem(BaseViewHolder helper, IndexHotEntity.NewsTopBlocksBean item, int pos) {
        int mediaType = item.getMediaType();
        if (mediaType == 1) {//显示视频图标
            helper.getView(R.id.iv_info_player_icon).setVisibility(View.VISIBLE);
        } else {//不显示视频播放
            helper.getView(R.id.iv_info_player_icon).setVisibility(View.GONE);
        }
        TextView tvTitle = helper.getView(R.id.tv_title_top);
        TextView tvTopTag = helper.getView(R.id.tv_top_tag);
        ImageView ivFace = helper.getView(R.id.iv_img_top);
        tvTopTag.setVisibility(View.VISIBLE);
        String imgUrl = item.getImgUrl();
        String title = item.getTitle();
        tvTitle.setText(isNotNull(title));
        GlideLoadImgUtil.loadImg(mContext,imgUrl,ivFace);

        //点击事件调详情
        helper.getView(R.id.rl_root_view_img).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = item.getNewsId();
                int mediaType = item.getMediaType();
                NavigateToDetailUtil.navigateToDetail(mContext,id, mediaType == 1);
            }
        });

        //设置评论
        CommentHotUtil.setHotComment(mContext,helper.getView(R.id.iv_comment_icon),helper.getView(R.id.tv_comment_count_top),item.getCommentCount());
    }


    /**
     * 有头像类型 单图 双图 三图类型
     *
     * @param type   0 单图 1 双图 2 三图
     * @param helper BaseViewHolder
     * @param item   HomeInfoListBean
     */
    private void adapterItemMultiImgWithHead(int type, BaseViewHolder helper, IndexHotEntity.NewsTopBlocksBean item,int position) {
        String id = item.getNewsId();
        int mediaType = item.getMediaType();
        if (TextUtils.isEmpty(id)) return;

        //设置评论
        CommentHotUtil.setHotComment(mContext,helper.getView(R.id.iv_comment_icon),helper.getView(R.id.tv_comment_count),item.getCommentCount());

        //点赞按钮
        NavigateToDetailUtil.showShareToast(helper.getView(R.id.rl_share_root_view),mContext,
                new ShareSdkParamBean(item.getTitle(),item.getWebShareUrl(),item.getPreview(),item.getImgUrl(),item.getWebShareUrl()));
//        NavigateToDetailUtil.showShareToast(helper.getView(R.id.rl_share_root_view),mContext,item.getTitle(),item.getWebShareUrl(),item.getPreview(),item.getImgUrl(),item.getWebShareUrl());

        //用户信息
        ImageView imageViewHead = helper.getView(R.id.iv_user_head_info);
        TextView tvNameInfo = helper.getView(R.id.tv_name_info);
        TextView tvDescInfo = helper.getView(R.id.tv_desc_info);
        IndexHotEntity.NewsTopBlocksBean.UserBeanX user = item.getUser();
        if (user != null) {
            String headImgUrl = user.getHeadImgUrl();
            GlideLoadImgUtil.loadImgHead(mContext,headImgUrl,imageViewHead);
            String nickname = user.getNickname();
            String personalDesc = user.getPersonalDesc();
            tvNameInfo.setText(isNotNull(nickname));
            tvDescInfo.setText(isNotNull(personalDesc));
            //点击头像
            helper.getView(R.id.iv_user_head_info).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    NavigateToDetailUtil.navigateToPerson(mContext, user.getId()); //UidUtil.getUid()
                }
            });
        } else {
            GlideLoadImgUtil.loadImgHead(mContext,"",imageViewHead);
            tvNameInfo.setText("");
            tvDescInfo.setText("");
        }

        //置顶标签
        helper.getView(R.id.tv_top_tag).setVisibility(View.VISIBLE);

        //点击事件
        View rootView = helper.getView(R.id.ll_root_view_multi);
        rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavigateToDetailUtil.navigateToDetail(mContext,id,mediaType == 1);
            }
        });

        //点赞的状态和数量
        TextView tvPraise = helper.getView(R.id.tv_praise_info);
        int praiseCount = item.getLikeCount();
        String like = praiseCount + "";
        tvPraise.setText(like);
        //点赞状态
        boolean hasFocus = item.isLike();
//        helper.addOnClickListener(R.id.iv_praise_icon);
        helper.addOnClickListener(R.id.rl_praise_root);
        helper.getView(R.id.iv_praise_icon).setSelected(hasFocus);

        //标题
        TextView tvTitle = helper.getView(R.id.tv_title_top);
        String title = item.getTitle();
        tvTitle.setText(isNotNull(title));

        RecyclerView recyclerViewImg = helper.getView(R.id.rv_imgs_list);
        GridLayoutManager layoutManager;
        switch (type) {
            case 1:
                layoutManager = new GridLayoutManager(mContext, 2);
                break;
            case 2:
                layoutManager = new GridLayoutManager(mContext, 3);
                break;
            default:
                layoutManager = new GridLayoutManager(mContext, 1);
                break;
        }
        recyclerViewImg.setLayoutManager(layoutManager);
        List<JumpBean> list = new ArrayList<>();

        if (type == 0) {//单图
            String imgUrl = item.getImgUrl();
            JumpBean jumpBean = new JumpBean();
            jumpBean.setImgUrl(isNotNull(imgUrl));
            jumpBean.setNewsId(id);
            list.add(jumpBean);

            CellImgAdapter cellImgAdapter = new CellImgAdapter(list);
            recyclerViewImg.setAdapter(cellImgAdapter);

        } else {//双图和多图

            List<IndexHotEntity.NewsTopBlocksBean.NewsImgsBeanX> newsImgs = item.getNewsImgs();
            if (newsImgs != null && newsImgs.size() != 0) {
                if (newsImgs.size() >= 3) {
                    for (int i = 0; i < 3; i++) {
                        IndexHotEntity.NewsTopBlocksBean.NewsImgsBeanX newsImgsBeanX = newsImgs.get(i);
                        String imgUrl = newsImgsBeanX.getImgUrl();
                        JumpBean jumpBean = new JumpBean();
                        jumpBean.setImgUrl(isNotNull(imgUrl));
                        jumpBean.setNewsId(id);
                        list.add(jumpBean);
                    }
                } else {
                    for (IndexHotEntity.NewsTopBlocksBean.NewsImgsBeanX homeIndexImgBean : newsImgs) {
                        String imgUrl = homeIndexImgBean.getImgUrl();
                        JumpBean jumpBean = new JumpBean();
                        jumpBean.setImgUrl(isNotNull(imgUrl));
                        jumpBean.setNewsId(id);

                        list.add(jumpBean);
                    }
                }


                CellImgAdapter cellImgAdapter = new CellImgAdapter(list);
                recyclerViewImg.setAdapter(cellImgAdapter);
            } else {//图片数组为空
                // TODO: 2019/10/10
                List<JumpBean> testImgList = ListImgUtil.getTestImgList(mContext,id,false);
                CellImgAdapter cellImgAdapter = new CellImgAdapter(testImgList);
                recyclerViewImg.setAdapter(cellImgAdapter);
            }
        }


    }


    /**
     * 适配视频数据
     *
     * @param type
     * @param helper
     * @param item
     */
    private void adapterItemVideo(int type, BaseViewHolder helper, IndexHotEntity.NewsTopBlocksBean item,int position) {
        String id = item.getNewsId();
        int mediaType = item.getMediaType();
        if (TextUtils.isEmpty(id)) return;

        //设置评论
        CommentHotUtil.setHotComment(mContext,helper.getView(R.id.iv_comment_icon),helper.getView(R.id.tv_comment_count),item.getCommentCount());

        //点赞按钮
        NavigateToDetailUtil.showShareToast(helper.getView(R.id.rl_share_root_view),mContext,
                new ShareSdkParamBean(item.getTitle(),item.getWebShareUrl(),item.getPreview(),item.getImgUrl(),item.getWebShareUrl()));

        //置顶标签
        helper.getView(R.id.tv_top_tag).setVisibility(View.VISIBLE);

        //点击事件到详情
        View rootView = helper.getView(R.id.ll_root_view_av);
        rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavigateToDetailUtil.navigateToDetail(mContext,id,mediaType == 1);
            }
        });

        //头像
        View headRootView = helper.getView(R.id.rl_head_info_root_view);
        if (type == 0) {//有头像
            headRootView.setVisibility(View.VISIBLE);
        } else {        //没有头像
            headRootView.setVisibility(View.GONE);
        }

        //用户信息
        STCircleImageView ivHead = helper.getView(R.id.iv_user_head_info);
        TextView tvName = helper.getView(R.id.tv_name_info);
        TextView tvDesc = helper.getView(R.id.tv_desc_info);
        TextView tvPraise = helper.getView(R.id.tv_praise_info);
        IndexHotEntity.NewsTopBlocksBean.UserBeanX userBean = item.getUser();
        if (userBean != null) {
            String nickname = userBean.getNickname();
            String personalDesc = userBean.getPersonalDesc();
            String headImgUrl = userBean.getHeadImgUrl();
            int followerCount = userBean.getFollowerCount();
            GlideLoadImgUtil.loadImgHead(mContext,headImgUrl,ivHead);
            tvName.setText(nickname);
            tvPraise.setText(followerCount + "");
            tvDesc.setText(personalDesc);
            //点击头像
            helper.getView(R.id.iv_user_head_info).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    NavigateToDetailUtil.navigateToPerson(mContext,item.getUser().getId());
                }
            });
        } else {
            GlideLoadImgUtil.loadImgHead(mContext,"",ivHead);
            tvName.setText("");
            tvPraise.setText("");
            tvDesc.setText("");
        }

        //标题
        TextView tvTitle = helper.getView(R.id.tv_title_top);
        String title = item.getTitle();
        tvTitle.setText(isNotNull(title));


        //播放器
        String imgUrl = item.getImgUrl();
        JzvdStd player = helper.getView(R.id.js_player);
        player.setUp(
                item.getPlayUrl(),
                "", Jzvd.SCREEN_NORMAL);
//        Glide.with(mContext).load(isNotNull(imgUrl)).into(player.thumbImageView);
        GlideLoadImgUtil.loadPlayerFaceImg(mContext,imgUrl,player.thumbImageView);

        //点赞状态和数量
        //点赞的状态和数量
        int praiseCount = item.getLikeCount();
        String like = praiseCount + "";
        tvPraise.setText(like);
        //点赞状态
//        helper.addOnClickListener(R.id.iv_praise_icon);
        helper.addOnClickListener(R.id.rl_praise_root);
        boolean hasFocus = item.isLike();
        helper.getView(R.id.iv_praise_icon).setSelected(hasFocus);


    }
    

    private String isNotNull(String string) {
        return !TextUtils.isEmpty(string) ? string : "";
    }

    /**
     * 刷新条目中指定view
     * @param view
     * @param item
     */
    public void changeLike(View view, IndexHotEntity.NewsTopBlocksBean item) {
        ImageView ivLike = view.findViewById(R.id.iv_praise_icon);
        TextView tvLike = view.findViewById(R.id.tv_praise_info);
        if (ivLike != null) {
            ivLike.setSelected(item.isLike());
        }
        if (tvLike != null) {
            tvLike.setText(String.valueOf(item.getLikeCount()));
        }
    }

}
