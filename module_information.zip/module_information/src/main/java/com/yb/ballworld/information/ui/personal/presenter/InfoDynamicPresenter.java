package com.yb.ballworld.information.ui.personal.presenter;

import android.text.TextUtils;

import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.common.callback.OnUICallback;
import com.yb.ballworld.information.http.PersonalHttpApi;
import com.yb.ballworld.information.ui.personal.bean.PostEntity;
import com.yb.ballworld.information.ui.personal.constant.FailStateConstant;
import com.yb.ballworld.information.ui.personal.constant.LoadMoreType;
import com.yb.ballworld.information.ui.personal.view.InformationPersonalPublishFragment;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc:
 * Author: JS-Kylo
 * Created On: 2019/10/10 20:14
 */
public class InfoDynamicPresenter implements InfoPersonalPublishContract.InfoPublishPresenter {
    private PersonalHttpApi httpApi;
    private InfoPersonalPublishContract.InfoPublishView mView;
    private List<PostEntity.ListBean> mPostLastList;
    //当前页数
    private int page = 1;
    //返回的总页数
    private int totalPage;
    //资讯类型 0 请求新闻 1 请求视频
    private int mediaType;
    private boolean isRefresh;
    private boolean isLoadMore;
    private String mUserId;
    private int type;

    /**
     * 构造方法
     */
    public InfoDynamicPresenter() {
        httpApi = new PersonalHttpApi();
        mPostLastList = new ArrayList<>();
    }
    public InfoDynamicPresenter(String userId) {
        this();
        this.mUserId = userId;
    }

    @Override
    public void loadData(int page) {
        //只有正常加载才有loading 加载更多和刷新是没有的
        if (!isRefresh && !isLoadMore) {
            mView.requestLoading();
        }
        //每页的数据条数
        int pageSize = 15;
        int mediaType=-1;
        if(type== InformationPersonalPublishFragment.KEY_TYPE_VIDEO){
            mediaType=1;
        }

        httpApi.getDynamic(mUserId,page, pageSize, new OnUICallback<PostEntity>() {
            @Override
            public void onUISuccess(PostEntity data) {
                LogUtils.INSTANCE.d(data.getPageNum());
                if (data!=null){
                    totalPage = data.getTotalPage();
                    List<PostEntity.ListBean> list = data.getList();
                    if (list != null && list.size() != 0){
                        if (isRefresh)
                            mPostLastList.clear();
                        mPostLastList.addAll(list);
                        //还原刷新的状态
                        if (isRefresh) {
                            isRefresh = false;
                            mView.resultRefreshSuccess();
                        }
                        //还原加载更多的状态
                        if (isLoadMore) {
                            isLoadMore = false;
                            mView.resultLoadMoreSuccess(LoadMoreType.TYPE_SUCCESS);
                        }
                        mView.resultSuccess(mPostLastList,page);
                        //执行成功完毕 清理中转数组 否则造成列表叠加
                        mPostLastList.clear();
                    }else {              //news为空
                        judgeStatusEmpty();
                    }
                }else {              //news为空
                    judgeStatusEmpty();
                }
            }

            @Override
            public void onUIFailed(int errCode, String errMsg) {
                if (isRefresh) {         //刷新失败
                    isRefresh = false;
                    mView.resultRefreshFail("刷新失败");
                } else if (isLoadMore) { //加载更多失败
                    isLoadMore = false;
                    mView.resultLoadMoreFail("加载更多失败");
                } else {                 //正常加载数据失败
                    mView.resultFail(FailStateConstant.TYPE_ERROR,errMsg);
                }
            }
        });
     }

    @Override
    public void refreshData() {
        isRefresh = true;
        page = 1;
        loadData(page);
    }

    @Override
    public void loadMoreData() {
        isLoadMore = true;
        page++;
        if (page <= totalPage) { //可以加载更多数据
            loadData(page);
        } else {                 //没有更多数据
            mView.resultLoadMoreSuccess(LoadMoreType.TYPE_ALL_DATA);
        }
    }

    /**
     * 判断刷新 加载更多 和 正常加载
     */
    private void judgeStatusEmpty() {
        if (isRefresh) {
            isRefresh = false;
            mView.resultRefreshFail("刷新数据为空");
        } else if (isLoadMore) {
            isLoadMore = false;
            mView.resultRefreshFail("加载更多数据为空");
        } else {
            dataEmpty();
        }
    }

    /**
     * 数据为空
     */
    private void dataEmpty() {
        mView.resultFail(FailStateConstant.TYPE_EMPTY,"");
    }

    @Override
    public void attachView(InfoPersonalPublishContract.InfoPublishView view) {
        this.mView = view;
    }

    @Override
    public void detachView() {
        this.mView = null;
    }

    private String isNotNull(String s) {
        return !TextUtils.isEmpty(s) ? s : "";
    }

    public void setType(int type) {
        this.type = type;
    }
}
