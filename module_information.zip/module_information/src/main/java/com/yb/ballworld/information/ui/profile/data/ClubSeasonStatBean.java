package com.yb.ballworld.information.ui.profile.data;

/**
 * @author Gethin
 * @time 2019/11/20 13:07
 */

public class ClubSeasonStatBean {


}
