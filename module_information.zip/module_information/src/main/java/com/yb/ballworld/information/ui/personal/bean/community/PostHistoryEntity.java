package com.yb.ballworld.information.ui.personal.bean.community;

import java.util.List;

/**
 * Desc: 足迹
 * Author: JS-Kylo
 * Created On: 2019/11/12 11:45
 */
public class PostHistoryEntity {

    /**
     * list : [{"content":"","createdDate":"","headImgUrl":"","id":0,"isAttention":true,"isLike":true,"likeCount":0,"nickname":"","pageViews":0,"postId":0,"postImgLists":[],"sonNum":0,"title":"","userId":"","videoUrl":""}]
     * pageNum : 0
     * pageSize : 0
     * totalCount : 0
     * totalPage : 0
     */

    private int pageNum;
    private int pageSize;
    private int totalCount;
    private int totalPage;
    private List<PostHistoryBean> list;

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<PostHistoryBean> getList() {
        return list;
    }

    public void setList(List<PostHistoryBean> list) {
        this.list = list;
    }
}
