package com.yb.ballworld.information.ui.home.utils;

import android.content.Context;
import android.widget.ImageView;
import android.widget.TextView;

import com.yb.ballworld.information.R;

/**
 * Desc 评论超过1000条显示热度的工具类
 * Date 2019/10/13
 * author mengk
 */
public class CommentHotUtil {
    /**
     * 设置评论是否是最热
     * @param context context
     * @param imageView icon
     * @param textView 评论文本
     * @param commentCount 评论数量
     */
    public static void setHotComment(Context context, ImageView imageView, TextView textView,int commentCount) {
        if (commentCount >= 99) {//超过1000 显示最热
            imageView.setBackgroundResource(R.drawable.icon_comment_info_hot);
            textView.setTextColor(context.getResources().getColor(R.color.color_ef4d4d));
        } else {//不超过1000 普通显示
            imageView.setBackgroundResource(R.drawable.icon_comment_info);
            textView.setTextColor(context.getResources().getColor(R.color.color_999999));
        }
        String com = commentCount + "";
        textView.setText(com);
    }
}
