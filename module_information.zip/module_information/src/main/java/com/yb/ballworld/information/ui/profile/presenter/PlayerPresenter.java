package com.yb.ballworld.information.ui.profile.presenter;

import android.text.TextUtils;

import androidx.lifecycle.LifecycleOwner;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.livedata.LiveDataWrap;
import com.yb.ballworld.information.ui.profile.data.PlayerStat;
import com.yb.ballworld.information.ui.profile.http.ProfileHttp;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;


/**
 * @author Gethin
 * @time 2019/11/9 10:50
 */

public class PlayerPresenter extends BasePresenter<LifecycleOwner, VoidModel> {

    private ProfileHttp http = new ProfileHttp();

    public LiveDataWrap<List<PlayerStat>> playerSeasonStat = new LiveDataWrap<>();

    public void loadPlayerData(String teamId, String seasonId) {
        add(http.getClubSeasonStat(teamId, seasonId, new LifecycleCallback<String>(mView) {
            @Override
            public void onSuccess(String data) {
                if (!TextUtils.isEmpty(data)) {
                    try {
                        JSONObject jsonObject =  new JSONObject(data);
                        String coachName = jsonObject.optString("coachName");
                        String coachPic = jsonObject.optString("coachPic");
                        List<PlayerStat> playerStats = new ArrayList<>();
                        Gson gson = new Gson();
                        Type type = new TypeToken<ArrayList<PlayerStat>>() {}.getType();

                        // 教练
                        PlayerStat playerCoach = new PlayerStat(PlayerStat.COACH);
                        playerStats.add(playerCoach);
                        playerCoach.setName(coachName);
                        playerCoach.setPicUrl(coachPic);

                        for (int i = 1; i < 6; i++) {
                            String s = jsonObject.optString("" + i);
                            if (TextUtils.isEmpty(s)) {
                                continue;
                            }
                            List<PlayerStat> list1 = gson.fromJson(s, type);
                            if(list1 == null || list1.isEmpty()){
                                continue;
                            }
                            // 分区
                            PlayerStat playerStat = new PlayerStat(PlayerStat.SECTION);
                            playerStat.setPosSection(i);
                            playerStats.add(playerStat);

                            // 球员
                            for (int j = 0; j < list1.size(); j++) {
                                PlayerStat playerStat1 = list1.get(j);
                                playerStat1.setItemType(PlayerStat.CONTENT);
                                if (j == 0) {
                                    playerStat1.setContentPos(PlayerStat.CONTENT_START);
                                } else if (j == list1.size() - 1) {
                                    playerStat1.setContentPos(PlayerStat.CONTENT_END);
                                }
                            }
                            playerStats.addAll(list1);
                        }
                        playerSeasonStat.setData(playerStats);
                    } catch (JSONException e) {
                        playerSeasonStat.setError(-1, "数据解析异常");
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                playerSeasonStat.setError(errCode, errMsg);
            }
        }));
    }

}
