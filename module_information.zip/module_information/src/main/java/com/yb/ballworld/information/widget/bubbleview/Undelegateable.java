package com.yb.ballworld.information.widget.bubbleview;

interface Undelegateable {
     interface BubbleStyle {
          @SuppressWarnings("unused")
          void setPadding(int left, int top, int right, int bottom);
     }
}
