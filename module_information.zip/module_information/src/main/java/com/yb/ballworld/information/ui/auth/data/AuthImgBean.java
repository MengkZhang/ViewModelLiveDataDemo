package com.yb.ballworld.information.ui.auth.data;

import android.net.Uri;

/**
 * @author Gethin
 * @time 2019/11/8 13:23
 */

public class AuthImgBean {

    private String path;
    private Uri uri;

    public AuthImgBean(String path, Uri uri) {
        this.path = path;
        this.uri = uri;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public Uri getUri() {
        return uri;
    }

    public void setUri(Uri uri) {
        this.uri = uri;
    }
}
