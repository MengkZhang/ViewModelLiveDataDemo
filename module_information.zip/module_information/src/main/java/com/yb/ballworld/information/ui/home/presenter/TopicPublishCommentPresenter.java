package com.yb.ballworld.information.ui.home.presenter;

import android.content.Intent;
import android.util.Log;

import com.jeremyliao.liveeventbus.LiveEventBus;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.information.ui.community.CommunityHttpApi;
import com.yb.ballworld.information.ui.community.bean.Topic;
import com.yb.ballworld.information.ui.community.data.CommunityNew;
import com.yb.ballworld.information.ui.community.data.CommunityPost;
import com.yb.ballworld.information.ui.home.bean.PublishCommentReqBean;
import com.yb.ballworld.information.ui.home.bean.PublishCommentResBean;
import com.yb.ballworld.information.ui.home.constant.FailStateConstant;

import java.util.ArrayList;
import java.util.List;

/**
 * 社区评论
 */
public class TopicPublishCommentPresenter extends PublishCommentPresenter {
    private CommunityHttpApi api = new CommunityHttpApi();

    /**
     * 图片评论发布
     *
     * @param bean
     * @param images
     */
    @Override
    public void publishComment(PublishCommentReqBean bean, List<String> images) {
        if (bean == null) return;
        mView.requestLoading();

        String id = bean.getReplyId();
        int replyId = 0;
        try {
            replyId = Integer.valueOf(id);
        } catch (Exception e) {
            e.printStackTrace();
        }

        CommunityNew communityNew = new CommunityNew();
        communityNew.content = bean.getContent();
        if (images != null && !images.isEmpty()) {
            communityNew.postImgLists = images;
        }
        communityNew.replyId = replyId;
        communityNew.userId=bean.getNewsId();

        post(communityNew);
    }

    /**
     * 视频评论发布
     *
     * @param bean
     * @param videoCoverUrl
     * @param videoUrl
     */
    @Override
    public void publishComment(PublishCommentReqBean bean, String videoCoverUrl, String videoUrl) {
        if (bean == null) return;
        mView.requestLoading();

        String id = bean.getReplyId();
        int replyId = 0;
        try {
            replyId = Integer.valueOf(id);
        } catch (Exception e) {
            e.printStackTrace();
        }

        CommunityNew communityNew = new CommunityNew();
        communityNew.content = bean.getContent();
        communityNew.imgUrl = videoCoverUrl;
        communityNew.replyId = replyId;
        communityNew.videoUrl = videoUrl;
        communityNew.userId=bean.getNewsId();
        post(communityNew);
    }


    private void post(CommunityNew community) {
        LogUtils.INSTANCE.i("arway","发送请求id="+community.userId+"/replyId="+community.replyId);
        api.communityPostComment(community, new LifecycleCallback<Topic>(mView.getActivity()) {
            @Override
            public void onSuccess(Topic data) {
                LogUtils.INSTANCE.i("arway","data="+data);
                if (data != null) {
                    mView.resultUploadFileSuccess(data);
                    LiveEventBus.get().with(LiveEventBusKey.KEY_TOPIC_PUBLIC_COMMENT, Topic.class).post(data);
                } else {
                    mView.resultUploadFileFail(FailStateConstant.TYPE_EMPTY);
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                mView.resultUploadFileFail(FailStateConstant.TYPE_ERROR);
                LogUtils.INSTANCE.i("arway","errMsg="+(errMsg==null?"xxx":errMsg));
            }
        });
    }
}
