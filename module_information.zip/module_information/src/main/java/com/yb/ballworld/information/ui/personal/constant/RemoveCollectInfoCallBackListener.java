package com.yb.ballworld.information.ui.personal.constant;

import rxhttp.wrapper.entity.Response;

/**
 * Desc: 取消收藏回调
 * Author: JS-Kylo
 * Created On: 2019/10/18 13:31
 */
public interface RemoveCollectInfoCallBackListener {
    void onRemoveCollectSuccess(Response response);
    void onRemoveCollectFail(String msg);
}
