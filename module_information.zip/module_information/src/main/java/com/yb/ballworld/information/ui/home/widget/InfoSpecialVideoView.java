package com.yb.ballworld.information.ui.home.widget;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseViewHolder;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.bean.IndexHotEntity;
import com.yb.ballworld.information.ui.home.utils.CommentHotUtil;
import com.yb.ballworld.information.ui.home.utils.GlideLoadImgUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.home.utils.UidUtil;

import cn.jzvd.Jzvd;
import cn.jzvd.JzvdStd;

/**
 * Desc 自定义首页条目-非/特约视频
 * Date 2019/10/22
 * author mengk
 */
public class InfoSpecialVideoView extends RelativeLayout {
    private Context mContext;
    private ImageView iv_comment_icon;
    private TextView tv_comment_count;
    private TextView tv_name_info;
    private TextView tv_desc_info;
    private TextView tv_title_top;
    private TextView tv_praise_info;
    private TextView tv_top_tag;
    private View rl_share_root_view;
    private View ll_root_view_av;
    private View rl_head_info_root_view;
    private ImageView iv_user_head_info;
    private ImageView iv_praise_icon;
    private JzvdStd js_player;

    public InfoSpecialVideoView(Context context) {
        this(context, null);
    }

    public InfoSpecialVideoView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public InfoSpecialVideoView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.mContext = context;
        initView();
    }

    /**
     * 设置具体数据
     * @param type 类型
     * @param item 数据
     */
    public void setDetailData(int type, BaseViewHolder helper, IndexHotEntity.NewsBean.ListBean item) {
        if (item == null) return;

        String id = item.getId();
        if (TextUtils.isEmpty(id)) return;

        //设置基本信息
        setBaseInfo(item, id);

        //设置用户信息
        setUserInfo(type, item);

        //播放器
        setPlayer(item);

        //点赞的状态和数量
        setPraiseInfo(helper, item);

    }

    /**
     * 设置基本信息
     * @param item
     * @param id
     */
    private void setBaseInfo(IndexHotEntity.NewsBean.ListBean item, String id) {
        //标题
        String title = item.getTitle();
        tv_title_top.setText(isNotNull(title));

        tv_top_tag.setVisibility(item.isTop() ? View.VISIBLE : View.GONE);

        //设置评论
        CommentHotUtil.setHotComment(mContext,iv_comment_icon,tv_comment_count,item.getCommentCount());

        //分享按钮
        NavigateToDetailUtil.showShareToast(rl_share_root_view,mContext,item.getTitle(),item.getWebShareUrl(),item.getPreview(),item.getImgUrl(),item.getWebShareUrl());

        ll_root_view_av.setOnClickListener(v -> NavigateToDetailUtil.navigateToDetail(mContext,id,true));
    }

    /**
     * 设置用户信息
     * @param type
     * @param item
     */
    private void setUserInfo(int type, IndexHotEntity.NewsBean.ListBean item) {

        //头像
        if (type == 0) {//有头像
            rl_head_info_root_view.setVisibility(View.VISIBLE);
        } else {        //没有头像
            rl_head_info_root_view.setVisibility(View.GONE);
        }

        //用户信息
        IndexHotEntity.NewsBean.ListBean.UserBean userBean = item.getUser();
        if (userBean != null) {
            String nickname = userBean.getNickname();
            String personalDesc = userBean.getPersonalDesc();
            String headImgUrl = userBean.getHeadImgUrl();
            int followerCount = userBean.getFollowerCount();
            GlideLoadImgUtil.loadImgHead(mContext,headImgUrl,iv_user_head_info);
            tv_name_info.setText(nickname);
            tv_praise_info.setText(followerCount + "");
            tv_desc_info.setText(personalDesc);
            //点击头像
            iv_user_head_info.setOnClickListener(v -> NavigateToDetailUtil.navigateToPerson(mContext, userBean.getId()));
        } else {
            GlideLoadImgUtil.loadImgHead(mContext,"",iv_user_head_info);
        }
    }

    /**
     * 设置点赞信息
     * @param helper
     * @param item
     */
    private void setPraiseInfo(BaseViewHolder helper, IndexHotEntity.NewsBean.ListBean item) {
        int praiseCount = item.getLikeCount();
        String like = praiseCount + "";
        tv_praise_info.setText(like);
        //点赞状态
        boolean hasFocus = item.isLike();
//        helper.addOnClickListener(R.id.iv_praise_icon);
        helper.addOnClickListener(R.id.rl_praise_root);
        iv_praise_icon.setSelected(hasFocus);
    }

    /**
     * 设置播放器
     * @param item
     */
    private void setPlayer(IndexHotEntity.NewsBean.ListBean item) {
        String imgUrl = item.getImgUrl();
        js_player.setUp(item.getPlayUrl(), "", Jzvd.SCREEN_NORMAL);
        GlideLoadImgUtil.loadPlayerFaceImg(mContext,imgUrl,js_player.thumbImageView);
    }

    /**
     * 初始化views
     */
    private void initView() {
        this.removeAllViews();
        View view = LayoutInflater.from(getContext()).inflate(R.layout.item_info_type_video_with_head_or_not,this, false);
        this.addView(view);
        iv_comment_icon = view.findViewById(R.id.iv_comment_icon);
        tv_comment_count = view.findViewById(R.id.tv_comment_count);
        rl_share_root_view = view.findViewById(R.id.rl_share_root_view);
        iv_user_head_info = view.findViewById(R.id.iv_user_head_info);
        ll_root_view_av = view.findViewById(R.id.ll_root_view_av);
        rl_head_info_root_view = view.findViewById(R.id.rl_head_info_root_view);
        tv_name_info = view.findViewById(R.id.tv_name_info);
        tv_desc_info = view.findViewById(R.id.tv_desc_info);
        tv_praise_info = view.findViewById(R.id.tv_praise_info);
        tv_top_tag = view.findViewById(R.id.tv_top_tag);
        tv_title_top = view.findViewById(R.id.tv_title_top);
        js_player = view.findViewById(R.id.js_player);
        iv_praise_icon = view.findViewById(R.id.iv_praise_icon);
    }

    private String isNotNull(String string) {
        return !TextUtils.isEmpty(string) ? string : "";
    }
}
