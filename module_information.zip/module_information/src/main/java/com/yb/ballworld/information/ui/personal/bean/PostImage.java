package com.yb.ballworld.information.ui.personal.bean;

/**
 * Desc:
 * Author: JS-Kylo
 * Created On: 2019/11/3 0:18
 */
public class PostImage {
    String imgUrl;
    String newsId;


    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getNewsId() {
        return newsId;
    }

    public void setNewsId(String newsId) {
        this.newsId = newsId;
    }
}
