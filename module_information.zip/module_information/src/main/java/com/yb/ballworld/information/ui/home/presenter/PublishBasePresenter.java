package com.yb.ballworld.information.ui.home.presenter;

import androidx.lifecycle.LifecycleOwner;

import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.information.ui.home.service.InfoHttpApi;

/**
 * Desc
 * Date 2019/11/5
 * author mengk
 */
public class PublishBasePresenter extends BasePresenter<LifecycleOwner, VoidModel> {
    private InfoHttpApi httpApi = new InfoHttpApi();




}
