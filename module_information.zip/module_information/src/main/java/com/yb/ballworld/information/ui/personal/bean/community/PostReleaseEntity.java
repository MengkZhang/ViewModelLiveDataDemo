package com.yb.ballworld.information.ui.personal.bean.community;

import java.util.List;

/**
 * Desc:
 * Author: JS-Kylo
 * Created On: 2019/11/11 20:37
 */
public class PostReleaseEntity {

    /**
     * list : [{"content":"","createdDate":"","headImgUrl":"","id":0,"imgUrl":"","isAttention":true,"isLike":true,"lastModifiedDate":"","latestPost":{},"likeCount":0,"mainPostId":0,"nickname":"","pageViews":0,"parent":{},"postImgLists":[],"postType":0,"replyId":0,"sex":0,"sonNum":0,"userId":0,"videoUrl":""}]
     * pageNum : 0
     * pageSize : 0
     * totalCount : 0
     * totalPage : 0
     */

    private int pageNum;
    private int pageSize;
    private int totalCount;
    private int totalPage;
    private List<PostReleaseBean> list;

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<PostReleaseBean> getList() {
        return list;
    }

    public void setList(List<PostReleaseBean> list) {
        this.list = list;
    }
}
