package com.yb.ballworld.information.widget;

/**
* Desc: 表示下拉列表的显示方位
* @author ink
* created at 2019/10/7 23:01
*/
enum PopUpTextAlignment {
    /**
     * 居首
     */
    START(0),
    /**
     * 居尾
     */
    END(1),
    /**
     * 居中
     */
    CENTER(2);

    private final int id;

    PopUpTextAlignment(int id) {
        this.id = id;
    }

    static PopUpTextAlignment fromId(int id) {
        for (PopUpTextAlignment value : values()) {
            if (value.id == id) return value;
        }
        return CENTER;
    }
}