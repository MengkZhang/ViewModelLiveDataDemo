package com.yb.ballworld.information.ui.home.bean;

import android.net.Uri;

/**
 * Desc
 * Date 2019/10/20
 * author mengk
 */
public class InfoPublishVideoBean extends InfoPublishImgBean{

    public InfoPublishVideoBean(String path, Uri uri) {
        super(path, uri);
    }
}
