package com.yb.ballworld.information.ui.detail;

import androidx.annotation.Nullable;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.yb.ballworld.information.data.AuthorBean;

import java.util.List;


public class InforRecommAdapter extends BaseQuickAdapter<AuthorBean, BaseViewHolder> {

    public InforRecommAdapter(int layoutResId, @Nullable List<AuthorBean> data) {
        super(layoutResId, data);
    }

    public InforRecommAdapter(@Nullable List<AuthorBean> data) {
        super(data);
    }

    public InforRecommAdapter(int layoutResId) {
        super(layoutResId);
    }


    @Override
    protected void convert(BaseViewHolder helper, AuthorBean item, int pos) {

    }
}
