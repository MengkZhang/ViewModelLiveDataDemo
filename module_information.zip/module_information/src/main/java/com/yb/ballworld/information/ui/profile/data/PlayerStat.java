package com.yb.ballworld.information.ui.profile.data;

import com.chad.library.adapter.base.entity.MultiItemEntity;

/**
 * @author Gethin
 * @time 2019/11/21 19:39
 */

public class PlayerStat implements MultiItemEntity {

    public static final int COACH = 1;
    public static final int SECTION = 2;
    public static final int CONTENT = 3;

    public static final int CONTENT_START = 1;
    public static final int CONTENT_END = 2;

    private int contentPos;
    private int itemType = CONTENT;
    private int posSection;// 球员位置，前锋，中场，后卫......

    public int getPosSection() {
        return posSection;
    }

    public void setPosSection(int posSection) {
        this.posSection = posSection;
    }

    public PlayerStat(int itemType) {
        this.itemType = itemType;
    }

    public int getContentPos() {
        return contentPos;
    }

    public void setContentPos(int contentPos) {
        this.contentPos = contentPos;
    }

    @Override
    public int getItemType() {
        return itemType;
    }

    public void setItemType(int itemType) {
        this.itemType = itemType;
    }

    private int id;
    private String name;
    private String picUrl;
    private String goal;
    private String assist;
    private String playerIn;
    private String position;
    private String shirtNumber;



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPicUrl() {
        return picUrl;
    }

    public void setPicUrl(String picUrl) {
        this.picUrl = picUrl;
    }

    public String getGoal() {
        return goal;
    }

    public void setGoal(String goal) {
        this.goal = goal;
    }

    public String getAssist() {
        return assist;
    }

    public void setAssist(String assist) {
        this.assist = assist;
    }

    public String getPlayerIn() {
        return playerIn;
    }

    public void setPlayerIn(String playerIn) {
        this.playerIn = playerIn;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getShirtNumber() {
        return shirtNumber;
    }

    public void setShirtNumber(String shirtNumber) {
        this.shirtNumber = shirtNumber;
    }

    @Override
    public String toString() {
        return "PlayerStat{" +
                "contentPos=" + contentPos +
                ", itemType=" + itemType +
                ", posSection=" + posSection +
                ", id=" + id +
                ", name='" + name + '\'' +
                ", picUrl='" + picUrl + '\'' +
                ", goal='" + goal + '\'' +
                ", assist='" + assist + '\'' +
                ", playerIn='" + playerIn + '\'' +
                ", position='" + position + '\'' +
                ", shirtNumber='" + shirtNumber + '\'' +
                '}';
    }
}
