package com.yb.ballworld.information.ui.personal.adapter.community;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bfw.image.core.utils.RoundType;
import com.bfw.image.glide.transform.RoundedCornersTransformation;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.request.RequestOptions;
import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.util.DensityUtil;
import com.yb.ballworld.baselib.utils.TimeUtils;
import com.yb.ballworld.baselib.utils.ViewUtils;
import com.yb.ballworld.common.sharesdk.ShareSdkParamBean;
import com.yb.ballworld.common.utils.TimeUtil;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.community.view.TopicDetailActivity;
import com.yb.ballworld.information.ui.home.utils.GlideLoadImgUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.home.utils.softkey.IFSPanelConflictLayout;
import com.yb.ballworld.information.ui.personal.adapter.ImgAdapter;
import com.yb.ballworld.information.ui.personal.bean.community.PostHistoryBean;
import com.yb.ballworld.information.ui.personal.adapter.CellImgAdapter;
import com.yb.ballworld.information.ui.personal.bean.PostImage;
import com.yb.ballworld.information.ui.personal.view.InformationPersonalActivityNew;
import com.yb.ballworld.information.widget.GridSpacingItemDecoration;
import com.yb.ballworld.information.widget.TimerTextView;

import java.util.ArrayList;
import java.util.List;

import cn.jmessage.support.qiniu.android.utils.StringUtils;
import cn.jzvd.Jzvd;
import cn.jzvd.JzvdStd;

/**
 * Desc: 足迹
 * Author: JS-Kylo
 * Created On: 2019/11/12 14:21
 */
public class PostHistoryAdapter extends BaseMultiItemQuickAdapter<PostHistoryBean, BaseViewHolder> {
    private Context context;
    private boolean isRelease;
    private ShareSdkParamBean mShareSdkParamBean = null;

    public Context getContext() {
        return context;
    }

    public PostHistoryAdapter(Context context, List<PostHistoryBean> data) {
        super(data);
        this.context = context;
        addItemType(PostAdapterType.TYPE_POST_IMG, R.layout.item_post_type_img);
        addItemType(PostAdapterType.TYPE_POST_VIDEOO, R.layout.item_post_type_video);
    }

    public PostHistoryAdapter(boolean release, Context context, List<PostHistoryBean> data) {
        this(context, data);
        this.isRelease = release;
    }


    @Override
    protected void convert(BaseViewHolder helper, PostHistoryBean item, int pos) {
        int itemViewType = helper.getItemViewType();
        switch (itemViewType) {
            case PostAdapterType.TYPE_POST_IMG:
                adapterItemTypeImg(helper, item, pos);
                break;
            case PostAdapterType.TYPE_POST_VIDEOO: // item类型 单图 普通没有头像类型
                adapterItemTypeVideo(helper, item, pos);
                break;

        }
    }

    /**
     * @param helper BaseViewHolder
     * @param item   HomeInfoListBean
     */
    private void adapterItemTypeImg(BaseViewHolder helper, PostHistoryBean item, int position) {
        helper.itemView.setPadding(0,0,0, DensityUtil.dp2px(12));

        //首页热门列表这里是Id 不是newsId 不知后台在搞啥
        int id = item.getId();
        if (id < 0) return;

        //用户信息
        ImageView imageViewHead = helper.getView(R.id.iv_user_head_info);
        String headImgUrl = item.getHeadImgUrl();
        helper.setText(R.id.tv_name_info, item.getNickname());
        loadImg(mContext, headImgUrl, imageViewHead);
        //点击头像再次进入个人页
        helper.getView(R.id.iv_user_head_info).setOnClickListener(v -> InformationPersonalActivityNew.startActivity(mContext,String.valueOf(item.getPostUserId()),InformationPersonalActivityNew.TYPE_COMMUNITY));
        helper.getView(R.id.tv_name_info).setOnClickListener(v -> InformationPersonalActivityNew.startActivity(mContext,String.valueOf(item.getPostUserId()),InformationPersonalActivityNew.TYPE_COMMUNITY));
        helper.getView(R.id.tv_desc_info).setOnClickListener(v -> InformationPersonalActivityNew.startActivity(mContext,String.valueOf(item.getPostUserId()),InformationPersonalActivityNew.TYPE_COMMUNITY));

        ((TextView) helper.getView(R.id.tv_desc_info)).setText(item.getPostDate());

        //标题
        TextView tvTitle = helper.getView(R.id.tv_title_top);
        String title = item.getContent();
        tvTitle.setText(isNotNull(title));
        if(TextUtils.isEmpty(title)){
            tvTitle.setVisibility(View.GONE);
            helper.getView(R.id.v_divde).setVisibility(View.VISIBLE);
        }else{
            tvTitle.setVisibility(View.VISIBLE);
            helper.getView(R.id.v_divde).setVisibility(View.GONE);
        }
        helper.getView(R.id.tv_title_top).setOnClickListener(v -> TopicDetailActivity.start(mContext,String.valueOf(item.getPostId())));
        helper.getView(R.id.rl_head_info_root_view).setOnClickListener(v -> TopicDetailActivity.start(mContext,String.valueOf(item.getPostId())));


        List<String> imgList = item.getPostImgLists();
        List<PostImage> list = new ArrayList<>();
        if (null != imgList) {
            int type = imgList.size();
            if (type == 0) {
                helper.setGone(R.id.rv_img_list, false);
                return;
            }

            helper.setVisible(R.id.rv_img_list, true);
            //图片列表
            RecyclerView recyclerViewImg = helper.getView(R.id.rv_img_list);
            for (String url : imgList) {
                PostImage postImage = new PostImage();
                postImage.setImgUrl(url);
                postImage.setNewsId(item.getId() + "");
                list.add(postImage);
            }
            GridLayoutManager manager = new GridLayoutManager(mContext, type < 3 ? 2 : 3);
            recyclerViewImg.setLayoutManager(manager);

            ImgAdapter cellImgAdapter = new ImgAdapter(list);
            recyclerViewImg.setAdapter(cellImgAdapter);
            cellImgAdapter.setOnItemClickListener(new OnItemClickListener() {
                @Override
                public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                    if (TextUtils.isEmpty(item.getWebShareUrl()))
                        NavigateToDetailUtil.navigateToGalleryActivityWithoutShare(mContext, imgList, position);
                    else
                        NavigateToDetailUtil.navigateToGalleryActivity(mContext, imgList, position,
                                item.getContent().substring(0, 6), item.getWebShareUrl(), item.getTitle(), item.getWebShareUrl());
                }
            });
        } else
            helper.setGone(R.id.rv_img_list, false);

        if (isRelease) {
            helper.setVisible(R.id.rly_operation, true);
            helper.setText(R.id.tv_comment_count, item.getSonNum() + "");
            helper.setText(R.id.tv_like_amount, item.getLikeCount() + "");
            helper.addOnClickListener(R.id.rl_praise_root);
            ImageView iv_praise_icon = helper.getView(R.id.iv_praise_icon);
            iv_praise_icon.setSelected(item.isIsLike());
        }
    }

    /**
     * @param helper BaseViewHolder
     * @param item   HomeInfoListBean
     */
    private void adapterItemTypeVideo(BaseViewHolder helper, PostHistoryBean item, int position) {
        helper.itemView.setPadding(0,0,0, DensityUtil.dp2px(12));
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams)helper.itemView.getLayoutParams();
        layoutParams.bottomMargin = DensityUtil.dp2px(1);
        helper.itemView.setLayoutParams(layoutParams);
        //首页热门列表这里是Id 不是newsId 不知后台在搞啥
        int id = item.getId();
        if (id < 0) return;

        //用户信息
        ImageView imageViewHead = helper.getView(R.id.iv_user_head_info);
        String headImgUrl = item.getHeadImgUrl();
        helper.setText(R.id.tv_name_info, item.getNickname());
        loadImg(mContext, headImgUrl, imageViewHead);
        //点击头像再次进入个人页
        helper.getView(R.id.iv_user_head_info).setOnClickListener(v -> InformationPersonalActivityNew.startActivity(mContext,String.valueOf(item.getPostUserId()),InformationPersonalActivityNew.TYPE_COMMUNITY));
        helper.getView(R.id.tv_name_info).setOnClickListener(v -> InformationPersonalActivityNew.startActivity(mContext,String.valueOf(item.getPostUserId()),InformationPersonalActivityNew.TYPE_COMMUNITY));
        helper.getView(R.id.tv_desc_info).setOnClickListener(v -> InformationPersonalActivityNew.startActivity(mContext,String.valueOf(item.getPostUserId()),InformationPersonalActivityNew.TYPE_COMMUNITY));


        ((TextView) helper.getView(R.id.tv_desc_info)).setText(item.getPostDate());

        //标题
        TextView tvTitle = helper.getView(R.id.tv_title_top);
        String title = item.getContent();
        tvTitle.setText(isNotNull(title));
        if(TextUtils.isEmpty(title)){
            tvTitle.setVisibility(View.GONE);
            helper.getView(R.id.v_divde).setVisibility(View.VISIBLE);
        }else{
            tvTitle.setVisibility(View.VISIBLE);
            helper.getView(R.id.v_divde).setVisibility(View.GONE);
        }
        helper.getView(R.id.tv_title_top).setOnClickListener(v -> TopicDetailActivity.start(mContext,String.valueOf(item.getPostId())));
        helper.getView(R.id.rl_head_info_root_view).setOnClickListener(v -> TopicDetailActivity.start(mContext,String.valueOf(item.getPostId())));

        //播放器
        if (!StringUtils.isNullOrEmpty(item.getVideoUrl())) {
            JzvdStd player = helper.getView(R.id.js_player);
            player.setUp(item.getVideoUrl(), "", Jzvd.SCREEN_NORMAL);

            String imgUrl = item.getImgUrl();
            if (!TextUtils.isEmpty(imgUrl)) {//取封面
                GlideLoadImgUtil.loadPlayerFaceImg(context,imgUrl,player.thumbImageView);
            } else {//取第一帧
                Glide.with(context).setDefaultRequestOptions(new RequestOptions()
                        .frame(1).transform(new CenterCrop(), new RoundedCornersTransformation(ViewUtils.dp2px(4), RoundType.ALL))).load(item.getVideoUrl())
                        .into(player.thumbImageView);
            }

        }


        if (isRelease) {
            helper.setVisible(R.id.rly_operation, true);
            helper.setText(R.id.tv_comment_count, item.getSonNum() + "");
            helper.setText(R.id.tv_like_amount, item.getLikeCount() + "");
            helper.addOnClickListener(R.id.rl_praise_root);
            ImageView iv_praise_icon = helper.getView(R.id.iv_praise_icon);
            iv_praise_icon.setSelected(item.isIsLike());
        }
    }

    private String isNotNull(String string) {
        return !TextUtils.isEmpty(string) ? string : "";
    }

    public void loadImg(Context context, String imgUrl, ImageView imageView) {
        //Glide.with(context).load(imgUrl).error(R.mipmap.banner_bg).placeholder(R.mipmap.banner_bg).into(imageView);
        Glide.with(context).load(imgUrl).error(R.drawable.user_default_icon2).placeholder(R.drawable.user_default_icon2).into(imageView);
    }

    public long getCreatedTime(String createdTime) {
        long createdTimes;
        if (!TextUtils.isEmpty(createdTime)) {
            createdTimes = TimeUtils.INSTANCE.toTimestamp(createdTime);
        } else {
            createdTimes = System.currentTimeMillis();
        }
        return createdTimes;
    }
}
