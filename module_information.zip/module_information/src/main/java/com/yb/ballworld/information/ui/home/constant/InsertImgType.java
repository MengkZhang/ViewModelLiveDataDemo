package com.yb.ballworld.information.ui.home.constant;

import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Desc
 * Date 2019/11/6
 * author mengk
 */
@IntDef({
        InsertImgType.TYPE_EMITTER_ONNEXT,
        InsertImgType.TYPE_ONNEXT,
        InsertImgType.TYPE_ONCOMPLETE,
        InsertImgType.TYPE_ONSUBSCRIBE,
        InsertImgType.TYPE_ONERROR
})

@Retention(RetentionPolicy.SOURCE)

public @interface InsertImgType {
    //发送事件
    int TYPE_EMITTER_ONNEXT = 1;
    //接受事件
    int TYPE_ONNEXT = 2;
    //接收完成
    int TYPE_ONCOMPLETE = 3;
    //onSubscribe
    int TYPE_ONSUBSCRIBE = 4;
    //接受异常
    int TYPE_ONERROR = 5;
}
