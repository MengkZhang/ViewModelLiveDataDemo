package com.yb.ballworld.information.ui.detail;

import android.text.TextUtils;

import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.common.base.mvp.BaseModel;
import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.information.http.InforMationHttpApi;

import java.util.List;

import io.reactivex.disposables.Disposable;

/**
 * Desc:
 *
 * @author ink
 * created at 2019/11/11 21:52
 */
public abstract class BaseCommentPresenter<V extends BaseCommentActivity, M extends BaseModel> extends BasePresenter<V, M> {
    private InforMationHttpApi inforMationHttpApi = new InforMationHttpApi();
    private int pageNum = 1;
    private int upPageNum = 0;
    private int totalPage = 1;
    private int totalcount;
    private final int pageSize = 15;

    private String newsId = null;//消息或贴子ID
    private int commentId = 0;//主评论ID
    private int targetId = 0;//评论定位ID

    final int INFOR_DETAIL = 0;
    final int INFOR_COMMITS = 1;

    private boolean isHeat = true;//是否热门排序
    private boolean isFristPage = true;//是否第一页

    private int action = 0;
    private final int pullUp = 1;
    private final int pullDown = 2;

    private MultiItemEntity commentParent;

    protected InforMationHttpApi getInforMationHttpApi() {
        return inforMationHttpApi;
    }

    public MultiItemEntity getCommentParent() {
        return commentParent;
    }

    public void setCommentParent(MultiItemEntity commentParent) {
        this.commentParent = commentParent;
    }

    public int getTotalcount() {
        return totalcount;
    }

    public void setTotalcount(int totalcount) {
        this.totalcount = totalcount;
    }

    public int getCommentId() {
        return commentId;
    }

    public void setCommentId(int commentId) {
        this.commentId = commentId;
    }

    public String getTargetId() {
        return targetId > 0 ? String.valueOf(targetId) : "";
    }

    public void setTargetId(int targetId) {
        this.targetId = targetId;
    }

    public void init(String newsId) {
        this.newsId = newsId;
    }

    public String getNewsId() {
        return this.newsId;
    }

    public void setNewsId(String newsId) {
        this.newsId = newsId;
    }

    public boolean isHeatSort() {
        return isHeat;
    }

    public void setHeatSort(boolean isHeat) {
        this.isHeat = isHeat;
    }

    public boolean isFristPage() {
        return isFristPage;
    }

    public void setFristPage(boolean fristPage) {
        isFristPage = fristPage;
    }

    public boolean hasPullUpMore() {
        return pageNum <= totalPage;
    }

    public boolean hasPullDownMore() {
        return upPageNum >= 1;
    }

    public int getAction() {
        return action;
    }

    public void setAction(int action) {
        this.action = action;
    }

    protected abstract CommentLifecycleCallback getLifecycleCallback();

    protected abstract Disposable requestCommentList(String newsId, int pageNum, int pageSize, boolean isHeat, String targetId, CommentLifecycleCallback commentLifecycleCallback);

    protected abstract Disposable addCommentLike(int commitId, LifecycleCallback lifecycleCallback);

    protected abstract Disposable addArticleLike(String newsId, LifecycleCallback lifecycleCallback);

    public void firstPage(int commentSize, int totalcount, int totalPage, int pageNum) {
        setTotalcount(totalcount);
        this.totalPage = totalPage;
        this.pageNum = pageNum;
        if (!TextUtils.isEmpty(getTargetId())) {
            pageNum += 1;
            if (commentSize > 0) {
                this.upPageNum = pageNum - (commentSize / pageSize + (commentSize % pageSize) > 0 ? 1 : 0);
            } else {
                this.upPageNum = 0;
            }
        } else {
            this.pageNum += 1;
            this.upPageNum = 0;
        }
    }

    public void otherPage(int totalcount, int totalPage) {
        setTotalcount(totalcount);
        this.totalPage = totalPage;
        if (getAction() == pullUp) {
            pageNum += 1;
        } else {
            upPageNum -= 1;
        }
    }

    public void initLoad() {
        add(requestCommentList(String.valueOf(getCommentId()), 1, pageSize, isHeatSort(), getTargetId(), getLifecycleCallback()));

    }


    public void pullUp() {
        add(requestCommentList(String.valueOf(getCommentId()), pageNum, pageSize, isHeatSort(), "", getLifecycleCallback()));
    }

    public void pullDown() {
        add(requestCommentList(String.valueOf(getCommentId()), upPageNum, pageSize, isHeatSort(), "", getLifecycleCallback()));
    }


    public void addArticleLike() {
        add(addArticleLike(this.newsId, new LifecycleCallback<String>(mView) {
            @Override
            public void onSuccess(String data) {
                showLike(INFOR_DETAIL, 0, 0, true);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                showLike(INFOR_DETAIL, 0, 0, errCode == 200);
            }
        }));
    }

    public void addCommitLike(final int commitId, final int position) {
        add(addCommentLike(commitId, new LifecycleCallback<String>(mView) {
            @Override
            public void onSuccess(String data) {
                LiveEventBus.get().with(LiveEventBusKey.KEY_COMMIT_LIKE, String.class).post(commitId + "");
                showLike(INFOR_COMMITS, commitId, position, true);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                showLike(INFOR_COMMITS, commitId, position, errCode == 200);
            }
        }));
    }

    /**
     * 显示错误
     */
    private void showLike(int area, int commitId, int position, boolean isSuccess) {
        if (mView != null) {
            //  mView.showLike(area, commitId, position, isSuccess);
        }
    }

    /**
     * 显示错误
     */
    public void showError(int area) {
        if (mView != null) {
            mView.showError(area);
        }
    }

    /**
     * 显示评论列表
     *
     * @param sonCommentList
     */
    public void showCommits(List<MultiItemEntity> sonCommentList, MultiItemEntity parent, boolean firstPage) {
        if (mView != null) {
            if (sonCommentList == null || parent == null) {
                mView.showEmpty(INFOR_COMMITS);
            } else {
                mView.showCommits(sonCommentList, parent, firstPage);
            }
        }
    }


}
