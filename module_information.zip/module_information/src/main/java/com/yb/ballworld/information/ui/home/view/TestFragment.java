package com.yb.ballworld.information.ui.home.view;

import android.widget.TextView;

import com.yb.ballworld.baselib.base.fragment.BaseFragment;
import com.yb.ballworld.baselib.base.fragment.BasePageFragment;
import com.yb.ballworld.information.R;

/**
 * Desc
 * Date 2019/11/12
 * author mengk
 */
public class TestFragment extends BasePageFragment {


    @Override
    public int getLayoutResID() {
        return R.layout.item_tip_off_layout;
    }

    @Override
    public void setTextSize(int id, Float size) {

    }

    @Override
    public void setTextSize(TextView textView, Float size) {

    }
}
