package com.yb.ballworld.information.ui.detail;

import android.view.View;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.ethanhua.skeleton.Skeleton;
import com.ethanhua.skeleton.SkeletonScreen;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshFooter;
import com.scwang.smartrefresh.layout.api.RefreshHeader;
import com.yb.ballworld.baselib.base.recycler.header.PlayBallHeader;
import com.yb.ballworld.baselib.base.recycler.header.RecyclerClassicsFooter;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.common.base.mvp.BaseMvpActivity;
import com.yb.ballworld.common.widget.CommonTitleBar;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.data.AuthorBean;

import java.util.List;

import static com.yb.ballworld.common.widget.CommonTitleBar.ACTION_LEFT_BUTTON;

/**
* Desc:
* @author ink
* created at 2019/11/3 20:04
*/
public class InforCommunityRecomActivity extends BaseMvpActivity<InforCommunityRecomPresenter> implements BaseQuickAdapter.OnItemChildClickListener, BaseQuickAdapter.OnItemClickListener {

    private SmartRefreshLayout mSmartRefreshLayout;
    private RecyclerView mRecyclerView;
    private SkeletonScreen mSkeletonScreen;
    private InforRecommAdapter mInforRecommAdapter;

    @Override
    public void initPresenter() {
        mPresenter.setVM(this);
    }

    @Override
    public PlaceholderView getPlaceholderView() {
        return F(R.id.placeholderView);
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_infor_community_recomm;
    }

    /**
     * 获取刷新头部
     *
     * @return
     */
    @Override
    protected RefreshHeader getRefreshHeader() {
        return new PlayBallHeader(this).createAnim(PlayBallHeader.FOOTBALL);
    }

    /**
     * 获取刷新底部
     */
    @Override
    protected RefreshFooter getRefreshFooter() {
        return new RecyclerClassicsFooter(this);
    }

    @Override
    protected void initView() {
        mSmartRefreshLayout=F(R.id.smartRefreshLayout);
        mSmartRefreshLayout.setRefreshFooter(getRefreshFooter());
        mSmartRefreshLayout.setRefreshHeader(getRefreshHeader());
        mSmartRefreshLayout.setEnableAutoLoadMore(true);
        initRefreshView();
        enableRefresh(false);
        enableLoadMore(false);

        mRecyclerView=F(R.id.recyclerView);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
        mInforRecommAdapter = new InforRecommAdapter(R.layout.item_community_recomm, null);
        mRecyclerView.setAdapter(mInforRecommAdapter);

        mInforRecommAdapter.setOnItemChildClickListener(this);
        mInforRecommAdapter.setOnItemClickListener(this);
    }

    @Override
    protected void bindEvent() {

        ((CommonTitleBar)F(R.id.inforCommunity_recommd)).setListener((v, action, extra) -> {
            if(action==ACTION_LEFT_BUTTON){
                finish();
            }
        });
        if (getPlaceholderView() != null) {
            getPlaceholderView().setPageErrorRetryListener(v -> initData());
        }
    }

    @Override
    protected void initData() {
        View rootView = F(R.id.rootView);
        mSkeletonScreen = Skeleton.bind(rootView)
                .load(R.layout.layout_place_detail_loading)
                .duration(1000)
                .shimmer(true)
                .color(R.color.white)
                .angle(0)
                .show();
    }

    @Override
    protected void processClick(View view) {}

    @Override
    public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
        //关注
        AuthorBean bean=mInforRecommAdapter.getItem(position);
        if(bean!=null){
            if(bean.getFollowed()==0){
                //请求关注

            }else{
                //请求取消关注

            }
        }
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
        //去用户主页

    }


    /**
     * 显示推存作者列表
     * @param beanList
     */
    public void showAuthors(List<AuthorBean> beanList){
        //如果是下拉，重新刷新列表
        //如果是上拉，则加载更多

    }

    /**
     * 跳转去推荐作者主页
     * @param bean
     */
    private void gotoAuthorPage(AuthorBean bean){

    }

    /**
     *  关注结果反馈
     * @param bean
     * @param position
     * @param isSuccess
     */
    public void followPrompt(AuthorBean bean,int position,boolean isSuccess){

    }
}
