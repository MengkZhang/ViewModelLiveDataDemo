package com.yb.ballworld.information.ui.profile.view.fragments;

import android.view.View;

import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.yb.ballworld.baselib.widget.tab.XTabLayout;
import com.yb.ballworld.common.base.BaseFragment;
import com.yb.ballworld.common.base.BaseFragmentStateAdapter;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.profile.presenter.DataCupPresenter;
import com.yb.ballworld.information.ui.profile.presenter.DataLeaguePresenter;
import com.yb.ballworld.information.ui.profile.presenter.DataTotalPresenter;

import java.util.ArrayList;
import java.util.List;

/**
 * 球员资料库-数据
 * @author Gethin
 * @time 2019/11/7 19:02
 */

public class DataFragment extends BaseFragment {

    private XTabLayout tabLayout;
    private ViewPager viewPager;
    private String playerId;

    private List<String> titles = new ArrayList<>();
    private List<Fragment> fragments = new ArrayList<>();

    public static DataFragment newInstance(String playerId){
        DataFragment dataFragment=new DataFragment();
        dataFragment.playerId=playerId;
        return dataFragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_data_player;
    }

    @Override
    protected void initView() {
        tabLayout=findView(R.id.x_tab);
        viewPager=findView(R.id.viewPager);
        titles.add("总计");
        titles.add("联赛");
        titles.add("杯赛");
        fragments.add(DataSubTotalFragment.newInstance(DataTotalPresenter.class,playerId));
        fragments.add(DataSubTotalFragment.newInstance(DataLeaguePresenter.class,playerId));
        fragments.add(DataSubTotalFragment.newInstance(DataCupPresenter.class,playerId));

        BaseFragmentStateAdapter viewPagerAdapter = new BaseFragmentStateAdapter(getChildFragmentManager(), fragments, titles);
        viewPager.setAdapter(viewPagerAdapter);
        viewPager.setOffscreenPageLimit(fragments.size());
        tabLayout.setViewPager(viewPager);
        tabLayout.setCurrentTabForce(0);
    }

    @Override
    protected void bindEvent() {

    }

    @Override
    protected void initData() {

    }

    @Override
    protected void processClick(View view) {

    }
}
