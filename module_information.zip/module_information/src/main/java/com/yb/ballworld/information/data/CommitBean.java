package com.yb.ballworld.information.data;

import android.text.TextUtils;

import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.yb.ballworld.baselib.utils.TimeUtils;

import java.io.Serializable;

import static com.yb.ballworld.information.ui.detail.InforConstant.ItemType.DETAIL_COMMENT;

/**
 * Desc: 评论
 *
 * @author ink
 * created at 2019/10/9 20:51
 */
public class CommitBean implements Serializable, MultiItemEntity {
    //评论ID
    private int id;

    //评论的新闻ID
    private String newsId;

    //子评论数
    private int sonNum;

    //评论的点赞数量
    private int likeCount;

    //评论是否被点赞
    private boolean isLike;

    //评论数量
    private int commentType;

    //用户ID
    private String userId;

    //图片1
    private String imgUrl1;

    //图片2
    private String imgUrl2;

    //图片3
    private String imgUrl3;

    //回复ID
    private String replyId;

    //回复内容
    private String content;

    //视频播放地址
    private String videoUrl;

    //视频播放地址
    private String videoCoverUrl;

    //评论人的名称
    private String nickName;

    //评论人的头像
    private String headImgUrl;

    //评化的时间
    private String createdDate;

    private long createdTime;

    private int itemType = DETAIL_COMMENT;

    private CommitBean parent;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNewsId() {
        return newsId;
    }

    public void setNewsId(String newsId) {
        this.newsId = newsId;
    }

    public String getVideoCoverUrl() {
        return videoCoverUrl;
    }

    public void setVideoCoverUrl(String videoCoverUrl) {
        this.videoCoverUrl = videoCoverUrl;
    }

    public int getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(int likeCount) {
        this.likeCount = likeCount;
    }

    public int getCommentType() {
        return commentType;
    }

    public void setCommentType(int commentType) {
        this.commentType = commentType;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getImgUrl1() {
        return imgUrl1;
    }

    public void setImgUrl1(String imgUrl1) {
        this.imgUrl1 = imgUrl1;
    }

    public String getImgUrl2() {
        return imgUrl2;
    }

    public void setImgUrl2(String imgUrl2) {
        this.imgUrl2 = imgUrl2;
    }

    public String getImgUrl3() {
        return imgUrl3;
    }

    public void setImgUrl3(String imgUrl3) {
        this.imgUrl3 = imgUrl3;
    }

    public String getReplyId() {
        return replyId;
    }

    public void setReplyId(String replyId) {
        this.replyId = replyId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getHeadImgUrl() {
        return headImgUrl;
    }

    public void setHeadImgUrl(String headImgUrl) {
        this.headImgUrl = headImgUrl;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public int getSonNum() {
        return sonNum;
    }

    public void setSonNum(int sonNum) {
        this.sonNum = sonNum;
    }

    public boolean isLike() {
        return isLike;
    }

    public void setLike(boolean like) {
        isLike = like;
    }

    @Override
    public int getItemType() {
        return itemType;
    }

    public long getCreatedTime() {
        if (this.createdTime <= 0) {
            if (!TextUtils.isEmpty(getCreatedDate())) {
                this.createdTime = TimeUtils.INSTANCE.toTimestamp(getCreatedDate());
            } else {
                this.createdTime = System.currentTimeMillis();
            }
        }
        return createdTime;
    }

    public void setItemType(int itemType) {
        this.itemType = itemType;
    }

    public CommitBean getParent() {
        return parent;
    }

    public void setParent(CommitBean parent) {
        this.parent = parent;
    }
}
