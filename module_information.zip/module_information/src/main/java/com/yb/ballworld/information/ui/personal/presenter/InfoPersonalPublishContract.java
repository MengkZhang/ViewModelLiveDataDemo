package com.yb.ballworld.information.ui.personal.presenter;
import com.yb.ballworld.information.ui.personal.bean.PostEntity;

import java.util.List;

/**
 * Desc: 个人页面-发布
 * Author: JS-Kylo
 * Created On: 2019/10/10 20:10
 */
public class InfoPersonalPublishContract {
    //--------------------------------View层----------------------------
    public interface InfoPublishView {
        //请求加载中
        void requestLoading();

        //请求成功
        void resultSuccess(List<PostEntity.ListBean> data,int pageNum);

        //请求失败
        void resultFail(int type,String errMsg);

        //刷新成功
        void resultRefreshSuccess();

        //刷新失败
        void resultRefreshFail(String errorMsg);

        //加载更多成功
        void resultLoadMoreSuccess(int type);

        //加载更多失败
        void resultLoadMoreFail(String errorMsg);
    }

    //--------------------------------Presenter层----------------------------
    public interface InfoPublishPresenter {

        //请求数据方法
        void loadData(int page);

        //刷新
        void refreshData();

        //加载更多
        void loadMoreData();

        //绑定View
        void attachView(InfoPublishView view);

        //解绑View
        void detachView();
    }
}
