package com.yb.ballworld.information.ui.profile.view;

import android.content.Context;
import android.content.Intent;
import android.widget.TextView;

import com.yb.ballworld.common.base.BaseFragment;
import com.yb.ballworld.common.livedata.LiveDataObserver;
import com.yb.ballworld.common.widget.STRoundImageView;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.utils.GlideLoadImgUtil;
import com.yb.ballworld.information.ui.personal.view.InfoDynamicFragment;
import com.yb.ballworld.information.ui.profile.data.MatchLeagueInfo;
import com.yb.ballworld.information.ui.profile.presenter.ProfileMatchPresenter;
import com.yb.ballworld.information.ui.profile.view.fragments.PlayerRankFragment;
import com.yb.ballworld.information.ui.profile.view.fragments.PointsFragment;
import com.yb.ballworld.information.ui.profile.view.fragments.TeamRankFragment;

import java.util.ArrayList;
import java.util.List;

/**
 * 赛事资料库
 * @author Gethin
 * @time 2019/11/7 17:35
 */

public class ProfileMatchActivity extends ProfileBaseActivity<ProfileMatchPresenter>{

    private STRoundImageView avatar;
    private TextView logo;
    private TextView name;
    private String teamAlis;

    public static void launch(Context context, String leagueId, String seasonId) {
        Intent intent = new Intent(context, ProfileMatchActivity.class);
        intent.putExtra("leagueId", leagueId);
        context.startActivity(intent);
    }

    @Override
    protected int getHeaderLayoutId() {
        return R.layout.activity_profile_match;
    }

    @Override
    protected String[] getTitles() {
        return new String[] {"动态", "积分", "球员榜", "球队榜"};
    }

    @Override
    protected List<BaseFragment> getFragments() {
        List<BaseFragment> list = new ArrayList<>();
        list.add(InfoDynamicFragment.newInstance(teamAlis));
        list.add(PointsFragment.newInstance(mPresenter.getSeasonId(), ""));
        list.add(PlayerRankFragment.newInstance(mPresenter.getSeasonId()));
        list.add(TeamRankFragment.newInstance(mPresenter.getSeasonId()));
        return list;
    }

    @Override
    protected void initView() {
        super.initView();
        avatar = findViewById(R.id.ivMatchLogo);
        logo = findViewById(R.id.tvMatchName);
        name = findViewById(R.id.tvPlayerName);
    }

    @Override
    protected void loadData() {

    }

    @Override
    protected void bindEvent() {
        super.bindEvent();
        Intent intent = getIntent();
        if (intent != null) {
            showPageLoading();
            String leagueId = intent.getStringExtra("leagueId");
            mPresenter.setLeagueId(leagueId);
        }
        mPresenter.getDataWrap().observe(this, new LiveDataObserver<MatchLeagueInfo>() {
            @Override
            public void onSuccess(MatchLeagueInfo data) {
                hidePageLoading();
                teamAlis = data.cnAlias;
                loadDataFinish();
                GlideLoadImgUtil.loadImg(mContext, data.logoUrl, avatar);
                logo.setText(data.cnAlias);
                name.setText(data.cnName);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                showPageError(errMsg);
            }
        });
    }

    @Override
    public void initPresenter() {
        mPresenter.setVM(this);
    }
}
