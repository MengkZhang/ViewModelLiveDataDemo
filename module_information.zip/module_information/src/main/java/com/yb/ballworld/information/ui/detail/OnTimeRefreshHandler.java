package com.yb.ballworld.information.ui.detail;

import com.jeremyliao.liveeventbus.utils.AppUtils;
import com.yb.ballworld.information.widget.TimerTextView;
import com.yb.ballworld.information.utils.CommondUtil;


public class OnTimeRefreshHandler implements TimerTextView.OnTimeRefreshListener {
    @Override
    public String onTimeRefresh(long time) {
        return CommondUtil.calcCommentTime(time, AppUtils.getApplicationContext());
    }
}
