package com.yb.ballworld.information.ui.profile.http;

import android.util.Log;

import com.rxjava.rxlife.RxLife;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.common.api.BaseHttpApi;
import com.yb.ballworld.common.api.ErrorInfo;
import com.yb.ballworld.common.api.HttpApiConstant;
import com.yb.ballworld.common.api.OnError;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.information.ui.auth.data.SpecialReviewBean;
import com.yb.ballworld.information.ui.home.bean.FileDataBean;
import com.yb.ballworld.information.ui.profile.data.ClubBasicsInfoBean;
import com.yb.ballworld.information.ui.profile.data.ClubSeasonAgendaBean;
import com.yb.ballworld.information.ui.profile.data.ClubSeasonStatBean;
import com.yb.ballworld.information.ui.profile.data.ClubTeamSeasonIdBean;
import com.yb.ballworld.information.ui.profile.data.DataSubTotalBean;
import com.yb.ballworld.information.ui.profile.data.MatchLeagueInfo;
import com.yb.ballworld.information.ui.profile.data.MatchPlayerBean;
import com.yb.ballworld.information.ui.profile.data.MatchTeamBean;
import com.yb.ballworld.information.ui.profile.data.PointData;
import com.yb.ballworld.information.ui.profile.data.SeasonData;
import com.yb.ballworld.information.ui.profile.data.SeasonIdFromTeamId;
import com.yb.ballworld.information.ui.profile.data.MatchLeagueInfo;
import com.yb.ballworld.information.ui.profile.data.MatchPlayerBean;
import com.yb.ballworld.information.ui.profile.data.MatchTeamBean;
import com.yb.ballworld.information.ui.profile.data.PointData;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import rxhttp.RxHttp;

import static android.text.TextUtils.isEmpty;

/**
 * @author Gethin
 * @time 2019/11/20 12:56
 */

public class ProfileHttp extends BaseHttpApi {
    static final String PREFIX = "/jmfen-sport-scoreapi";

    private static final String SMS_SEND_CODE = "/qiutx-sms/sms/send/code";

    // 特约认证
    private static final String SPECIAL_REVIEW_GET = "/qiutx-news/special_review/get";
    private static final String SPECIAL_REVIEW_SAVE = "/qiutx-news/special_review/save";
    private static final String SPECIAL_REVIEW_UPDATE = "/qiutx-news/special_review/update";

    // 资料库
    private static final String CLUB_TEAM_SEASONID = PREFIX + "/v4/league/seasonsByTeamId";
    private static final String CLUB_BASE_INFO = PREFIX + "/v10/queryTeamSeasonInfo";
    private static final String CLUB_SEASON_STAT = PREFIX + "/v9/queryTeamSeasonStat";
    private static final String CLUB_SEASON_AGENDA = PREFIX + "/v10/queryTeamSeasonAgenda";
    // 球员信息
    public static final String URL_PLAYER_INFO = PREFIX + "/v10/player/info";
    // 球员数据
    public static final String URL_PLAYER_DATA = PREFIX + "/v10/playerStatistics/info";
    //球队信息接口地址
    public static final String URL_MATCH_INFO = PREFIX + "/v9/league/info";
    //赛季列表接口地址
    public static final String URL_MATCH_SEASONS = PREFIX + "/v4/league/seasons";
    //根据teamId获取赛季列表
    public static final String URL_MATCH_SEASON_ID_FROM_TEAM_ID = PREFIX + "/v4/league/seasonsByTeamId";
    //球队积分榜接口地址
    public static final String URL_MATCH_TEAM_RANK = PREFIX + "/v4/league/teamRank";
    //球员榜接口地址
    public static final String URL_MATCH_SHOOTER_RANK = PREFIX + "/v9/queryShooterRank";
    //球队榜接口地址
    public static final String URL_MATCH_STATE = PREFIX + "/v9/queryMatchStat";

    /**
     * 上传文件
     * @param file
     * @param type 文件类型,1=图片|2=视频
     * @param callback
     * @return
     */
    public Disposable uploadFile(File file, String type, LifecycleCallback<FileDataBean> callback) {
        String url = getUploadBaseUrl() + HttpApiConstant.UPLOAD;
        return getUploadApi(RxHttp.postForm(url))
                .addFile("file", file)
                .add("uid", LoginOrdinaryUtils.INSTANCE.getUid())
                .add("type", type)
                .asResponse(FileDataBean.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(new Consumer<FileDataBean>() {
                    @Override
                    public void accept(FileDataBean data) throws Exception {
                        callback.onSuccess(data);
                    }
                }, new OnError() {
                    @Override
                    public void onError(ErrorInfo error) throws Exception {
                        callback.onFailed(error.getErrorCode(), error.getErrorMsg());
                    }
                });
    }

    /**
     * 用户发送短信获取验证码
     * type:1登录注册，2找回密码，3修改手机号，4:资讯特约认证
     * earNo: 手机所在国家编码
     */
    public Disposable getAuthCode(String phone,String areaNo, String type, LifecycleCallback<String> callback) {
        if (phone.startsWith("0")) {
            phone = phone.substring(1);
        }
        Long phoneNumber;
        int authType;
        phoneNumber = Long.valueOf(phone);
        authType = Integer.valueOf(type);
        return getApi(RxHttp.postJson(SMS_SEND_CODE))
                .add("phone", phoneNumber)
                .add("type", authType)
                .add("areaNo", areaNo)
                .asResponse(String.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(s -> {
                    callback.onSuccess(s);
                }, (OnError) error -> {
                    callback.onFailed(error.getErrorCode(), error.getErrorMsg());
                });
    }

    /**
     * 获取用户特约信息
     */
    public Disposable getSpecialReview(LifecycleCallback<String> callback) {
       return getSpecialAuthRxHttp(getApi(RxHttp.postJson(SPECIAL_REVIEW_GET)))
                .asObject(String.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(beans -> {
                    callback.onSuccess(beans);
                }, (OnError) error -> {
                    callback.onFailed(error.getErrorCode(), error.getErrorMsg());
                });
    }

    /**
     * 【特约审核】提交申请
     */
    public Disposable saveSpecialReview(SpecialReviewBean data, LifecycleCallback<String> callback) {
        JSONObject json = new JSONObject();
        try {
            json.put("id", data.getId());             // Id
            json.put("idCard", data.getIdCard());     // 身份证
            json.put("idUrl", data.getIdUrl());       // 身份证照片
            json.put("imgUrl", data.getImgUrl());     // 其他身份证明图片 逗号分隔
            json.put("name", data.getName());         // 姓名
            json.put("phoneNum", data.getPhoneNum()); // 手机号
            json.put("code", data.getCode());         // 验证码
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return getSpecialAuthRxHttp(getApi(RxHttp.postJson(SPECIAL_REVIEW_SAVE)))
                .setJsonParams(json.toString())
                .asObject(String.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(beans -> {
                    callback.onSuccess(beans);
                }, (OnError) error -> {
                    callback.onFailed(error.getErrorCode(), error.getErrorMsg());
                });
    }

    /**
     * 【特约审核】更新资料
     */
    public Disposable updateSpecialReview(SpecialReviewBean data, LifecycleCallback<String> callback) {
        JSONObject json = new JSONObject();
        try {
            json.put("id", data.getId());             // Id
            json.put("idCard", data.getIdCard());     // 身份证
            json.put("idUrl", data.getIdUrl());       // 身份证照片
            json.put("imgUrl", data.getImgUrl());     // 其他身份证明图片 逗号分隔
            json.put("name", data.getName());         // 姓名
            json.put("phoneNum", data.getPhoneNum()); // 手机号
            json.put("code", data.getCode());         // 验证码
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return getSpecialAuthRxHttp(getApi(RxHttp.postJson(SPECIAL_REVIEW_UPDATE)))
                .setJsonParams(json.toString())
                .asObject(String.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(beans -> {
                    callback.onSuccess(beans);
                }, (OnError) error -> {
                    callback.onFailed(error.getErrorCode(), error.getErrorMsg());
                });
    }

    /**
     * 查询球队基础信息
     */
    public Disposable getClubTeamSeasonId(String teamId, LifecycleCallback<ClubTeamSeasonIdBean> callback) {
        return getApi(RxHttp.get(CLUB_TEAM_SEASONID))
                .add("teamId", teamId)
                .asResponse(ClubTeamSeasonIdBean.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(beans -> {
                    callback.onSuccess(beans);
                }, (OnError) error -> {
                    callback.onFailed(error.getErrorCode(), error.getErrorMsg());
                });
    }


    /**
     * 查询球队基础信息
     */
    public Disposable getClubBasicsInfo(String teamId, String seasonId, LifecycleCallback<ClubBasicsInfoBean> callback) {
        return getApi(RxHttp.get(CLUB_BASE_INFO))
                .add("teamId", teamId)
                .add("seasonId", seasonId)
                .asResponse(ClubBasicsInfoBean.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(beans -> {
                    callback.onSuccess(beans);
                }, (OnError) error -> {
                    callback.onFailed(error.getErrorCode(), error.getErrorMsg());
                });
    }

    /**
     * 查询队伍赛季球员统计
     */
    public Disposable getClubSeasonStat(String teamId, String seasonId, LifecycleCallback<String> callback) {
        return getApi(RxHttp.get(CLUB_SEASON_STAT))
                .add("teamId", teamId)
                .add("seasonId", seasonId)
                .asResponse(String.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(beans -> {
                    callback.onSuccess(beans);
                }, (OnError) error -> {
                    callback.onFailed(error.getErrorCode(), error.getErrorMsg());
                });
    }

    /**
     * 查询球队赛季赛程
     */
    public Disposable getClubSeasonAgenda(String teamId, String seasonId, LifecycleCallback<List<ClubSeasonAgendaBean>> callback) {
        return getApi(RxHttp.get(CLUB_SEASON_AGENDA))
                .add("teamId", teamId)
                .add("seasonId", seasonId)
                .asResponseList(ClubSeasonAgendaBean.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(beans -> {
                    callback.onSuccess(beans);
                }, (OnError) error -> {
                    callback.onFailed(error.getErrorCode(), error.getErrorMsg());
                });
    }

    /**
     * 获取球队信息接口
     */
    public Disposable getMatchInfo(String leagueId, LifecycleCallback<MatchLeagueInfo> callback) {
        return getApi(RxHttp.get(URL_MATCH_INFO))
                .add("leagueId", leagueId)
                .asResponse(MatchLeagueInfo.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError)error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 获取赛季信息接口
     */
    public Disposable getMatchSeasons(String leagueId, LifecycleCallback<SeasonData> callback) {
        return getApi(RxHttp.get(URL_MATCH_SEASONS))
                .add("leagueId", leagueId)
                .asResponse(SeasonData.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError)error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 根据teamId获取赛季列表接口
     */
    public Disposable getSeasonIdFromTeamId(String teamId, LifecycleCallback<SeasonIdFromTeamId> callback) {
        return getApi(RxHttp.get(URL_MATCH_SEASON_ID_FROM_TEAM_ID))
                .add("teamId", teamId)
                .asResponse(SeasonIdFromTeamId.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError)error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 获取积分榜接口
     */
    public Disposable getMatchTeamRank(String seasonId, String groupId, LifecycleCallback<List<PointData>> callback) {
        RxHttp http = getApi(RxHttp.get(URL_MATCH_TEAM_RANK))
                .add("seasonId", seasonId);
        if (!isEmpty(groupId)) {
            http.add("groupId", groupId);
        }
        return http.asResponseList(PointData.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError)error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 获取球员榜接口L
     */
    public Disposable getMatchShooterRank(String seasonId, String statType, LifecycleCallback<List<MatchPlayerBean>> callback) {
        return getApi(RxHttp.get(URL_MATCH_SHOOTER_RANK))
                .add("seasonId", seasonId)
                .add("statType", statType)
                .asResponseList(MatchPlayerBean.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError)error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 获取球队榜接口
     */
    public Disposable getMatchState(String seasonId, String statType, LifecycleCallback<List<MatchTeamBean>> callback) {
        return getApi(RxHttp.get(URL_MATCH_STATE))
                .add("seasonId", seasonId)
                .add("statType", statType)
                .asResponseList(MatchTeamBean.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError)error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 特约认证，绑定特定请求头的RxHttp
     */
    private RxHttp getSpecialAuthRxHttp(RxHttp rxHttp) {
        long uid = LoginOrdinaryUtils.INSTANCE.getUid();
        String uidOrDeviceId;
        JSONObject json = new JSONObject();
        try {
            json.put("uid", uid);
            uidOrDeviceId = json.toString();
        } catch (JSONException e) {
            e.printStackTrace();
            uidOrDeviceId = getDeviceId();
        }

        rxHttp.addHeader("deviceId", getDeviceId());       // 设备id
        rxHttp.addHeader("x-user-header", uidOrDeviceId);  // uid
        return rxHttp;
    }


    public Disposable getPlayerData(String playerId, String type, LifecycleCallback<List<DataSubTotalBean>> callback) {
        return getApi(RxHttp.get(URL_PLAYER_DATA))
                .add("playerId", playerId)
                .add("type", type)
                .asResponseList(DataSubTotalBean.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(beans -> {
                    callback.onSuccess(beans);
                }, (OnError) error -> {
                    callback.onFailed(error.getErrorCode(), error.getErrorMsg());
                });
    }


    public <T> Disposable getRequest(String url, Map<String,String> map, Class<T> tClass, LifecycleCallback<T> callback) {
        if(map==null)map=new HashMap<>();
        return getApi(RxHttp.get(url))
                .add(map)
                .asResponse(tClass)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(T -> {
                    callback.onSuccess(T);
                }, (OnError) error -> {
                    callback.onFailed(error.getErrorCode(), error.getErrorMsg());
                });
    }
}
