package com.yb.ballworld.information.ui.home.presenter;

import android.content.Intent;
import android.text.TextUtils;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.MutableLiveData;

import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.livedata.LiveDataWrap;
import com.yb.ballworld.information.ui.home.bean.IndexLableLetterBean;
import com.yb.ballworld.information.ui.home.bean.OutSideIndexLableLetterBean;
import com.yb.ballworld.information.ui.home.bean.OutSideIndexListLableLetterBean;
import com.yb.ballworld.information.ui.home.constant.PublishTagType;
import com.yb.ballworld.information.ui.home.constant.TagParams;
import com.yb.ballworld.information.ui.home.constant.TagReqCode;
import com.yb.ballworld.information.ui.home.service.InfoHttpApi;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc
 * Date 2019/11/6
 * author mengk
 */
public class TagSortByIndexPresenter extends BasePresenter<LifecycleOwner, VoidModel> {
    private InfoHttpApi httpApi = new InfoHttpApi();

    private LiveDataWrap<OutSideIndexLableLetterBean> mOutSideIndexLableLetterBean = new LiveDataWrap<>();
    private MutableLiveData<Boolean> reqLoading = new MutableLiveData<>();

    public MutableLiveData<Boolean> getReqLoading() {
        return reqLoading;
    }

    public LiveDataWrap<OutSideIndexLableLetterBean> getmOutSideIndexLableLetterBean() {
        return mOutSideIndexLableLetterBean;
    }

    /**
     * 获取按照字母排序的tag列表
     * @param type
     * @param searchKey
     */
    public void getLableLetterListData(String type,String searchKey) {
        reqLoading.setValue(true);
        add(httpApi.getLableListLetter(type, searchKey, new LifecycleCallback<OutSideIndexLableLetterBean>(mView) {
            @Override
            public void onSuccess(OutSideIndexLableLetterBean data) {
                if (data != null) {
                    mOutSideIndexLableLetterBean.setData(data);
                } else {
                    mOutSideIndexLableLetterBean.setError(0,"data数据为空");
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                mOutSideIndexLableLetterBean.setError(errCode,!TextUtils.isEmpty(errMsg) ? errMsg : "请求服务器失败");
            }
        }));
    }

    /**
     * 点击确认按钮之后的数据处理
     * @param activity
     * @param labelLetterOutSideList
     */
    public void clickSureBtnAndHandleData(AppCompatActivity activity,List<OutSideIndexListLableLetterBean> labelLetterOutSideList,int position) {
        List<IndexLableLetterBean> resultList = new ArrayList<>();
        ArrayList<String> ids = new ArrayList<>();

        if (labelLetterOutSideList != null) {
            for (OutSideIndexListLableLetterBean outSideIndexListLableLetterBean : labelLetterOutSideList) {
                List<IndexLableLetterBean> list = outSideIndexListLableLetterBean.getList();
                if (list != null) {
                    for (IndexLableLetterBean indexLableLetterBean : list) {
                        if (indexLableLetterBean.isCheck()) {
                            resultList.add(indexLableLetterBean);
                        }
                    }
                }
            }

            for (IndexLableLetterBean indexLableLetterBean : resultList) {
                ids.add(String.valueOf(indexLableLetterBean.getId()));
                LogUtils.INSTANCE.e("===z","标签二级页面确认的data = " + indexLableLetterBean.getLable());
            }


            //关闭页面 传递数据回去
            Intent intent = new Intent();
            intent.putStringArrayListExtra(TagParams.INTENT_PARAM, ids);
            intent.putExtra(TagParams.INTENT_PARAM_POSITION, position);
            activity.setResult(TagReqCode.REQ_CODE_PUBLISH_TO_TAG_TO_MORE, intent);
        }
    }

    /**
     * 刷选数据和添加给adapter
     * @param labelLetterOutSideList
     * @param outSideListLableLetterData
     * @param ids
     */
    public void adapterListAddAllDataAndFilter(List<OutSideIndexListLableLetterBean> labelLetterOutSideList,List<OutSideIndexListLableLetterBean> outSideListLableLetterData,ArrayList<String> ids) {
        //判断上个页面带过来的数据id是否选中
        for (OutSideIndexListLableLetterBean outSideListLableLetterDatum : outSideListLableLetterData) {
            List<IndexLableLetterBean> list = outSideListLableLetterDatum.getList();
            for (IndexLableLetterBean indexLableLetterBean : list) {
                int id = indexLableLetterBean.getId();
                if (ids != null && ids.size() != 0) {
                    if (ids.contains(String.valueOf(id))) {
                        indexLableLetterBean.setCheck(true);
                    }
                }
            }
        }

        //添加数据
        labelLetterOutSideList.addAll(outSideListLableLetterData);
    }

    /**
     * 获取index字母排序的数据
     * @param labelLetterOutSideList
     * @return
     */
    public List<String> getIndexListData(List<OutSideIndexListLableLetterBean> labelLetterOutSideList) {
        List<String> indexList = new ArrayList<>();
        for (OutSideIndexListLableLetterBean outSideIndexListLableLetterBean : labelLetterOutSideList) {
            indexList.add(outSideIndexListLableLetterBean.getTitle());
        }
        return indexList;
    }

    /**
     * 获取上一个页面传递的参数ids
     * @param intent
     * @return
     */
    public ArrayList<String> getIds(Intent intent) {
        return intent.getStringArrayListExtra(TagParams.INTENT_PARAM);
    }

    /**
     * 获取上一个页面传递的type
     *
     * @param intent
     * @return 默认查询全部类型。1球员，2俱乐部球队，3国家队，4赛事
     */
    public String getType(Intent intent) {
        return String.valueOf(intent.getIntExtra(TagParams.INTENT_PARAM_TYPE, PublishTagType.TYPE_PERSON));
    }

    /**
     * 获取位置
     * @param intent
     * @return
     */
    public int getPosition(Intent intent) {
        return intent.getIntExtra(TagParams.INTENT_PARAM_POSITION, 0);
    }

    /**
     * 获取标题
     * @param position
     * @return
     */
    public String getTitleFromUp(int position) {
        //1球员，2俱乐部球队，3赛事 4国家队
        //数组组装按照 1球员，2俱乐部球队，3国家队，4赛事 的顺序

        String title;
        switch (position) {
            case 0:
                title = "球员标签库";
                break;
            case 1:
                title = "球队标签库";
                break;
            case 2:
                title = "赛事标签库";
                break;
            case 3:
                title = "国家队标签库";
                break;
            default:
                title = "球员标签库";
                break;
        }
        return title;

    }
}
