package com.yb.ballworld.information;

import android.view.View;

import com.yb.ballworld.common.base.SystemBarActivity;

/**
 * Desc: <功能简述>
 * Author: JS-Dugu
 * Created On: 2019/10/11 19:22
 */
public class MainInformationActivity extends SystemBarActivity {


    @Override
    public int getLayoutId() {
        return R.layout.activityr_main_info;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void bindEvent() {

    }

    @Override
    protected void initData() {

    }

    @Override
    protected void processClick(View view) {

    }
}
