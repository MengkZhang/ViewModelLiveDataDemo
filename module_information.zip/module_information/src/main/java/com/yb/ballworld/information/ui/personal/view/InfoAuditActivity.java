package com.yb.ballworld.information.ui.personal.view;

import android.content.Context;
import android.content.Intent;
import android.view.View;

import com.yb.ballworld.common.base.mvp.BaseMvpActivity;
import com.yb.ballworld.common.widget.CommonTitleBar;
import com.yb.ballworld.information.R;

public class InfoAuditActivity extends BaseMvpActivity {
    private String userId;

    public static final void start(Context context, String userId) {
        Intent intent = new Intent(context, InfoAuditActivity.class);
        intent.putExtra("userId", userId);
        context.startActivity(intent);
    }

    @Override
    public void initPresenter() {

    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_info_audit_activity;
    }

    @Override
    protected void initView() {
        userId = getIntent().getStringExtra("userId");
        if (userId == null) {
            userId = "";
        }
        getSupportFragmentManager().beginTransaction()
                .add(R.id.fl_container, InfoAuditFragment.newInstance(userId))
                .commit();
    }

    @Override
    protected void bindEvent() {
        ((CommonTitleBar) findViewById(R.id.commonTitleBar)).setListener(new CommonTitleBar.OnTitleBarListener() {
            @Override
            public void onClicked(View v, int action, String extra) {
                if (action == CommonTitleBar.ACTION_LEFT_BUTTON) {
                    finish();
                }
            }
        });
    }

    @Override
    protected void initData() {

    }

    @Override
    protected void processClick(View view) {

    }
}
