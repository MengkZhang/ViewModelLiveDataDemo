package com.yb.ballworld.information.ui.home.presenter;

/**
 * Desc 资讯列表presenter
 * Date 2019/10/16
 * author mengk
 */
public class InfoIndexAllPresenterImpl implements InfoIndexAllContract.IInfoIndexAllPresenter {
    private InfoIndexAllContract.IInfoIndexAllView mView;

    @Override
    public void loadData(int page) {

    }

    @Override
    public void refreshData() {

    }

    @Override
    public void loadMoreData() {

    }

    @Override
    public void attachView(InfoIndexAllContract.IInfoIndexAllView view) {
        this.mView = view;
    }
}
