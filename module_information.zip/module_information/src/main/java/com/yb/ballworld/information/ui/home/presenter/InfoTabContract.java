package com.yb.ballworld.information.ui.home.presenter;

import androidx.fragment.app.Fragment;

import com.yb.ballworld.information.ui.home.bean.HomeIndexTabBean;
import com.yb.ballworld.information.ui.home.bean.TabEntity;

import java.util.List;

/**
 * Desc 资讯TAb协议类
 * Date 2019/10/7
 * author mengk
 */
public class InfoTabContract {

    //--------------------------------View层----------------------------
    public interface IInfoTabView {
        Fragment getFragment();
        //请求加载中
        void requestLoading();

        //请求失败
        void resultFail(int type);

        //请求tab成功
//        void resultTabSuccess(List<HomeIndexTabBean> list);
        void resultTabSuccess(List<TabEntity.CustomLablesBean> list);

    }

    //--------------------------------Presenter层----------------------------
    public interface IInfoTabPresenter {

        //请求数据方法
        void loadData();


        //绑定View
        void attachView(IInfoTabView view);

        //解绑View
        void detachView();
    }

}
