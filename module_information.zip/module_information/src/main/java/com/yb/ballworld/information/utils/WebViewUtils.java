package com.yb.ballworld.information.utils;

import android.text.TextUtils;

import com.yb.ballworld.information.data.ArticleBean;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc: <功能简述>
 * Author: JS-Dugu
 * Created On: 2019/10/16 0:40
 */
public class WebViewUtils {

    public static HtmlParseData parseHtmlText(ArticleBean articleBean) {
        HtmlParseData htmlParseData = new HtmlParseData();

        htmlParseData.setPublisher(articleBean.getNickName());
        htmlParseData.setPublishTime(articleBean.getCreatedDate());
        htmlParseData.setDetailTitle(articleBean.getTitle());

        if (articleBean == null) {
            return htmlParseData;
        }
        String content = "";
        if (TextUtils.isEmpty(content)) {
            content = articleBean.getContent().replace("<p style=\"text-align: center;\">",
                    "<p style=\"display: flex; align-items: center; justify-content: center;\">");
        }
        // TAG2
        String docHtml = "<!DOCTYPE html><head>" +
                "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no\">" +
                // " <script src=\"file:///android_asset/js/flexible.js\"></script> " +
                "<link rel=\"stylesheet\" href=\"file:///android_asset/css/news.css\" type=\"text/css\" /> "+
                "</head><body>"
                +  content +
                "</body></html>";
        Document doc = Jsoup.parse(docHtml);
        List<String> imgUrls = fixImg(doc);
        List<String> aUrls = fixA(doc);
        fixEmbed(doc);
        if (imgUrls != null) {
            htmlParseData.setImgUrls(imgUrls);
        }
        if (aUrls != null) {
            htmlParseData.setAUrls(aUrls);
        }
        htmlParseData.setDocHtml(doc.html());

        return htmlParseData;
    }

    /**
     * 修复 img 标签
     **/
    public static List<String> fixImg(Document doc) {
        List<String> imgUrls = new ArrayList<String>();
        // 使用 jsoup 修改 img 的属性:
        Elements images = doc.getElementsByTag("img");
        for (int i = 0; i < images.size(); i++) {
            // 宽度最大100%，高度自适应
            images.get(i).attr("style", "max-width: 100%; height: auto;")
                    //.attr("onclick", "RichTextJs.onTagClick(this.src, this.getAttribute('data-filename'))")
                    .attr("onclick", "RichTextJs.onTagClick(this.src,"
                            + HtmlParseData.TYPE_IMG + "," + i + ")");
            imgUrls.add(images.get(i).attr("src"));
        }
        return imgUrls;
    }

    /**
     * 修复 a 标签
     **/
    public static List<String> fixA(Document doc) {
        List<String> aUrls = new ArrayList<String>();
        // 使用 jsoup 修改 img 的属性:
        Elements aList = doc.getElementsByTag("a");
        for (int i = 0; i < aList.size(); i++) {
            Element tempA = aList.get(i);
            aUrls.add(tempA.attr("href"));
            tempA.attr("onclick", "RichTextJs.onTagClick('"
                    + tempA.attr("href") + "'," + HtmlParseData.TYPE_LINK + "," + i + ")")
                    .attr("href", "javascript:void(0)")
                    .attr("style", "word-break: break-word");
        }
        return aUrls;
    }

    /**
     * 修复 embed 标签
     **/
    public static void fixEmbed(Document doc) {
        //使用 jsoup 修改 embed 的属性:
        Elements embeds = doc.getElementsByTag("embed");
        for (Element element : embeds) {
            //宽度最大100%，高度自适应
            element.attr("style", "max-width: 100%; height: auto;")
                    .attr("controls", "controls");
        }
        //webview 无法正确识别 embed 为视频时，需要这个标签改成 video 手机就可以识别了
        doc.select("embed").tagName("video");
    }

}
