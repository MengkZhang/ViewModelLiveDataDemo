package com.yb.ballworld.information.ui.profile.presenter;

import androidx.lifecycle.LifecycleOwner;

import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.livedata.LiveDataWrap;
import com.yb.ballworld.information.ui.profile.data.MatchLeagueInfo;
import com.yb.ballworld.information.ui.profile.data.SeasonData;
import com.yb.ballworld.information.ui.profile.http.ProfileHttp;

/**
 * Desc: <>
 * Author: JS-Barder
 * Created On: 2019/11/21 17:01
 */
public class MatchMomentsPresenter extends BasePresenter<LifecycleOwner, VoidModel> {

    private ProfileHttp http = new ProfileHttp();
    private LiveDataWrap<MatchLeagueInfo> dataWrap = new LiveDataWrap<>();
    private String leagueId;

    public void setLeagueId(String leagueId) {
        this.leagueId = leagueId;
    }

    public LiveDataWrap<MatchLeagueInfo> getDataWrap() {
        return dataWrap;
    }

    public void loadData() {
//        add(http.getMatchSeasons(leagueId, new LifecycleCallback<SeasonData>(mView) {
//            @Override
//            public void onSuccess(SeasonData data) {
//                dataWrap.setData(data);
//            }
//
//            @Override
//            public void onFailed(int errCode, String errMsg) {
//                dataWrap.setError(errCode, errMsg);
//            }
//        }));
    }

}
