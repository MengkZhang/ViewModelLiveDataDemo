package com.yb.ballworld.information.ui.home.view;

import android.os.Bundle;

import com.yb.ballworld.baselib.web.WebConstant;
import com.yb.ballworld.baselib.web.WebNavFragment;

/**
 * Desc 去掉titleBar的H5
 * Date 2019/10/18
 * author mengk
 */
public class InfoWebNavFragment extends WebNavFragment {

    public static InfoWebNavFragment newInstance(String url) {
        InfoWebNavFragment fragment = new InfoWebNavFragment();
        Bundle bundle = new Bundle();
        bundle.putString(WebConstant.KEY_WEB_URL, url);
        bundle.putString(WebConstant.KEY_WEB_TITLE, "");
        bundle.putBoolean(WebConstant.KEY_WEB_BACK, true);
        bundle.putBoolean(WebConstant.KEY_WEB_SWIPE_BACK, false);
        bundle.putInt(WebConstant.KEY_WEB_SPORT_TYPE, 1);
        fragment.setArguments(bundle);
        return fragment;
    }


    @Override
    protected boolean isShowToolBar() {
        return false;
    }

    @Override
    protected boolean isShowStatus() {
        return false;
    }


}
