package com.yb.ballworld.information.ui.profile.data;

import java.util.List;

/**
 * Desc: <>
 * Author: JS-Barder
 * Created On: 2019/11/21 19:18
 */
public class PointData {
    public String groupName;
    public List<PointsBean> stat;
    public int groupId;
}
