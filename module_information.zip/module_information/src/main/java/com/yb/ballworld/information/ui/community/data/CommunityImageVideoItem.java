package com.yb.ballworld.information.ui.community.data;

import android.content.ContentUris;
import android.net.Uri;
import android.provider.MediaStore;

import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.zhihu.matisse.MimeType;
import com.zhihu.matisse.internal.entity.Item;

import java.io.File;
import java.io.Serializable;

/**
 * Desc: <>
 * Author: JS-Barder
 * Created On: 2019/11/16 21:38
 */
public class CommunityImageVideoItem implements Serializable, MultiItemEntity {
    public final long id;
    public final String mimeType;
//    public final Uri uri;
    public final long size;
    public final long duration;
    public File faceFile;
    public String filePath;
    public final int type;//类型

    public CommunityImageVideoItem(long id, String mimeType,long size, long duration, int type) {
        this.id = id;
        this.mimeType = mimeType;
        this.size = size;
        this.duration = duration;
        this.type = type;
    }

    public Item getItem() {
        return new Item(id, mimeType, size, duration);
    }

    public boolean isImage() {
        return MimeType.isImage(mimeType);
    }

    public boolean isGif() {
        return MimeType.isGif(mimeType);
    }

    public boolean isVideo() {
        return MimeType.isVideo(mimeType);
    }

    @Override
    public int getItemType() {
        return type;
    }
}
