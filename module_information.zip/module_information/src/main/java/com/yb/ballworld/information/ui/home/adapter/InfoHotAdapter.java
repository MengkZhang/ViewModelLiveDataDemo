package com.yb.ballworld.information.ui.home.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.common.widget.STCircleImageView;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.bean.HomeIndexImgBean;
import com.yb.ballworld.information.ui.home.bean.IndexHotEntity;
import com.yb.ballworld.information.ui.home.constant.ItemTypeConstant;
import com.yb.ballworld.information.ui.home.utils.CommentHotUtil;
import com.yb.ballworld.information.ui.home.utils.GlideLoadImgUtil;
import com.yb.ballworld.information.ui.home.utils.ListImgUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.home.utils.UidUtil;
import com.yb.ballworld.information.ui.home.widget.InfoNoSpecialView;
import com.yb.ballworld.information.ui.home.widget.InfoSpecialImgView;
import com.yb.ballworld.information.ui.home.widget.InfoSpecialVideoView;

import java.util.ArrayList;
import java.util.List;

import cn.jzvd.Jzvd;
import cn.jzvd.JzvdStd;

/**
 * Desc 资讯热门列表页adapter
 * Date 2019/10/7
 * author mengk
 */
public class InfoHotAdapter extends BaseMultiItemQuickAdapter<IndexHotEntity.NewsBean.ListBean, BaseViewHolder> {

    /**
     * Same as QuickAdapter#QuickAdapter(Context,int) but with
     * some initialization data.
     *
     * @param data A new list is created out of this one to avoid mutable list
     */
    public InfoHotAdapter(List<IndexHotEntity.NewsBean.ListBean> data) {
        super(data);
        addItemType(ItemTypeConstant.TYPE_IMG_WITHOUT_HEAD, R.layout.item_info_type_img_new);

        addItemType(ItemTypeConstant.TYPE_IMG_WITH_HEAD, R.layout.item_info_type_imgs_new1);
        addItemType(ItemTypeConstant.TYPE_IMGS_WITH_HEAD, R.layout.item_info_type_imgs_new2);
        addItemType(ItemTypeConstant.TYPE_IMGS3_WITH_HEAD, R.layout.item_info_type_imgs_new3);

        addItemType(ItemTypeConstant.TYPE_VIDEO_WITH_HEAD, R.layout.item_info_type_video_with_head_or_not_new);
        addItemType(ItemTypeConstant.TYPE_VIDEO_WITHOUT_HEAD, R.layout.item_info_type_video_with_head_or_not_new);
    }

    @Override
    protected void convert(BaseViewHolder helper, IndexHotEntity.NewsBean.ListBean item, int pos) {
        int itemViewType = helper.getItemViewType();
        LogUtils.INSTANCE.e("===z","热门列表中的itemType = "+itemViewType);
        switch (itemViewType) {
            case ItemTypeConstant.TYPE_IMG_WITHOUT_HEAD:             //item类型 单图 普通没有头像类型 展示正常

                adapterItem(helper, item);
                break;

            case ItemTypeConstant.TYPE_IMG_WITH_HEAD:                //item类型 单图有头像类型

                adapterItemMultiImgWithHead(0,helper,item);
                break;

            case ItemTypeConstant.TYPE_IMGS_WITH_HEAD:               //item类型 双图

                adapterItemMultiImgWithHead(1,helper,item);
                break;

            case ItemTypeConstant.TYPE_IMGS3_WITH_HEAD:              //item类型 三图

                adapterItemMultiImgWithHead(2,helper,item);
                break;

            case ItemTypeConstant.TYPE_VIDEO_WITH_HEAD:               //item类型 视频有头像

                adapterItemVideo(0,helper,item);
                break;

            case ItemTypeConstant.TYPE_VIDEO_WITHOUT_HEAD:            //item类型 视频没有头像

                adapterItemVideo(1,helper,item);
                break;

            default:

                adapterItem(helper, item);
                break;

        }

    }

    /**
     * new 适配没有头像的单图类型
     * @param helper
     * @param item
     */
    private void adapterItem(BaseViewHolder helper, IndexHotEntity.NewsBean.ListBean item) {
        InfoNoSpecialView infoNoSpecialView = helper.getView(R.id.insv_info);
        infoNoSpecialView.setDetailData(item);

        //图片点击事件 到图片浏览器
        infoNoSpecialView.setOnFaceClickListener(() -> {

            oneImgJump(mContext,item);

        });
    }

    /**
     * 有头像类型 单图 双图 三图类型
     * @param type    0 单图 1 双图 2 三图
     * @param helper  BaseViewHolder
     * @param item    HomeInfoListBean
     */
    private void adapterItemMultiImgWithHead(int type, BaseViewHolder helper, IndexHotEntity.NewsBean.ListBean item) {
        InfoSpecialImgView infoSpecialImgView = helper.getView(R.id.isiv_info);
        infoSpecialImgView.setDetailData(type,helper,item);

        //点击事件
        infoSpecialImgView.setOnFaceClickListener((position) -> {
            if (type == 0) { //单图

                oneImgJump(mContext,item);

            } else {         //双图 和 多图

                MultiImgJump(mContext,item,position);

          }

        });
    }

    /**
     * 适配视频数据
     * @param type 0有头像 1 没有头像
     * @param helper
     * @param item
     */
    private void adapterItemVideo(int type, BaseViewHolder helper, IndexHotEntity.NewsBean.ListBean item) {
        InfoSpecialVideoView infoSpecialVideoView = helper.getView(R.id.isvv_info);
        infoSpecialVideoView.setDetailData(type,helper,item);
    }

    /**
     * 刷新条目中指定view
     * @param view
     * @param item
     */
    public void changeLike(View view, IndexHotEntity.NewsBean.ListBean item) {
        ImageView ivLike = view.findViewById(R.id.iv_praise_icon);
        TextView tvLike = view.findViewById(R.id.tv_praise_info);
        if (ivLike != null) {
            ivLike.setSelected(item.isLike());
        }
        if (tvLike != null) {
            tvLike.setText(String.valueOf(item.getLikeCount()));
        }
    }

    /**
     * 单张图片点击跳转
     * @param context
     * @param item
     */
    private void oneImgJump(Context context,IndexHotEntity.NewsBean.ListBean item) {
        ArrayList<String> peerList = new ArrayList<>();
        peerList.add(item.getImgUrl());
        String title = item.getTitle();
        String preview = item.getPreview();
        String webShareUrl = item.getWebShareUrl();
        NavigateToDetailUtil.navigateToGalleryActivity(context,peerList,0,title,webShareUrl,preview,webShareUrl);
    }

    /**
     * 双图和多图点击跳转
     * @param context
     * @param item
     * @param position
     */
    private void MultiImgJump(Context context,IndexHotEntity.NewsBean.ListBean item,int position) {
        List<IndexHotEntity.NewsBean.ListBean.NewsImgsBean> newsImgs = item.getNewsImgs();
        ArrayList<String> peerList = new ArrayList<>();
        if (newsImgs != null && newsImgs.size() != 0) {

            for (IndexHotEntity.NewsBean.ListBean.NewsImgsBean newsImg : newsImgs) {
                peerList.add(newsImg.getImgUrl());
            }
            String title = item.getTitle();
            String preview = item.getPreview();
            String webShareUrl = item.getWebShareUrl();
            NavigateToDetailUtil.navigateToGalleryActivity(context,peerList,position,title,webShareUrl,preview,webShareUrl);
        }

    }



}
