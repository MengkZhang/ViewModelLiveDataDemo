package com.yb.ballworld.information.ui.home.utils;

import android.content.Context;
import android.net.Uri;

import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.bean.JumpBean;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc
 * Date 2019/10/12
 * author mengk
 */
public class ListImgUtil {
    // TODO: 2019/10/12 测试列表
    public static List<JumpBean> getTestImgList(Context context,String id,boolean isDouble) {
        List<JumpBean> list = new ArrayList<>();
        try {
            Uri uri = Uri.parse("res://"
                    + context.getPackageName() +
                    "/" + R.mipmap.banner_bg
            );
            if (isDouble) {
                for (int i = 0; i < 2; i++) {
                    JumpBean bean = new JumpBean();
                    bean.setNewsId(id);
                    bean.setImgUrl(uri.toString());
                    list.add(bean);
                }

            } else {
                for (int i = 0; i < 3; i++) {
                    JumpBean bean = new JumpBean();
                    bean.setNewsId(id);
                    bean.setImgUrl(uri.toString());
                    list.add(bean);
                }

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }


}
