package com.yb.ballworld.information.ui.home.utils.cache;

import android.content.Context;

import com.yb.ballworld.information.ui.home.bean.PublishVideoDataBean;
import com.yb.ballworld.information.ui.home.constant.TagParams;

/**
 * Desc
 * Date 2019/11/12
 * author mengk
 */
public class DataCacheUtils {
    private InfoShareUtils mSharedPreferences;
    private static DataCacheUtils mInstance;

    /**
     * 通过单例模式实例化对象
     *
     * @param context
     */
    private DataCacheUtils(Context context) {
        mSharedPreferences = new InfoShareUtils(context);
    }

    /**
     * 调用构造函数时，传入context.getApplicationContext()
     *
     * @param context
     * @return
     */
    public static DataCacheUtils getInstance(Context context) {
        if (mInstance == null) {
            synchronized (DataCacheUtils.class) {
                if (mInstance == null) {
                    mInstance = new DataCacheUtils(context.getApplicationContext());
                }
            }
        }
        return mInstance;
    }

    /**
     * 存储单个的Video对象
     *
     * @param videoDataBean
     */
    public void saveVideo(PublishVideoDataBean videoDataBean) {
        mSharedPreferences.saveObject(TagParams.PUBLISH_VIDEO_DATA, videoDataBean);
    }

    /**
     * 清除指定的key的数据
     *
     * @param key
     */
    public void clearDataByKey(String key) {
        mSharedPreferences.clear(key);
    }

    /**
     * 获取单个Video对象
     *
     * @return
     */
    public PublishVideoDataBean getVideoFromCache() {
        return mSharedPreferences.getObject(TagParams.PUBLISH_VIDEO_DATA, PublishVideoDataBean.class);
    }


//    /**
//     * 保存单个用户数据存储
//     * @param user
//     */
//    public void saveUser(User user){
//        mSharedPreferences.saveObject("user_info",user);
//    }
//
//    /**
//     * 获取单个用户数据
//     * @return
//     */
//    public User getUser(){
//        return mSharedPreferences.getObject("user_info",User.class);
//    }


//    /**
//     * 保存List<User>对象
//     * @param users
//     */
//    public void saveUserList(List<User> users){
//        mSharedPreferences.saveList("user_list_info",users);
//    }

//    /**
//     * 获取List<User>对象
//     * @return
//     */
//    public List<User> getUserList(){
//        return  mSharedPreferences.getList("user_list_info",new TypeToken<List<User>>(){});
//    }

//
//    /**
//     * 保存User对象,对象中包括List<Friend>列表
//     * @return
//     */
//    public void saveUserWithFriend(User user){
//        mSharedPreferences.saveObject("user_with_friend",user);
//    }
//
//    /**
//     * 获取User对象,对象中包括List<Friend>列表
//     * @return
//     */
//    public User getUserWithFriend(){
//        return mSharedPreferences.getObject("user_with_friend",User.class);
//    }
}
