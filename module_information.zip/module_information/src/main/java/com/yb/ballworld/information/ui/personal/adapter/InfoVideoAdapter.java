package com.yb.ballworld.information.ui.personal.adapter;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;

public class InfoVideoAdapter extends BaseQuickAdapter<Object, BaseViewHolder> {

    public InfoVideoAdapter(int layoutResId) {
        super(layoutResId);
    }

    @Override
    protected void convert(BaseViewHolder helper, Object item, int pos) {

    }
}
