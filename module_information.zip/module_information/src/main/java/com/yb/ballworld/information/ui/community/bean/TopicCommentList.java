package com.yb.ballworld.information.ui.community.bean;

public class TopicCommentList {
    private Topic parent;
    private TopicComment son;

    public Topic getParent() {
        return parent;
    }

    public void setParent(Topic parent) {
        this.parent = parent;
    }

    public TopicComment getSon() {
        return son;
    }

    public void setSon(TopicComment son) {
        this.son = son;
    }
}
