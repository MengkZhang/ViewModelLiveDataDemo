package com.yb.ballworld.information.ui.profile.view.fragments;

import android.widget.RelativeLayout;

import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.common.base.mvp.BaseMvpFragment;
import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.information.R;

/**
 * 资料库-基类Fragment
 * @author Gethin
 * @time 2019/11/7 17:47
 */

public abstract class RvBaseFragment<P extends BasePresenter> extends BaseMvpFragment<P> {

    protected SmartRefreshLayout smartRefreshLayout;
    protected PlaceholderView placeholderView;
    protected RecyclerView recyclerView;
    protected BaseQuickAdapter adapter;
    protected RelativeLayout rlRoot;

    protected abstract void loadData();

    protected abstract BaseQuickAdapter getAdapter();

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_recycler_view;
    }

    @Override
    protected void initView() {
        rlRoot = findView(R.id.rlRoot);
        recyclerView = findView(R.id.recyclerView);
        placeholderView = findView(R.id.placeholder);
        smartRefreshLayout = findView(R.id.smart_refresh_layout);
        initRefreshView();
        enableLoadMore(false);
        enableRefresh(true);
        placeholderView.setPageErrorRetryListener(view ->  loadData());
        adapter=getAdapter();
        recyclerView.setAdapter(adapter);
    }

    @Override
    public PlaceholderView getPlaceholderView() {
        return placeholderView;
    }

    @Override
    protected SmartRefreshLayout getSmartRefreshLayout() {
        return smartRefreshLayout;
    }

    @Override
    protected void onRefreshData() {
        loadData();
    }

    @Override
    protected void initData() {
        loadData();
    }
}
