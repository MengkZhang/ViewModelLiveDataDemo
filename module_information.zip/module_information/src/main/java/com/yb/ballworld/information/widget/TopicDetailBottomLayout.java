package com.yb.ballworld.information.widget;

import android.content.Context;
import android.content.Intent;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.alibaba.android.arouter.launcher.ARouter;
import com.bfw.util.ToastUtils;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.constant.Constant;
import com.yb.ballworld.baselib.core.RouterHub;
import com.yb.ballworld.baselib.data.UserInfo;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.baselib.utils.ViewUtils;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.sharesdk.ShareSdkParamBean;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.http.InforMationHttpApi;
import com.yb.ballworld.information.ui.community.CommunityHttpApi;
import com.yb.ballworld.information.ui.home.constant.PublishIntentParam;
import com.yb.ballworld.information.ui.home.constant.PublishReqCode;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.home.view.PublishCommentActivity;

/**
 * Desc: <功能简述>
 * Author: JS-Dugu
 * Created On: 2019/10/18 18:26
 */
public class TopicDetailBottomLayout extends LinearLayout {

    private TextView tvChatHint;
    private RelativeLayout rlInforCollect;
    private ImageView imgCollect;
    private RelativeLayout rlInforShare;
    private String topicId;
    private String replyId;
    private int commentStatus;
    private AppCompatActivity context;
    public static final int STYLE_TEXT_ONLY = 1;
    public static final int STYLE_DEFAULT = 0;

    public static final int TYPE_ARTICLE = 0;
    public static final int TYPE_COMMENT = 1;
    private int publishType = TYPE_ARTICLE;
    private boolean isCollected;
    private InforMationHttpApi inforMationHttpApi = new InforMationHttpApi();
    private ShareSdkParamBean mShareSdkParamBean;



    private OnCollectListener onCollectListener;

    public TopicDetailBottomLayout(Context context) {
        super(context);
        this.context = (AppCompatActivity) context;
        init();
    }

    public TopicDetailBottomLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        this.context = (AppCompatActivity) context;
        init();
    }

    public void setShareSdkParamBean(ShareSdkParamBean shareSdkParamBean) {
        this.mShareSdkParamBean = shareSdkParamBean;
    }

    /**
     * 设置参数
     *
     * @param commentStatus 评论的状态 1正常 0禁用
     * @param newsId        新闻id
     * @param replyId       回复id
     */
    public void setParam(int commentStatus, String newsId, String replyId) {
        this.commentStatus = commentStatus;
        this.topicId = newsId;
        this.replyId = replyId;
    }

    /**
     * 设置参数
     *
     * @param commentStatus 用户是否 1正常 0禁用
     * @param newsId        新闻id
     * @param replyId       回复id
     */
    public void setParam(int commentStatus, String newsId, String replyId, int publishType) {
        this.commentStatus = commentStatus;
        this.topicId = newsId;
        this.replyId = replyId;
        this.publishType = publishType;
        initCollectImg(false);
    }

    /**
     * 设置参数
     *
     * @param commentStatus 用户是否 1正常 0禁用
     * @param newsId        新闻id
     * @param replyId       回复id
     * @param isFavorites   是否已收藏
     */
    public void setParam(int commentStatus, String newsId, String replyId, boolean isFavorites) {
        this.commentStatus = commentStatus;
        this.topicId = newsId;
        this.replyId = replyId;
        this.isCollected = isFavorites;
        initCollectImg(isCollected);
    }

    public void switchStyle(int style) {
        if (STYLE_TEXT_ONLY == style) {
            switch2OnlyEdit();
        } else {
            switch2Default();
        }
    }

    private void switch2OnlyEdit() {
        if (rlInforCollect != null) {
            rlInforCollect.setVisibility(View.GONE);
        }
        if (rlInforShare != null) {
            rlInforShare.setVisibility(View.GONE);
        }
        if (tvChatHint != null) {
            tvChatHint.setVisibility(View.VISIBLE);
            MarginLayoutParams marginLayoutParams = (MarginLayoutParams) tvChatHint.getLayoutParams();
            marginLayoutParams.setMarginEnd(ViewUtils.dp2px(12));
            marginLayoutParams.setMarginStart(ViewUtils.dp2px(12));
        }
    }

    private void switch2Default() {
        if (rlInforCollect != null) {
            rlInforCollect.setVisibility(View.VISIBLE);
        }
        if (rlInforShare != null) {
            rlInforShare.setVisibility(View.VISIBLE);
        }
        if (tvChatHint != null) {
            tvChatHint.setVisibility(View.VISIBLE);
            MarginLayoutParams marginLayoutParams = (MarginLayoutParams) tvChatHint.getLayoutParams();
            marginLayoutParams.setMarginEnd(ViewUtils.dp2px(24));
            marginLayoutParams.setMarginStart(ViewUtils.dp2px(12));
        }
    }

    private void init() {
        setOrientation(VERTICAL);
        this.removeAllViews();
        View view = LayoutInflater.from(getContext()).inflate(R.layout.news_details_bottom_layout, this, false);
        this.addView(view);
        tvChatHint = view.findViewById(R.id.tvChatHint);
        rlInforCollect = view.findViewById(R.id.rlInforCollect);
        imgCollect = view.findViewById(R.id.imgCollect);
        rlInforShare = view.findViewById(R.id.rlInforShare);

        tvChatHint.setOnClickListener(v -> {
//                ToastUitl.showShort(R.string.prompt_coding);
            UserInfo userInfo = LoginOrdinaryUtils.INSTANCE.getUserInfo();
            if (userInfo == null) {//未登录
                NavigateToDetailUtil.toLogin(context);
            } else if (commentStatus != 1) {//不能评论
                ToastUtils.showToast("该贴不可以评论");
            } else {               //已登录
                new CommunityHttpApi().judgeUserFreeze(new LifecycleCallback<Boolean>(context) {
                    @Override
                    public void onSuccess(Boolean data) {
                        if (!data) {
                            Intent intent = new Intent(context, PublishCommentActivity.class);
                            intent.putExtra(PublishIntentParam.NEWS_ID, topicId);
                            intent.putExtra(PublishIntentParam.REPLY_ID, replyId);
                            intent.putExtra("type", Integer.MIN_VALUE);
                            context.startActivityForResult(intent, PublishReqCode.REQ_CODE);
                            LogUtils.INSTANCE.i("arway2","id="+topicId+"/replayid=" +replyId);
                        }
                    }

                    @Override
                    public void onFailed(int errCode, String errMsg) {
                        ToastUtils.showToast("用户已冻结");
                    }
                });
            }
        });

        rlInforCollect.setOnClickListener(v -> {
            if (LoginOrdinaryUtils.INSTANCE.getUserInfo() == null) {
                toLogin();
                return;
            }
            v.setEnabled(false);
            if (isCollected) {
                inforMationHttpApi.removeCollectTopic(topicId, new LifecycleCallback<String>(context) {
                    @Override
                    public void onSuccess(String data) {
                        v.setEnabled(true);
                        ToastUtils.showToast("已取消");
                        isCollected = false;
                        initCollectImg(false);
                        LiveEventBus.get().with(LiveEventBusKey.KEY_TOPIC_REMOVE_COLLECT,String.class).post(topicId);
                        if(onCollectListener!=null){
                            onCollectListener.onClick(false);
                        }
                    }

                    @Override
                    public void onFailed(int errCode, String errMsg) {
                        v.setEnabled(true);
                        ToastUtils.showToast("网络异常，请稍后再试");
                    }
                });
            } else {
                inforMationHttpApi.collectTopic(topicId, new LifecycleCallback<String>(context) {
                    @Override
                    public void onSuccess(String data) {
                        v.setEnabled(true);
                        ToastUtils.showToast("已收藏");
                        isCollected = true;
                        initCollectImg(true);
                        LiveEventBus.get().with(LiveEventBusKey.KEY_TOPIC_COLLECT,String.class).post(topicId);
                        if(onCollectListener!=null){
                            onCollectListener.onClick(true);
                        }
                    }

                    @Override
                    public void onFailed(int errCode, String errMsg) {
                        v.setEnabled(true);
                        ToastUtils.showToast("网络异常，请稍后再试");
                    }
                });
            }
        });
        rlInforShare.setOnClickListener(v -> {
            if (mShareSdkParamBean != null) {
                NavigateToDetailUtil.showShareToast(v, context, mShareSdkParamBean);
            }
        }

        );
    }

    private void toLogin() {
        ARouter.getInstance().build(RouterHub.USER_LOGIN_REGISTER_ACTIVITY)
                .navigation(context, Constant.COMMON_LOGIN_REQUEST);
    }

    private void initCollectImg(boolean isCollect) {
        imgCollect.setImageResource(isCollect ? R.drawable.ic_infor_collect_selected : R.drawable.ic_infor_collect_normal);
    }


    public void updateCOllect(boolean isCollected) {
        this.isCollected = isCollected;
        initCollectImg(isCollected);

    }


    public interface OnCollectListener{
        void onClick(boolean collect);
    }

    public void setOnCollectListener(OnCollectListener onCollectListener) {
        this.onCollectListener = onCollectListener;
    }

}
