package com.yb.ballworld.information.data;

import java.util.List;

/**
* Desc: 回复列表
* @author ink
* created at 2019/10/9 20:52
*/
public class ReplyList {
    private int count;
    private long artId;
    private List<Reply> replies;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public long getArtId() {
        return artId;
    }

    public void setArtId(long artId) {
        this.artId = artId;
    }

    public List<Reply> getReplies() {
        return replies;
    }

    public void setReplies(List<Reply> replies) {
        this.replies = replies;
    }
}
