package com.yb.ballworld.information.ui.personal.presenter;

import android.text.TextUtils;

import androidx.lifecycle.LifecycleOwner;

import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.information.http.PersonalHttpApi;
import com.yb.ballworld.information.ui.personal.bean.CollectionEntity;
import com.yb.ballworld.information.ui.personal.constant.AdapterConstant;
import com.yb.ballworld.information.ui.personal.constant.FailStateConstant;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Desc: <足迹P>
 * Author: JS-Barder
 * Created On: 2019/11/20 11:40
 */
public class InfoFootprintPresenter extends BasePresenter<LifecycleOwner, VoidModel> implements InfoFootprintContract.FootprintPresenter{
    private PersonalHttpApi httpApi;
    private InfoFootprintContract.FootprintView view;
    private List<CollectionEntity.ListBean> mFootprintList;
    private List<CollectionEntity.ListBean> mFootprintTempList;

    private boolean isLoadMore;
    private int pageNum = 1;

    @Override
    public void attachView(InfoFootprintContract.FootprintView view) {
        this.view = view;
        init();
    }

    public void init(){
        httpApi = new PersonalHttpApi();
        mFootprintList = new ArrayList<>();
        mFootprintTempList = new ArrayList<>();
    }

    @Override
    public void loadData() {
        //只有正常加载才有loading 加载更多和刷新是没有的
        httpApi.getFootprintList(pageNum, new LifecycleCallback<CollectionEntity>(mView) {
            @Override
            public void onSuccess(CollectionEntity data) {
                LogUtils.INSTANCE.d(data.getTotalPage());
                if (null == data) {
                    judgeStatusEmpty();
                    return;
                }
                if (!isLoadMore) {
                    mFootprintTempList.clear();
                }
                mFootprintTempList.addAll(data.getList());
                if (mFootprintTempList.size() > 0) {
                    mFootprintList.clear();
                    setDataClassification(mFootprintTempList);
//
                    view.resultSuccess(mFootprintList);
                    pageNum++;
                } else {
                    judgeStatusEmpty();
                }
                if(isLoadMore){
                    isLoadMore=false;
                }
                view.setEnableLoadMore(data.getPageNum() < data.getTotalPage());
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                if (isLoadMore) {
                    view.resultRefreshFail("刷新失败");
                    isLoadMore=false;
                }else {                 //正常加载数据失败
                    view.resultFail(FailStateConstant.TYPE_ERROR);
                }
            }
        });
    }

    /**
     * 将返回的数据分类
     */
    private void setDataClassification(List<CollectionEntity.ListBean> beans) {
        if (null == beans || beans.size() == 0) {
            judgeStatusEmpty();
            return;
        }
        List<String> dataList = new ArrayList<>();
        for (CollectionEntity.ListBean listBean : beans) {

            String date = getCreateDate(listBean.getCreatedDate());
            if (!dataList.contains(date) && !TextUtils.isEmpty(date)) {
                dataList.add(date);
                CollectionEntity.ListBean listBean1 = new CollectionEntity.ListBean();
                listBean1.setShowDate(date);
                listBean1.setCreatedDate(listBean.getCreatedDate());
                listBean1.setItemViewType(AdapterConstant.TYPE_ONLY_TITLE);
                listBean1.setTitle(true);
                mFootprintList.add(listBean1);
            }
            listBean.setShowDate(date);
            //collectionBean.setHasFocus(isLike);  是否已收藏
            //判断类型
            //没有头像 （单图类型 图片居右） 1\n 有头像 单图 2\n 双图 3\n 三图 4\n 视频 没有头像 5\n 有头像 6
            int showType = listBean.getShowType();
            int mediaType = listBean.getMediaType();
            int editor = 0;
            if (listBean.getUser()!=null)
                editor = listBean.getUser().getIsEditor();
            if (editor==1) {//-----------------特约-------------------
                if (mediaType==0) { //资讯类型（0.新闻 1.视频）
                    if(showType == 0)
                        listBean.setItemViewType(AdapterConstant.TYPE_IMG_WITH_HEAD);  //特约 单图
                    else if (showType == 1)
                        listBean.setItemViewType( AdapterConstant.TYPE_IMGS_WITH_HEAD); //特约 双图
                    else if (showType == 2 || showType == 3)
                        listBean.setItemViewType(AdapterConstant.TYPE_IMGS3_WITH_HEAD); //特约  三图 图集
                }else if (mediaType == 1) {//视频
                    listBean.setItemViewType(AdapterConstant.TYPE_VIDEO_WITH_HEAD); // 特约视频
                }
            }else { //i------------------非特约---------------------
                if (mediaType == 0) { //资讯类型（0.新闻 1.视频）
                    if (showType == 0||showType == 1||showType == 2||showType == 3) // //非特约 单图 双图 三图 （统一为单张图）
                        listBean.setItemViewType(AdapterConstant.TYPE_IMG_WITHOUT_HEAD);  //非特约 单图
                } else if (mediaType == 1) {
                    listBean.setItemViewType(AdapterConstant.TYPE_VIDEO_WITHOUT_HEAD);//视频
                }
            }

            mFootprintList.add(listBean);
        }
    }

    @Override
    public void refreshData() {
        pageNum = 1;
        loadData();
    }

    @Override
    public void loadMore() {
        isLoadMore = true;
        loadData();
    }

    /**
     * 判断刷新 加载更多 和 正常加载
     */
    private void judgeStatusEmpty() {
        if (isLoadMore) {
            view.resultRefreshFail("刷新数据为空");
        } //else if (isLoadMore) {
        //    isLoadMore = false;
        //    mView.resultRefreshFail("加载更多数据为空");
        //}
        else {
            dataEmpty();
        }
    }

    /**
     * 数据为空
     */
    private void dataEmpty() {
        view.resultFail(FailStateConstant.TYPE_EMPTY);
    }

    @Override
    public void detachView() {
        this.mView = null;
    }

    private String isNotNull(String s) {
        return !TextUtils.isEmpty(s) ? s : "";
    }

    /**
     * 转换日期
     */
    private String getCreateDate(String createDate) {
        String dateStr = "";
        if (TextUtils.isEmpty(createDate))
            return dateStr;
        else if (createDate.length() <= 10)
            return createDate;
        String date = createDate.substring(0, 10).trim();
        if (isNow(date))
            return date+" / 今天";
        String weekStr = "";
        try {
            int week = dayForWeek(createDate);
            switch (week) {
                case 1:
                    weekStr = "星期一";
                    break;
                case 2:
                    weekStr = "星期二";
                    break;
                case 3:
                    weekStr = "星期三";
                    break;
                case 4:
                    weekStr = "星期四";
                    break;
                case 5:
                    weekStr = "星期五";
                    break;
                case 6:
                    weekStr = "星期六";
                    break;
                case 7:
                    weekStr = "星期日";
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        dateStr=date+" / "+weekStr;
        return dateStr;
    }

    /**
     * 根据日期获取周几
     */
    public int dayForWeek(String pTime) throws Exception {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Calendar c = Calendar.getInstance();
        Date date = format.parse(pTime);
        c.setTime(date);
        int dayForWeek = 0;
        if (c.get(Calendar.DAY_OF_WEEK) == 1) {
            dayForWeek = 7;
        } else {
            dayForWeek = c.get(Calendar.DAY_OF_WEEK) - 1;
        }
        return dayForWeek;
    }

    /**
     * 判断时间是不是今天
     * @param date
     * @return    是返回true，不是返回false
     */
    private boolean isNow(String date) {
        //当前时间
        Date now = new Date();
        SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
        //获取今天的日期
        String nowDay = sf.format(now);
        return date.equals(nowDay);
    }
}
