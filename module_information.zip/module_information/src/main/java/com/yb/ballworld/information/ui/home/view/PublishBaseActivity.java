package com.yb.ballworld.information.ui.home.view;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bfw.util.ToastUtils;
import com.bigkoo.pickerview.builder.OptionsPickerBuilder;
import com.bigkoo.pickerview.view.OptionsPickerView;
import com.gyf.immersionbar.ImmersionBar;
import com.tbruyelle.rxpermissions2.RxPermissions;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.widget.chat.EmojiLayout;
import com.yb.ballworld.common.base.mvp.BaseMvpActivity;
import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.adapter.TagCommitAdapter;
import com.yb.ballworld.information.ui.home.bean.IndexLableLetterBean;
import com.yb.ballworld.information.ui.home.bean.InfoPublishCategoryBean;
import com.yb.ballworld.information.ui.home.bean.PublishVideoDataBean;
import com.yb.ballworld.information.ui.home.constant.TagReqCode;
import com.yb.ballworld.information.ui.home.listener.OnMultiClickListener;
import com.yb.ballworld.information.ui.home.presenter.PublishBaseViewModel;
import com.yb.ballworld.information.ui.home.utils.EditTextLimitUtil;
import com.yb.ballworld.information.ui.home.utils.KeyBoardHeightUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.home.utils.RichGlideUtil;
import com.yb.ballworld.information.ui.home.utils.StatusBarHeightUtil;
import com.yb.ballworld.information.ui.home.utils.softkey.KPSwitchFSPanelLinearLayout;
import com.yb.ballworld.information.ui.home.utils.softkey.KeyboardUtil;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.disposables.Disposable;


/**
 * Desc 发布文章和视频基类activity
 * Date 2019/11/5
 * author mengk
 */
public abstract class PublishBaseActivity<P extends BasePresenter> extends BaseMvpActivity<P> {

    private RxPermissions rxPermissions;
    private Disposable permissionDisposable;
    private RecyclerView rvTag;
    //emoji RootView
    private KPSwitchFSPanelLinearLayout llEmojiRootView;
    //emoji控件
    private EmojiLayout mEmojiLayout;
    //emoji icon
    private RelativeLayout rlEmojiIcon;
    private FrameLayout flContent;
    private ImageView ivChoice;
    private RelativeLayout rlAddCategory;
    private RelativeLayout rlBgAddCategory;
    private ImageView ivBgAddCategory;
    private TextView tvAddCategory;
    private TextView tvAddTag;
    private ArrayList<IndexLableLetterBean> listTag = new ArrayList<>();
    private ArrayList<String> ids = new ArrayList<>();
    private TagCommitAdapter tagCommitAdapter;
    private EditText etTitle;
    private KeyboardOnGlobalChangeListener keyboardOnGlobalChangeListener;
    private View decorRootView;
    private boolean keyboardShown;
    private OptionsPickerView<Object> pickerView;
    private PublishBaseViewModel baseViewModel;
    //选中的分类id
    private String choiceCategoryId;
    private InfoPublishCategoryBean categoryChoiceDataBean;
    private boolean isShowTextMaxLimit;

    /**
     * 初始化沉浸式
     */
    protected void initImmersionBar() {
        // 设置共同沉浸式样式
        ImmersionBar.with(this).statusBarDarkFont(true, 0.2f).statusBarColor(getStatusBarColor()).navigationBarColor(R.color.white).init();
    }

    @Override
    public void initPresenter() {

    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_publish_base;
    }

    public abstract int getContentLayoutId();

    public abstract void setIconChoice(ImageView ivChoice);

    @Override
    protected boolean isTouchHideSoftInput() {
        return false;
    }

    @Override
    protected void initView() {
        baseViewModel = ViewModelProviders.of(this).get(PublishBaseViewModel.class);
        StatusBarHeightUtil.getStatusBarHeight(F(R.id.statusbar_new), getStatusHeight());
        //F(R.id.statusbar_new).setVisibility(View.GONE);
        etTitle = F(R.id.et_input_title_info);
        rxPermissions = new RxPermissions(this);
        RichGlideUtil.initXRichTextImgLoad(PublishBaseActivity.this);
        ivChoice = F(R.id.iv_publish_img_info);
        rlAddCategory = F(R.id.rl_add_categry_info);
        tvAddCategory = F(R.id.tv_add_categry_info);
        rlBgAddCategory = F(R.id.rl_small_add_categry_info);
        ivBgAddCategory = F(R.id.iv_category_info);
        setIconChoice(ivChoice);
        flContent = F(R.id.fl_content_publish_base);
        llEmojiRootView = F(R.id.emoji_root_view_publish_base);
        mEmojiLayout = F(R.id.emoji_info_publish_base);
        setEmojiLayout(mEmojiLayout);
        rlEmojiIcon = F(R.id.rl_emoji_info_publish_base);
        //监听视图树的布局改变(弹出/隐藏软键盘会触发)
        decorRootView = getWindow().getDecorView().findViewById(android.R.id.content);
        keyboardOnGlobalChangeListener = new KeyboardOnGlobalChangeListener();
        addOnGlobalLayoutListener();

        flContent.removeAllViews();
        LayoutInflater.from(this).inflate(getContentLayoutId(), flContent);
        initViews();
        tvAddTag = F(R.id.tv_add_tag_info);
        rvTag = F(R.id.rv_tag_publish);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(RecyclerView.HORIZONTAL);
        rvTag.setLayoutManager(layoutManager);
        tagCommitAdapter = new TagCommitAdapter(listTag, true);
        rvTag.setAdapter(tagCommitAdapter);
        EditTextLimitUtil.setEditTextInputSpace(etTitle);
//        EditTextLimitUtil.setEditTextInputSpeChat(etTitle);
        EditTextLimitUtil.setEditTextLimitEnter(etTitle);
        measureSoftKeyHeight();
        getDataFromCacheAndShow();
    }

    private void measureSoftKeyHeight() {
        //测量键盘高度
        KeyboardUtil.attach(PublishBaseActivity.this, llEmojiRootView);
        int mKeyboardHeight = KeyboardUtil.getKeyboardHeight(PublishBaseActivity.this);

        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) mEmojiLayout.getLayoutParams();
        layoutParams.height = mKeyboardHeight;
        mEmojiLayout.setVisibility(View.VISIBLE);
        llEmojiRootView.setVisibility(View.VISIBLE);
    }

    protected abstract void setEmojiLayout(EmojiLayout mEmojiLayout);

    @Override
    protected void onResume() {
        super.onResume();
//        addOnGlobalLayoutListener();
    }

    /**
     * 添加软键盘监听
     */
    private void addOnGlobalLayoutListener() {
        decorRootView.getViewTreeObserver().addOnGlobalLayoutListener(keyboardOnGlobalChangeListener);
    }

    private void getDataFromCacheAndShow() {
        notifyFromCacheData(getDataFromCache());
    }

    public abstract void initViews();

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void bindEvent() {
        F(R.id.rl_publish_img_info).setOnClickListener(new OnMultiClickListener() {
            @Override
            public void onMultiClick(View v) {
                ifOpenGallery();
            }
        });

        F(R.id.title_bar_sure).setOnClickListener(new OnMultiClickListener() {
            @Override
            public void onMultiClick(View v) {
                sure();
            }
        });

        F(R.id.title_bar_back).setOnClickListener(new OnMultiClickListener() {
            @Override
            public void onMultiClick(View v) {
                cancel();
            }
        });

        View viewAddTag = F(R.id.rl_add_tag_info);

        viewAddTag.setOnClickListener(new OnMultiClickListener() {
            @Override
            public void onMultiClick(View v) {
                NavigateToDetailUtil.navigateToTagSort(PublishBaseActivity.this, ids.size() != 0 ? ids : new ArrayList<>());
            }
        });

        rlEmojiIcon.setOnClickListener(new OnMultiClickListener() {
            @Override
            public void onMultiClick(View v) {
                ifNeedShowEmoji();
            }
        });

        rlAddCategory.setOnClickListener(new OnMultiClickListener() {
            @Override
            public void onMultiClick(View v) {
                ifShowCategoryPopView();
            }
        });

        touchEvent();

        //获取分类数据回调
        callbackGetCategoryEvent();

        titleChangeEvent();
    }

    /**
     * 标题超过50字的限制
     */
    private void titleChangeEvent() {
        etTitle.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                int maxSize = 50;
                if (s.length() > maxSize) {
                    etTitle.setText(s.toString().substring(0,maxSize)); //设置EditText只显示前面50位字符
                    etTitle.setSelection(maxSize);//让光标移至末端
                    if (!isShowTextMaxLimit) {
                        ToastUtils.showToast(getResources().getString(R.string.info_place_publish_title_limit));
                        isShowTextMaxLimit = true;
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    /**
     * 是否显示分类pop
     */
    private void ifShowCategoryPopView() {
        if (pickerView != null) {

            //判断软键盘是否显示 如果显示则收起软键盘
            if (keyboardShown) {
                KeyboardUtil.hideKeyboard(llEmojiRootView);
            }

            pickerView.show();
        }
    }

    @Override
    protected void initData() {
        //获取分类数据
        baseViewModel.getCategoryViewModel(this);
    }

    /**
     * //获取分类数据回调
     */
    private void callbackGetCategoryEvent() {
        baseViewModel.getCategory().observe(this, categoryList -> {
            if (categoryList != null && categoryList.size() != 0) {
                initCategoryPopWindow(categoryList);
            }
        });
    }

    /**
     * 初始化分类选择框pop
     *
     * @param categoryListSourceData
     */
    private void initCategoryPopWindow(List<InfoPublishCategoryBean> categoryListSourceData) {
        List<Object> categoryList = baseViewModel.getCategoryList(categoryListSourceData);

        List<String> categoryIdList = baseViewModel.getCategoryIdList(categoryListSourceData);

        pickerView = new OptionsPickerBuilder(this, (options1, options2, options3, v) -> {
            //点击确定按钮后触发
            choiceCategoryId = categoryIdList.get(options1);
            tvAddCategory.setText(String.valueOf(categoryList.get(options1)));
            tvAddCategory.setTextColor(getResources().getColor(R.color.color_ff6b00));
            rlBgAddCategory.setBackgroundResource(R.drawable.bg_category_choice);
            ivBgAddCategory.setImageResource(R.drawable.icon_cat);
            //获取要缓存的分类
            categoryChoiceDataBean = categoryListSourceData.get(options1);
        })
                .setOptionsSelectChangeListener((options1, options2, options3) -> {
                    //切换选中Item项后触发
                })
                .setTitleColor(Color.BLACK)//标题文字颜色
                .setSubmitColor(getResources().getColor(R.color.color_ff6b00))//确定按钮文字颜色
                .setCancelColor(getResources().getColor(R.color.color_7E))//取消按钮文字颜色
                .build();
        pickerView.setNPicker(categoryList, null, null);
        pickerView.setTitleText(getResources().getString(R.string.info_place_publish_add_category));
    }

    /**
     * 获取要缓存的分类实体
     * @return
     */
    public InfoPublishCategoryBean getCategoryChoiceDataBean() {
        return categoryChoiceDataBean;
    }

    /**
     * 获取选中的分类id
     * @return
     */
    public String getChoiceCategoryId() {
        return choiceCategoryId;
    }

    @SuppressLint("ClickableViewAccessibility")
    private void touchEvent() {

    }


    /**
     * 上传文件
     */
    protected abstract void sure();

    public abstract void cancel();


    public abstract PublishVideoDataBean getDataFromCache();

    public abstract void openMedia();

    @SuppressLint("CheckResult")
    private void ifOpenGallery() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {//Android6.0及其以上
            permissionDisposable = rxPermissions.request(Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.CAMERA)
                    .subscribe(granted -> {
                        if (granted) { //权限通过
                            openMedia();

                        } else {       //权限拒绝
                            ToastUtils.showToast("权限已被拒绝");
                        }
                    });
        } else {                                             //Android6.0以下
            openMedia();
        }
    }


    @Override
    protected void processClick(View view) {

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        //选择标签回调
        if (requestCode == TagReqCode.REQ_CODE_PUBLISH_TO_TAG) {
            LogUtils.INSTANCE.e("===z", "选择标签回调");
            if (data == null) return;
            ArrayList<IndexLableLetterBean> resultData = baseViewModel.getResultData(data);
            if (resultData != null && resultData.size() != 0) {
                notifyTagListData(resultData);

            } else {//已经全部取消了数据

//                PublishBaseUtil.clearAllTagsAndIdsNotifyData(PublishBaseActivity.this, listTag, ids, tagCommitAdapter, tvAddTag);
                baseViewModel.clearAllTagsAndIdsNotifyData(listTag, ids);
                tagCommitAdapter.notifyDataSetChanged();
                tvAddTag.setText(getResources().getString(R.string.info_place_publish_add_tag));

            }
        }
    }

    private void notifyFromCacheData(PublishVideoDataBean bean) {
        if (bean == null) return;
        notifyTagListData(bean.getTagList());
        notifyTitleData(bean.getTitle());

        InfoPublishCategoryBean categoryBean = bean.getCategoryBean();
        if (categoryBean != null) {
            choiceCategoryId = categoryBean.getId();
            tvAddCategory.setText(String.valueOf(categoryBean.getName()));
            tvAddCategory.setTextColor(getResources().getColor(R.color.color_ff6b00));
            rlBgAddCategory.setBackgroundResource(R.drawable.bg_category_choice);
            ivBgAddCategory.setImageResource(R.drawable.icon_cat);
            //获取要缓存的分类
            categoryChoiceDataBean = categoryBean;
        }
    }

    private void notifyTitleData(String title) {
        if (!TextUtils.isEmpty(title)) {
            etTitle.setText(title);
        }
    }

    private void notifyTagListData(ArrayList<IndexLableLetterBean> resultData) {
//        PublishBaseUtil.notifyTagListData(resultData, PublishBaseActivity.this, listTag, ids, tagCommitAdapter, tvAddTag);

        if (resultData != null) {
            baseViewModel.notifyTagListData(resultData,listTag);
            tagCommitAdapter.notifyDataSetChanged();

            baseViewModel.clearAndAddIds(resultData,ids);

            if (listTag.size() == 0) {
                tvAddTag.setText(getResources().getString(R.string.info_place_publish_add_tag));
            } else {
                StringBuilder sbAddTag = new StringBuilder();
                sbAddTag.append(getResources().getString(R.string.info_place_publish_add_tag)).append("(").append(listTag.size()).append(")");
                tvAddTag.setText(sbAddTag.toString());
            }
        }
    }

    /**
     * 获取tag列表
     *
     * @return
     */
    public ArrayList<IndexLableLetterBean> getParamTagsList() {
        return listTag;
    }

    /**
     * 获取文章标题
     *
     * @return
     */
    public String getVideoOrArticleTitle() {
        return etTitle.getText().toString().trim();
    }

    public EditText getTitleEditText() {
        return etTitle;
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        dispose(permissionDisposable);
    }

    private void dispose(Disposable disposable) {
        if (disposable != null && disposable.isDisposed()) {
            disposable.dispose();
        }
    }


    private boolean shouldShowEmoji;

    /**
     * 是否打开emoji表情包
     */
    private void ifNeedShowEmoji() {

        if (keyboardShown) {//软键盘和表情包都显示了 需要隐藏软键盘
            KeyboardUtil.hideKeyboard(llEmojiRootView);

            shouldShowEmoji = true;

        } else {

            //判断emoji表情包是否显示
            if (llEmojiRootView.getVisibility() == View.GONE) {
                shouldShowEmoji = true;
            } else {
                shouldShowEmoji = false;
            }
        }

        llEmojiRootView.setVisibility(View.VISIBLE);


    }

    /**
     * 监听软键盘
     */
    private class KeyboardOnGlobalChangeListener implements ViewTreeObserver.OnGlobalLayoutListener {

        @Override
        public void onGlobalLayout() {
            //判断是否显示了软键盘
            keyboardShown = KeyBoardHeightUtil.isKeyboardShown(decorRootView);

            if (keyboardShown) {
                shouldShowEmoji = false;
            }

            if (!shouldShowEmoji) {

                if (keyboardShown) {//显示了软键盘
                    //当软键盘弹起的时候 显示emoji布局
                    llEmojiRootView.setVisibility(View.VISIBLE);

                } else {//隐藏了软键盘 隐藏表情包
                    llEmojiRootView.setVisibility(View.GONE);
                }

            }


        }
    }


}
