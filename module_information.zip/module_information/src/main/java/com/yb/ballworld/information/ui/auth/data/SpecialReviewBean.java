package com.yb.ballworld.information.ui.auth.data;

/**
 * @author Gethin
 * @time 2019/11/20 14:30
 */

public class SpecialReviewBean {

    /**
     * 查询成功
     * {"code":200,"msg":"操作成功","data":{"id":"3","name":"哈哈哈","phoneNum":"1865885966966","idCard":"545757679767976797","idUrl":"http://sta.5yqz2.com/static/avatar/cf4e6f3feb8d821d2577cd74fe502ad6.jpg","imgUrl":"http://sta.5yqz2.com/static/avatar/0c0bfa040a1db52a32a19a8603e5b5f3.jpg","userId":"0","reviewStatus":0}}
     */

    /**
     * 重复
     * {
     *     "code":80032,
     *     "msg":"该用户已提交申请",
     *     "data":null
     * }
     */

    public static final String TYPE_SAVE = "save";
    public static final String TYPE_UPDATE = "update";

    // 审核状态
    public static final int AUTH_ING = 0;      // 待审核
    public static final int AUTH_SUCCESS = 1;  // 审核通过
    public static final int AUTH_FAILURE = 2;  // 审核未通过

    private String id;
    private String idCard;
    private String idUrl;
    private String imgUrl;
    private String name;
    private String phoneNum;
    private String userId;
    private int reviewStatus;
    private String code;

    private String submitType = "";

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public int getReviewStatus() {
        return reviewStatus;
    }

    public void setReviewStatus(int reviewStatus) {
        this.reviewStatus = reviewStatus;
    }

    public String getSubmitType() {
        return submitType;
    }

    public void setSubmitType(String submitType) {
        this.submitType = submitType;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getIdUrl() {
        return idUrl;
    }

    public void setIdUrl(String idUrl) {
        this.idUrl = idUrl;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Override
    public String toString() {
        return "SpecialReviewBean{" +
                "id='" + id + '\'' +
                ", idCard='" + idCard + '\'' +
                ", idUrl='" + idUrl + '\'' +
                ", imgUrl='" + imgUrl + '\'' +
                ", name='" + name + '\'' +
                ", phoneNum='" + phoneNum + '\'' +
                ", userId='" + userId + '\'' +
                ", reviewStatus=" + reviewStatus +
                ", submitType='" + submitType + '\'' +
                '}';
    }
}
