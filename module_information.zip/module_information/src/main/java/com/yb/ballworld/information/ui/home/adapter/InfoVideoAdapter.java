package com.yb.ballworld.information.ui.home.adapter;

import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.yb.ballworld.baselib.utils.NetWorkUtils;
import com.yb.ballworld.common.sharesdk.ShareSdkParamBean;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.bean.HomeInfoListBean;
import com.yb.ballworld.information.ui.home.bean.InfoListEntity;
import com.yb.ballworld.information.ui.home.utils.CommentHotUtil;
import com.yb.ballworld.information.ui.home.utils.GlideLoadImgUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;

import java.util.List;

import cn.jzvd.Jzvd;
import cn.jzvd.JzvdStd;

/**
 * Desc 资讯列表页视频adapter
 * Date 2019/10/7
 * author mengk
 */
public class InfoVideoAdapter extends BaseQuickAdapter<InfoListEntity.ListBean, BaseViewHolder> {

    private String savePlayerUrl;
    /**
     * Same as QuickAdapter#QuickAdapter(Context,int) but with
     * some initialization data.
     *
     * @param data A new list is created out of this one to avoid mutable list
     */
    public InfoVideoAdapter(List<InfoListEntity.ListBean> data) {
        super(R.layout.item_info_type_video, data);
    }


    @Override
    protected void convert(BaseViewHolder helper, InfoListEntity.ListBean item, int pos) {
        String id = item.getId();
        if (TextUtils.isEmpty(id)) return;

        //设置评论
        CommentHotUtil.setHotComment(mContext,helper.getView(R.id.iv_comment_icon),helper.getView(R.id.tv_comment_count_video),item.getCommentCount());

        //点赞按钮
        NavigateToDetailUtil.showShareToast(helper.getView(R.id.rl_share_root_view),mContext,
                new ShareSdkParamBean(item.getTitle(),item.getWebShareUrl(),item.getPreview(),item.getImgUrl(),item.getWebShareUrl()));

        View rootView = helper.getView(R.id.ll_root_view_video);
        rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavigateToDetailUtil.navigateToDetail(mContext,id,true);
            }
        });

        //标题
        TextView tvTitle = helper.getView(R.id.tv_title);
        String title = item.getTitle();
        tvTitle.setText(!TextUtils.isEmpty(title) ? title : "title");

        //封面
        ImageView ivFaceImg = helper.getView(R.id.iv_img2);
        String imgUrl = item.getImgUrl();
        GlideLoadImgUtil.loadImg(mContext,imgUrl,ivFaceImg);


        //点赞count
        TextView tvPraise = helper.getView(R.id.tv_praise_video);
//        int praiseCount = PreferencesHelper.INSTANCE.getPref(id,0);
        int likeCount = item.getLikeCount();
        String like = likeCount + "";
        tvPraise.setText(like);

        //播放器
        JzvdStd player = helper.getView(R.id.js_player);

        ivFaceImg.setVisibility(View.VISIBLE);

        //点击播放按钮
        ImageView ivClickPlay = helper.getView(R.id.iv_player_video);

        ivClickPlay.setVisibility(View.GONE);

        player.setUp(
                item.getPlayUrl(),
                "", Jzvd.SCREEN_NORMAL);
//        //判断是否是WiFi
//        if (NetWorkUtils.INSTANCE.isWifiConnected()) {//wifi自动播放
//            if (TextUtils.isEmpty(savePlayerUrl)) {
//                savePlayerUrl = item.getPlayUrl();
//                player.startVideo();
//                player.setEndListener(new Jzvd.VideoEndListener() {
//                    @Override
//                    public void onEnd() {
//                        savePlayerUrl = "";
//                        // player.startVideo();
//                    }
//                });
//            }
//        }

//        Glide.with(mContext).load(imgUrl).into(player.thumbImageView);
        GlideLoadImgUtil.loadPlayerFaceImg(mContext,imgUrl,player.thumbImageView);

        //点赞
//        helper.addOnClickListener(R.id.iv_praise_icon);
        helper.addOnClickListener(R.id.rl_praise_root);
//        Boolean pref = PreferencesHelper.INSTANCE.getPref(id, false);
        boolean hasFocus = item.isIsLike();
        helper.getView(R.id.iv_praise_icon).setSelected(hasFocus);

    }

    /**
     * 刷新条目中指定view
     * @param baseViewHolder
     * @param item
     */
    public void changeLike(BaseViewHolder baseViewHolder, InfoListEntity.ListBean item) {
        ImageView ivLike = baseViewHolder.getView(R.id.iv_praise_icon);
        TextView tvLike = baseViewHolder.getView(R.id.tv_praise_video);
        if (ivLike != null) {
            ivLike.setSelected(item.isIsLike());
        }
        if (tvLike != null) {
            tvLike.setText(String.valueOf(item.getLikeCount()));
        }
    }

}
