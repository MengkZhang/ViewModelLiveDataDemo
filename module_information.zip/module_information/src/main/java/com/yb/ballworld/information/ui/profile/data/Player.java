package com.yb.ballworld.information.ui.profile.data;

/**
 * 球员信息
 */
public class Player {
    private int id; // 球员ID
    private String cnAlias;
    private String enAlias;
    private String cnName;
    private String enName;
    private String picUrl;
    private int height;
    private int weight;
    private String nationality;
    private String birthdate;
    private String marketvalue;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCnAlias() {
        return defaultValue(cnAlias);
    }

    public void setCnAlias(String cnAlias) {
        this.cnAlias = cnAlias;
    }

    public String getEnAlias() {
        return defaultValue(enAlias);
    }

    public void setEnAlias(String enAlias) {
        this.enAlias = enAlias;
    }

    public String getCnName() {
        return defaultValue(cnName);
    }

    public void setCnName(String cnName) {
        this.cnName = cnName;
    }

    public String getEnName() {
        return defaultValue(enName);
    }

    public void setEnName(String enName) {
        this.enName = enName;
    }

    public String getPicUrl() {
        return defaultValue(picUrl);
    }

    public void setPicUrl(String picUrl) {
        this.picUrl = picUrl;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getNationality() {
        return defaultValue(nationality);
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getBirthdate() {
        return defaultValue(birthdate);
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    public String getMarketvalue() {
        return defaultValue(marketvalue);
    }

    public void setMarketvalue(String marketvalue) {
        this.marketvalue = marketvalue;
    }


    private String defaultValue(String v) {
        return v == null ? "-" : v;
    }
}
