package com.yb.ballworld.information.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.alibaba.android.arouter.launcher.ARouter;
import com.bfw.util.ToastUtils;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.constant.Constant;
import com.yb.ballworld.baselib.core.RouterHub;
import com.yb.ballworld.baselib.data.UserInfo;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.baselib.utils.ViewUtils;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.sharesdk.ShareSdkParamBean;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.http.InforMationHttpApi;
import com.yb.ballworld.information.ui.home.constant.PublishCommentStatus;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;

/**
 * Desc: <功能简述>
 * Author: JS-Dugu
 * Created On: 2019/10/18 18:26
 */
public class NewsDetailBottomLayout extends LinearLayout {

    private TextView tvChatHint;
    private RelativeLayout rlInforCollect;
    private ImageView imgCollect;
    private RelativeLayout rlInforShare;
    private String newsId;
    private String replyId;
    private int commentStatus;
    private AppCompatActivity context;
    public static final int STYLE_TEXT_ONLY = 1;
    public static final int STYLE_DEFAULT = 0;

    public static final int TYPE_ARTICLE = 0;
    public static final int TYPE_COMMENT = 1;
    public static final int TYPE_TOPIC = 2;
    private int publishType = TYPE_ARTICLE;
    private boolean isCollected;
    private InforMationHttpApi inforMationHttpApi = new InforMationHttpApi();
    private ShareSdkParamBean mShareSdkParamBean;

    public NewsDetailBottomLayout(Context context) {
        super(context);
        this.context = (AppCompatActivity) context;
        init();
    }

    public NewsDetailBottomLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        this.context = (AppCompatActivity) context;
        init();
    }

    public void setShareSdkParamBean(ShareSdkParamBean shareSdkParamBean) {
        this.mShareSdkParamBean = shareSdkParamBean;
    }

    /**
     * 设置参数
     *
     * @param commentStatus 评论的状态 1正常 0禁用
     * @param newsId        新闻id
     * @param replyId       回复id
     */
    public void setParam(int commentStatus, String newsId, String replyId) {
        this.commentStatus = commentStatus;
        this.newsId = newsId;
        this.replyId = replyId;
    }

    /**
     * 设置参数
     *
     * @param commentStatus 用户是否 1正常 0禁用
     * @param newsId        新闻id
     * @param replyId       回复id
     */
    public void setParam(int commentStatus, String newsId, String replyId, int publishType) {
        this.commentStatus = commentStatus;
        this.newsId = newsId;
        this.replyId = replyId;
        this.publishType = publishType;
        initCollectImg(false);
    }

    /**
     * 设置参数
     *
     * @param commentStatus 用户是否 1正常 0禁用
     * @param newsId        新闻id
     * @param replyId       回复id
     * @param isFavorites   是否已收藏
     */
    public void setParam(int commentStatus, String newsId, String replyId, boolean isFavorites) {
        this.commentStatus = commentStatus;
        this.newsId = newsId;
        this.replyId = replyId;
        this.isCollected = isFavorites;
        initCollectImg(isCollected);
    }

    public void switchStyle(int style) {
        if (STYLE_TEXT_ONLY == style) {
            switch2OnlyEdit();
        } else {
            switch2Default();
        }
    }

    private void switch2OnlyEdit() {
        if (rlInforCollect != null) {
            rlInforCollect.setVisibility(View.GONE);
        }
        if (rlInforShare != null) {
            rlInforShare.setVisibility(View.GONE);
        }
        if (tvChatHint != null) {
            tvChatHint.setVisibility(View.VISIBLE);
            MarginLayoutParams marginLayoutParams = (MarginLayoutParams) tvChatHint.getLayoutParams();
            marginLayoutParams.setMarginEnd(ViewUtils.dp2px(12));
            marginLayoutParams.setMarginStart(ViewUtils.dp2px(12));
        }
    }

    private void switch2Default() {
        if (rlInforCollect != null) {
            rlInforCollect.setVisibility(View.VISIBLE);
        }
        if (rlInforShare != null) {
            rlInforShare.setVisibility(View.VISIBLE);
        }
        if (tvChatHint != null) {
            tvChatHint.setVisibility(View.VISIBLE);
            MarginLayoutParams marginLayoutParams = (MarginLayoutParams) tvChatHint.getLayoutParams();
            marginLayoutParams.setMarginEnd(ViewUtils.dp2px(24));
            marginLayoutParams.setMarginStart(ViewUtils.dp2px(12));
        }
    }

    private void init() {
        setOrientation(VERTICAL);
        this.removeAllViews();
        View view = LayoutInflater.from(getContext()).inflate(R.layout.news_details_bottom_layout, this, false);
        this.addView(view);
        tvChatHint = view.findViewById(R.id.tvChatHint);
        rlInforCollect = view.findViewById(R.id.rlInforCollect);
        imgCollect = view.findViewById(R.id.imgCollect);
        rlInforShare = view.findViewById(R.id.rlInforShare);

        tvChatHint.setOnClickListener(v -> {
//                ToastUitl.showShort(R.string.prompt_coding);
            UserInfo userInfo = LoginOrdinaryUtils.INSTANCE.getUserInfo();
            if (userInfo == null) {//未登录
                NavigateToDetailUtil.toLogin(context);
            } else {               //已登录
                if (TYPE_ARTICLE == publishType) {
                    if (PublishCommentStatus.ENABLE == commentStatus) { //资讯可评论
                        NavigateToDetailUtil.navigateToPublishComment(context, newsId, replyId);
                    } else {                                            //资讯不可评论
                        ToastUtils.showToast(R.string.prompt_comment_un_enable);
                    }
                } else if(TYPE_COMMENT== publishType) {
                    if (PublishCommentStatus.ENABLE == commentStatus) { //资讯可评论
                        NavigateToDetailUtil.navigateToPublishComment(context, newsId, replyId);
                    } else {                                            //资讯不可评论
                        ToastUtils.showToast(R.string.prompt_userUnavailable);
                    }
                }else if(TYPE_TOPIC==publishType){
                    if (PublishCommentStatus.ENABLE == commentStatus) { //资讯可评论
                        NavigateToDetailUtil.navigateToPublishTopicComment(context, newsId, replyId);
                    } else {                                            //资讯不可评论
                        ToastUtils.showToast(R.string.prompt_userUnavailable);
                    }
                }
            }
        });

        rlInforCollect.setOnClickListener(v -> {
            if (LoginOrdinaryUtils.INSTANCE.getUserInfo() == null) {
                toLogin();
                return;
            }
            if (isCollected) {
                inforMationHttpApi.removeCollectInfo(newsId, new LifecycleCallback<String>(context) {
                    @Override
                    public void onSuccess(String data) {
                        ToastUtils.showToast("取消收藏成功");
                        isCollected = false;
                        initCollectImg(false);
                        LiveEventBus.get().with(LiveEventBusKey.KEY_INFO_REMOVE_COLLECT).post(newsId);
                    }

                    @Override
                    public void onFailed(int errCode, String errMsg) {
                        ToastUtils.showToast(errMsg);
                    }
                });
            } else {
                inforMationHttpApi.collectInfo(newsId, new LifecycleCallback<String>(context) {
                    @Override
                    public void onSuccess(String data) {
                        ToastUtils.showToast("收藏成功");
                        isCollected = true;
                        initCollectImg(true);
                        LiveEventBus.get().with(LiveEventBusKey.KEY_INFO_COLLECT).post(newsId);
                    }

                    @Override
                    public void onFailed(int errCode, String errMsg) {
                        ToastUtils.showToast(errMsg);
                    }
                });
            }
        });
        rlInforShare.setOnClickListener(v -> {
            if (mShareSdkParamBean != null) {
                NavigateToDetailUtil.showShareToast(v, context, mShareSdkParamBean);
            }
        }

        );
    }

    private void toLogin() {
        ARouter.getInstance().build(RouterHub.USER_LOGIN_REGISTER_ACTIVITY)
                .navigation(context, Constant.COMMON_LOGIN_REQUEST);
    }

    private void initCollectImg(boolean isCollect) {
        imgCollect.setImageResource(isCollect ? R.drawable.ic_infor_collect_selected : R.drawable.ic_infor_collect_normal);
    }

}
