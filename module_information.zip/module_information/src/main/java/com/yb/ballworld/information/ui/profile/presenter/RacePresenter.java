package com.yb.ballworld.information.ui.profile.presenter;

import androidx.lifecycle.LifecycleOwner;

import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.livedata.LiveDataWrap;
import com.yb.ballworld.information.ui.profile.data.ClubSeasonAgendaBean;
import com.yb.ballworld.information.ui.profile.http.ProfileHttp;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * @author Gethin
 * @time 2019/11/9 14:25
 */

public class RacePresenter extends BasePresenter<LifecycleOwner, VoidModel> {

    private ProfileHttp http = new ProfileHttp();
    public LiveDataWrap<List<ClubSeasonAgendaBean>> seasonAgenda = new LiveDataWrap<>();

    public void loadRaceData(String teamId, String seasonId) {
        add(http.getClubSeasonAgenda(teamId, seasonId, new LifecycleCallback<List<ClubSeasonAgendaBean>>(mView) {
            @Override
            public void onSuccess(List<ClubSeasonAgendaBean> data) {
                if (data != null && data.size() > 0) {
                    List<ClubSeasonAgendaBean> clubSeasonAgendaBeans = new ArrayList<>();
                    Calendar calendar = Calendar.getInstance();
                    int tempY = 0;
                    int tempM = 0;
                    for (int i = 0; i < data.size(); i++) {
                        ClubSeasonAgendaBean content = data.get(i);
                        content.setItemType(ClubSeasonAgendaBean.CONTENT);
                        long matchTime = data.get(i).getMatchTime();
                        calendar.setTimeInMillis(matchTime);
                        int y = calendar.get(Calendar.YEAR);
                        int m = calendar.get(Calendar.MONTH);
                        if ((y != tempY) || (m != tempM)) { //比较若为不同月份增加一个头部分区
                            ClubSeasonAgendaBean header = new ClubSeasonAgendaBean();
                            header.setItemType(ClubSeasonAgendaBean.HEADER);
                            header.setMatchTime(matchTime);
                            clubSeasonAgendaBeans.add(header);
                        }
                        tempY = y;
                        tempM = m;
                        clubSeasonAgendaBeans.add(content);
                    }
                    seasonAgenda.setData(clubSeasonAgendaBeans);
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                seasonAgenda.setError(errCode, errMsg);
            }
        }));
    }
}
