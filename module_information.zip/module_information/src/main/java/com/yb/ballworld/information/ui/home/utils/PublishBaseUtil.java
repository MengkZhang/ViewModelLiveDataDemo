package com.yb.ballworld.information.ui.home.utils;

import android.content.Intent;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.adapter.TagCommitAdapter;
import com.yb.ballworld.information.ui.home.bean.IndexLableLetterBean;
import com.yb.ballworld.information.ui.home.constant.TagParams;

import java.util.ArrayList;

/**
 * Desc
 * Date 2019/11/15
 * author mengk
 */
public class PublishBaseUtil {

    public static ArrayList<IndexLableLetterBean> getResultData(Intent data) {
        return ((ArrayList<IndexLableLetterBean>) data.getSerializableExtra(TagParams.INTENT_PARAM_DATA));
    }

    public static void clearAllTagsAndIdsNotifyData(AppCompatActivity activity,ArrayList<IndexLableLetterBean> listTag, ArrayList<String> ids, TagCommitAdapter tagCommitAdapter, TextView tvAddTag) {
        listTag.clear();
        ids.clear();
        tagCommitAdapter.notifyDataSetChanged();
        tvAddTag.setText(activity.getResources().getString(R.string.info_place_publish_add_tag));
    }

    public static void notifyTagListData(ArrayList<IndexLableLetterBean> resultData,
                                         AppCompatActivity activity,ArrayList<IndexLableLetterBean> listTag,
                                         ArrayList<String> ids, TagCommitAdapter tagCommitAdapter, TextView tvAddTag) {
        if (resultData != null) {
            listTag.clear();
            listTag.addAll(resultData);
            tagCommitAdapter.notifyDataSetChanged();
            for (IndexLableLetterBean resultDatum : resultData) {
                ids.add(String.valueOf(resultDatum.getId()));
                LogUtils.INSTANCE.e("===z", "返回的数据 = " + resultDatum.getLable() + "");
            }
            if (listTag.size() == 0) {
                tvAddTag.setText(activity.getResources().getString(R.string.info_place_publish_add_tag));
            } else {
                StringBuilder sbAddTag = new StringBuilder();
                sbAddTag.append(activity.getResources().getString(R.string.info_place_publish_add_tag)).append("(").append(listTag.size()).append(")");
                tvAddTag.setText(sbAddTag.toString());
            }
        }
    }
}
