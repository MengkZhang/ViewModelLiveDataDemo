package com.yb.ballworld.information.ui.home.constant;

import androidx.annotation.IntDef;
import androidx.annotation.StringDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Desc 区分资讯类型
 * Date 2019/10/9
 * author mengk
 */
@StringDef({
        HotVideoType.TYPE_NEWS,
        HotVideoType.TYPE_VIDEO
})

@Retention(RetentionPolicy.SOURCE)

public @interface HotVideoType {
    //0 新闻
    String TYPE_NEWS = "0";
    //1 视频
    String TYPE_VIDEO = "1";
}
