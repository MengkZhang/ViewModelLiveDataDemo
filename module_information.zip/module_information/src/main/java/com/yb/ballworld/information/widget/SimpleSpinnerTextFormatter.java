package com.yb.ballworld.information.widget;

import android.text.Spannable;
import android.text.SpannableString;

/**
* Desc:
* @author ink
* created at 2019/10/7 23:04
*/
public class SimpleSpinnerTextFormatter implements SpinnerTextFormatter {

    @Override
    public Spannable format(Object item) {
        return new SpannableString(item.toString());
    }
}
