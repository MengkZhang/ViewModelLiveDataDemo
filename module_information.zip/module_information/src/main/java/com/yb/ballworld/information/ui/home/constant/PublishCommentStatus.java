package com.yb.ballworld.information.ui.home.constant;

import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Desc 评论状态
 * Date 2019/10/16
 * author mengk
 */
@IntDef({
        PublishCommentStatus.ENABLE,
        PublishCommentStatus.UN_ENABLE
})

@Retention(RetentionPolicy.SOURCE)

public @interface PublishCommentStatus {
    //评论状态（1: 正常,0: 禁用）
    int ENABLE = 1;
    int UN_ENABLE = 0;
}
