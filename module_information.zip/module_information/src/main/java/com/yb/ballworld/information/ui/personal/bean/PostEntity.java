package com.yb.ballworld.information.ui.personal.bean;

import android.util.Log;

import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.information.ui.personal.constant.AdapterConstant;

import java.util.List;
import java.util.PropertyResourceBundle;

/**
 * Desc: 2019/10/24 结构修改
 * Author: JS-Kylo
 * Created On: 2019/10/17 16:16
 */
public class PostEntity {

    /**
     * totalCount : 371
     * pageNum : 1
     * pageSize : 10
     * totalPage : 38
     * list : [{"title":"里奥莱因克尔分析拜仁大战热刺[中字]","imgUrl":"http://tu.duoduocdn.com/v/img/191003/274998_04231944108.jpg","preview":"里奥莱因克尔分析拜仁大战热刺[中字]","keywords":"英超,热刺,德甲","id":"8ded8d8d470d4e2281ec293ffa55e943","userId":"999","categoryId":"13","nickName":"","content":"","pageViews":693,"createdDate":"2019-10-07 11:36:12","mediaType":1,"playUrl":"http://1251542705.vod2.myqcloud.com/9665f9bfvodgzp1251542705/6a6cdfbd5285890794569903744/zoO959lJ7GoA.mp4","showType":3,"commentStatus":1,"likeCount":3,"commentCount":0,"status":"","appShowType":8,"newsImgs":[{"newsId":"8ded8d8d470d4e2281ec293ffa55e943","imgUrl":"http://sta.5yqz2.com/static/avatar/zhibo@2x.png","content":""},{"newsId":"8ded8d8d470d4e2281ec293ffa55e943","imgUrl":"http://sta.5yqz2.com/static/avatar/shoucang@2x.png","content":""},{"newsId":"8ded8d8d470d4e2281ec293ffa55e943","imgUrl":"http://sta.5yqz2.com/static/avatar/199d2e104ebe06c444ceba4f7fe810e0.png","content":""},{"newsId":"8ded8d8d470d4e2281ec293ffa55e943","imgUrl":"http://sta.5yqz2.com/static/avatar/95f2fc694d87a3bbd791c6cefabcd86e.jpg","content":""}],"isLike":true,"user":{"id":"999","nickname":"fanatik","headImgUrl":"","personalDesc":"我的个人简介","followerCount":0,"articleCount":0,"attentionStatus":"","commentCount":0,"focusCount":0,"dynamicCount":0}},{"title":"过把瘾！盘点足坛另类破门方式","imgUrl":"http://tu.duoduocdn.com/v/img/191003/274999_01234455672.jpg","preview":"过把瘾！盘点足坛另类破门方式","keywords":"英超,西甲,意甲","id":"b61a352bccb547468cc9ee9ed348f9de","userId":"999","categoryId":"13","nickName":"","content":null,"pageViews":359,"createdDate":"2019-10-07 11:36:12","mediaType":1,"playUrl":"http://1251542705.vod2.myqcloud.com/9665f9bfvodgzp1251542705/9da4431c5285890794570762658/nvIjl5VDKH0A.mp4","showType":2,"commentStatus":1,"likeCount":3,"commentCount":1,"status":null,"appShowType":8,"newsImgs":[{"newsId":"b61a352bccb547468cc9ee9ed348f9de","imgUrl":"http://sta.5yqz2.com/static/bfw/20191005/14/04/0/367185637d0b022d91ede589d3b66ad4.jpg","content":null},{"newsId":"b61a352bccb547468cc9ee9ed348f9de","imgUrl":"http://sta.5yqz2.com/static/avatar/shoucang@2x.png","content":null}],"isLike":true,"user":{"id":"999","nickname":"fanatik","headImgUrl":null,"personalDesc":"我的个人简介","followerCount":null,"articleCount":null,"attentionStatus":null,"commentCount":null,"focusCount":null,"dynamicCount":null}},{"title":"身材如何？佩嫂性感比基尼下水游泳","imgUrl":"http://tu.duoduocdn.com/v/img/190928/274346_02104928344.jpg","preview":"身材如何？佩嫂性感比基尼下水游泳","keywords":"中超,山东鲁能,花边","id":"6d7f8c5a877847cd9283ce528953ff12","userId":"999","categoryId":"3","nickName":null,"content":null,"pageViews":427,"createdDate":"2019-10-07 11:36:12","mediaType":1,"playUrl":"http://1251542705.vod2.myqcloud.com/9665f9bfvodgzp1251542705/633508bb5285890794409523967/naOITHEn52UA.mp4","showType":1,"commentStatus":1,"likeCount":0,"commentCount":0,"status":null,"appShowType":8,"newsImgs":[{"newsId":"6d7f8c5a877847cd9283ce528953ff12","imgUrl":"http://sta.5yqz2.com/static/avatar/199d2e104ebe06c444ceba4f7fe810e0.png","content":null}],"isLike":false,"user":{"id":"999","nickname":"fanatik","headImgUrl":null,"personalDesc":"我的个人简介","followerCount":null,"articleCount":null,"attentionStatus":null,"commentCount":null,"focusCount":null,"dynamicCount":null}},{"title":"足坛各种愚蠢红牌合集","imgUrl":"http://tu.duoduocdn.com/v/img/191002/274885_04235913214.jpg","preview":"足坛各种愚蠢红牌合集","keywords":"英超,西甲,意甲","id":"fdf700122dd348d9831a4321b084b5fb","userId":"999","categoryId":"13","nickName":null,"content":null,"pageViews":986,"createdDate":"2019-10-07 11:36:12","mediaType":1,"playUrl":"http://1251542705.vod2.myqcloud.com/9665f9bfvodgzp1251542705/1c73eeee5285890794541355702/LjjaOWWr0WkA.mp4","showType":0,"commentStatus":1,"likeCount":3,"commentCount":1,"status":null,"appShowType":8,"newsImgs":null,"isLike":true,"user":{"id":"999","nickname":"fanatik","headImgUrl":null,"personalDesc":"我的个人简介","followerCount":null,"articleCount":null,"attentionStatus":null,"commentCount":null,"focusCount":null,"dynamicCount":null}},{"title":"让人惋惜！盘点足坛天才堕落球员","imgUrl":"http://tu.duoduocdn.com/v/img/191005/275156_03035919318.jpg","preview":"让人惋惜！盘点足坛天才堕落球员","keywords":"英超,西甲,意甲","id":"9295263c974f4ced941ce23e0dad96f9","userId":"999","categoryId":"12","nickName":null,"content":null,"pageViews":141,"createdDate":"2019-10-07 11:36:12","mediaType":1,"playUrl":"http://1251542705.vod2.myqcloud.com/9665f9bfvodgzp1251542705/d04005d95285890794604768066/sciFXDxdrrMA.mp4","showType":0,"commentStatus":1,"likeCount":3,"commentCount":2,"status":null,"appShowType":8,"newsImgs":null,"isLike":true,"user":{"id":"999","nickname":"fanatik","headImgUrl":null,"personalDesc":"我的个人简介","followerCount":null,"articleCount":null,"attentionStatus":null,"commentCount":null,"focusCount":null,"dynamicCount":null}},{"title":"若日尼奥训练赛倒地后遭队友各种欺负","imgUrl":"http://sta.5yqz2.com/static/avatar/LogUtils.INSTANCE.png","preview":"若日尼奥训练赛倒地后遭队友各种欺负","keywords":"英超,切尔西,足球","id":"4d407ab76b204fb9a7d085d4b60303a9","userId":"999","categoryId":"10","nickName":null,"content":null,"pageViews":780,"createdDate":"2019-10-07 11:36:12","mediaType":1,"playUrl":"http://sta.5yqz2.com/static/avatar/video_2019-09-22_12-03-39.mp4","showType":0,"commentStatus":1,"likeCount":4,"commentCount":0,"status":null,"appShowType":8,"newsImgs":null,"isLike":true,"user":{"id":"999","nickname":"fanatik","headImgUrl":null,"personalDesc":"我的个人简介","followerCount":null,"articleCount":null,"attentionStatus":null,"commentCount":null,"focusCount":null,"dynamicCount":null}},{"title":"苏超-迪福帽子戏法 流浪者5-0大胜汉密尔顿","imgUrl":"http://tu.duoduocdn.com/v/img/191007/275418_01052817153.jpg","preview":"苏超-迪福帽子戏法 流浪者5-0大胜汉密尔顿","keywords":"英超,苏超,足球","id":"f7af9bc86ae24c3ba9f41b7bb205d034","userId":"999","categoryId":"10","nickName":null,"content":null,"pageViews":797,"createdDate":"2019-10-07 11:36:12","mediaType":1,"playUrl":"http://1251542705.vod2.myqcloud.com/9665f9bfvodgzp1251542705/ef4711755285890794666590034/5Ri5Wrjjv9oA.mp4","showType":0,"commentStatus":1,"likeCount":1,"commentCount":2,"status":null,"appShowType":8,"newsImgs":null,"isLike":true,"user":{"id":"999","nickname":"fanatik","headImgUrl":null,"personalDesc":"我的个人简介","followerCount":null,"articleCount":null,"attentionStatus":null,"commentCount":null,"focusCount":null,"dynamicCount":null}},{"title":"秀啊！门将疯狂戏耍前锋时刻","imgUrl":"http://tu.duoduocdn.com/v/img/191005/275152_04001336903.jpg","preview":"秀啊！门将疯狂戏耍前锋时刻","keywords":"英超,西甲,意甲","id":"cb802da1cfd041be81cc0c8c193ee641","userId":"999","categoryId":"9","nickName":null,"content":null,"pageViews":1001,"createdDate":"2019-10-07 11:36:12","mediaType":1,"playUrl":"http://1251542705.vod2.myqcloud.com/9665f9bfvodgzp1251542705/ebd9080f5285890794601891701/crwyL4ha3rgA.mp4","showType":0,"commentStatus":1,"likeCount":1,"commentCount":1,"status":null,"appShowType":8,"newsImgs":null,"isLike":true,"user":{"id":"999","nickname":"fanatik","headImgUrl":null,"personalDesc":"我的个人简介","followerCount":null,"articleCount":null,"attentionStatus":null,"commentCount":null,"focusCount":null,"dynamicCount":null}},{"title":"祖国70周年华诞！阿瑙托维奇祝大家国庆快乐","imgUrl":"http://tu.duoduocdn.com/v/img/191001/274771_01223857670.jpg","preview":"祖国70周年华诞！阿瑙托维奇祝大家国庆快乐","keywords":"1232","id":"48c2661e595446bc8c843c389d1200fe","userId":"999","categoryId":"3","nickName":null,"content":null,"pageViews":731,"createdDate":"2019-10-07 11:36:12","mediaType":1,"playUrl":"http://1251542705.vod2.myqcloud.com/9665f9bfvodgzp1251542705/d537f9f25285890794509403078/SECHJhU3ADYA.mp4","showType":0,"commentStatus":1,"likeCount":5,"commentCount":78,"status":null,"appShowType":8,"newsImgs":null,"isLike":true,"user":{"id":"999","nickname":"fanatik","headImgUrl":null,"personalDesc":"我的个人简介","followerCount":null,"articleCount":null,"attentionStatus":null,"commentCount":null,"focusCount":null,"dynamicCount":null}},{"title":"真香！专业分析贡多齐技术特点","imgUrl":"http://tu.duoduocdn.com/v/img/191006/275343_02125016567.jpg","preview":"真香！专业分析贡多齐技术特点","keywords":"英超,阿森纳,足球","id":"500afcf4df1a445182471b6ba7deb387","userId":"999","categoryId":"10","nickName":null,"content":null,"pageViews":577,"createdDate":"2019-10-07 11:36:12","mediaType":1,"playUrl":"http://1251542705.vod2.myqcloud.com/9665f9bfvodgzp1251542705/90cdbb355285890794641338158/mJxTZ2larkYA.mp4","showType":0,"commentStatus":1,"likeCount":3,"commentCount":0,"status":null,"appShowType":8,"newsImgs":null,"isLike":true,"user":{"id":"999","nickname":"fanatik","headImgUrl":null,"personalDesc":"我的个人简介","followerCount":null,"articleCount":null,"attentionStatus":null,"commentCount":null,"focusCount":null,"dynamicCount":null}}]
     */

    private int totalCount;
    private int pageNum;
    private int pageSize;
    private int totalPage;
    private List<ListBean> list;

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    public static class ListBean implements MultiItemEntity {
        /**
         * title : 里奥莱因克尔分析拜仁大战热刺[中字]
         * imgUrl : http://tu.duoduocdn.com/v/img/191003/274998_04231944108.jpg
         * preview : 里奥莱因克尔分析拜仁大战热刺[中字]
         * keywords : 英超,热刺,德甲
         * id : 8ded8d8d470d4e2281ec293ffa55e943
         * userId : 999
         * categoryId : 13
         * nickName :
         * content :
         * pageViews : 693
         * createdDate : 2019-10-07 11:36:12
         * mediaType : 1
         * playUrl : http://1251542705.vod2.myqcloud.com/9665f9bfvodgzp1251542705/6a6cdfbd5285890794569903744/zoO959lJ7GoA.mp4
         * showType : 3
         * commentStatus : 1
         * likeCount : 3
         * commentCount : 0
         * status :
         * appShowType : 8
         * newsImgs : [{"newsId":"8ded8d8d470d4e2281ec293ffa55e943","imgUrl":"http://sta.5yqz2.com/static/avatar/zhibo@2x.png","content":""},{"newsId":"8ded8d8d470d4e2281ec293ffa55e943","imgUrl":"http://sta.5yqz2.com/static/avatar/shoucang@2x.png","content":""},{"newsId":"8ded8d8d470d4e2281ec293ffa55e943","imgUrl":"http://sta.5yqz2.com/static/avatar/199d2e104ebe06c444ceba4f7fe810e0.png","content":""},{"newsId":"8ded8d8d470d4e2281ec293ffa55e943","imgUrl":"http://sta.5yqz2.com/static/avatar/95f2fc694d87a3bbd791c6cefabcd86e.jpg","content":""}]
         * isLike : true
         * user : {"id":"999","nickname":"fanatik","headImgUrl":"","personalDesc":"我的个人简介","followerCount":0,"articleCount":0,"attentionStatus":"","commentCount":0,"focusCount":0,"dynamicCount":0}
         */

        private String title;
        private String imgUrl;
        private String preview;
        private String keywords;
        private String id;
        private String userId;
        private String categoryId;
        private String nickName;
        private String content;
        private int pageViews;
        private String createdDate;
        private int mediaType;
        private String playUrl;
        private int showType;
        private int commentStatus;
        private int likeCount;
        private int commentCount;
        private String status;
        private int appShowType;
        private boolean isLike;
        private UserBean user;
        private String  webShareUrl;
        private String reviewStatus;// 审核状态 0待审核，1审核失败 ，3审核通过
        private List<NewsImgsBean> newsImgs;

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getImgUrl() {
            return imgUrl;
        }

        public void setImgUrl(String imgUrl) {
            this.imgUrl = imgUrl;
        }

        public String getPreview() {
            return preview;
        }

        public void setPreview(String preview) {
            this.preview = preview;
        }

        public String getKeywords() {
            return keywords;
        }

        public void setKeywords(String keywords) {
            this.keywords = keywords;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public String getCategoryId() {
            return categoryId;
        }

        public void setCategoryId(String categoryId) {
            this.categoryId = categoryId;
        }

        public String getNickName() {
            return nickName;
        }

        public void setNickName(String nickName) {
            this.nickName = nickName;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public int getPageViews() {
            return pageViews;
        }

        public void setPageViews(int pageViews) {
            this.pageViews = pageViews;
        }

        public String getCreatedDate() {
            return createdDate;
        }

        public void setCreatedDate(String createdDate) {
            this.createdDate = createdDate;
        }

        public int getMediaType() {
            return mediaType;
        }

        public void setMediaType(int mediaType) {
            this.mediaType = mediaType;
        }

        public String getPlayUrl() {
            return playUrl;
        }

        public void setPlayUrl(String playUrl) {
            this.playUrl = playUrl;
        }

        public int getShowType() {
            return showType;
        }

        public void setShowType(int showType) {
            this.showType = showType;
        }

        public int getCommentStatus() {
            return commentStatus;
        }

        public void setCommentStatus(int commentStatus) {
            this.commentStatus = commentStatus;
        }

        public int getLikeCount() {
            return likeCount;
        }

        public void setLikeCount(int likeCount) {
            this.likeCount = likeCount;
        }

        public int getCommentCount() {
            return commentCount;
        }

        public void setCommentCount(int commentCount) {
            this.commentCount = commentCount;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public int getAppShowType() {
            return appShowType;
        }

        public void setAppShowType(int appShowType) {
            this.appShowType = appShowType;
        }

        public boolean isIsLike() {
            return isLike;
        }

        public void setIsLike(boolean isLike) {
            this.isLike = isLike;
        }

        public UserBean getUser() {
            return user;
        }

        public void setUser(UserBean user) {
            this.user = user;
        }

        public String getWebShareUrl() {
            return webShareUrl;
        }

        public void setWebShareUrl(String webShareUrl) {
            this.webShareUrl = webShareUrl;
        }

        public List<NewsImgsBean> getNewsImgs() {
            return newsImgs;
        }

        public void setNewsImgs(List<NewsImgsBean> newsImgs) {
            this.newsImgs = newsImgs;
        }

        @Override
        public int getItemType() {
            LogUtils.INSTANCE.e("===z","getItemType zhixing");
            if (user ==  null) return AdapterConstant.TYPE_IMG_WITHOUT_HEAD;

            int isEditor = user.getIsEditor();
            if (isEditor == 1) {//特约
                if (mediaType == 1) { //特约视频
                    return AdapterConstant.TYPE_VIDEO_WITH_HEAD;
                } else {              //特约非视频
                    if (showType == 0) {         //特约单图
                        return AdapterConstant.TYPE_IMG_WITH_HEAD;
                    } else if (showType == 1) {  //特约双图
                        return AdapterConstant.TYPE_IMGS_WITH_HEAD;
                    } else {                     //特约多图
                        return AdapterConstant.TYPE_IMGS3_WITH_HEAD;
                    }
                }
            } else {            //非特约
                if (mediaType == 1) { //非特约视频
                    return AdapterConstant.TYPE_VIDEO_WITHOUT_HEAD;
                } else {              //非特约非视频
                    return AdapterConstant.TYPE_IMG_WITHOUT_HEAD;
                }
            }


        }

        public String getReviewStatus() {
            return reviewStatus==null?"":reviewStatus;
        }

        public void setReviewStatus(String reviewStatus) {
            this.reviewStatus = reviewStatus;
        }

        public boolean isEditor(){
            if(user==null) return false;
            return user.getIsEditor()==1;
        }


        public static class UserBean {
            /**
             * id : 999
             * nickname : fanatik
             * headImgUrl :
             * personalDesc : 我的个人简介
             * followerCount : 0
             * articleCount : 0
             * attentionStatus :
             * commentCount : 0
             * focusCount : 0
             * dynamicCount : 0
             */

            private String id;
            private String nickname;
            private String headImgUrl;
            private String personalDesc;
            private int followerCount;
            private int articleCount;
            private String attentionStatus;
            private int commentCount;
            private int focusCount;
            private int dynamicCount;
            private int isEditor;  //是否特约编辑 1是 0 不是
            private int sex;

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public String getNickname() {
                return nickname;
            }

            public void setNickname(String nickname) {
                this.nickname = nickname;
            }

            public String getHeadImgUrl() {
                return headImgUrl;
            }

            public void setHeadImgUrl(String headImgUrl) {
                this.headImgUrl = headImgUrl;
            }

            public String getPersonalDesc() {
                return personalDesc;
            }

            public void setPersonalDesc(String personalDesc) {
                this.personalDesc = personalDesc;
            }

            public int getFollowerCount() {
                return followerCount;
            }

            public void setFollowerCount(int followerCount) {
                this.followerCount = followerCount;
            }

            public int getArticleCount() {
                return articleCount;
            }

            public void setArticleCount(int articleCount) {
                this.articleCount = articleCount;
            }

            public String getAttentionStatus() {
                return attentionStatus;
            }

            public void setAttentionStatus(String attentionStatus) {
                this.attentionStatus = attentionStatus;
            }

            public int getCommentCount() {
                return commentCount;
            }

            public void setCommentCount(int commentCount) {
                this.commentCount = commentCount;
            }

            public int getFocusCount() {
                return focusCount;
            }

            public void setFocusCount(int focusCount) {
                this.focusCount = focusCount;
            }

            public int getDynamicCount() {
                return dynamicCount;
            }

            public void setDynamicCount(int dynamicCount) {
                this.dynamicCount = dynamicCount;
            }

            public int getIsEditor() { return isEditor; }

            public void setIsEditor(int isEditor) { this.isEditor = isEditor; }

            public int getSex() {
                return sex;
            }

            public void setSex(int sex) {
                this.sex = sex;
            }
        }

        public static class NewsImgsBean {
            /**
             * newsId : 8ded8d8d470d4e2281ec293ffa55e943
             * imgUrl : http://sta.5yqz2.com/static/avatar/zhibo@2x.png
             * content :
             */

            private String newsId;
            private String imgUrl;
            private String content;

            public String getNewsId() {
                return newsId;
            }

            public void setNewsId(String newsId) {
                this.newsId = newsId;
            }

            public String getImgUrl() {
                return imgUrl;
            }

            public void setImgUrl(String imgUrl) {
                this.imgUrl = imgUrl;
            }

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }
        }
    }
}
