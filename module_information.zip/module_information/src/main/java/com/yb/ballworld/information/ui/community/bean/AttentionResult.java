package com.yb.ballworld.information.ui.community.bean;

/**
 * Desc: 关注/取消关注返回结果
 * Author: JS-Kylo
 * Created On: 2019/11/11 15:18
 */
public class AttentionResult {

    /**
     * focusCount : 0
     * followerCount : 0
     * headImgUrl :
     * id : 0
     * isAttention : true
     * nickname :
     * popularity : 0
     * postCount : 0
     * sex : 0
     * userId : 0
     */

    private int focusCount;
    private int followerCount;
    private String headImgUrl;
    private int id;
    private boolean isAttention;
    private String nickname;
    private int popularity;
    private int postCount;
    private int sex;
    private int userId;

    public int getFocusCount() {
        return focusCount;
    }

    public void setFocusCount(int focusCount) {
        this.focusCount = focusCount;
    }

    public int getFollowerCount() {
        return followerCount;
    }

    public void setFollowerCount(int followerCount) {
        this.followerCount = followerCount;
    }

    public String getHeadImgUrl() {
        return headImgUrl;
    }

    public void setHeadImgUrl(String headImgUrl) {
        this.headImgUrl = headImgUrl;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public boolean isIsAttention() {
        return isAttention;
    }

    public void setIsAttention(boolean isAttention) {
        this.isAttention = isAttention;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public int getPopularity() {
        return popularity;
    }

    public void setPopularity(int popularity) {
        this.popularity = popularity;
    }

    public int getPostCount() {
        return postCount;
    }

    public void setPostCount(int postCount) {
        this.postCount = postCount;
    }

    public int getSex() {
        return sex;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }
}
