package com.yb.ballworld.information.ui.detail;

/**
* Desc: 资讯常量库
* @author ink
* created at 2019/10/22 17:32
*/
public class InforConstant {

    /**
     * 事件类型
     */
    public static class ItemEvent {
        public static final int NONE = 0;
        public static final int SHARE_ARTICLE = 1;
        public static final int LIKE_ARTICLE = 2;
        public static final int LIKE_COMMENT = 3;
        public static final int SHARE_COMMENT = 4;
        public static final int ROOT_SORT = 5;
        public static final int USER_COMMENT = 6;
        public static final int REPLIES_COMMENT = 7;
    }

    /**
     * 布局类型
     */
    public static class ItemType {
        public static final int DETAIL_NEWS = 0;
        public static final int DETAIL_COMMENT = 1;
        public static final int DETAIL_HEADER_NEWS = 2;
        public static final int DETAIL_HEADER_COMMENT = 6;
        public static final int DETAIL_NO_DATA = 4;
    }

    /**
     * 媒资类型
     */
    public static class MediaType{
        public static final int ITEMTYPE_NO_MEDIA=0;
        public static final int ITEMTYPE_IMGS=1;
        public static final int ITEMTYPE_VIDEO=2;
    }

    /**
     * 网络媒资类型
     */
    public static class WebMediaType{
        public static final int TYPE_OTHER=0;
        public static final int TYPE_LINK=1;
        public static final int TYPE_IMG=2;
        public static final int TYPE_VIDEO=3;
    }

    /**
     * 排序类型
     */
    public static class SortType{
        public static final int ITEMTYPE_HEAT=0;
        public static final int ITEMTYPE_TIME=1;
    }


    public static class TopicDetailItemType{
        public static final int TYPE_TOPIC=0;
        public static final int TYPE_TOPIC_COMMENT_TEXT=1;
        public static final int TYPE_TOPIC_COMMENT_IMAGE=2;
        public static final int TYPE_TOPIC_COMMENT_VIDEO=3;

    }

    public static class CommentKeyForPage{
        public static final String COMMENT="COMMENT";
        public static final String COMMENT_ID="COMMENT_ID";
        public static final String COMMENT_TYPE="COMMENT_TYPE";
        public static final String MAIN_COMMENT_ID="MAIN_COMMENT_ID";

    }
}
