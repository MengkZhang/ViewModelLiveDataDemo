package com.yb.ballworld.information.data;

public class ArticleParser {

}
