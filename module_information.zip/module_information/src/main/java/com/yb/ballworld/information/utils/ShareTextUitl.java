package com.yb.ballworld.information.utils;

import android.text.TextUtils;

public class ShareTextUitl {

    public static String  getShareTitle(String content){
        String title="球天下";
        try{
            if(TextUtils.isEmpty(content)){

            }else if(content.length()>6){
                title=content.substring(0,6);
            }else{
               title=content;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return title;

    }


    public static String getMarksText(String text){
        if(TextUtils.isEmpty(text)){
            return "";
        }
        return "\""+text+"\"";
    }
}
