package com.yb.ballworld.information.ui.home.bean;

/**
 * Desc 资讯列表请求body
 * Date 2019/10/7
 * author mengk
 */
public class InfoRequestBody {
    private int page;
    private boolean isVideo;

    public boolean isVideo() {
        return isVideo;
    }

    public void setVideo(boolean video) {
        isVideo = video;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }
}
