package com.yb.ballworld.information.ui.home.listener;

/**
 * Desc 点赞结果回调listener
 * Date 2019/10/10
 * author mengk
 */
public interface PraiseResultListener {
    void onSuccess();
    void onFail();
}
