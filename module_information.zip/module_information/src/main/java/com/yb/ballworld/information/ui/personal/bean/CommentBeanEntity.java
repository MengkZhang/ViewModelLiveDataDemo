package com.yb.ballworld.information.ui.personal.bean;

import com.yb.ballworld.information.data.CommitBean;

import java.io.Serializable;
import java.util.List;

/**
 * Desc: 评论实体类
 * Author: JS-Kylo
 * Created On: 2019/10/26 11:31
 */
public class CommentBeanEntity  {

    /**
     * totalCount : 61
     * pageNum : 1
     * pageSize : 10
     * totalPage : 7
     * list : [{"id":"140","commentType":1,"newsId":"48c2661e595446bc8c843c389d1200fe","replyId":"0","userId":"1060","content":"不开玩笑😐😑😑环境","imgUrl1":"http://sta.5yqz2.com/static/bfw/20190929/10/00/4/e9465017b861be587000c02ec044ce79.jpg","imgUrl2":"","imgUrl3":"","videoUrl":"","videoCoverUrl":"","likeCount":5,"nickName":"qtx76","headImgUrl":"http://sta.5yqz2.com/static/avatar/6b4a9d89d1d94a02bf8ad44550040772.jpg","createdDate":"2019-10-23 17:58:51","sonNum":0,"isLike":false,"mainCommentId":"0","parent":null,"title":"祖国70周年华诞！阿瑙托维奇祝大家国庆快乐","mediaType":1}]
     */

    private int totalCount;
    private int pageNum;
    private int pageSize;
    private int totalPage;
    private List<CommentBean> list;

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<CommentBean> getList() {
        return list;
    }

    public void setList(List<CommentBean> list) {
        this.list = list;
    }
}