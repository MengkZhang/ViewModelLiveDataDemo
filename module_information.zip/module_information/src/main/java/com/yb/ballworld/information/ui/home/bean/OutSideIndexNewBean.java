package com.yb.ballworld.information.ui.home.bean;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * Desc 外层索引列表数据
 * Date 2019/11/7
 * author mengk
 */
public class OutSideIndexNewBean  implements Parcelable {

    /**
     * hotTournamentList : [{"id":26,"matchCount":1,"cnAlias":"瑞典超","headLetter":"R","isHot":1}]
     * A : [{"id":1407,"matchCount":8,"cnAlias":"阿后备","headLetter":"A","isHot":0},{"id":743,"matchCount":2,"cnAlias":"阿拉冠","headLetter":"A","isHot":0},{"id":11139,"matchCount":2,"cnAlias":"阿维女锦","headLetter":"A","isHot":0},{"id":1395,"matchCount":4,"cnAlias":"爱尔高联","headLetter":"A","isHot":0},{"id":268,"matchCount":1,"cnAlias":"爱沙杯","headLetter":"A","isHot":0}]
     * B : [{"id":521,"matchCount":1,"cnAlias":"巴地区","headLetter":"B","isHot":0},{"id":512,"matchCount":2,"cnAlias":"巴丁","headLetter":"B","isHot":0},{"id":1677,"matchCount":1,"cnAlias":"巴高杯","headLetter":"B","isHot":0},{"id":131,"matchCount":6,"cnAlias":"巴甲","headLetter":"B","isHot":0},{"id":1686,"matchCount":1,"cnAlias":"巴拉杯","headLetter":"B","isHot":0},{"id":517,"matchCount":1,"cnAlias":"巴圣青联","headLetter":"B","isHot":0},{"id":1385,"matchCount":2,"cnAlias":"北爱后备","headLetter":"B","isHot":0},{"id":313,"matchCount":2,"cnAlias":"玻利甲","headLetter":"B","isHot":0},{"id":545,"matchCount":4,"cnAlias":"博茨超","headLetter":"B","isHot":0}]
     * C : [{"id":545,"matchCount":4,"cnAlias":"博茨超","headLetter":"B","isHot":0}]
     * D : [{"id":36,"matchCount":2,"cnAlias":"丹麦杯","headLetter":"D","isHot":0},{"id":31,"matchCount":1,"cnAlias":"丹麦甲","headLetter":"D","isHot":0},{"id":1631,"matchCount":1,"cnAlias":"德地杯","headLetter":"D","isHot":0}]
     * E : [{"id":1405,"matchCount":3,"cnAlias":"EFL杯","headLetter":"E","isHot":0}]
     * F : [{"id":141,"matchCount":2,"cnAlias":"法国杯","headLetter":"F","isHot":0}]
     * G : [{"id":389,"matchCount":1,"cnAlias":"哥伦杯","headLetter":"G","isHot":0},{"id":309,"matchCount":2,"cnAlias":"国际友谊","headLetter":"G","isHot":0}]
     * H : [{"id":545,"matchCount":4,"cnAlias":"博茨超","headLetter":"B","isHot":0}]
     * I : [{"id":545,"matchCount":4,"cnAlias":"博茨超","headLetter":"B","isHot":0}]
     * J : [{"id":118,"matchCount":1,"cnAlias":"捷克杯","headLetter":"J","isHot":0}]
     * K : [{"id":492,"matchCount":1,"cnAlias":"科索沃超","headLetter":"K","isHot":0},{"id":332,"matchCount":1,"cnAlias":"科威特联","headLetter":"K","isHot":0}]
     * L : [{"id":542,"matchCount":1,"cnAlias":"卢旺达联","headLetter":"L","isHot":0}]
     * M : [{"id":1334,"matchCount":1,"cnAlias":"马里甲","headLetter":"M","isHot":0},{"id":323,"matchCount":2,"cnAlias":"摩洛超","headLetter":"M","isHot":0},{"id":406,"matchCount":2,"cnAlias":"墨西哥杯","headLetter":"M","isHot":0}]
     * N : [{"id":157,"matchCount":4,"cnAlias":"南非超","headLetter":"N","isHot":0},{"id":1886,"matchCount":2,"cnAlias":"尼拉杯","headLetter":"N","isHot":0}]
     * O : [{"id":2,"matchCount":8,"cnAlias":"欧冠","headLetter":"O","isHot":0},{"id":462,"matchCount":5,"cnAlias":"欧联U19","headLetter":"O","isHot":0}]
     * P : [{"id":545,"matchCount":4,"cnAlias":"博茨超","headLetter":"B","isHot":0}]
     * Q : [{"id":311,"matchCount":3,"cnAlias":"球会友谊","headLetter":"Q","isHot":0}]
     * R : [{"id":1264,"matchCount":2,"cnAlias":"瑞典丙","headLetter":"R","isHot":0},{"id":26,"matchCount":1,"cnAlias":"瑞典超","headLetter":"R","isHot":1}]
     * S : [{"id":327,"matchCount":1,"cnAlias":"沙特联","headLetter":"S","isHot":0},{"id":116,"matchCount":4,"cnAlias":"世青U17","headLetter":"S","isHot":0},{"id":800,"matchCount":1,"cnAlias":"斯伐丙","headLetter":"S","isHot":0},{"id":1295,"matchCount":1,"cnAlias":"苏丹超","headLetter":"S","isHot":0},{"id":780,"matchCount":6,"cnAlias":"苏高联","headLetter":"S","isHot":0}]
     * T : [{"id":545,"matchCount":4,"cnAlias":"博茨超","headLetter":"B","isHot":0}]
     * U : [{"id":10335,"matchCount":2,"cnAlias":"U20戈亚诺","headLetter":"U","isHot":0}]
     * V : [{"id":545,"matchCount":4,"cnAlias":"博茨超","headLetter":"B","isHot":0}]
     * W : [{"id":1656,"matchCount":2,"cnAlias":"危地女甲","headLetter":"W","isHot":0},{"id":576,"matchCount":1,"cnAlias":"危地乙","headLetter":"W","isHot":0},{"id":537,"matchCount":2,"cnAlias":"委内杯","headLetter":"W","isHot":0},{"id":115,"matchCount":5,"cnAlias":"乌拉甲","headLetter":"W","isHot":0}]
     * X : [{"id":577,"matchCount":2,"cnAlias":"西联杯","headLetter":"X","isHot":0},{"id":391,"matchCount":5,"cnAlias":"匈乙","headLetter":"X","isHot":0}]
     * Y : [{"id":433,"matchCount":3,"cnAlias":"亚青U19","headLetter":"Y","isHot":0},{"id":302,"matchCount":10,"cnAlias":"意丙杯","headLetter":"Y","isHot":0},{"id":403,"matchCount":1,"cnAlias":"英U23杯","headLetter":"Y","isHot":0},{"id":140,"matchCount":1,"cnAlias":"英锦赛","headLetter":"Y","isHot":0},{"id":1491,"matchCount":4,"cnAlias":"英郡杯","headLetter":"Y","isHot":0},{"id":566,"matchCount":1,"cnAlias":"英南超","headLetter":"Y","isHot":0},{"id":10381,"matchCount":3,"cnAlias":"英依联杯","headLetter":"Y","isHot":0}]
     * Z : [{"id":545,"matchCount":4,"cnAlias":"博茨超","headLetter":"B","isHot":0}]
     * totalCount : 138
     */

    private int totalCount;
    private List<HotTournamentListBean> hotTournamentList;
    private List<IndexBean> A;
    private List<IndexBean> B;
    private List<IndexBean> C;
    private List<IndexBean> D;
    private List<IndexBean> E;
    private List<IndexBean> F;
    private List<IndexBean> G;
    private List<IndexBean> H;
    private List<IndexBean> I;
    private List<IndexBean> J;
    private List<IndexBean> K;
    private List<IndexBean> L;
    private List<IndexBean> M;
    private List<IndexBean> N;
    private List<IndexBean> O;
    private List<IndexBean> P;
    private List<IndexBean> Q;
    private List<IndexBean> R;
    private List<IndexBean> S;
    private List<IndexBean> T;
    private List<IndexBean> U;
    private List<IndexBean> V;
    private List<IndexBean> W;
    private List<IndexBean> X;
    private List<IndexBean> Y;
    private List<IndexBean> Z;

    protected OutSideIndexNewBean(Parcel in) {
        totalCount = in.readInt();
    }

    public static final Creator<OutSideIndexNewBean> CREATOR = new Creator<OutSideIndexNewBean>() {
        @Override
        public OutSideIndexNewBean createFromParcel(Parcel in) {
            return new OutSideIndexNewBean(in);
        }

        @Override
        public OutSideIndexNewBean[] newArray(int size) {
            return new OutSideIndexNewBean[size];
        }
    };

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public List<HotTournamentListBean> getHotTournamentList() {
        return hotTournamentList;
    }

    public void setHotTournamentList(List<HotTournamentListBean> hotTournamentList) {
        this.hotTournamentList = hotTournamentList;
    }

    public List<IndexBean> getA() {
        return A;
    }

    public void setA(List<IndexBean> A) {
        this.A = A;
    }

    public List<IndexBean> getB() {
        return B;
    }

    public void setB(List<IndexBean> B) {
        this.B = B;
    }

    public List<IndexBean> getC() {
        return C;
    }

    public void setC(List<IndexBean> C) {
        this.C = C;
    }

    public List<IndexBean> getD() {
        return D;
    }

    public void setD(List<IndexBean> D) {
        this.D = D;
    }

    public List<IndexBean> getE() {
        return E;
    }

    public void setE(List<IndexBean> E) {
        this.E = E;
    }

    public List<IndexBean> getF() {
        return F;
    }

    public void setF(List<IndexBean> F) {
        this.F = F;
    }

    public List<IndexBean> getG() {
        return G;
    }

    public void setG(List<IndexBean> G) {
        this.G = G;
    }

    public List<IndexBean> getH() {
        return H;
    }

    public void setH(List<IndexBean> H) {
        this.H = H;
    }

    public List<IndexBean> getI() {
        return I;
    }

    public void setI(List<IndexBean> I) {
        this.I = I;
    }

    public List<IndexBean> getJ() {
        return J;
    }

    public void setJ(List<IndexBean> J) {
        this.J = J;
    }

    public List<IndexBean> getK() {
        return K;
    }

    public void setK(List<IndexBean> K) {
        this.K = K;
    }

    public List<IndexBean> getL() {
        return L;
    }

    public void setL(List<IndexBean> L) {
        this.L = L;
    }

    public List<IndexBean> getM() {
        return M;
    }

    public void setM(List<IndexBean> M) {
        this.M = M;
    }

    public List<IndexBean> getN() {
        return N;
    }

    public void setN(List<IndexBean> N) {
        this.N = N;
    }

    public List<IndexBean> getO() {
        return O;
    }

    public void setO(List<IndexBean> O) {
        this.O = O;
    }

    public List<IndexBean> getP() {
        return P;
    }

    public void setP(List<IndexBean> P) {
        this.P = P;
    }

    public List<IndexBean> getQ() {
        return Q;
    }

    public void setQ(List<IndexBean> Q) {
        this.Q = Q;
    }

    public List<IndexBean> getR() {
        return R;
    }

    public void setR(List<IndexBean> R) {
        this.R = R;
    }

    public List<IndexBean> getS() {
        return S;
    }

    public void setS(List<IndexBean> S) {
        this.S = S;
    }

    public List<IndexBean> getT() {
        return T;
    }

    public void setT(List<IndexBean> T) {
        this.T = T;
    }

    public List<IndexBean> getU() {
        return U;
    }

    public void setU(List<IndexBean> U) {
        this.U = U;
    }

    public List<IndexBean> getV() {
        return V;
    }

    public void setV(List<IndexBean> V) {
        this.V = V;
    }

    public List<IndexBean> getW() {
        return W;
    }

    public void setW(List<IndexBean> W) {
        this.W = W;
    }

    public List<IndexBean> getX() {
        return X;
    }

    public void setX(List<IndexBean> X) {
        this.X = X;
    }

    public List<IndexBean> getY() {
        return Y;
    }

    public void setY(List<IndexBean> Y) {
        this.Y = Y;
    }

    public List<IndexBean> getZ() {
        return Z;
    }

    public void setZ(List<IndexBean> Z) {
        this.Z = Z;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(totalCount);
    }

    public static class HotTournamentListBean  implements Parcelable  {
        /**
         * id : 26
         * matchCount : 1
         * cnAlias : 瑞典超
         * headLetter : R
         * isHot : 1
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        protected HotTournamentListBean(Parcel in) {
            id = in.readInt();
            matchCount = in.readInt();
            cnAlias = in.readString();
            headLetter = in.readString();
            isHot = in.readInt();
        }

        public static final Creator<HotTournamentListBean> CREATOR = new Creator<HotTournamentListBean>() {
            @Override
            public HotTournamentListBean createFromParcel(Parcel in) {
                return new HotTournamentListBean(in);
            }

            @Override
            public HotTournamentListBean[] newArray(int size) {
                return new HotTournamentListBean[size];
            }
        };

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeInt(id);
            dest.writeInt(matchCount);
            dest.writeString(cnAlias);
            dest.writeString(headLetter);
            dest.writeInt(isHot);
        }
    }

    public static class IndexBean implements Parcelable {
        /**
         * id : 1407
         * matchCount : 8
         * cnAlias : 阿后备
         * headLetter : A
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;
        private boolean isCheck;

        protected IndexBean(Parcel in) {
            id = in.readInt();
            matchCount = in.readInt();
            cnAlias = in.readString();
            headLetter = in.readString();
            isHot = in.readInt();
            isCheck = in.readByte() != 0;
        }

        public static final Creator<IndexBean> CREATOR = new Creator<IndexBean>() {
            @Override
            public IndexBean createFromParcel(Parcel in) {
                return new IndexBean(in);
            }

            @Override
            public IndexBean[] newArray(int size) {
                return new IndexBean[size];
            }
        };

        public boolean isCheck() {
            return isCheck;
        }

        public void setCheck(boolean check) {
            isCheck = check;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeInt(id);
            dest.writeInt(matchCount);
            dest.writeString(cnAlias);
            dest.writeString(headLetter);
            dest.writeInt(isHot);
            dest.writeByte((byte) (isCheck ? 1 : 0));
        }
    }


}
