package com.yb.ballworld.information.ui.personal.presenter;

import android.text.TextUtils;
import android.util.Log;

import com.jeremyliao.liveeventbus.LiveEventBus;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.callback.OnUICallback;
import com.yb.ballworld.information.http.PersonalHttpApi;
import com.yb.ballworld.information.ui.personal.constant.CollectInfoCallbackListener;
import com.yb.ballworld.information.ui.personal.constant.PraiseCallbackListener;
import com.yb.ballworld.information.ui.personal.constant.RemoveCollectInfoCallBackListener;

import rxhttp.wrapper.entity.Response;

/**
 * Desc  点赞presenter
 * Date 2019/10/10
 */
public class ItemPraisePresenter {//implements ItemPraiseContract.IItemPraisePresenter {
    private PersonalHttpApi httpApi;

    public ItemPraisePresenter() {
        httpApi = new PersonalHttpApi();
    }


    /**
     * 评论 / 资讯点赞
     *
     * @param newsId    资讯id
     * @param commentId 评论id
     * @param callBack  回调
     */
    public void loadData(String newsId, int commentId, PraiseCallbackListener callBack) {
        if (!TextUtils.isEmpty(newsId)) { // 资讯点赞
            httpApi.praiseInfo(newsId, new OnUICallback<Response>() {
                @Override
                public void onUISuccess(Response data) {
                    if (data.getCode() == 200) { //点赞成功
                        callBack.onPraiseSuccess(data);
                    } else {                     //点赞失败
                        callBack.onPraiseFail(data.getMsg());
                    }
                }

                @Override
                public void onUIFailed(int errCode, String errMsg) {
                    LogUtils.INSTANCE.e("===z", "点赞 data = shibai");
                    callBack.onPraiseFail(errMsg);
                }
            });
        } else if (commentId != 0) { // 评论点赞
            httpApi.praiseComment(commentId, new OnUICallback<Response>() {
                @Override
                public void onUISuccess(Response data) {
                    if (data.getCode() == 200) { //点赞成功
                        callBack.onPraiseSuccess(data);
                    } else {                     //点赞失败
                        callBack.onPraiseFail(data.getMsg());
                    }
                }

                @Override
                public void onUIFailed(int errCode, String errMsg) {
                    callBack.onPraiseFail(errMsg);
                }
            });
        }
    }

    /**
     * 收藏
     *
     * @param newsId   资讯id
     * @param listener 返回结果回调
     */
    public void collectInfo(String newsId, CollectInfoCallbackListener listener) {
        httpApi.collectInfo(newsId, new OnUICallback<Response>() {
            @Override
            public void onUISuccess(Response data) {
                if (data.getCode() == 200) { //收藏成功
                    listener.onCollectSuccess(data);
                } else {                     //收藏失败
                    listener.onCollectFail(data.getMsg());
                }
            }

            @Override
            public void onUIFailed(int errCode, String errMsg) {
                listener.onCollectFail(errMsg);
            }
        });
    }

    /**
     * 取消收藏
     *
     * @param newsId   资讯id
     * @param listener 返回结果回调
     */
    public void removeCollectInfo(String newsId, RemoveCollectInfoCallBackListener listener) {
        httpApi.removeCollectInfo(newsId, new OnUICallback<Response>() {
            @Override
            public void onUISuccess(Response data) {
                if (data.getCode() == 200) { //取消收藏成功
                    listener.onRemoveCollectSuccess(data);
                } else {                     //取消收藏失败
                    listener.onRemoveCollectFail(data.getMsg());
                }
            }

            @Override
            public void onUIFailed(int errCode, String errMsg) {
                listener.onRemoveCollectFail(errMsg);
            }
        });
    }

}
