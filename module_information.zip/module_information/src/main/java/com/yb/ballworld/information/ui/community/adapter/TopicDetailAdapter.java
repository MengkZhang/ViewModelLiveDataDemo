package com.yb.ballworld.information.ui.community.adapter;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.scwang.smartrefresh.layout.util.DensityUtil;
import com.yb.ballworld.baselib.utils.ImageManager;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.baselib.utils.NetWorkUtils;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.community.CommunityImageAdapter;
import com.yb.ballworld.information.ui.community.bean.Topic;
import com.yb.ballworld.information.ui.community.bean.TopicConstant;
import com.yb.ballworld.information.ui.detail.CommentImgQuickAdapter;
import com.yb.ballworld.information.ui.detail.InforConstant;
import com.yb.ballworld.information.utils.CommondUtil;
import com.yb.ballworld.information.utils.HtmlParseData;
import com.yb.ballworld.information.widget.GridSpacingItemDecoration;
import com.yb.ballworld.information.widget.TimerTextView;
import com.yb.ballworld.information.widget.listener.OnElementClickListener2;

import java.util.List;

import cn.jzvd.JzvdStd;

import static com.yb.ballworld.information.utils.CommondUtil.fitEmpty;

public class TopicDetailAdapter extends BaseMultiItemQuickAdapter<MultiItemEntity, BaseViewHolder> {
    private OnElementClickListener2 mOnElementClickListener;
    private ImageView ivCollection;

    public TopicDetailAdapter(List<MultiItemEntity> data) {
        super(data);
        addItemType(InforConstant.TopicDetailItemType.TYPE_TOPIC, R.layout.item_topic_detail_head);
        addItemType(InforConstant.TopicDetailItemType.TYPE_TOPIC_COMMENT_TEXT, R.layout.item_commit_layout);
        addItemType(InforConstant.TopicDetailItemType.TYPE_TOPIC_COMMENT_IMAGE, R.layout.item_commit_layout);
        addItemType(InforConstant.TopicDetailItemType.TYPE_TOPIC_COMMENT_VIDEO, R.layout.item_commit_layout);
    }

    @Override
    protected void convert(BaseViewHolder helper, MultiItemEntity item, int pos) {
        if (item == null) return;
        int type = item.getItemType();
        switch (type) {
            case InforConstant.TopicDetailItemType.TYPE_TOPIC:
                setTopicValue(helper, item);
                break;

            case InforConstant.TopicDetailItemType.TYPE_TOPIC_COMMENT_TEXT:
            case InforConstant.TopicDetailItemType.TYPE_TOPIC_COMMENT_IMAGE:
            case InforConstant.TopicDetailItemType.TYPE_TOPIC_COMMENT_VIDEO:
                setTopicCommentValue(helper, item, pos);
                break;

        }
    }

    /**
     * 帖子
     *
     * @param helper
     * @param item
     */
    private void setTopicValue(BaseViewHolder helper, MultiItemEntity item) {
        if (!(item instanceof Topic)) return;
        Topic topic = (Topic) item;
        ImageView ivHead = helper.itemView.findViewById(R.id.iv_head_image);
        TextView tvNick = helper.itemView.findViewById(R.id.tv_nick_name);
        TextView tvTime = helper.itemView.findViewById(R.id.tv_time);
        TextView tvFollow = helper.itemView.findViewById(R.id.tv_follow);
        TextView tvContent = helper.itemView.findViewById(R.id.tv_comment_text);
        TextView tvBrowseNum = helper.itemView.findViewById(R.id.tv_browse_count);
        TextView tvLikes = helper.itemView.findViewById(R.id.singleCommit_likeCount);
        TextView tvAllCommetion = helper.itemView.findViewById(R.id.inforDetail_title);
        TextView tvSortBy = helper.itemView.findViewById(R.id.inforDetail_sortTitle);
        ivCollection = helper.itemView.findViewById(R.id.iv_collection);
        ImageView ivLike = helper.itemView.findViewById(R.id.singleCommit_like);
        ConstraintLayout ivSortBy = helper.itemView.findViewById(R.id.inforDetail_sortType_view);


        helper.addOnClickListener(ivHead.getId(), tvNick.getId(), tvFollow.getId(), ivCollection.getId(), ivSortBy.getId(), tvFollow.getId(), ivLike.getId());

        Glide.with(ivHead.getContext())
                .load(topic.getHeadImgUrl())
                .placeholder(R.drawable.user_default_icon2)
                .error(R.drawable.user_default_icon2)
                .into(ivHead);

        tvNick.setText(topic.getNickname());
        tvTime.setText(topic.getPostDate());
        tvContent.setText(topic.getContent());
        tvBrowseNum.setText("" + topic.getPageViews());
        tvLikes.setText("" + topic.getLikeCount());
        //tvAllCommetion.setText("全部评论(" + topic.getSonNum() + ")");
        tvAllCommetion.setText("全部评论");

        tvContent.setVisibility(TextUtils.isEmpty(topic.getContent()) ? View.GONE : View.VISIBLE);
        tvFollow.setSelected(topic.getIsAttention());
        ivCollection.setSelected(topic.isFavorites());
        ivLike.setSelected(topic.getIsLike());
        ivLike.setTag(tvLikes);

        tvSortBy.setText("按时间排序");


        int mediaType = topic.getTopicType();
        if (mediaType == TopicConstant.TYPE_TOPIC_VIDEO) {
            handleVideo(helper, topic, R.layout.item_topic_video);
        } else if (mediaType == TopicConstant.TYPE_TOPIC_IMAGE) {
            handleImgs(helper, topic, R.layout.item_topic_imglist);
        } else {
            helper.getView(R.id.singleCommit_frameLayout).setVisibility(View.GONE);
        }

        if(isSelf(""+((Topic) item).getUserId())){
            tvFollow.setVisibility(View.GONE);
        }else{
            tvFollow.setVisibility(View.VISIBLE);
        }
    }


    /**
     * 评论
     *
     * @param helper
     * @param item
     */
    private void setTopicCommentValue(BaseViewHolder helper, MultiItemEntity item, int pos) {
        if (!(item instanceof Topic)) return;
        Topic topic = (Topic) item;
        //头像、名称、时间
        ImageManager.INSTANCE.loadRoundIcon(topic.getHeadImgUrl(), R.drawable.user_default_icon2, 0, helper.getView(R.id.singleCommit_photo));
        helper.setText(R.id.singleCommit_commiter, topic.getNickname());
        // TODO 设置createTime
        ((TimerTextView) helper.getView(R.id.singleCommit_time)).setText(topic.getPostDate());

        //点赞s
        ImageView ivLike=helper.getView(R.id.singleCommit_like);
        ivLike.setImageResource(R.drawable.btn_focus_selector);
        ivLike.setSelected(topic.getIsLike());
        TextView tvLike=helper.getView(R.id.singleCommit_likeCount);
        tvLike.setText(String.valueOf(topic.getLikeCount()));
        ivLike.setTag(tvLike);

        //文字
        String text = fitEmpty(topic.getContent());
        boolean isNonZero = text.length() > 0;
        if (isNonZero) {
            helper.setText(R.id.singleCommit_text, text);
        }
        helper.setGone(R.id.singleCommit_text, isNonZero);

        //评论数
        isNonZero = topic.getSonNum() > 0;
        if (isNonZero) {
            helper.setText(R.id.singleCommit_count, CommondUtil.commentCount(topic.getSonNum(), helper.itemView.getContext()));
        }
        helper.setGone(R.id.singleCommit_countLayout, isNonZero);

        //添加单击事件
        helper.addOnClickListener(R.id.singleCommit_like, R.id.singleCommit_countLayout, R.id.singleCommit_photo, R.id.singleCommit_commiter);

        //媒体布局扩展
        int mediaType = topic.getTopicType();
        if (mediaType == TopicConstant.TYPE_TOPIC_VIDEO) {
            handleVideo(helper, topic, R.layout.item_comment_video_image);
        } else if (mediaType == TopicConstant.TYPE_TOPIC_IMAGE) {
            handleImgs(helper, topic, R.layout.item_comment_imglist);
        } else {
            helper.getView(R.id.singleCommit_frameLayout).setVisibility(View.GONE);
        }

        View line = helper.getView(R.id.singleCommit_bottomLine);
        View line2 = helper.getView(R.id.singleCommit_bottomLine2);
        if (getItemCount()-1 == pos) {
            line.setVisibility(View.GONE);
            line2.setVisibility(View.VISIBLE);
        } else {
            line.setVisibility(View.VISIBLE);
            line2.setVisibility(View.GONE);
        }

    }


    /**
     * 处理评论中含有视频的扩展布局
     *
     * @param helper
     * @param item
     */
    private void handleVideo(BaseViewHolder helper, Topic item, int layoutId) {
        View parent=helper.getView(R.id.singleCommit_frameLayout);
        parent.setVisibility(View.VISIBLE);

        // 主贴视频自动播放
        if(item.getItemType()==InforConstant.TopicDetailItemType.TYPE_TOPIC){
            JzvdStd jzvdStd = helper.getView(R.id.item_comment_video);
            if (jzvdStd == null) {
                LayoutInflater.from(helper.itemView.getContext()).inflate(layoutId, helper.getView(R.id.singleCommit_frameLayout), true);
                jzvdStd = helper.getView(R.id.item_comment_video);
            }
            jzvdStd.setUp(item.getVideoUrl(), "", JzvdStd.SCREEN_NORMAL);
            if(TextUtils.isEmpty(item.getImgUrl())){
                Glide.with(helper.itemView.getContext()).setDefaultRequestOptions(new RequestOptions()
                        .frame(1).centerCrop()).load(item.getVideoUrl())
                        .into(jzvdStd.thumbImageView);
            }else{
                Glide.with(helper.itemView.getContext()).load(item.getImgUrl()).into(jzvdStd.thumbImageView);
            }

            if (NetWorkUtils.INSTANCE.isWifiConnected()) {//wifi自动播放
                //jzvdStd.startVideo();
            }
        }else{
            ImageView imageView = helper.getView(R.id.item_comment_video);
            if(imageView==null){
                LayoutInflater.from(helper.itemView.getContext()).inflate(layoutId, helper.getView(R.id.singleCommit_frameLayout), true);
                imageView = helper.getView(R.id.item_comment_video);
            }
            Glide.with(helper.itemView.getContext()).load(item.getImgUrl()).into(imageView);
            helper.addOnClickListener(imageView.getId());
        }
    }


    /**
     * 处理评论中含有图片的扩展布局
     *
     * @param helper
     * @param item
     */
    private void handleImgs(BaseViewHolder helper, Topic item, int layoutId) {
        helper.getView(R.id.singleCommit_frameLayout).setVisibility(View.VISIBLE);
        RecyclerView recyclerView = helper.getView(R.id.recycle_imgs);
        if (recyclerView == null) {
            LayoutInflater.from(helper.itemView.getContext()).inflate(layoutId, helper.getView(R.id.singleCommit_frameLayout), true);
            recyclerView = helper.getView(R.id.recycle_imgs);
        }
        // 主贴
        if(item.getItemType()==InforConstant.TopicDetailItemType.TYPE_TOPIC){
            GridLayoutManager manager = new GridLayoutManager(mContext, item.getPostImgLists().size() < 3 ? item.getPostImgLists().size() : 3);
            recyclerView.setLayoutManager(manager);

            if (recyclerView.getItemDecorationCount() == 0) {
                recyclerView.addItemDecoration(new GridSpacingItemDecoration(3, DensityUtil.dp2px(6), false));
            }

            List<String> postImgLists = item.getPostImgLists();
            if (postImgLists.size() == 1) {
                CommunitySingleImageAdapter singleImageAdapter = new CommunitySingleImageAdapter(postImgLists);
                recyclerView.setAdapter(singleImageAdapter);
                singleImageAdapter.setOnItemClickListener(new OnImageItemClickListener(item));
                singleImageAdapter.setOnItemChildClickListener((adapter1, view, position) -> {
                    if (view.getId() == R.id.iv_image) {
                        OnItemClickListener listener = singleImageAdapter.getOnItemClickListener();
                        if (listener != null) {
                            listener.onItemClick(singleImageAdapter,view,position);
                        }
                    }
                });
            } else {
                CommunityImageAdapter adapter = new CommunityImageAdapter(item.getPostImgLists(), true);
                recyclerView.setAdapter(adapter);
                adapter.setOnItemClickListener(new OnImageItemClickListener(item));
                adapter.setOnItemChildClickListener((adapter1, view, position) -> {
                    if (view.getId() == R.id.iv_image) {
                        OnItemClickListener listener = adapter.getOnItemClickListener();
                        if (listener != null) {
                            listener.onItemClick(adapter,view,position);
                        }
                    }
                });
            }
        }else{
            // 回复

            GridLayoutManager manager = new GridLayoutManager(mContext, 3);
            recyclerView.setLayoutManager(manager);

            if (recyclerView.getItemDecorationCount() == 0) {
                recyclerView.addItemDecoration(new GridSpacingItemDecoration(3, DensityUtil.dp2px(6), false));
            }
            CommunityImageAdapter adapter = new CommunityImageAdapter(item.getPostImgLists(), false);
            recyclerView.setAdapter(adapter);
            adapter.setOnItemClickListener(new OnImageItemClickListener(item));
            adapter.setOnItemChildClickListener((adapter1, view, position) -> {
                if (view.getId() == R.id.iv_image) {
                    OnItemClickListener listener = adapter.getOnItemClickListener();
                    if (listener != null) {
                        listener.onItemClick(adapter,view,position);
                    }
                }
            });

//            CommentImgQuickAdapter commentImgQuickAdapter = new CommentImgQuickAdapter(null);
//            recyclerView.setAdapter(commentImgQuickAdapter);
//            commentImgQuickAdapter.autoFit(recyclerView, item.getPostImgLists());
//            commentImgQuickAdapter.setOnItemClickListener(new OnImageItemClickListener(item));
        }




    }


    /**
     * 主要用在点击评论图片的事件转发
     *
     */

    private class OnImageItemClickListener  implements OnItemClickListener{
        private Topic topic;

        private OnImageItemClickListener(Topic topic) {
            this.topic = topic;
        }

        @Override
        public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
            if (mOnElementClickListener != null) {
                mOnElementClickListener.onElementClick(topic,(String) adapter.getItem(position), HtmlParseData.TYPE_IMG, position, adapter.getData());
            }
        }
    }



    public void setmOnElementClickListener(OnElementClickListener2<Topic> mOnElementClickListener) {
        this.mOnElementClickListener = mOnElementClickListener;
    }


    /**
     * 更新收藏
     * @param isFavorite
     */
    public void updateFollow(boolean isFavorite){
        try{
            if(ivCollection!=null){
                ivCollection.setSelected(isFavorite);
            }
            ((Topic)getData().get(0)).setFavorites(isFavorite);
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    private boolean isSelf(String userId){
        if(TextUtils.isEmpty(userId)){
            return false;
        }
        long uid= LoginOrdinaryUtils.INSTANCE.getUid();
        if(uid==0){
            return false;
        }
        return String.valueOf(uid).equals(userId);
    }


}
