package com.yb.ballworld.information.ui.detail;

import android.text.TextUtils;

import com.jeremyliao.liveeventbus.LiveEventBus;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.information.data.ArticleDetailBean;
import com.yb.ballworld.information.data.CommitBean;
import com.yb.ballworld.information.data.CommitBeanList;
import com.yb.ballworld.information.data.SonCommentList;
import com.yb.ballworld.information.http.InforMationHttpApi;
import com.yb.ballworld.information.utils.CommondUtil;

import java.util.List;

/**
* Desc:
* @author ink
* created at 2019/10/24 19:24
*/
public class InforCommentPresenter extends BasePresenter<InforCommentActivity, VoidModel> {

    private InforMationHttpApi inforMationHttpApi = new InforMationHttpApi();
    private int pageNum = 1;
    private int upPageNum = 0;
    private int totalPage = 1;
    private final int pageSize = 15;
    private String newsId = null;
    final int INFOR_DETAIL = 0;
    final int INFOR_COMMITS = 1;
    private boolean isHeat = true;
    private boolean isFristPage=true;
    private int commentId=0;
    private int targetId=0;
    private final int pullUp=1;
    private final int pullDown=2;
    private int action=0;
    private int totalcount;

    public int getTotalcount() {
        return totalcount;
    }

    public void setTotalcount(int totalcount) {
        this.totalcount = totalcount;
    }

    public int getCommentId() {
        return commentId;
    }

    public void setCommentId(int commentId) {
        this.commentId = commentId;
    }

    public String getTargetId() {
        return targetId>0?String.valueOf(targetId):"";
    }

    public void setTargetId(int targetId) {
        this.targetId = targetId;
    }

    public void init(String newsId) {
        this.newsId = newsId;
    }

    public String getNewsId() {
        return this.newsId;
    }

    public void setNewsId(String newsId){
        this.newsId=newsId;
    }

    public boolean isHeatSort() {
        return isHeat;
    }

    public void setHeatSort(boolean isHeat) {
        this.isHeat = isHeat;
    }

    public boolean isFristPage() {
        return isFristPage;
    }

    public void setFristPage(boolean fristPage) {
        isFristPage = fristPage;
    }

    public boolean hasPullUpMore() {
        return pageNum <=totalPage;
    }

    public boolean hasPullDownMore() {
        return upPageNum>=1;
    }

    public int getAction() {
        return action;
    }

    public void setAction(int action) {
        this.action = action;
    }

    public void initLoad() {
        add(inforMationHttpApi.getCommitsReplyList(getCommentId(), 1, pageSize, isHeatSort(),getTargetId(),new LifecycleCallback<SonCommentList>(mView) {
            @Override
            public void onSuccess(SonCommentList data) {
                boolean hasData = data != null;
                if (data != null) {
                    CommitBeanList commitList=data.getSonComments();
                    hasData=data.getParent()!=null;
                    if(data.getSonComments()!=null){
                        setTotalcount(commitList.getTotalCount());
                        totalPage = commitList.getTotalPage();
                        pageNum = commitList.getPageNum();
                        if(!TextUtils.isEmpty(getTargetId())) {
                            pageNum+=1;
                            List<CommitBean> commitBeans=commitList.getList();
                            if(!CommondUtil.isEmpty(commitBeans)){
                            upPageNum=pageNum-(commitBeans.size()/pageSize+(commitBeans.size()%pageSize)>0?1:0);
                            }else{
                              upPageNum=0;
                            }
                        }else{
                            pageNum+=1;
                            upPageNum=0;
                        }
                    }
                }
                setTargetId(-1);
                showCommits(hasData?data:null,isFristPage());
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                showError(INFOR_COMMITS);
            }
        }));
    }


    public void pullUp(){
        add(inforMationHttpApi.getCommitsReplyList(getCommentId(), pageNum, pageSize, isHeatSort(),"",new LifecycleCallback<SonCommentList>(mView) {
            @Override
            public void onSuccess(SonCommentList data) {
                boolean hasData = data != null;
                if (data != null) {
                    CommitBeanList commitList=data.getSonComments();
                    hasData=data.getParent()!=null;
                    if(data.getSonComments()!=null){
                        setTotalcount(commitList.getTotalCount());
                        totalPage = commitList.getTotalPage();
                        pageNum+=1;
                    }
                }
                showCommits(hasData?data:null,isFristPage());
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                showError(INFOR_COMMITS);
            }
        }));
    }

    public void pullDown(){
        add(inforMationHttpApi.getCommitsReplyList(getCommentId(), upPageNum, pageSize, isHeatSort(),"",new LifecycleCallback<SonCommentList>(mView) {
            @Override
            public void onSuccess(SonCommentList data) {
                boolean hasData = data != null;
                if (data != null) {
                    CommitBeanList commitList=data.getSonComments();
                    hasData=data.getParent()!=null;
                    if(data.getSonComments()!=null){
                        setTotalcount(commitList.getTotalCount());
                        totalPage = commitList.getTotalPage();
                        upPageNum-=1;
                    }
                }
                showCommits(hasData?data:null,isFristPage());
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                showError(INFOR_COMMITS);
            }
        }));
    }


    public void addArticleLike() {
        add(inforMationHttpApi.submitArticleLike(this.newsId, new LifecycleCallback<String>(mView) {
            @Override
            public void onSuccess(String data) {
                showLike(INFOR_DETAIL, 0, 0, true);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                showLike(INFOR_DETAIL, 0, 0, errCode == 200);
            }
        }));
    }

    public void addCommitLike(final int commitId, final int position) {
        add(inforMationHttpApi.submitCommitLike(commitId, new LifecycleCallback<String>(mView) {
            @Override
            public void onSuccess(String data) {
                LiveEventBus.get().with(LiveEventBusKey.KEY_COMMIT_LIKE, String.class).post(commitId+"");
                showLike(INFOR_COMMITS, commitId, position, true);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                showLike(INFOR_COMMITS, commitId, position, errCode == 200);
            }
        }));
    }

    /**
     * 显示错误
     */
    private void showLike(int area, int commitId, int position, boolean isSuccess) {
        if (mView != null) {
          //  mView.showLike(area, commitId, position, isSuccess);
        }
    }

    /**
     * 显示错误
     */
    private void showError(int area) {
        if (mView != null) {
            mView.showError(area);
        }
    }

    /**
     * 显示评论列表
     *
     * @param sonCommentList
     */
    private void showCommits(SonCommentList sonCommentList, boolean firstPage) {
        if (mView != null) {
            if (sonCommentList==null||sonCommentList.getParent()==null) {
                mView.showEmpty(INFOR_COMMITS);
            } else {
                mView.showCommits(sonCommentList,firstPage);
            }
        }
    }




}
