package com.yb.ballworld.information.ui.detail;

import android.view.View;

/**
* Desc:
* @author ink
* created at 2019/10/22 17:32
*/
public interface OnShareOrLikeClickListener extends View.OnClickListener {
    /**
     *  viewType,见{@link com.yb.ballworld.information.ui.detail.InforConstant.ItemType}
     * @param viewType
     * @param view
     */
    void onClick(int viewType, View view);
}
