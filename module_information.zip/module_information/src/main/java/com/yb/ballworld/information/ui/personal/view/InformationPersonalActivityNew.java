package com.yb.ballworld.information.ui.personal.view;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.viewpager.widget.ViewPager;

import com.bfw.util.ToastUtils;
import com.bifen.tablayout.SlidingTabLayout;
import com.bifen.tablayout.listener.OnTabSelectListener;
import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.entity.LiveDataResult;
import com.gyf.immersionbar.ImmersionBar;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.data.UserInfo;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.baselib.utils.ViewUtils;
import com.yb.ballworld.baselib.widget.placeholder.HomePlaceholderView;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.common.base.BaseFragmentStateAdapter;
import com.yb.ballworld.common.base.mvp.BaseMvpActivity;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.utils.DisplayUtil;
import com.yb.ballworld.common.widget.CommonTitleBar;
import com.yb.ballworld.common.widget.DialogInterface;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.community.bean.Topic;
import com.yb.ballworld.information.ui.community.view.TopicDetailActivity;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.personal.bean.PersonalInfo;
import com.yb.ballworld.information.ui.personal.bean.community.ReportAuthorReason;

import com.yb.ballworld.information.ui.personal.presenter.InfoPersonalPresenterNew;
import com.yb.ballworld.information.ui.personal.view.community.CommunityPersonalFragment;
import com.yb.ballworld.information.utils.ShareTextUitl;
import com.yb.ballworld.information.widget.ConfirmDialog;
import com.yb.ballworld.information.widget.PersonalReportWindow;
import com.yb.ballworld.information.widget.TipOffDialog;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Desc: 资讯 个人页面
 * Author: JS-Kylo
 * Created On: 2019/10/10 10:48
 */
public class InformationPersonalActivityNew extends BaseMvpActivity<InfoPersonalPresenterNew> {
    public final static int TYPE_NEWS=0; // 资讯
    public final static int TYPE_COMMUNITY=1; // 社区
    private ImageView topBackground;
    private SlidingTabLayout xTab;
    private ImageView ivUserHeader;
    private TextView tvUserName, tvDesc, tvDay;
    private ViewPager viewPager;
    private BaseFragmentStateAdapter adapter = null;
    private HomePlaceholderView placeholder;
    private List<Fragment> fragments = new ArrayList<Fragment>();
    private String userID;
    private PersonalInfo userBean;
    private String userName = "";
    private String headUrl = "";
    private TextView tvFollow;
    ImageView ivWriter;
    ImageView ivAnchor;
    private TipOffDialog dialog;
    private PersonalReportWindow reportWindow;
    private int type;

    public static void startActivity(Context activity, String userId,int type) {
        Intent intent = new Intent(activity, InformationPersonalActivityNew.class);
        intent.putExtra("userId", userId);
        intent.putExtra("type", type);
        activity.startActivity(intent);
    }

    /**
     * 初始化沉浸式
     */
    @Override
    protected void initImmersionBar() {
        // 设置共同沉浸式样式
        ImmersionBar.with(this)
                .statusBarDarkFont(false)
                .statusBarColor(getStatusBarColor())
                .navigationBarColor(getNavigationBarColor())
                .init();
    }

    @Override
    public void initPresenter() {
        if (mPresenter != null) {
            mPresenter.setVM(this);
        }
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_personal_page_new;
    }

    @Override
    protected void initView() {
        try {
            userID = getIntent().getStringExtra("userId");
            type=getIntent().getIntExtra("type",0);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        topBackground = F(R.id.iv_background);
        xTab = F(R.id.xTab);
        placeholder = F(R.id.placeholderView);
        ivUserHeader = F(R.id.ivUserHeader);
        tvUserName = F(R.id.tvUserName);
        tvDesc = F(R.id.tvDesc);
        tvDay = F(R.id.tv_day);
        viewPager = F(R.id.viewPager);
        ivAnchor = F(R.id.iv_anchor);
        ivWriter = F(R.id.iv_writer);

        tvFollow = findViewById(R.id.tv_follow);
        dialog = new TipOffDialog(InformationPersonalActivityNew.this);
        tvDay.setVisibility(View.GONE);
    }

    @Override
    public PlaceholderView getPlaceholderView() {
        return placeholder;
    }

    @Override
    protected void initData() {
        placeholder.showLoading();
        //showDialogLoading();
        mPresenter.loadUserInfo(userID);
        //mPresenter.loadUserInfo("999");
        mPresenter.getReportReason();
    }

    @Override
    protected void bindEvent() {
        //F(R.id.ivBack).setOnClickListener(this);
        ((CommonTitleBar) findViewById(R.id.commonTitleBar)).setListener(new CommonTitleBar.OnTitleBarListener() {
            @Override
            public void onClicked(View v, int action, String extra) {
                if (action == CommonTitleBar.ACTION_LEFT_BUTTON) {
                    finish();
                }
            }
        });
        placeholder.setPageErrorRetryListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPageLoading();
                mPresenter.loadUserInfo(userID);
            }
        });
        reportWindow = new PersonalReportWindow(mContext);
        reportWindow.setReportClickListener(v -> {
            reportWindow.dismiss();
            if (LoginOrdinaryUtils.INSTANCE.isLogin()) {
                if (!dialog.isShowing()) {
                    List list = dialog.getList();
                    if (list != null && !list.isEmpty()) {
                        dialog.show();
                    } else {
                        showToastMsgShort("网络异常,请稍后再试！");
                        mPresenter.getReportReason();
                    }
                }
            } else {
                NavigateToDetailUtil.toLogin(InformationPersonalActivityNew.this);
            }
        });
        ((CommonTitleBar) findViewById(R.id.commonTitleBar)).getRightCustomView().setOnClickListener(v -> {
            reportWindow.showAsDropDown(v, -ViewUtils.dp2px(60), -ViewUtils.dp2px(16));
        });
        ivUserHeader.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!TextUtils.isEmpty(headUrl)) {
                    toImageBrowser(headUrl);
                }
            }
        });

        tvFollow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (LoginOrdinaryUtils.INSTANCE.isLogin()) {
                    if (userBean != null) {
                        try {
                            onAttentionClick(userBean.getNickname(), Integer.valueOf(userID), v);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                } else {
                    NavigateToDetailUtil.toLogin(InformationPersonalActivityNew.this);
                }
            }
        });
        // 关注结果
        mPresenter.followData.observe(this, new Observer<LiveDataResult>() {
            @Override
            public void onChanged(LiveDataResult liveDataResult) {
                boolean isSelected = tvFollow.isSelected();
                if (liveDataResult.getResult()) {
                    tvFollow.setSelected(!isSelected);
                } else {
                    showToastMsgShort(liveDataResult.getMsg());
                }
            }
        });
        dialog.setDialogInterface(new DialogInterface<ReportAuthorReason>() {
            @Override
            public void onItemClick(ReportAuthorReason s, int position) {
                dialog.dismiss();
                UserInfo userInfo = LoginOrdinaryUtils.INSTANCE.getUserInfo();
                if (userInfo == null) {
                    NavigateToDetailUtil.toLogin(InformationPersonalActivityNew.this);
                    return;
                }
                mPresenter.reportAuthorOrPost(s, Integer.valueOf(userID));
            }
        });

        ivUserHeader.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!TextUtils.isEmpty(headUrl)) {
                    List<String> arrayList = new ArrayList();
                    arrayList.add(headUrl);
                    NavigateToDetailUtil.navigateToGalleryActivityWithoutShare(InformationPersonalActivityNew.this, arrayList, 0);
                }
            }
        });
    }

    @Override
    protected void processClick(View view) {
        int viewId = view.getId();
        if (viewId == R.id.ivBack)
            finish();
    }

    /**
     * 初始化用户信息
     */
    public void initUserInfo(PersonalInfo data, String errMsg) {
        hideDialogLoading();
        placeholder.hideLoading();

        if (data != null) {
            if (isSelf(userID)) {
                tvFollow.setVisibility(View.GONE);
            } else {
                tvFollow.setVisibility(View.VISIBLE);
            }
            tvDay.setVisibility(View.GONE);

            userBean = data;
            userBean.setId(userID);
            userName = userBean.getNickname();
            headUrl = userBean.getHeadImgUrl();
            String introduce = TextUtils.isEmpty(userBean.getPersonalDesc()) ? "" : userBean.getPersonalDesc();
            Glide.with(InformationPersonalActivityNew.this).load(headUrl).error(R.drawable.user_default_icon2).placeholder(R.drawable.user_default_icon2).into(ivUserHeader);
            if (data.getBackground() != null) {
                Glide.with(mContext).load(data.getBackground()).error(R.mipmap.person_bg).into(topBackground);
            }
            tvUserName.setText(userName);
            tvDesc.setText(introduce);
            tvFollow.setSelected(data.isAttention());
            if (userBean.isAnchor()) {
                ivAnchor.setVisibility(View.VISIBLE);
            }
            if (userBean.isAuthor()) {
                ivWriter.setVisibility(View.VISIBLE);
            }
            tvDay.setText(userBean.getCreateTime());
            initTabPager();
        }else{
           showPageError("网络异常，请稍后再试");
        }
    }

    /**
     * 初始化fragment
     */
    private void initTabPager() {
        List<String> titles = getTabTitles();
        fragments = getTabFragments();
        adapter = new BaseFragmentStateAdapter(getSupportFragmentManager(), fragments, titles);
        viewPager.setAdapter(adapter);
        viewPager.setOffscreenPageLimit(fragments.size());
        float tabWidth = DisplayUtil.getScreenWidth(this) * 1.0f / titles.size();
        xTab.setTabWidth(tabWidth);
        xTab.setViewPager(viewPager);
        if(viewPager.getChildCount()>type){
            viewPager.setCurrentItem(type);
        }else{
            viewPager.setCurrentItem(0);
        }

       /* xTab.setOnTabSelectListener(new OnTabSelectListener() {
            @Override
            public void onTabSelect(int position) {
                fragments.get(position).getView().requestLayout();
            }

            @Override
            public void onTabReselect(int position) {
                fragments.get(position).getView().requestLayout();
            }
        });*/
        viewPagerOnPagerListener();
    }

    private void viewPagerOnPagerListener() {
        if (viewPager != null) {
            viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {

                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                }

                @Override
                public void onPageSelected(int position) {
                    // 当前位置 如果不是社区的话 发送停止播放视频的广播
                    LogUtils.INSTANCE.e("===z", "当前所在的位置pos = " + position);
                    if (position != 0) {
                        LiveEventBus.get().with(LiveEventBusKey.KEY_INFO_PAUSE_PLAY).post(true);
                    }
                }

                @Override
                public void onPageScrollStateChanged(int state) {
                }

            });
        }
    }

    //获取举报原因
    public void initReport(List<ReportAuthorReason> reasonList) {
        if (reasonList == null)
            return;
        if (reasonList.size() == 0)
            return;
        // List<String> reasons = new ArrayList<>();
        // for (ReportAuthorReason reason:reasonList){
        //     reasons.add(reason.getReason());
        // }
        dialog.setDate(reasonList);
    }

    /**
     * 跳转到图片浏览页
     *
     * @param headUrl
     */
    private void toImageBrowser(String... headUrl) {
        NavigateToDetailUtil.navigateToGalleryActivityWithoutShare(this, (ArrayList<String>) add(headUrl), 0);
    }

    private List<String> getTabTitles() {
        return add("资讯", "社区", "关注", "粉丝");
    }


    private List<Fragment> getTabFragments() {
        return add(
                InfoUserSpaceFragment.newInstance(userBean),
                CommunityPersonalFragment.newInstance(userBean),
                FollowFragment.newInstance(userID, FollowFragment.TYPE_FOLLOW,type),
                FollowFragment.newInstance(userID, FollowFragment.TYPE_FANS,type)

        );
    }

    /**
     * 判断是否用户本人
     *
     * @param userId
     * @return
     */
    private boolean isSelf(String userId) {
        if (TextUtils.isEmpty(userId)) {
            return false;
        }
        long uid = LoginOrdinaryUtils.INSTANCE.getUid();
        if (uid == 0) {
            return false;
        }
        return String.valueOf(uid).equals(userId);
    }

    /**
     * 计算注册多少天
     *
     * @param time
     * @return
     */
    private String getDay(long time) {
        if (time <= 0) {
            return "1";
        }
        long t = System.currentTimeMillis() - time;
        if (time <= 0) {
            return "1";
        }

        return String.valueOf((int) (t / 24 * 60 * 60 * 1000));

    }

    private void onAttentionClick(String nickName, int userId, View view) {
        boolean isAttention = view.isSelected();
        if (isAttention) {
            new ConfirmDialog(this, ShareTextUitl.getMarksText(nickName), "是否取消对ta的关注？", new ConfirmDialog.OnCloseListener() {
                @Override
                public void onClick(Dialog dialog, boolean confirm) {
                    if (confirm) {
                        //取消关注
                        attentionAction(view, userId);
                    }
                }
            }).show();
        } else {
            attentionAction(view, userId);
        }
    }


    private void attentionAction(View view, int userId) {
        mPresenter.attentionAction(userId, !view.isSelected(), new LifecycleCallback(this) {
            @Override
            public void onSuccess(Object data) {
                view.setSelected(!view.isSelected());
                Topic topic = new Topic();
                topic.setId(userId);
                topic.setIsAttention(view.isSelected());
                LiveEventBus.get().with(LiveEventBusKey.KEY_TOPIC_ATTENTION_USER_SPACE, Topic.class).post(topic);
                ToastUtils.showToast(view.isSelected() ? "已关注" : "已取消");
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                ToastUtils.showToast("网络异常，请稍后再试");
            }
        });
    }


    protected boolean isNotEmpty(List<?> list) {
        return list != null && !list.isEmpty();
    }

    private <T> List<T> add(T... t) {
        return new ArrayList<>(Arrays.asList(t));
    }
}
