package com.yb.ballworld.information.ui.home.bean;

import java.util.List;

/**
 * Desc 外层索引列表数据
 * Date 2019/11/7
 * author mengk
 *
 */

/**
 * 过时api 建议使用OutSideIndexNewBean替代
 * @deprecated Use {@link OutSideIndexNewBean} instead.
 */
@Deprecated
public class OutSideIndexBean {

    /**
     * hotTournamentList : [{"id":26,"matchCount":1,"cnAlias":"瑞典超","headLetter":"R","isHot":1}]
     * A : [{"id":1407,"matchCount":8,"cnAlias":"阿后备","headLetter":"A","isHot":0},{"id":743,"matchCount":2,"cnAlias":"阿拉冠","headLetter":"A","isHot":0},{"id":11139,"matchCount":2,"cnAlias":"阿维女锦","headLetter":"A","isHot":0},{"id":1395,"matchCount":4,"cnAlias":"爱尔高联","headLetter":"A","isHot":0},{"id":268,"matchCount":1,"cnAlias":"爱沙杯","headLetter":"A","isHot":0}]
     * B : [{"id":521,"matchCount":1,"cnAlias":"巴地区","headLetter":"B","isHot":0},{"id":512,"matchCount":2,"cnAlias":"巴丁","headLetter":"B","isHot":0},{"id":1677,"matchCount":1,"cnAlias":"巴高杯","headLetter":"B","isHot":0},{"id":131,"matchCount":6,"cnAlias":"巴甲","headLetter":"B","isHot":0},{"id":1686,"matchCount":1,"cnAlias":"巴拉杯","headLetter":"B","isHot":0},{"id":517,"matchCount":1,"cnAlias":"巴圣青联","headLetter":"B","isHot":0},{"id":1385,"matchCount":2,"cnAlias":"北爱后备","headLetter":"B","isHot":0},{"id":313,"matchCount":2,"cnAlias":"玻利甲","headLetter":"B","isHot":0},{"id":545,"matchCount":4,"cnAlias":"博茨超","headLetter":"B","isHot":0}]
     * C : [{"id":545,"matchCount":4,"cnAlias":"博茨超","headLetter":"B","isHot":0}]
     * D : [{"id":36,"matchCount":2,"cnAlias":"丹麦杯","headLetter":"D","isHot":0},{"id":31,"matchCount":1,"cnAlias":"丹麦甲","headLetter":"D","isHot":0},{"id":1631,"matchCount":1,"cnAlias":"德地杯","headLetter":"D","isHot":0}]
     * E : [{"id":1405,"matchCount":3,"cnAlias":"EFL杯","headLetter":"E","isHot":0}]
     * F : [{"id":141,"matchCount":2,"cnAlias":"法国杯","headLetter":"F","isHot":0}]
     * G : [{"id":389,"matchCount":1,"cnAlias":"哥伦杯","headLetter":"G","isHot":0},{"id":309,"matchCount":2,"cnAlias":"国际友谊","headLetter":"G","isHot":0}]
     * H : [{"id":545,"matchCount":4,"cnAlias":"博茨超","headLetter":"B","isHot":0}]
     * I : [{"id":545,"matchCount":4,"cnAlias":"博茨超","headLetter":"B","isHot":0}]
     * J : [{"id":118,"matchCount":1,"cnAlias":"捷克杯","headLetter":"J","isHot":0}]
     * K : [{"id":492,"matchCount":1,"cnAlias":"科索沃超","headLetter":"K","isHot":0},{"id":332,"matchCount":1,"cnAlias":"科威特联","headLetter":"K","isHot":0}]
     * L : [{"id":542,"matchCount":1,"cnAlias":"卢旺达联","headLetter":"L","isHot":0}]
     * M : [{"id":1334,"matchCount":1,"cnAlias":"马里甲","headLetter":"M","isHot":0},{"id":323,"matchCount":2,"cnAlias":"摩洛超","headLetter":"M","isHot":0},{"id":406,"matchCount":2,"cnAlias":"墨西哥杯","headLetter":"M","isHot":0}]
     * N : [{"id":157,"matchCount":4,"cnAlias":"南非超","headLetter":"N","isHot":0},{"id":1886,"matchCount":2,"cnAlias":"尼拉杯","headLetter":"N","isHot":0}]
     * O : [{"id":2,"matchCount":8,"cnAlias":"欧冠","headLetter":"O","isHot":0},{"id":462,"matchCount":5,"cnAlias":"欧联U19","headLetter":"O","isHot":0}]
     * P : [{"id":545,"matchCount":4,"cnAlias":"博茨超","headLetter":"B","isHot":0}]
     * Q : [{"id":311,"matchCount":3,"cnAlias":"球会友谊","headLetter":"Q","isHot":0}]
     * R : [{"id":1264,"matchCount":2,"cnAlias":"瑞典丙","headLetter":"R","isHot":0},{"id":26,"matchCount":1,"cnAlias":"瑞典超","headLetter":"R","isHot":1}]
     * S : [{"id":327,"matchCount":1,"cnAlias":"沙特联","headLetter":"S","isHot":0},{"id":116,"matchCount":4,"cnAlias":"世青U17","headLetter":"S","isHot":0},{"id":800,"matchCount":1,"cnAlias":"斯伐丙","headLetter":"S","isHot":0},{"id":1295,"matchCount":1,"cnAlias":"苏丹超","headLetter":"S","isHot":0},{"id":780,"matchCount":6,"cnAlias":"苏高联","headLetter":"S","isHot":0}]
     * T : [{"id":545,"matchCount":4,"cnAlias":"博茨超","headLetter":"B","isHot":0}]
     * U : [{"id":10335,"matchCount":2,"cnAlias":"U20戈亚诺","headLetter":"U","isHot":0}]
     * V : [{"id":545,"matchCount":4,"cnAlias":"博茨超","headLetter":"B","isHot":0}]
     * W : [{"id":1656,"matchCount":2,"cnAlias":"危地女甲","headLetter":"W","isHot":0},{"id":576,"matchCount":1,"cnAlias":"危地乙","headLetter":"W","isHot":0},{"id":537,"matchCount":2,"cnAlias":"委内杯","headLetter":"W","isHot":0},{"id":115,"matchCount":5,"cnAlias":"乌拉甲","headLetter":"W","isHot":0}]
     * X : [{"id":577,"matchCount":2,"cnAlias":"西联杯","headLetter":"X","isHot":0},{"id":391,"matchCount":5,"cnAlias":"匈乙","headLetter":"X","isHot":0}]
     * Y : [{"id":433,"matchCount":3,"cnAlias":"亚青U19","headLetter":"Y","isHot":0},{"id":302,"matchCount":10,"cnAlias":"意丙杯","headLetter":"Y","isHot":0},{"id":403,"matchCount":1,"cnAlias":"英U23杯","headLetter":"Y","isHot":0},{"id":140,"matchCount":1,"cnAlias":"英锦赛","headLetter":"Y","isHot":0},{"id":1491,"matchCount":4,"cnAlias":"英郡杯","headLetter":"Y","isHot":0},{"id":566,"matchCount":1,"cnAlias":"英南超","headLetter":"Y","isHot":0},{"id":10381,"matchCount":3,"cnAlias":"英依联杯","headLetter":"Y","isHot":0}]
     * Z : [{"id":545,"matchCount":4,"cnAlias":"博茨超","headLetter":"B","isHot":0}]
     * totalCount : 138
     */

    private int totalCount;
    private List<HotTournamentListBean> hotTournamentList;
    private List<ABean> A;
    private List<BBean> B;
    private List<CBean> C;
    private List<DBean> D;
    private List<EBean> E;
    private List<FBean> F;
    private List<GBean> G;
    private List<HBean> H;
    private List<IBean> I;
    private List<JBean> J;
    private List<KBean> K;
    private List<LBean> L;
    private List<MBean> M;
    private List<NBean> N;
    private List<OBean> O;
    private List<PBean> P;
    private List<QBean> Q;
    private List<RBean> R;
    private List<SBean> S;
    private List<TBean> T;
    private List<UBean> U;
    private List<VBean> V;
    private List<WBean> W;
    private List<XBean> X;
    private List<YBean> Y;
    private List<ZBean> Z;

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public List<HotTournamentListBean> getHotTournamentList() {
        return hotTournamentList;
    }

    public void setHotTournamentList(List<HotTournamentListBean> hotTournamentList) {
        this.hotTournamentList = hotTournamentList;
    }

    public List<ABean> getA() {
        return A;
    }

    public void setA(List<ABean> A) {
        this.A = A;
    }

    public List<BBean> getB() {
        return B;
    }

    public void setB(List<BBean> B) {
        this.B = B;
    }

    public List<CBean> getC() {
        return C;
    }

    public void setC(List<CBean> C) {
        this.C = C;
    }

    public List<DBean> getD() {
        return D;
    }

    public void setD(List<DBean> D) {
        this.D = D;
    }

    public List<EBean> getE() {
        return E;
    }

    public void setE(List<EBean> E) {
        this.E = E;
    }

    public List<FBean> getF() {
        return F;
    }

    public void setF(List<FBean> F) {
        this.F = F;
    }

    public List<GBean> getG() {
        return G;
    }

    public void setG(List<GBean> G) {
        this.G = G;
    }

    public List<HBean> getH() {
        return H;
    }

    public void setH(List<HBean> H) {
        this.H = H;
    }

    public List<IBean> getI() {
        return I;
    }

    public void setI(List<IBean> I) {
        this.I = I;
    }

    public List<JBean> getJ() {
        return J;
    }

    public void setJ(List<JBean> J) {
        this.J = J;
    }

    public List<KBean> getK() {
        return K;
    }

    public void setK(List<KBean> K) {
        this.K = K;
    }

    public List<LBean> getL() {
        return L;
    }

    public void setL(List<LBean> L) {
        this.L = L;
    }

    public List<MBean> getM() {
        return M;
    }

    public void setM(List<MBean> M) {
        this.M = M;
    }

    public List<NBean> getN() {
        return N;
    }

    public void setN(List<NBean> N) {
        this.N = N;
    }

    public List<OBean> getO() {
        return O;
    }

    public void setO(List<OBean> O) {
        this.O = O;
    }

    public List<PBean> getP() {
        return P;
    }

    public void setP(List<PBean> P) {
        this.P = P;
    }

    public List<QBean> getQ() {
        return Q;
    }

    public void setQ(List<QBean> Q) {
        this.Q = Q;
    }

    public List<RBean> getR() {
        return R;
    }

    public void setR(List<RBean> R) {
        this.R = R;
    }

    public List<SBean> getS() {
        return S;
    }

    public void setS(List<SBean> S) {
        this.S = S;
    }

    public List<TBean> getT() {
        return T;
    }

    public void setT(List<TBean> T) {
        this.T = T;
    }

    public List<UBean> getU() {
        return U;
    }

    public void setU(List<UBean> U) {
        this.U = U;
    }

    public List<VBean> getV() {
        return V;
    }

    public void setV(List<VBean> V) {
        this.V = V;
    }

    public List<WBean> getW() {
        return W;
    }

    public void setW(List<WBean> W) {
        this.W = W;
    }

    public List<XBean> getX() {
        return X;
    }

    public void setX(List<XBean> X) {
        this.X = X;
    }

    public List<YBean> getY() {
        return Y;
    }

    public void setY(List<YBean> Y) {
        this.Y = Y;
    }

    public List<ZBean> getZ() {
        return Z;
    }

    public void setZ(List<ZBean> Z) {
        this.Z = Z;
    }

    public static class HotTournamentListBean {
        /**
         * id : 26
         * matchCount : 1
         * cnAlias : 瑞典超
         * headLetter : R
         * isHot : 1
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class ABean {
        /**
         * id : 1407
         * matchCount : 8
         * cnAlias : 阿后备
         * headLetter : A
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class BBean {
        /**
         * id : 521
         * matchCount : 1
         * cnAlias : 巴地区
         * headLetter : B
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class CBean {
        /**
         * id : 545
         * matchCount : 4
         * cnAlias : 博茨超
         * headLetter : B
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class DBean {
        /**
         * id : 36
         * matchCount : 2
         * cnAlias : 丹麦杯
         * headLetter : D
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class EBean {
        /**
         * id : 1405
         * matchCount : 3
         * cnAlias : EFL杯
         * headLetter : E
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class FBean {
        /**
         * id : 141
         * matchCount : 2
         * cnAlias : 法国杯
         * headLetter : F
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class GBean {
        /**
         * id : 389
         * matchCount : 1
         * cnAlias : 哥伦杯
         * headLetter : G
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class HBean {
        /**
         * id : 545
         * matchCount : 4
         * cnAlias : 博茨超
         * headLetter : B
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class IBean {
        /**
         * id : 545
         * matchCount : 4
         * cnAlias : 博茨超
         * headLetter : B
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class JBean {
        /**
         * id : 118
         * matchCount : 1
         * cnAlias : 捷克杯
         * headLetter : J
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class KBean {
        /**
         * id : 492
         * matchCount : 1
         * cnAlias : 科索沃超
         * headLetter : K
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class LBean {
        /**
         * id : 542
         * matchCount : 1
         * cnAlias : 卢旺达联
         * headLetter : L
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class MBean {
        /**
         * id : 1334
         * matchCount : 1
         * cnAlias : 马里甲
         * headLetter : M
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class NBean {
        /**
         * id : 157
         * matchCount : 4
         * cnAlias : 南非超
         * headLetter : N
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class OBean {
        /**
         * id : 2
         * matchCount : 8
         * cnAlias : 欧冠
         * headLetter : O
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class PBean {
        /**
         * id : 545
         * matchCount : 4
         * cnAlias : 博茨超
         * headLetter : B
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class QBean {
        /**
         * id : 311
         * matchCount : 3
         * cnAlias : 球会友谊
         * headLetter : Q
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class RBean {
        /**
         * id : 1264
         * matchCount : 2
         * cnAlias : 瑞典丙
         * headLetter : R
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class SBean {
        /**
         * id : 327
         * matchCount : 1
         * cnAlias : 沙特联
         * headLetter : S
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class TBean {
        /**
         * id : 545
         * matchCount : 4
         * cnAlias : 博茨超
         * headLetter : B
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class UBean {
        /**
         * id : 10335
         * matchCount : 2
         * cnAlias : U20戈亚诺
         * headLetter : U
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class VBean {
        /**
         * id : 545
         * matchCount : 4
         * cnAlias : 博茨超
         * headLetter : B
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class WBean {
        /**
         * id : 1656
         * matchCount : 2
         * cnAlias : 危地女甲
         * headLetter : W
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class XBean {
        /**
         * id : 577
         * matchCount : 2
         * cnAlias : 西联杯
         * headLetter : X
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class YBean {
        /**
         * id : 433
         * matchCount : 3
         * cnAlias : 亚青U19
         * headLetter : Y
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }

    public static class ZBean {
        /**
         * id : 545
         * matchCount : 4
         * cnAlias : 博茨超
         * headLetter : B
         * isHot : 0
         */

        private int id;
        private int matchCount;
        private String cnAlias;
        private String headLetter;
        private int isHot;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getMatchCount() {
            return matchCount;
        }

        public void setMatchCount(int matchCount) {
            this.matchCount = matchCount;
        }

        public String getCnAlias() {
            return cnAlias;
        }

        public void setCnAlias(String cnAlias) {
            this.cnAlias = cnAlias;
        }

        public String getHeadLetter() {
            return headLetter;
        }

        public void setHeadLetter(String headLetter) {
            this.headLetter = headLetter;
        }

        public int getIsHot() {
            return isHot;
        }

        public void setIsHot(int isHot) {
            this.isHot = isHot;
        }
    }
}
