package com.yb.ballworld.information.ui.detail;

import com.yb.ballworld.baselib.constant.BaseAppConfig;
import com.yb.ballworld.common.api.StatisticsHttpApi;
import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.callback.ApiCallback;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.utils.MD5Utils;
import com.yb.ballworld.information.data.ArticleDetailBean;
import com.yb.ballworld.information.data.CommitBean;
import com.yb.ballworld.information.data.CommitBeanList;
import com.yb.ballworld.information.http.InforMationHttpApi;
import com.yb.ballworld.information.utils.CommondUtil;

import java.util.List;
import java.util.concurrent.TimeUnit;

import io.reactivex.Flowable;
import io.reactivex.disposables.Disposable;

/**
 * Desc: <功能简述>
 * Author: JS-Dugu
 * Created On: 2019/10/15 23:05
 */
public class NewsTextDetailPresenter extends BasePresenter<NewsTextDetailActivity, VoidModel> {

    private InforMationHttpApi inforMationHttpApi = new InforMationHttpApi();
    private StatisticsHttpApi statisticsHttpApi = new StatisticsHttpApi();
    private int pageNum = 1;
    private int totalPage = 1;
    private final int pageSize = 15;
    private String newsId = null;
    final int INFOR_DETAIL = 0;
    final int INFOR_COMMITS = 1;
    private boolean isHeat = true;
    private boolean isFristPage=true;
    private Disposable newsLookDisposable;

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (newsLookDisposable != null && !newsLookDisposable.isDisposed()) {
            newsLookDisposable.dispose();
        }
    }

    public void init(String newsId) {
        this.newsId = newsId;
    }

    public String getNewsId() {
        return this.newsId;
    }

    public boolean isHeatSort() {
        return isHeat;
    }

    public void setHeatSort(boolean isHeat) {
        this.isHeat = isHeat;
    }

    public boolean isFristPage() {
        return isFristPage;
    }

    public void setFristPage(boolean fristPage) {
        isFristPage = fristPage;
    }

    public boolean hasMore() {
        return pageNum < totalPage;
    }


    public void loadInfor() {
        add(inforMationHttpApi.getArticleDetail(newsId, new LifecycleCallback<ArticleDetailBean>(mView) {
            @Override
            public void onSuccess(ArticleDetailBean data) {
                showInfor(data);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                showError(INFOR_DETAIL);
            }
        }));
    }

    public void loadMore() {
        pageNum=isFristPage()?1:pageNum;
        add(inforMationHttpApi.getCommitList(this.newsId, pageNum, pageSize, isHeatSort(), new LifecycleCallback<CommitBeanList>(mView) {
            @Override
            public void onSuccess(CommitBeanList data) {
                boolean hasData = data != null && !CommondUtil.isEmpty(data.getList());
                if (data != null) {
                    totalPage = data.getTotalPage();
                }
                showCommits(hasData ? data.getList() : null,isFristPage());
                if (hasData) {
                    pageNum += 1;
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                showError(INFOR_COMMITS);
            }
        }));
    }

    public void addArticleLike() {
        add(inforMationHttpApi.submitArticleLike(this.newsId, new LifecycleCallback<String>(mView) {
            @Override
            public void onSuccess(String data) {
                showLike(INFOR_DETAIL, 0, 0, true);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                showLike(INFOR_DETAIL, 0, 0, errCode == 200);
            }
        }));
    }

    public void addCommitLike(final int commitId, final int position) {
        add(inforMationHttpApi.submitCommitLike(commitId, new LifecycleCallback<String>(mView) {
            @Override
            public void onSuccess(String data) {
                showLike(INFOR_COMMITS, commitId, position, true);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                showLike(INFOR_COMMITS, commitId, position, errCode == 200);
            }
        }));
    }

    /**
     * 显示错误
     */
    private void showLike(int area, int commitId, int position, boolean isSuccess) {
        if (mView != null) {
         //   mView.showLike(area, commitId, position, isSuccess);
        }
    }

    /**
     * 显示错误
     */
    private void showError(int area) {
        if (mView != null) {
            mView.showError(area);
        }
    }

    /**
     * 显示评论列表
     *
     * @param commitList
     */
    private void showCommits(List<CommitBean> commitList,boolean firstPage) {
        if (mView != null) {
            if (CommondUtil.isEmpty(commitList)) {
                mView.showEmpty(INFOR_COMMITS);
            } else {
                mView.showCommits(commitList,firstPage);
            }
        }
    }

    /**
     * 显示文章信息
     *
     * @param articleBean
     */
    private void showInfor(ArticleDetailBean articleBean) {
        if (mView != null) {
            if (articleBean == null || articleBean.getNews() == null) {
                mView.showEmpty(INFOR_DETAIL);
            } else {
                mView.showInfor(articleBean);
                int length = articleBean.getNews().getPreview().length();
                int second = length * 3 / 100;
                newsLookCompleted(second);
            }
        }
    }

    private void newsLookCompleted(int second) {
        newsLookDisposable = Flowable.timer(second, TimeUnit.SECONDS)
                .subscribe(aLong -> {
                    String currentSecondTimestamp = String.valueOf(System.currentTimeMillis());
                    String encode = MD5Utils.encode(currentSecondTimestamp + BaseAppConfig.SIGN_APP_SECRET);
                    add(statisticsHttpApi.newsLook(newsId, encode, currentSecondTimestamp, new ApiCallback<String>() {
                        @Override
                        public void onSuccess(String data) {

                        }

                        @Override
                        public void onFailed(int errCode, String errMsg) {

                        }
                    }));
                });
    }


    /**
     * 关注与取消关注
     *
     * @param focusUserId
     * @param action
     * @param callback
     */
    public void attentionAction(int focusUserId, boolean action, LifecycleCallback callback) {
        if (action) {
            inforMationHttpApi.attentionAuthor(focusUserId, callback);
        } else {
            inforMationHttpApi.attentionAuthorCancel(focusUserId, callback);
        }
    }
}
