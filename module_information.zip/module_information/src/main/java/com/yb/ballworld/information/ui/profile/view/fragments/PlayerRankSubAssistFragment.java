package com.yb.ballworld.information.ui.profile.view.fragments;

import android.view.View;

import com.chad.library.adapter.base.BaseQuickAdapter;

/**
 * 赛事资料库-球员榜-助攻榜
 * @author Gethin
 * @time 2019/11/9 10:37
 */

public class PlayerRankSubAssistFragment extends RvBaseFragment {

    @Override
    protected void loadData() {

    }

    @Override
    protected BaseQuickAdapter getAdapter() {
        return null;
    }

    @Override
    public void initPresenter() {

    }

    @Override
    protected void bindEvent() {

    }

    @Override
    protected void processClick(View view) {

    }
}
