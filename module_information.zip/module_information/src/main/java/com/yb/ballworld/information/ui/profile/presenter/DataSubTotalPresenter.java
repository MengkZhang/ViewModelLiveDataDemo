package com.yb.ballworld.information.ui.profile.presenter;

import androidx.lifecycle.LifecycleOwner;

import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.livedata.LiveDataWrap;
import com.yb.ballworld.information.ui.profile.data.DataSubTotalBean;
import com.yb.ballworld.information.ui.profile.http.ProfileHttp;

import java.util.List;
import java.util.Map;

/**
 * @author Gethin
 * @time 2019/11/9 15:19
 */

public abstract class DataSubTotalPresenter extends BasePresenter<LifecycleOwner, VoidModel> {
    protected ProfileHttp http=new ProfileHttp();
    protected String playerId;
    public LiveDataWrap<List<DataSubTotalBean>> dataSubTotalData = new LiveDataWrap<>();

    public abstract void loadDataSubTotal();

    public void setPlayerId(String playerId) {
        this.playerId = playerId;
    }

}
