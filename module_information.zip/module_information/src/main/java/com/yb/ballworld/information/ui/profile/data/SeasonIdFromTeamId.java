package com.yb.ballworld.information.ui.profile.data;

/**
 * Desc: <>
 * Author: JS-Barder
 * Created On: 2019/11/21 21:00
 */
public class SeasonIdFromTeamId {
    public String seasonId;
    public String teamId;
    public String type;
}
