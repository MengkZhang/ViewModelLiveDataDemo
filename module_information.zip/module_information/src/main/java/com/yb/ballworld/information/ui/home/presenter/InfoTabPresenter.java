package com.yb.ballworld.information.ui.home.presenter;

import android.text.TextUtils;
import android.util.Log;

import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.callback.OnUICallback;
import com.yb.ballworld.information.ui.home.bean.HomeIndexTabBean;
import com.yb.ballworld.information.ui.home.bean.TabEntity;
import com.yb.ballworld.information.ui.home.constant.FailStateConstant;
import com.yb.ballworld.information.ui.home.service.InfoHttpApi;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc
 * Date 2019/10/8
 * author mengk
 */
public class InfoTabPresenter implements InfoTabContract.IInfoTabPresenter {
    private InfoHttpApi httpApi;
    private InfoTabContract.IInfoTabView mView;

    public InfoTabPresenter() {
        httpApi = new InfoHttpApi();
    }

    /**
     * 加载数据
     */
    @Override
    public void loadData() {
        mView.requestLoading();
        httpApi.getInfoTabData(new LifecycleCallback<TabEntity>(mView.getFragment()) {
            @Override
            public void onSuccess(TabEntity data) {
                LogUtils.INSTANCE.e("===z","TabEntity data = " + data);
                if (data != null) {
                    List<TabEntity.CustomLablesBean> customLables = data.getCustomLables();
                    if (customLables != null && customLables.size() != 0) {
                        LogUtils.INSTANCE.e("===z","TabEntity customLables = " + customLables.get(0).getName());
                        //回调tab数据
                        mView.resultTabSuccess(customLables);
                    } else {
                        mView.resultFail(FailStateConstant.TYPE_EMPTY);
                    }
                } else {
                    LogUtils.INSTANCE.e("===z","tab为空");
                    mView.resultFail(FailStateConstant.TYPE_EMPTY);
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                LogUtils.INSTANCE.e("===z","请求失败");
                mView.resultFail(FailStateConstant.TYPE_ERROR);
            }
        });
    }

    /**
     * 绑定view
     *
     * @param view View
     */
    @Override
    public void attachView(InfoTabContract.IInfoTabView view) {
        this.mView = view;
    }

    /**
     * 解绑view
     */
    @Override
    public void detachView() {
        this.mView = null;
    }
}
