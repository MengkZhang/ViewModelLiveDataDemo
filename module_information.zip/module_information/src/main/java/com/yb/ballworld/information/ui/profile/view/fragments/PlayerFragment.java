package com.yb.ballworld.information.ui.profile.view.fragments;

import android.os.Bundle;
import android.view.View;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.yb.ballworld.common.livedata.LiveDataObserver;
import com.yb.ballworld.information.ui.profile.adapter.PlayerAdapter;
import com.yb.ballworld.information.ui.profile.data.PlayerStat;
import com.yb.ballworld.information.ui.profile.presenter.PlayerPresenter;

import java.util.ArrayList;
import java.util.List;

/**
 * 俱乐部资料库-球员
 * @author Gethin
 * @time 2019/11/7 18:08
 */

public class PlayerFragment extends RvBaseFragment<PlayerPresenter> {

    private PlayerAdapter adapter = new PlayerAdapter(new ArrayList<>());
    private String teamId;
    private String seasonId;

    public static PlayerFragment newInstance(String teamId, String seasonId) {
        PlayerFragment playerFragment = new PlayerFragment();
        Bundle args = new Bundle();
        args.putString("teamId", teamId);
        args.putString("seasonId", seasonId);
        playerFragment.setArguments(args);
        return playerFragment;
    }

    @Override
    protected void initData() {
        Bundle arguments = getArguments();
        if (arguments != null) {
            teamId = arguments.getString("teamId");
            seasonId = arguments.getString("seasonId");
        }
        super.initData();
    }

    @Override
    protected void loadData() {
        mPresenter.loadPlayerData(teamId, seasonId);
    }

    @Override
    protected BaseQuickAdapter getAdapter() {
        return adapter;
    }

    @Override
    public void initPresenter() {
        mPresenter.setVM(this);
    }

    @Override
    protected void bindEvent() {
        mPresenter.playerSeasonStat.observe(this, new LiveDataObserver<List<PlayerStat>>() {
            @Override
            public void onSuccess(List<PlayerStat> data) {
                stopRefresh();
                if (data != null) {
                    showPageContent();
                    adapter.setNewData(data);
                } else {
                    showPageEmpty("");
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                stopRefresh();
                showPageError(errMsg);
            }
        });

    }

    @Override
    protected void processClick(View view) {

    }
}
