package com.yb.ballworld.information.ui.community.data;

import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.yb.ballworld.information.ui.community.CommunityAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc: <社区话题与回复实体类>
 * Author: JS-Barder
 * Created On: 2019/11/8 17:24
 */
public class CommunityPost implements MultiItemEntity {
    public String content;//内容文字
    public String createdDate;//创建时间
    public String postDate;//创建时间
    public String id;//主键
    public String imgUrl;//封面图
    public String webShareUrl;//分享地址
    public int likeCount;//点赞数量
    public int pageViews;//浏览量
    public int postType;//0.主贴 1.回复
    public String preview;//文章预览 100字
    public int replyId;//回复ID
    public int sex;//0 未设置 1 男 2 女
    public int sonNum;//评论数量
    public String title;//标题
    public String videoUrl;//视频播放地址
    public ArrayList<String> postImgLists;//图片列表

    public String userId;//用户ID
    public String nickname;//昵称
    public String headImgUrl;//头像
    public CommunityPost latestPost;//最新回复
    public boolean isLike;//是否点赞
    public boolean isAttention;//是否关注该贴作者

    @Override
    public int getItemType() {
        return CommunityAdapter.TYPE_CONTENT_POST;
    }
}
