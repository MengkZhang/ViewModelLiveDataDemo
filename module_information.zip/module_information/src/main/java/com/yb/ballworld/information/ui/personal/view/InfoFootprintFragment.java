package com.yb.ballworld.information.ui.personal.view;

import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshFooter;
import com.scwang.smartrefresh.layout.api.RefreshHeader;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yb.ballworld.baselib.base.recycler.header.PlayBallHeader;
import com.yb.ballworld.baselib.base.recycler.header.RecyclerClassicsFooter;
import com.yb.ballworld.baselib.widget.placeholder.HomePlaceholderView;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.common.base.mvp.BaseMvpFragment;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.utils.JZReleaseUtil;
import com.yb.ballworld.information.ui.personal.adapter.InfoCollectionQuickAdapter;
import com.yb.ballworld.information.ui.personal.adapter.ItemPraiseAdapterHelper;
import com.yb.ballworld.information.ui.personal.bean.CollectionEntity;
import com.yb.ballworld.information.ui.personal.constant.FailStateConstant;
import com.yb.ballworld.information.ui.personal.presenter.InfoFootprintContract;
import com.yb.ballworld.information.ui.personal.presenter.InfoFootprintPresenter;
import com.yb.ballworld.information.ui.personal.presenter.ItemPraisePresenter;
import com.yb.ballworld.information.widget.GoodView;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.disposables.CompositeDisposable;

/**
 * A simple {@link Fragment} subclass.
 */
public class InfoFootprintFragment extends BaseMvpFragment<InfoFootprintPresenter> implements InfoFootprintContract.FootprintView {
    private PlaceholderView placeholder;
    private SmartRefreshLayout smartRefreshLayout;
    private RecyclerView recyclerView;
    private LinearLayoutManager layoutManager;
    private InfoCollectionQuickAdapter quickAdapter;
    //数据
    private List<CollectionEntity.ListBean> dataList = new ArrayList<>();
    private GoodView goodView;
    private CompositeDisposable compositeDisposable;

    public static InfoFootprintFragment newInstance() {
        return new InfoFootprintFragment();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_info_footprint;
    }

    @Override
    protected void initView() {
        goodView = new GoodView(getActivity());
        goodView.setText("+1");
        goodView.setImage(getResources().getDrawable(R.drawable.icon_priase_info));
        placeholder = findView(R.id.placeholder);
        smartRefreshLayout = findView(R.id.smartRefreshLayout);
        recyclerView = findView(R.id.recyclerView);
        layoutManager = new LinearLayoutManager(getActivity());
        smartRefreshLayout.setRefreshHeader(getRefreshHeader());
        smartRefreshLayout.setRefreshFooter(getRefreshFooter());
        quickAdapter = new InfoCollectionQuickAdapter(getActivity(), dataList);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(quickAdapter);
        smartRefreshLayout.setEnableLoadMore(false);
    }

    @Override
    public PlaceholderView getPlaceholderView() {
        return placeholder;
    }


    @Override
    protected RefreshFooter getRefreshFooter() {
        return new RecyclerClassicsFooter(getActivity());
    }

    @Override
    protected void bindEvent() {
        compositeDisposable = new CompositeDisposable();
        initRefreshLoadMoreEvent();
        initReLoadEvent();
        initScrollEvent();
        //点赞事件
        ItemPraiseAdapterHelper.initRemoveCollectOrPraise(quickAdapter, new ItemPraisePresenter(), goodView);
        //取消收藏
//        LiveEventBus.get().with(LiveEventBusKey.KEY_INFO_REMOVE_COLLECT, String.class)
//                .observe(this, newId -> compositeDisposable.add(loadCollectPosition(newId)
//                        .subscribeOn(AndroidSchedulers.mainThread())
//                        .subscribe(new Consumer<Integer>() {
//                            @Override
//                            public void accept(Integer integer) throws Exception {
//                                removeData(integer);
//                            }
//                        })
//                ));
        //收藏
//        LiveEventBus.get().with(LiveEventBusKey.KEY_INFO_COLLECT, String.class)
//                .observe(this, newId -> compositeDisposable.add(loadCollectPosition(newId)
//                        .subscribeOn(AndroidSchedulers.mainThread())
//                        .subscribe(new Consumer<Integer>() {
//                            @Override
//                            public void accept(Integer integer) throws Exception {
//                                if (mPresenter != null)
//                                    mPresenter.loadData();
//                            }
//                        })
//                ));
//        LiveEventBus.get().with(LiveEventBusKey.KEY_NEWS_COLLECTION, String.class).observe(this, newsId -> {
//            if (dataList.size() != 0) {
//                for (int i = 0; i < dataList.size(); i++) {
//                    CollectionEntity.ListBean listBean = dataList.get(i);
//                    String listBeanId = listBean.getId();
//                    int commentCount = listBean.getCommentCount();
//                    if (newsId.equals(listBeanId)) {
//                        listBean.setCommentCount(commentCount + 1);
//                        quickAdapter.notifyItemChanged(i);
//                        break;
//                    }
//                }
//            }
//        });
//        LiveEventBus.get().with(LiveEventBusKey.KEY_INFO_LIKE, String.class).observe(this, newsId -> {
//            if (dataList.size() != 0) {
//                for (int i = 0; i < dataList.size(); i++) {
//                    CollectionEntity.ListBean listBean = dataList.get(i);
//                    String listBeanId = listBean.getId();
//                    if (newsId.equals(listBeanId)) {
//                        listBean.setLike(true);
//                        quickAdapter.notifyItemChanged(i);
//                        break;
//                    }
//                }
//            }
//        });
    }

    @Override
    protected void initData() {
        showLoading(placeholder);
        mPresenter.loadData();
    }

    @Override
    protected void processClick(View view) {

    }

    @Override
    public void initPresenter() {
        mPresenter.setVM(this);
        mPresenter.attachView(this);
    }

    @Override
    public void requestLoading() {
        /*showLoading(placeholder);
        smartRefreshLayout.setEnableRefresh(false);
        smartRefreshLayout.setEnableLoadMore(false);*/
    }

    @Override
    public void resultSuccess(List<CollectionEntity.ListBean> beanList) {
        placeholder.hideLoading();
        smartRefreshLayout.finishRefresh(true);
        smartRefreshLayout.finishLoadMore(true);
        dataList.clear();
        dataList.addAll(beanList);
        quickAdapter.notifyDataSetChanged();
    }

    @Override
    public void setEnableLoadMore(boolean enableLoadMore) {
        smartRefreshLayout.setEnableLoadMore(enableLoadMore);
    }

    @Override
    public void resultFail(int type) {
        hidePageLoading();
        smartRefreshLayout.finishRefresh(false);
        smartRefreshLayout.finishLoadMore(false);
        switch (type) {
            case FailStateConstant.TYPE_ERROR:
                showError(placeholder, "网络出了小差，连接失败~");
                break;
            case FailStateConstant.TYPE_EMPTY:
                showEmpty(placeholder, "暂无数据");
                break;
            default:
                break;
        }
    }

    @Override
    public void resultRefreshSuccess() {
        hidePageLoading();
        smartRefreshLayout.finishRefresh();
        smartRefreshLayout.finishLoadMore();
        //刷新成功清理存储的数组
        dataList.clear();
    }

    @Override
    public void resultRefreshFail(String errorMsg) {
        hidePageLoading();
        smartRefreshLayout.finishRefresh();
        smartRefreshLayout.finishLoadMore();
    }

    /**
     * 初始化滑动事件
     */
    private void initScrollEvent() {
        //recyclerView滑动停止播放
        JZReleaseUtil.releaseAllVideos(recyclerView);
    }

    /**
     * 初始化重新加载数据
     */
    private void initReLoadEvent() {
        placeholder.setPageErrorRetryListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showLoading(placeholder);
                mPresenter.loadData();
            }
        });
    }

    /**
     * 初始化刷新和加载更多
     */
    private void initRefreshLoadMoreEvent() {
        smartRefreshLayout.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                mPresenter.loadMore();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                mPresenter.refreshData();
            }
        });
    }

    /**
     * 删除收藏的数据
     *
     * @param position
     */
    private void removeData(int position) {
        if (null == dataList || dataList.size() < position)
            return;
        CollectionEntity.ListBean bean = dataList.get(position);
        int count = 0;
        for (int i = 0; i < dataList.size(); i++) {
            CollectionEntity.ListBean b = dataList.get(i);
            if (b.getShowDate().equals(bean.getShowDate()) && !b.isTitle() && i != position)
                count++;
        }
        if (dataList.contains(bean)) {
            dataList.remove(bean);
        }
        quickAdapter.notifyDataSetChanged();

        if (count == 0) {
            for (int i = 0; i < dataList.size(); i++) {
                CollectionEntity.ListBean b = dataList.get(i);
                if (b.getShowDate().equals(bean.getShowDate()) && b.isTitle()) {
                    quickAdapter.remove(i);
                    quickAdapter.notifyItemChanged(i);
                }
            }

        }
        if (dataList.size() == 0)
            showEmpty(placeholder, "暂无数据");
    }

    @Override
    protected RefreshHeader getRefreshHeader() {
        return new PlayBallHeader(getActivity()).createAnim(PlayBallHeader.FOOTBALL);
    }


    private void showLoading(PlaceholderView placeholder) {
        showPageLoading();
    }

    private void showEmpty(PlaceholderView placeholder, String msg) {
        showPageEmpty(msg);
    }

    private void showError(PlaceholderView placeholder, String msg) {
        showPageError(msg);
    }

    /**
     * 根据Id查找所在收藏类别的位置
     *
     * @param newsId
     * @return
     */
    private Observable<Integer> loadCollectPosition(String newsId) {
        return Observable.create(new ObservableOnSubscribe<Integer>() {
            @Override
            public void subscribe(ObservableEmitter<Integer> emitter) throws Exception {
                List<CollectionEntity.ListBean> list = dataList;
                for (int i = 0; i < list.size(); i++) {
                    CollectionEntity.ListBean listBean = list.get(i);

                    if (newsId.equals(listBean.getId())) {
                        emitter.onNext(i);
                    }
                }
                emitter.onNext(-1);

            }
        });
    }

    @Override
    public void onPause() {
        super.onPause();
        JZReleaseUtil.releaseAllVideos();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        compositeDisposable.clear();
    }
}
