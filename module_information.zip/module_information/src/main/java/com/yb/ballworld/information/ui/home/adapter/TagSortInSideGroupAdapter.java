package com.yb.ballworld.information.ui.home.adapter;

import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.util.DensityUtil;
import com.yb.ballworld.common.baseapp.AppContext;
import com.yb.ballworld.common.utils.ScreenUtils;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.bean.IndexLableLetterBean;
import com.yb.ballworld.information.ui.home.bean.OutSideIndexNewBean;
import com.yb.ballworld.information.ui.home.utils.GlideLoadImgUtil;

import java.util.List;

/**
 * Desc 标签库内层adapter
 * Date 2019/11/7
 * author mengk
 */
public class TagSortInSideGroupAdapter extends BaseQuickAdapter<IndexLableLetterBean, BaseViewHolder> {

    int screenWidth;
    List<IndexLableLetterBean> data;

    public TagSortInSideGroupAdapter(@Nullable List<IndexLableLetterBean> data) {
        super(R.layout.item_tag_in_side, data);
        this.data = data;
        screenWidth = ScreenUtils.getScreenWidth(AppContext.getAppContext());
    }

    @Override
    public int getItemCount() {
//        if (data != null && data.size() > 0) {
//            if (data.size() >= 10) {
//                return 10;
//            } else {
//                return data.size();
//            }
//        } else {
//            return 0;
//        }
        return data.size();
    }

    @Override
    protected void convert(BaseViewHolder helper, IndexLableLetterBean item, int pos) {
        if (item == null) return;
        RelativeLayout rlTagRootView = helper.getView(R.id.rl_tag_root_view);
        setMargin(rlTagRootView);

        TextView tvTitle = helper.getView(R.id.tv_title_in_side);
        String cnAlias = item.getLable();
        tvTitle.setText(cnAlias);

        GlideLoadImgUtil.loadTeamLogo(mContext,item.getPicUrl(),helper.getView(R.id.iv_icon_in_side));

        helper.addOnClickListener(R.id.rl_tag_root_view);

        rlTagRootView.setBackgroundResource(item.isCheck() ? R.drawable.shape_info_sort_press : R.drawable.shape_info_sort_normal);
        tvTitle.setTextColor(item.isCheck() ? mContext.getResources().getColor(R.color.color_ff6b00) : mContext.getResources().getColor(R.color.color_4a4a4a));

    }

    private void setMargin(RelativeLayout rlTagRootView) {
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) rlTagRootView.getLayoutParams();
        layoutParams.bottomMargin = DensityUtil.dp2px(15);
        layoutParams.topMargin = 0;
        layoutParams.leftMargin = DensityUtil.dp2px(12);
    }

    public void changeCheck(AppCompatActivity activity,View view, IndexLableLetterBean item) {
        RelativeLayout tagRootView = view.findViewById(R.id.rl_tag_root_view);
        if (tagRootView != null) {
            tagRootView.setBackgroundResource(item.isCheck() ? R.drawable.shape_info_sort_press : R.drawable.shape_info_sort_normal);
        }
        TextView title = view.findViewById(R.id.tv_title_in_side);
        if (title != null) {
            title.setTextColor(item.isCheck() ? activity.getResources().getColor(R.color.color_ff6b00) : activity.getResources().getColor(R.color.color_4a4a4a));
        }

    }
}
