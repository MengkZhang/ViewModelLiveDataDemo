package com.yb.ballworld.information.ui.auth.utils;

import android.text.TextUtils;
/**
 * @author Gethin
 * @time 2019/11/21 13:56
 */

public class DigitUtil {

    /**
     * 手机号中间四位隐藏
     * @param phone 手机号
     */
    public static String hidePhone(String phone) {
        if(!TextUtils.isEmpty(phone) && phone.length() > 6 ) {
            int length = phone.length();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < length; i++) {
                char c = phone.charAt(i);
                if (i >= 3 && i <= 6) {
                    sb.append('*');
                } else {
                    sb.append(c);
                }
            }
            return sb.toString();
        }
        return "";
    }

    /**
     * 手机号中间四位隐藏
     * @param phone 手机号
     */
    public static String phoneHide(String phone) {
        String phoneHide = phone.replaceAll("(\\d{3})\\d{4}(\\d{4})","$1****$2");
        return phoneHide;
    }

    /**
     * 身份证中间8位隐藏
     * 隐藏出生年月
     * @param idCard 身份证号
     */
    public static String idCardHide(String idCard) {
        String idCardHide = idCard.replaceAll("(\\d{6})\\d{8}(\\w{4})","$1*****$2");
        return idCardHide;
    }
}
