package com.yb.ballworld.information.ui.home.bean;

import java.util.List;

/**
 * Desc TAb最终返回值
 * Date 2019/10/9
 * author mengk
 */
public class TabEntity {

    private List<CustomLablesBean> customLables;

    public List<CustomLablesBean> getCustomLables() {
        return customLables;
    }

    public void setCustomLables(List<CustomLablesBean> customLables) {
        this.customLables = customLables;
    }

    public static class CustomLablesBean {
        /**
         * id : 2
         * name : 视频
         * jumpUrl :
         */

        private String id;
        private String categoryId;
        private String name;
        private String jumpUrl;
        private int lableType;
        private String mediaType;
        private String sportType;

        public String getCategoryId() {
            return categoryId;
        }

        public void setCategoryId(String categoryId) {
            this.categoryId = categoryId;
        }

        public int getLableType() {
            return lableType;
        }

        public void setLableType(int lableType) {
            this.lableType = lableType;
        }

        public String getMediaType() {
            return mediaType;
        }

        public void setMediaType(String mediaType) {
            this.mediaType = mediaType;
        }

        public String getSportType() {
            return sportType;
        }

        public void setSportType(String sportType) {
            this.sportType = sportType;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getJumpUrl() {
            return jumpUrl;
        }

        public void setJumpUrl(String jumpUrl) {
            this.jumpUrl = jumpUrl;
        }
    }
}
