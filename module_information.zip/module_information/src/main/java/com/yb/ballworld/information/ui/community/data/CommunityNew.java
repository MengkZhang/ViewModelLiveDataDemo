package com.yb.ballworld.information.ui.community.data;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc: <发帖实体类>
 * Author: JS-Barder
 * Created On: 2019/11/11 15:49
 */
public class CommunityNew {
    public String content;
    public String imgUrl;
    public int replyId;
    public String userId;
    public String videoUrl;
    public List<String> postImgLists = new ArrayList<>();
}
