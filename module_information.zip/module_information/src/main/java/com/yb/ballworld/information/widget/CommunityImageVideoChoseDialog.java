package com.yb.ballworld.information.widget;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.PopupWindow;

import com.yb.ballworld.information.R;

import org.jetbrains.annotations.NotNull;

/**
 * Desc: <帖子发布选择视频或照片Window>
 * Author: JS-Barder
 * Created On: 2019/11/11 15:14
 */
public class CommunityImageVideoChoseDialog extends Dialog {

    private Context context;

    private View.OnClickListener captureVideoClickListener;
    private View.OnClickListener captureImageClickListener;
    private View.OnClickListener imageClickListener;

    public CommunityImageVideoChoseDialog(@NotNull Context context) {
        super(context);
        this.context = context;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_window_community_image_video);

        setCanceledOnTouchOutside(true);

        initView();
    }

    protected void initView() {
        Window window = getWindow();
        if (window != null) {
            WindowManager.LayoutParams params = window.getAttributes();
            params.width = ViewGroup.LayoutParams.MATCH_PARENT;
            params.gravity = Gravity.BOTTOM;
            window.setAttributes(params);
            window.setBackgroundDrawableResource(com.yb.ballworld.baselib.R.color.transparent);
            window.setWindowAnimations(com.yb.ballworld.baselib.R.style.dialog_bottom);
        }

        findViewById(R.id.tv_window_community_capture_video).setOnClickListener(v -> {
            if (captureVideoClickListener != null) {
                captureVideoClickListener.onClick(v);
            }
        });

        findViewById(R.id.tv_window_community_capture_image).setOnClickListener(v -> {
            if (captureImageClickListener != null) {
                captureImageClickListener.onClick(v);
            }
        });
        findViewById(R.id.tv_window_community_image).setOnClickListener(v -> {
            if (imageClickListener != null) {
                imageClickListener.onClick(v);
            }
        });
        findViewById(R.id.tv_window_community_cancel).setOnClickListener(v -> dismiss());
    }

    public void setCaptureVideoClickListener(View.OnClickListener captureVideoClickListener) {
        this.captureVideoClickListener = captureVideoClickListener;
    }

    public void setCaptureImageClickListener(View.OnClickListener captureClickListener) {
        this.captureImageClickListener = captureClickListener;
    }

    public void setImageClickListener(View.OnClickListener imageClickListener) {
        this.imageClickListener = imageClickListener;
    }
}
