package com.yb.ballworld.information.data;

import com.chad.library.adapter.base.entity.MultiItemEntity;

public class RootBean implements MultiItemEntity {
    private int itemType=0;
    private String title;
    private int args;

    public void setItemType(int itemType){
        this.itemType=itemType;
    }

    @Override
    public int getItemType() {
        return itemType;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getArgs() {
        return args;
    }

    public void setArgs(int args) {
        this.args = args;
    }

    public RootBean(int itemType, int args) {
        this.itemType = itemType;
        this.args = args;
    }

    public RootBean() {
    }
}
