package com.yb.ballworld.information.ui.profile.data;

/**
 * @author Gethin
 * @time 2019/11/18 14:45
 */

public class ChampionBean {
}
