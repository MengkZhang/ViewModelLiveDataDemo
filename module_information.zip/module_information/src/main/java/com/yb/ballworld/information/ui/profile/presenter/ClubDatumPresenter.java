package com.yb.ballworld.information.ui.profile.presenter;

import androidx.lifecycle.LifecycleOwner;

import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.livedata.LiveDataWrap;
import com.yb.ballworld.information.ui.profile.data.ClubDatumBean;

/**
 * @author Gethin
 * @time 2019/11/9 17:25
 */

public class ClubDatumPresenter extends BasePresenter<LifecycleOwner, VoidModel> {

    public LiveDataWrap<ClubDatumBean> clubDatum = new LiveDataWrap<>();

    public void loadClubDatum() {

    }
}
