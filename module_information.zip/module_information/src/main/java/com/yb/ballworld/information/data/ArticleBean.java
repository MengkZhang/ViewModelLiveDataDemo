package com.yb.ballworld.information.data;

import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.yb.ballworld.information.ui.detail.InforConstant;
import com.yb.ballworld.information.ui.home.bean.IndexLableDetailBean;
import com.yb.ballworld.information.utils.HtmlParseData;

import java.util.List;

/**
 * Desc: 单篇文章
 *
 * @author ink
 * created at 2019/10/9 20:51
 */
public class ArticleBean implements MultiItemEntity {
    private int multiItemType= InforConstant.ItemType.DETAIL_NEWS;

    //1: 正常, 0: 禁用
    private int status;

    //用户id
    private int userId;

    //展示类型（0: 正常, 1: 双图展示，2: 三图展示，3: 图集）
    private int showType;

    //文章点赞数量
    private int likeCount;

    //是否点过赞了
    private boolean isLike;

    //是否已收藏
    private boolean isFavorites;

    //资讯类型（0.新闻 1.视频）
    private int mediaType;

    //浏览量
    private int pageViews;

    //评论数量
    private int commentCount;

    //评论状态（1: 正常,0: 禁用）
    private int commentStatus;

    //文章ID
    private String id;

    //文章标题
    private String title;

    //封面图片地址
    private String imgUrl;

    //播放地址
    private String playUrl;

    //预览文字
    private String preview;

    //内容文字
    private String content;

    //关键词
    private String keywords;

    //用户昵称
    private String nickName;

    //创建时间
    private String createdDate;

    //发布来源
    private String releaseSource;

    //资讯图片列表
    private List<ImageBean> newsImgs;

    private List<IndexLableDetailBean> labels;

    //分类列表
    private String categoryId;

    //分享链接
    private String webShareUrl;

    //用户头像
    private String headImgUrl;

    //是否关注了作者
    private boolean isAttention;

    private HtmlParseData htmlParseData;

    public List<IndexLableDetailBean> getLabels() {
        return labels;
    }

    public void setLabels(List<IndexLableDetailBean> labels) {
        this.labels = labels;
    }

    public boolean isAttention() {
        return isAttention;
    }

    public void setAttention(boolean attention) {
        isAttention = attention;
    }

    public String getHeadImgUrl() {
        return headImgUrl;
    }

    public void setHeadImgUrl(String headImgUrl) {
        this.headImgUrl = headImgUrl;
    }

    public String getWebShareUrl() {
        return webShareUrl;
    }

    public void setWebShareUrl(String webShareUrl) {
        this.webShareUrl = webShareUrl;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getShowType() {
        return showType;
    }

    public void setShowType(int showType) {
        this.showType = showType;
    }

    public int getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(int likeCount) {
        this.likeCount = likeCount;
    }

    public int getMediaType() {
        return mediaType;
    }

    public void setMediaType(int mediaType) {
        this.mediaType = mediaType;
    }

    public int getPageViews() {
        return pageViews;
    }

    public void setPageViews(int pageViews) {
        this.pageViews = pageViews;
    }

    public int getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(int commentCount) {
        this.commentCount = commentCount;
    }

    public int getCommentStatus() {
        return commentStatus;
    }

    public void setCommentStatus(int commentStatus) {
        this.commentStatus = commentStatus;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getPlayUrl() {
        return playUrl;
    }

    public void setPlayUrl(String playUrl) {
        this.playUrl = playUrl;
    }

    public String getPreview() {
        return preview;
    }

    public void setPreview(String preview) {
        this.preview = preview;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getReleaseSource() {
        return releaseSource;
    }

    public void setReleaseSource(String releaseSource) {
        this.releaseSource = releaseSource;
    }

    public List<ImageBean> getNewsImgs() {
        return newsImgs;
    }

    public void setNewsImgs(List<ImageBean> newsImgs) {
        this.newsImgs = newsImgs;
    }

    public boolean isLike() {
        return isLike;
    }

    public void setLike(boolean like) {
        isLike = like;
    }

    public boolean isFavorites() { return isFavorites; }

    public void setFavorites(boolean favorites) { isFavorites = favorites; }

    @Override
    public int getItemType() {
        return multiItemType;
    }

    public void setItemType(int multiItemType) {
        this.multiItemType= multiItemType;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public HtmlParseData getHtmlParseData() {
        return htmlParseData;
    }

    public void setHtmlParseData(HtmlParseData htmlParseData) {
        this.htmlParseData = htmlParseData;
    }
}
