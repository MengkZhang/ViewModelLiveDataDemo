package com.yb.ballworld.information.ui.home.adapter;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.android.flexbox.FlexboxLayoutManager;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.bean.IndexLableLetterBean;
import com.yb.ballworld.information.ui.home.bean.OutSideIndexListBean;
import com.yb.ballworld.information.ui.home.bean.OutSideIndexListLableLetterBean;
import com.yb.ballworld.information.ui.home.bean.OutSideIndexNewBean;
import com.yb.ballworld.information.ui.home.bean.TagOutSideListBean2;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc 标签库外层adapter
 * Date 2019/11/7
 * author mengk
 */
public class TagSortOutSideLabelGroupAdapter extends BaseQuickAdapter<OutSideIndexListLableLetterBean, BaseViewHolder> {

    private TagSortInSideGroupAdapter tagSortByIndexInSideAdapter;

    public TagSortOutSideLabelGroupAdapter(@Nullable List<OutSideIndexListLableLetterBean> data) {
        super(R.layout.item_tag_out_side, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, OutSideIndexListLableLetterBean item, int pos) {
        if (item == null) return;
        TextView tvTitle = helper.getView(R.id.tv_title_out_side);
        helper.getView(R.id.tv_to_tag_more).setVisibility(View.VISIBLE);
        helper.addOnClickListener(R.id.tv_to_tag_more);

        //这个title一定不为空
        tvTitle.setText(item.getTitle());
        List<IndexLableLetterBean> data = new ArrayList<>();
        data.addAll(item.getList());

        RecyclerView recyclerView = helper.getView(R.id.rv_inside);
        FlexboxLayoutManager flexboxLayoutManager = new FlexboxLayoutManager(mContext);
//        recyclerView.setLayoutManager(new GridLayoutManager(mContext, 3));
        recyclerView.setLayoutManager(flexboxLayoutManager);
        tagSortByIndexInSideAdapter = new TagSortInSideGroupAdapter(data);
        recyclerView.setAdapter(tagSortByIndexInSideAdapter);
        tagSortByIndexInSideAdapter.setOnItemChildClickListener((adapter, view, position) -> {
            if (view.getId() == R.id.rl_tag_root_view) {
                Object bean = adapter.getItem(position);
                if (bean instanceof IndexLableLetterBean) {
                    if (onClickTagListener != null) {
                        onClickTagListener.clickTag(view,position,(IndexLableLetterBean) bean);
                    }
                }
            }
        });

    }

    public TagSortInSideGroupAdapter getTagSortInSideAdapter() {
        return tagSortByIndexInSideAdapter;
    }

    public interface OnClickTagListener {
        void clickTag(View view, int position, IndexLableLetterBean bean);
    }

    private OnClickTagListener onClickTagListener;

    public void setOnClickTagListener(OnClickTagListener onClickTagListener) {
        this.onClickTagListener = onClickTagListener;
    }
}
