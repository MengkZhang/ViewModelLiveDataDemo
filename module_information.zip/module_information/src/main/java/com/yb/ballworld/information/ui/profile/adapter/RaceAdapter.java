package com.yb.ballworld.information.ui.profile.adapter;

import android.graphics.Color;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.profile.data.ClubSeasonAgendaBean;

import java.text.SimpleDateFormat;
import java.util.List;

/**
 * @author Gethin
 * @time 2019/11/9 10:16
 */

public class RaceAdapter extends BaseMultiItemQuickAdapter<ClubSeasonAgendaBean, BaseViewHolder> {

    public RaceAdapter(List<ClubSeasonAgendaBean> data) {
        super(data);
        addItemType(ClubSeasonAgendaBean.HEADER, R.layout.rv_item_race_header);
        addItemType(ClubSeasonAgendaBean.CONTENT, R.layout.rv_item_race_content);
    }

    @Override
    protected void convert(BaseViewHolder helper, ClubSeasonAgendaBean item, int pos) {
        switch (item.getItemType()) {
            case ClubSeasonAgendaBean.HEADER:
                TextView tvTime = helper.getView(R.id.tvTime);
                SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy年MM月");
                if (item.getMatchTime() > 0) {
                    String time = sdf1.format(item.getMatchTime());
                    tvTime.setText(time);
                }
                break;
            case ClubSeasonAgendaBean.CONTENT:
                TextView tvDate = helper.getView(R.id.tvDate);
                TextView tvMatchInfo = helper.getView(R.id.tvMatchInfo);
                TextView tvScore = helper.getView(R.id.tvScore);
                ImageView ivHostLogo = helper.getView(R.id.ivHostLogo);
                ImageView ivGuestLogo = helper.getView(R.id.ivGuestLogo);
                TextView tvHostTeamName = helper.getView(R.id.tvHostTeamName);
                TextView tvGuestTeamName = helper.getView(R.id.tvGuestTeamName);

                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM-dd HH:mm");
                if (item.getMatchTime() > 0) {
                    String time = simpleDateFormat.format(item.getMatchTime());
                    tvDate.setText(time);
                } else {
                    tvDate.setText("-");
                }
                String zhDayName = item.getZhDayName();
                String leagueName = item.getLeagueName();
                String round = item.getRound();
                tvMatchInfo.setText("" +zhDayName + " " + leagueName + " " + round);
                int status = item.getStatus();
                if (status == 1) { // 1，未开赛，2进行中，3已结束
                    tvScore.setText("VS");
                    tvScore.setTextColor(Color.parseColor("#999999"));
                }  else {
                    tvScore.setText(""+item.getHostTeamScore() + "-" + item.getGuestTeamScore());
                    tvScore.setTextColor(Color.parseColor("#ff7801"));
                }
                Glide.with(mContext).load(item.getHostTeamLogo()).placeholder(R.mipmap.ic_placeholder_match_event).error(R.mipmap.ic_placeholder_match_event).into(ivHostLogo);
                Glide.with(mContext).load(item.getGuestTeamLogo()).placeholder(R.mipmap.ic_placeholder_match_event).error(R.mipmap.ic_placeholder_match_event).into(ivGuestLogo);
                tvHostTeamName.setText(item.getHostTeamName());
                tvGuestTeamName.setText(item.getGuestTeamName());
                break;
        }
    }
}
