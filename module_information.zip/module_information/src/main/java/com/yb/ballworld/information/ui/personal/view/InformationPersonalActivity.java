package com.yb.ballworld.information.ui.personal.view;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.bifen.tablayout.listener.OnTabSelectListener;
import com.bumptech.glide.Glide;
import com.yb.ballworld.baselib.widget.placeholder.HomePlaceholderView;
import com.yb.ballworld.common.base.BaseFragmentStateAdapter;
import com.yb.ballworld.common.base.mvp.BaseMvpActivity;
import com.yb.ballworld.common.utils.DisplayUtil;
import com.yb.ballworld.common.widget.CommonTitleBar;
import com.yb.ballworld.common.widget.STCircleImageView;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.personal.bean.PersonalInfo;
import com.yb.ballworld.information.ui.personal.presenter.InfoPersonalPresenter;
import com.yb.ballworld.information.widget.SlidingTitleTabLayout;

import java.util.ArrayList;


/**
 * Desc: 资讯 个人页面
 * Author: JS-Kylo
 * Created On: 2019/10/10 10:48
 */
@Deprecated
public class InformationPersonalActivity extends BaseMvpActivity<InfoPersonalPresenter> {
    private SlidingTitleTabLayout xTab;
    private STCircleImageView ivUserHeader;
    private TextView tvUserName, tvDesc;
    private ViewPager viewPager;
    private HomePlaceholderView placeholder;
    private ArrayList<Fragment> fragments = new ArrayList<Fragment>();
    private String userID;
    private PersonalInfo userBean;
    private int publishCount;
    private int commentCount;
    private String userName = "";
    private String headUrl = "";

    public static void startActivity(Activity activity, String userId) {
        Intent intent = new Intent(activity, InformationPersonalActivity.class);
        intent.putExtra("userId", userId);
        activity.startActivity(intent);
    }

    public static void startActivity(Context activity, String userId) {
        Intent intent = new Intent(activity, InformationPersonalActivity.class);
        intent.putExtra("userId", userId);
        activity.startActivity(intent);
    }

    @Override
    public void initPresenter() {
        if (mPresenter != null) {
            mPresenter.setVM(this);
        }
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_personal_page;
    }

    @Override
    protected void initView() {
        xTab = F(R.id.xTab);
        placeholder = F(R.id.placeholderView);
        ivUserHeader = F(R.id.ivUserHeader);
        tvUserName = F(R.id.tvUserName);
        tvDesc = F(R.id.tvDesc);
        viewPager = F(R.id.viewPager);
    }

    @Override
    protected void initData() {
        try {
            userID = getIntent().getStringExtra("userId");
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        placeholder.showLoading();
        //showDialogLoading();
        mPresenter.loadUserInfo(userID);
        //mPresenter.loadUserInfo("999");
    }

    @Override
    protected void bindEvent() {
        //F(R.id.ivBack).setOnClickListener(this);
        ((CommonTitleBar) findViewById(R.id.commonTitleBar)).setListener(new CommonTitleBar.OnTitleBarListener() {
            @Override
            public void onClicked(View v, int action, String extra) {
                if (action == CommonTitleBar.ACTION_LEFT_BUTTON) {
                    finish();
                }
            }
        });
    }

    @Override
    protected void processClick(View view) {
        int viewId = view.getId();
        if (viewId == R.id.ivBack)
            finish();
    }

    /**
     * 初始化用户信息
     */
    public void initUserInfo(PersonalInfo data, String errMsg) {
        if (data != null) {
            userBean = data;
            try {
                this.publishCount = userBean.getArticleCount();
                this.commentCount = userBean.getCommentCount();
            } catch (Exception e) {
            }
            userName = userBean.getNickname();
            headUrl = userBean.getHeadImgUrl();
            String introduce = TextUtils.isEmpty(userBean.getPersonalDesc())?"":userBean.getPersonalDesc();
            Glide.with(InformationPersonalActivity.this).load(headUrl).error(R.drawable.user_default_icon2).placeholder(R.drawable.user_default_icon2).into(ivUserHeader);
            tvUserName.setText(userName);
            tvDesc.setText(introduce);
        }
        initTabPager();
    }

    /**
     * 初始化fragment
     */
    private void initTabPager() {
        //hideDialogLoading();
        placeholder.hideLoading();
        String publishTitle = "发表";
        String commentTitle = "评论";
        String secondPubTitle = "", secondComTitle = "";
        //if (publishCount > 0)
        secondPubTitle = "" + publishCount;
        //if (commentCount > 0)
        secondComTitle = "" + commentCount;

        String[] titles = new String[]{publishTitle, commentTitle};
        String[] secondTitles = new String[]{secondPubTitle, secondComTitle};
        ArrayList<String> titleList = new ArrayList<String>();
        for (String str : titles) {
            titleList.add(str);
        }
        fragments.add(InformationPersonalPublishFragment.newInstance(userID));
        fragments.add(InformationPersonalCommentFragment.newInstance(userID, userName,headUrl));

        BaseFragmentStateAdapter adapter = new BaseFragmentStateAdapter(getSupportFragmentManager(), fragments, titleList);
        viewPager.setAdapter(adapter);
        viewPager.setOffscreenPageLimit(fragments.size());
        float tabWidth = DisplayUtil.getScreenWidth(this) * 1.0f / titles.length;
        xTab.setTabWidth(tabWidth);
        xTab.setViewPager(viewPager, titles, secondTitles);
        viewPager.setCurrentItem(0);
        xTab.setOnTabSelectListener(new OnTabSelectListener() {
            @Override
            public void onTabSelect(int position) {
                fragments.get(position).getView().requestLayout();
            }

            @Override
            public void onTabReselect(int position) {
                fragments.get(position).getView().requestLayout();
            }
        });
    }

    private void initTab(String[] titles ,String[] secondTitles){
        fragments.add(InformationPersonalPublishFragment.newInstance(""));
        fragments.add(InformationPersonalCommentFragment.newInstance("", userName,headUrl));
        viewPager.setAdapter(new BaseFragmentStateAdapter(getSupportFragmentManager(), fragments));
        float tabWidth = DisplayUtil.getScreenWidth(this) * 1.0f / titles.length;
        xTab.setTabWidth(tabWidth);
        xTab.setViewPager(viewPager, titles, secondTitles);
    }
}
