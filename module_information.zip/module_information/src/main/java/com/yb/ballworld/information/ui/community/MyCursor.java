package com.yb.ballworld.information.ui.community;

import android.database.AbstractCursor;
import android.database.CursorWindow;
import android.provider.MediaStore;
import android.util.Log;

import com.yb.ballworld.baselib.utils.LogUtils;

import java.util.ArrayList;

/**
 * Desc: <自定义 Cursor>
 * Author: JS-Dugu
 * Created On: 2019/11/16 21:22
 */
public class MyCursor extends AbstractCursor {

    private static final String TAG = "MyCursor";
    // 构建cursor时必须先传入列明数组以规定列数
    private String[] columnNames = {
            MediaStore.Files.FileColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.SIZE,
            "duration"};


    private int allDataCnt = 0;//总记录行数
    private int columnNum = 0;
    private int logicNum = 0;
    private int currentPosition = 0;
    private final int MAX_SHOW_NUM = 10;

    /**
     * 数据区域
     */
    // 在构造的时候填充数据，里层数据的 size == columnNames.leng
    private ArrayList<ArrayList<String>> allDatas = new ArrayList<ArrayList<String>>();
    private ArrayList<ArrayList<String>> currentDatas = null;// 在 fillwindow 时填充
    private ArrayList<String> oneLineData = null;// onMove 时填充

    @Override
    public void fillWindow(int position, CursorWindow window) {
        if (position < 0 || position >= allDataCnt) {
            return;
        }
        if (position > 0) {
            position -= 1;
        }
        currentPosition = position;
        int currentShowCnt = MAX_SHOW_NUM;

        if (allDataCnt - position < MAX_SHOW_NUM) {
            currentShowCnt = allDataCnt - position;
        }

        if (currentDatas == null) {
            currentDatas = new ArrayList<ArrayList<String>>();
        } else {
            currentDatas.clear();
        }

        for (int i = 0; i < currentShowCnt; i++) {
            currentDatas.add(allDatas.get(position + i));
        }
        LogUtils.INSTANCE.d(TAG, "fillWindowout end position=" + (position + currentShowCnt - 1));
        super.fillWindow(position, window);
    }

    /**
     * 获取当前行对象，为一个oneLineDatastring[]
     */
    @Override
    public boolean onMove(int oldPosition, int newPosition) {
        if(newPosition< 0 || newPosition >= getCount()){
            oneLineData= null;
            return false;
        }
        int index = newPosition - currentPosition;
        if(index< 0 || index >= currentDatas.size()){
            return false;
        }
        oneLineData= currentDatas.get(index);
        return super.onMove(oldPosition,newPosition);
    }

    @Override
    public int getInt(int column) {
        Object value = getString(column);
        try{
            return value != null? ((Number) value).intValue() : null;
        } catch(ClassCastException e) {

            if(value instanceof CharSequence) {
                try{
                    return Integer.valueOf(value.toString());
                } catch(NumberFormatException e2) {
                    LogUtils.INSTANCE.e(TAG,"Cannotparse int value for "+ value + "at key "+ column);
                    return 0;
                }
            } else{
                LogUtils.INSTANCE.e(TAG,"Cannotcast value for "+ column + "to a int: "+ value+ e);
                return 0;
            }
        }
    }

    @Override
    public long getLong(int column) {
        return 0;
    }

    @Override
    public float getFloat(int column) {
        return 0;
    }

    @Override
    public double getDouble(int column) {
        return 0;
    }

    @Override
    public boolean isNull(int column) {
        return false;
    }

    /**
     *获取游标行数
     */
    @Override
    public int getCount() {
        return allDataCnt;
    }

    /**
     * 获取列名称
     */
    @Override
    public String[] getColumnNames() {
        return columnNames;
    }

    @Override
    public String getString(int column) {
        if(oneLineData== null){
            return"null";
        }
        return oneLineData.get(column);
    }

    @Override
    public short getShort(int column) {
        return 0;
    }

}
