package com.yb.ballworld.information.ui.detail;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

import com.bfw.image.glide.GlideApp;
import com.bumptech.glide.request.RequestOptions;
import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.yb.ballworld.baselib.utils.ImageManager;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.data.CommitBean;
import com.yb.ballworld.information.utils.CommondUtil;

import java.util.ArrayList;
import java.util.List;

import cn.jzvd.JzvdStd;

import static com.yb.ballworld.information.ui.detail.InforConstant.MediaType.ITEMTYPE_IMGS;
import static com.yb.ballworld.information.ui.detail.InforConstant.MediaType.ITEMTYPE_NO_MEDIA;
import static com.yb.ballworld.information.ui.detail.InforConstant.MediaType.ITEMTYPE_VIDEO;


public class CommentQuickAdapter extends BaseMultiItemQuickAdapter<CommitBean, BaseViewHolder> {
    /**
     * Same as QuickAdapter#QuickAdapter(Context,int) but with
     * some initialization data.
     *
     * @param data A new list is created out of this one to avoid mutable list
     */
    public CommentQuickAdapter(List data) {
        super(data);
        addItemType(ITEMTYPE_IMGS, R.layout.item_commit_layout);
    }


    @Override
    protected void convert(BaseViewHolder helper, CommitBean item, int pos) {
        ImageManager.INSTANCE.loadRoundIcon(item.getHeadImgUrl(), R.drawable.user_default_icon2, 0, helper.getView(R.id.singleCommit_photo));
        helper.setText(R.id.singleCommit_commiter, item.getNickName());
        helper.setText(R.id.singleCommit_likeCount, CommondUtil.likeCount(item.getLikeCount(), helper.itemView.getContext()));
        helper.setImageResource(R.id.singleCommit_like, item.isLike() ? R.drawable.icon_priase_info : R.drawable.icon_priase_info_normal);
        helper.setText(R.id.singleCommit_text, item.getContent());
        helper.setText(R.id.singleCommit_count, CommondUtil.likeCount(item.getSonNum(), helper.itemView.getContext()));


        int mediaType = getMediaType(item);
        if (mediaType == ITEMTYPE_VIDEO) {
            handleVideo(helper, item);
        } else if (mediaType == ITEMTYPE_IMGS) {
            handleImgs(helper, item);
        } else {
            helper.getView(R.id.singleCommit_frameLayout).setVisibility(View.GONE);
        }

    }

    private int getMediaType(CommitBean commitBean) {
        int type;
        if (!TextUtils.isEmpty(commitBean.getVideoUrl())) {
            type = ITEMTYPE_VIDEO;
        } else if (isHasImg(commitBean)) {
            type = ITEMTYPE_IMGS;
        } else {
            type = ITEMTYPE_NO_MEDIA;
        }
        return type;
    }

    private boolean isHasImg(CommitBean commitBean) {

        return !TextUtils.isEmpty(commitBean.getImgUrl1()) || !TextUtils.isEmpty(commitBean.getImgUrl2()) || !TextUtils.isEmpty(commitBean.getImgUrl3());
    }

    private List<String> getImgList(CommitBean commitBean) {
        List<String> imgList = new ArrayList<>();

        String imgUrl = commitBean.getImgUrl1();
        if (!TextUtils.isEmpty(imgUrl)) {
            imgList.add(imgUrl);
        }
        imgUrl = commitBean.getImgUrl2();
        if (!TextUtils.isEmpty(imgUrl)) {
            imgList.add(imgUrl);
        }
        imgUrl = commitBean.getImgUrl3();
        if (!TextUtils.isEmpty(imgUrl)) {
            imgList.add(imgUrl);
        }
        return imgList;
    }

    private void handleVideo(BaseViewHolder helper, CommitBean commitBean) {
        helper.getView(R.id.singleCommit_frameLayout).setVisibility(View.VISIBLE);
        LayoutInflater.from(helper.itemView.getContext()).inflate(R.layout.item_comment_video, helper.getView(R.id.singleCommit_frameLayout), true);
        JzvdStd jzvdStd = helper.getView(R.id.item_comment_video);
//        if (!TextUtils.isEmpty(commitBean.getImgUrl())) {
//            Glide.with(helper.itemView.getContext()).load(commitBean.getImgUrl()).into(jzvdStd.thumbImageView);
//        }
        if (!TextUtils.isEmpty(commitBean.getVideoUrl())) {
            jzvdStd.setUp(commitBean.getVideoUrl(), "", JzvdStd.SCREEN_NORMAL);
            GlideApp.with(helper.itemView.getContext())
                    .setDefaultRequestOptions(
                            new RequestOptions()
                                    .frame(1).optionalFitCenter())
                    .load(commitBean.getVideoUrl())
                    .into(jzvdStd.thumbImageView);
        }
    }

    private void handleImgs(BaseViewHolder helper, CommitBean commitBean) {
        helper.getView(R.id.singleCommit_frameLayout).setVisibility(View.VISIBLE);
        LayoutInflater.from(helper.itemView.getContext()).inflate(R.layout.item_comment_imglist, helper.getView(R.id.singleCommit_frameLayout), true);
        RecyclerView recyclerView = helper.getView(R.id.recycle_imgs);
        CommentImgQuickAdapter commentImgQuickAdapter = new CommentImgQuickAdapter(null);
        recyclerView.setAdapter(commentImgQuickAdapter);
        commentImgQuickAdapter.autoFit(recyclerView, getImgList(commitBean));
    }
}
