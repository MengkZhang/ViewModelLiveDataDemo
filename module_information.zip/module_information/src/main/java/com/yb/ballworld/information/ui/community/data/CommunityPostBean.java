package com.yb.ballworld.information.ui.community.data;

import java.util.List;

/**
 * Desc: <>
 * Author: JS-Barder
 * Created On: 2019/11/9 16:31
 */
public class CommunityPostBean {
    public int totalCount;
    public int pageNum;
    public int pageSize;
    public int totalPage;
    public List<CommunityPost> list;
}
