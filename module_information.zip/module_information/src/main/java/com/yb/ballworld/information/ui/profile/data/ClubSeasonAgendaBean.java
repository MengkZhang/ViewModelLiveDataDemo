package com.yb.ballworld.information.ui.profile.data;

import com.chad.library.adapter.base.entity.MultiItemEntity;
/**
 * @author Gethin
 * @time 2019/11/20 13:11
 */

public class ClubSeasonAgendaBean implements MultiItemEntity {

    /**
     * leagueId : 9
     * leagueName : 英超
     * enLeagueName : null
     * matchId : 1686806
     * matchTime : 1565377200000
     * hostTeamId : 44
     * hostTeamName : 利物浦
     * enHostTeamName : null
     * guestTeamId : 217
     * guestTeamName : 诺维奇
     * enGuestTeamName : null
     * hostTeamLogo : https://img.qiutianxia.com/imgs/teams/20190219230536728_100x100.png
     * guestTeamLogo : https://img.qiutianxia.com/imgs/teams/20190219230556282_100x100.png
     * hostTeamScore : 4
     * guestTeamScore : 1
     * seasonId : 11100
     * round : 第1轮
     * zhDayName : 周六
     * groupId : null
     * status : 3
     * level : null
     * leagueColor : null
     * leagueLogo : null
     */

    public static final int HEADER = 1;
    public static final int CONTENT = 2;

    public static final int CONTENT_START = 1;
    public static final int CONTENT_END = 2;

    private int contentPos;
    private int itemType = CONTENT;

    public int getContentPos() {
        return contentPos;
    }

    public void setContentPos(int contentPos) {
        this.contentPos = contentPos;
    }

    public void setItemType(int itemType) {
        this.itemType = itemType;
    }

    @Override
    public int getItemType() {
        return itemType;
    }

    private int leagueId;
    private String leagueName;
    private String enLeagueName;
    private int matchId;
    private long matchTime;
    private int hostTeamId;
    private String hostTeamName;
    private String enHostTeamName;
    private int guestTeamId;
    private String guestTeamName;
    private String enGuestTeamName;
    private String hostTeamLogo;
    private String guestTeamLogo;
    private int hostTeamScore;
    private int guestTeamScore;
    private int seasonId;
    private String round;
    private String zhDayName;
    private String groupId;
    private int status;
    private String level;
    private String leagueColor;
    private String leagueLogo;

    public int getLeagueId() {
        return leagueId;
    }

    public void setLeagueId(int leagueId) {
        this.leagueId = leagueId;
    }

    public String getLeagueName() {
        return leagueName;
    }

    public void setLeagueName(String leagueName) {
        this.leagueName = leagueName;
    }

    public String getEnLeagueName() {
        return enLeagueName;
    }

    public void setEnLeagueName(String enLeagueName) {
        this.enLeagueName = enLeagueName;
    }

    public int getMatchId() {
        return matchId;
    }

    public void setMatchId(int matchId) {
        this.matchId = matchId;
    }

    public long getMatchTime() {
        return matchTime;
    }

    public void setMatchTime(long matchTime) {
        this.matchTime = matchTime;
    }

    public int getHostTeamId() {
        return hostTeamId;
    }

    public void setHostTeamId(int hostTeamId) {
        this.hostTeamId = hostTeamId;
    }

    public String getHostTeamName() {
        return hostTeamName;
    }

    public void setHostTeamName(String hostTeamName) {
        this.hostTeamName = hostTeamName;
    }

    public Object getEnHostTeamName() {
        return enHostTeamName;
    }

    public void setEnHostTeamName(String enHostTeamName) {
        this.enHostTeamName = enHostTeamName;
    }

    public int getGuestTeamId() {
        return guestTeamId;
    }

    public void setGuestTeamId(int guestTeamId) {
        this.guestTeamId = guestTeamId;
    }

    public String getGuestTeamName() {
        return guestTeamName;
    }

    public void setGuestTeamName(String guestTeamName) {
        this.guestTeamName = guestTeamName;
    }

    public Object getEnGuestTeamName() {
        return enGuestTeamName;
    }

    public void setEnGuestTeamName(String enGuestTeamName) {
        this.enGuestTeamName = enGuestTeamName;
    }

    public String getHostTeamLogo() {
        return hostTeamLogo;
    }

    public void setHostTeamLogo(String hostTeamLogo) {
        this.hostTeamLogo = hostTeamLogo;
    }

    public String getGuestTeamLogo() {
        return guestTeamLogo;
    }

    public void setGuestTeamLogo(String guestTeamLogo) {
        this.guestTeamLogo = guestTeamLogo;
    }

    public int getHostTeamScore() {
        return hostTeamScore;
    }

    public void setHostTeamScore(int hostTeamScore) {
        this.hostTeamScore = hostTeamScore;
    }

    public int getGuestTeamScore() {
        return guestTeamScore;
    }

    public void setGuestTeamScore(int guestTeamScore) {
        this.guestTeamScore = guestTeamScore;
    }

    public int getSeasonId() {
        return seasonId;
    }

    public void setSeasonId(int seasonId) {
        this.seasonId = seasonId;
    }

    public String getRound() {
        return round;
    }

    public void setRound(String round) {
        this.round = round;
    }

    public String getZhDayName() {
        return zhDayName;
    }

    public void setZhDayName(String zhDayName) {
        this.zhDayName = zhDayName;
    }

    public Object getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public Object getLeagueColor() {
        return leagueColor;
    }

    public void setLeagueColor(String leagueColor) {
        this.leagueColor = leagueColor;
    }

    public String getLeagueLogo() {
        return leagueLogo;
    }

    public void setLeagueLogo(String leagueLogo) {
        this.leagueLogo = leagueLogo;
    }
}
