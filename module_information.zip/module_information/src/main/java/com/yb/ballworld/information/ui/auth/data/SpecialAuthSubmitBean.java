package com.yb.ballworld.information.ui.auth.data;

/**
 * 特约认证数据提交回调状态
 * @author Gethin
 * @time 2019/11/20 19:42
 */

public class SpecialAuthSubmitBean {

    public static final int SUCCESS = 0;
    public static final int FAILURE = -1;

    private int state;
    private int errCode;
    private String errMsg;

    public SpecialAuthSubmitBean(int state, String errMsg) {
        this.state = state;
        this.errMsg = errMsg;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public int getErrCode() {
        return errCode;
    }

    public void setErrCode(int errCode) {
        this.errCode = errCode;
    }

    public String getErrMsg() {
        return errMsg;
    }

    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }
}
