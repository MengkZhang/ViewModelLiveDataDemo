package com.yb.ballworld.information.ui.community.presenter;

import com.jeremyliao.liveeventbus.LiveEventBus;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.information.http.InforMationHttpApi;
import com.yb.ballworld.information.ui.home.constant.FailStateConstant;
import com.yb.ballworld.information.ui.home.constant.LoadMoreType;
import com.yb.ballworld.information.ui.community.bean.AttentionResult;
import com.yb.ballworld.information.ui.community.bean.AuthorBeanList;
import com.yb.ballworld.information.ui.community.view.AuthorListActivity;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc: 作者列表
 * Author: JS-Kylo
 * Created On: 2019/11/8 13:24
 */
public class AuthorListPresenter extends BasePresenter<AuthorListActivity, VoidModel> {
    private InforMationHttpApi httpApi = new InforMationHttpApi();
    private int page = 1;
    private final int pageSize = 15;
    private boolean isRefresh;
    private boolean isLoadMore;
    //返回的总页数
    private int totalPage;
    List<AuthorBeanList.ListBean> mBeanLastList = new ArrayList<>();

    public void refreshData() {
        isRefresh = true;
        page = 1;
        loadAuthorList(page);
    }

    /**
     * 加载更多
     */
    public void loadMoreData() {
        isLoadMore = true;
        page++;
        if (page <= totalPage) { //可以加载更多数据
            loadAuthorList(page);
        } else {                 //没有更多数据
            mView.resultLoadMoreSuccess(LoadMoreType.TYPE_ALL_DATA);
        }
    }

    /**
     * 加载作者列表
     * @param page 当前页
     */
    public void loadAuthorList(int page){
        //只有正常加载才有loading 加载更多和刷新是没有的
        if (!isRefresh && !isLoadMore) {
            mView.requestLoading();
        }
        int pageSize = 15;
        List<AuthorBeanList.ListBean> beanLastList = new ArrayList<>();
        add(httpApi.getAuthorList(page, pageSize, new LifecycleCallback<AuthorBeanList>(mView) {
            @Override
            public void onSuccess(AuthorBeanList data) {
                totalPage = data.getTotalPage();
                beanLastList.addAll(data.getList());
                if (beanLastList.size()>0){
                    if (isRefresh){
                        mBeanLastList.clear();
                    }
                    mBeanLastList.addAll(beanLastList);
                    if (isRefresh){
                        isRefresh = false;
                        mView.resultRefreshSuccess();
                    }

                    //还原加载更多的状态
                    if (isLoadMore) {
                        isLoadMore = false;
                        mView.resultLoadMoreSuccess(LoadMoreType.TYPE_SUCCESS);
                    }
                    mView.resultSuccess(mBeanLastList);
                    //执行成功完毕 清理中转数组 否则造成列表叠加
                    mBeanLastList.clear();
                }else {
                    judgeStatusEmpty();
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                if (isRefresh) {         //刷新失败
                    isRefresh = false;
                    mView.resultRefreshFail("刷新失败");
                } else if (isLoadMore) { //加载更多失败
                    isLoadMore = false;
                    mView.resultLoadMoreFail("加载更多失败");
                } else {                 //正常加载数据失败
                    mView.resultFail(FailStateConstant.TYPE_ERROR);
                }
            }
        }));
    }

    /**
     * 判断刷新 加载更多 和 正常加载
     */
    private void judgeStatusEmpty() {
        if (isRefresh) {
            isRefresh = false;
            mView.resultRefreshFail("刷新数据为空");
        } else if (isLoadMore) {
            isLoadMore = false;
            mView.resultRefreshFail("加载更多数据为空");
        } else {
            dataEmpty();
        }
    }

    /**
     * 数据为空
     */
    private void dataEmpty() {
        mView.resultFail(FailStateConstant.TYPE_EMPTY);
    }

    /**
     * 关注作者
     */
    public void payAttentionAuthor(AuthorBeanList.ListBean bean,int position){
        httpApi.attentionAuthor(bean.getUserId(), new LifecycleCallback<AttentionResult>(mView) {
            @Override
            public void onSuccess(AttentionResult data) {
                mView.attentionSucceed(data,position);
                LiveEventBus.get().with(LiveEventBusKey.KEY_AUTHOR_FOCUS).post(bean.getUserId());
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                //ToastUtils.INSTANCE.showToast(errMsg);
            }
        });
    }

    /**
     * 取消关注作者
     */
    public void cancelAttentionAuthor(AuthorBeanList.ListBean bean,int position){
        httpApi.attentionAuthorCancel(bean.getUserId(), new LifecycleCallback<AttentionResult>(mView) {
            @Override
            public void onSuccess(AttentionResult data) {
                mView.cancelAttentionSucceed(data,position);
                LiveEventBus.get().with(LiveEventBusKey.KEY_AUTHOR_UNFOCUS).post(bean.getUserId());
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                //ToastUtils.INSTANCE.showToast(errMsg);
            }
        });
    }
}
