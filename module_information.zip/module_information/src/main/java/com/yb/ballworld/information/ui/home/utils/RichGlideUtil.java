package com.yb.ballworld.information.ui.home.utils;

import android.content.Context;
import android.util.Log;

import com.bumptech.glide.Glide;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.widget.bfrich.XRichText;

/**
 * Desc
 * Date 2019/11/9
 * author mengk
 */
public class RichGlideUtil {

    public static void initXRichTextImgLoad(Context context) {
        XRichText.getInstance().setImageLoader((imagePath, imageView, centerCrop) -> {
            if (centerCrop) {
                LogUtils.INSTANCE.e("===z", "图片的地址 = " + imagePath);
                Glide.with(context).asBitmap().load(imagePath).centerCrop()
                        .placeholder(R.drawable.img_load_fail).error(R.drawable.img_load_fail).into(imageView);
            } else {
                Glide.with(context).asBitmap().load(imagePath)
                        .placeholder(R.drawable.img_load_fail).error(R.drawable.img_load_fail).into(new TransformationScale(imageView));
            }
        });
    }
}
