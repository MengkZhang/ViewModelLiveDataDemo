package com.yb.ballworld.information.ui.personal.view;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bfw.util.ToastUtils;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshHeader;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.base.activity.BaseActivity;
import com.yb.ballworld.baselib.base.recycler.header.PlayBallHeader;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.widget.placeholder.HomePlaceholderView;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.common.widget.CommonTitleBar;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.utils.JZReleaseUtil;
import com.yb.ballworld.information.ui.personal.adapter.InfoCollectionQuickAdapter;
import com.yb.ballworld.information.ui.personal.adapter.ItemPraiseAdapterHelper;
import com.yb.ballworld.information.ui.personal.bean.CollectionEntity;
import com.yb.ballworld.information.ui.personal.constant.FailStateConstant;
import com.yb.ballworld.information.ui.personal.presenter.InfoCollectionContract;
import com.yb.ballworld.information.ui.personal.presenter.InfoCollectionPresenter;
import com.yb.ballworld.information.ui.personal.presenter.ItemPraisePresenter;
import com.yb.ballworld.information.widget.GoodView;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;

import static com.yb.ballworld.common.widget.CommonTitleBar.ACTION_LEFT_BUTTON;

/**
 * Desc:
 * Author: JS-Kylo
 * Created On: 2019/10/10 11:49
 *
 */
@Deprecated
public class InformationCollectionActivity2 extends BaseActivity implements InfoCollectionContract.CollectionView {
    private CommonTitleBar commonTitleBar;
    private HomePlaceholderView placeholder;
    private SmartRefreshLayout smartRefreshLayout;
    private RecyclerView recyclerView;
    private LinearLayoutManager layoutManager;
    private InfoCollectionQuickAdapter quickAdapter;
    private InfoCollectionPresenter presenter;
    //数据
    private List<CollectionEntity.ListBean> dataList = new ArrayList<>();
    private GoodView goodView;
    private CompositeDisposable compositeDisposable;

    public static void startActivity(Activity activity) {
        Intent intent = new Intent(activity, InformationCollectionActivity2.class);
        activity.startActivity(intent);
    }

    @Override
    public int getLayoutResID() {
        return R.layout.activity_infor_collection;
    }

    @Override
    protected void initView() {
        goodView = new GoodView(this);
        goodView.setText("+1");
        goodView.setImage(getResources().getDrawable(R.drawable.icon_priase_info));
        commonTitleBar = findViewById(R.id.commonTitleBar);
        commonTitleBar.setListener((v, action, extra) -> {
            if (action == ACTION_LEFT_BUTTON) {
                finish();
            }
        });
        placeholder = findViewById(R.id.placeholder);
        smartRefreshLayout = findViewById(R.id.smartRefreshLayout);
        recyclerView = findViewById(R.id.recyclerView);
        layoutManager = new LinearLayoutManager(this);
        smartRefreshLayout.setRefreshHeader(getRefreshHeader());
        quickAdapter = new InfoCollectionQuickAdapter(this, dataList);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(quickAdapter);
    }

    @Override
    protected void initEvent() {
        super.initEvent();
        compositeDisposable = new CompositeDisposable();
        initRefreshLoadMoreEvent();
        initReLoadEvent();
        initScrollEvent();
        //点赞事件
        ItemPraiseAdapterHelper.initRemoveCollectOrPraise(quickAdapter, new ItemPraisePresenter(), goodView);
        //取消收藏
        LiveEventBus.get().with(LiveEventBusKey.KEY_INFO_REMOVE_COLLECT, String.class)
                .observe(this, newId -> compositeDisposable.add(loadCollectPosition(newId)
                        .subscribeOn(AndroidSchedulers.mainThread())
                        .subscribe(new Consumer<Integer>() {
                            @Override
                            public void accept(Integer integer) throws Exception {
                                removeData(integer);
                            }
                        })
                ));
        //收藏
        LiveEventBus.get().with(LiveEventBusKey.KEY_INFO_COLLECT, String.class)
                .observe(this, newId -> compositeDisposable.add(loadCollectPosition(newId)
                        .subscribeOn(AndroidSchedulers.mainThread())
                        .subscribe(new Consumer<Integer>() {
                            @Override
                            public void accept(Integer integer) throws Exception {
                                if (presenter != null)
                                    presenter.loadData();
                            }
                        })
                ));
        LiveEventBus.get().with(LiveEventBusKey.KEY_NEWS_COLLECTION,String.class).observe(this, newsId -> {
            if (dataList.size() != 0) {
                for (int i = 0; i < dataList.size(); i++) {
                    CollectionEntity.ListBean listBean = dataList.get(i);
                    String listBeanId = listBean.getId();
                    int commentCount = listBean.getCommentCount();
                    if (newsId.equals(listBeanId)) {
                        listBean.setCommentCount(commentCount + 1);
                        quickAdapter .notifyItemChanged(i);
                        break;
                    }
                }
            }
        });
        LiveEventBus.get().with(LiveEventBusKey.KEY_INFO_LIKE,String.class).observe(this, newsId -> {
            if (dataList.size() != 0) {
                for (int i = 0; i < dataList.size(); i++) {
                    CollectionEntity.ListBean listBean = dataList.get(i);
                    String listBeanId = listBean.getId();
                    if (newsId.equals(listBeanId)) {
                        listBean.setLike(true);
                        quickAdapter .notifyItemChanged(i);
                        break;
                    }
                }
            }
        });
    }

    /**
     * 初始化滑动事件
     */
    private void initScrollEvent() {
        //recyclerView滑动停止播放
        JZReleaseUtil.releaseAllVideos(recyclerView);
    }

    @Override
    protected void initData() {
        super.initData();
        presenter = new InfoCollectionPresenter();
        presenter.attachView(this);
        requestLoading();
        presenter.loadData();
    }

    @Override
    public void requestLoading() {
        showLoading(placeholder);
        smartRefreshLayout.setEnableRefresh(false);
        smartRefreshLayout.setEnableLoadMore(false);

    }

    @Override
    public void resultSuccess(List<CollectionEntity.ListBean> beanList) {
        placeholder.hideLoading();
        smartRefreshLayout.finishRefresh(true);
        smartRefreshLayout.finishLoadMore(true);
        smartRefreshLayout.setEnableRefresh(true);
        smartRefreshLayout.setEnableLoadMore(true);
        dataList.clear();
        dataList.addAll(beanList);
        quickAdapter.notifyDataSetChanged();
    }

    @Override
    public void setEnableLoadMore(boolean enableLoadMore) {
        smartRefreshLayout.setEnableLoadMore(enableLoadMore);
    }

    @Override
    public void resultFail(int type) {
        smartRefreshLayout.finishRefresh(false);
        smartRefreshLayout.finishLoadMore(false);
        smartRefreshLayout.setEnableRefresh(false);
        smartRefreshLayout.setEnableLoadMore(false);
        switch (type) {
            case FailStateConstant.TYPE_ERROR:
                showError(placeholder, "网络出了小差，连接失败~");
                break;
            case FailStateConstant.TYPE_EMPTY:
                showEmpty(placeholder, "暂无数据");
                break;
            default:
                break;
        }
    }

    @Override
    public void resultRefreshSuccess() {
        ToastUtils.showToast("刷新成功");
        smartRefreshLayout.finishRefresh();
        //刷新成功清理存储的数组
        dataList.clear();
    }

    @Override
    public void resultRefreshFail(String errorMsg) {
        ToastUtils.showToast("刷新失败");
        smartRefreshLayout.finishRefresh();
    }

    /**
     * 初始化重新加载数据
     */
    private void initReLoadEvent() {
        placeholder.setPageErrorRetryListener(v -> presenter.loadData());
    }

    /**
     * 初始化刷新和加载更多
     */
    private void initRefreshLoadMoreEvent() {
        smartRefreshLayout.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                presenter.loadMore();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                presenter.refreshData();
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        JZReleaseUtil.releaseAllVideos();
    }

    /**
     * 删除收藏的数据
     *
     * @param position
     */
    private void removeData(int position) {
        if (null == dataList || dataList.size() < position)
            return;
        CollectionEntity.ListBean bean = dataList.get(position);
        int count = 0;
        for (int i = 0; i < dataList.size(); i++) {
            CollectionEntity.ListBean b = dataList.get(i);
            if (b.getShowDate().equals(bean.getShowDate()) && !b.isTitle() && i != position)
                count++;
        }
        LogUtils.INSTANCE.d("hhhhh", "xxposition: " + position + " content: " + bean.getId());
        if (dataList.contains(bean)) {
            dataList.remove(bean);
        }
        quickAdapter.notifyDataSetChanged();

        if (count == 0) {
            for (int i = 0; i < dataList.size(); i++) {
                CollectionEntity.ListBean b = dataList.get(i);
                if (b.getShowDate().equals(bean.getShowDate()) && b.isTitle()) {
                    quickAdapter.remove(i);
                    quickAdapter.notifyItemChanged(i);
                }
            }

        }
        if (dataList.size() == 0)
            showEmpty(placeholder, "暂无数据");
    }

    /**
     * 获取刷新头部
     *
     * @return 头部
     */
    private RefreshHeader getRefreshHeader() {
        return new PlayBallHeader(this).createAnim(PlayBallHeader.FOOTBALL);
    }

    private void showLoading(PlaceholderView placeholder) {
        mDelegate.showPageLoading(placeholder);
    }

    private void showEmpty(PlaceholderView placeholder, String msg) {
        mDelegate.showPageEmpty(placeholder, msg);
    }

    private void showError(PlaceholderView placeholder, String msg) {
        mDelegate.showPageError(placeholder, msg);
    }

    /**
     * 根据Id查找所在收藏类别的位置
     *
     * @param newsId
     * @return
     */
    private Observable<Integer> loadCollectPosition(String newsId) {
        return Observable.create(new ObservableOnSubscribe<Integer>() {
            @Override
            public void subscribe(ObservableEmitter<Integer> emitter) throws Exception {
                List<CollectionEntity.ListBean> list = InformationCollectionActivity2.this.dataList;
                for (int i = 0; i < list.size(); i++) {
                    CollectionEntity.ListBean listBean = list.get(i);

                    if (newsId.equals(listBean.getId())) {
                        emitter.onNext(i);
                    }
                }
                emitter.onNext(-1);

            }
        });
    }

    @Override
    public void setTextSize(int id, Float size) {

    }

    @Override
    public void setTextSize(TextView textView, Float size) {

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        compositeDisposable.clear();
    }
}