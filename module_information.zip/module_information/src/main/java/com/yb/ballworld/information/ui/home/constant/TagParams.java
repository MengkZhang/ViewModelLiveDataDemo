package com.yb.ballworld.information.ui.home.constant;

import androidx.annotation.IntDef;
import androidx.annotation.StringDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Desc
 * Date 2019/10/16
 * author mengk
 */
@StringDef({
        TagParams.INTENT_PARAM,
        TagParams.INTENT_PARAM_TYPE,
        TagParams.INTENT_PARAM_DATA,
        TagParams.INTENT_PARAM_POSITION,
        TagParams.PUBLISH_ARTICLE_DATA,
        TagParams.PUBLISH_VIDEO_DATA
})

@Retention(RetentionPolicy.SOURCE)

public @interface TagParams {
    String INTENT_PARAM = "ids";
    String INTENT_PARAM_TYPE = "intent_param_type";
    String INTENT_PARAM_POSITION = "intent_param_position";
    String INTENT_PARAM_DATA = "ids_data";
    String PUBLISH_ARTICLE_DATA = "publish_article_data";
    String PUBLISH_ARTICLE_DATA_WITHOUT_CONTENT = "publish_article_data_without_content";
    String PUBLISH_VIDEO_DATA = "publish_video_data";
}
