package com.yb.ballworld.information.ui.personal.presenter;

import android.text.TextUtils;

import androidx.lifecycle.MutableLiveData;

import com.bfw.util.ToastUtils;
import com.chad.library.adapter.base.entity.LiveDataResult;
import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.information.http.InforMationHttpApi;
import com.yb.ballworld.information.http.PersonalHttpApi;
import com.yb.ballworld.information.ui.personal.bean.PersonalInfo;
import com.yb.ballworld.information.ui.personal.bean.community.ReportAuthorReason;
import com.yb.ballworld.information.ui.personal.view.InformationPersonalActivity;
import com.yb.ballworld.information.ui.personal.view.InformationPersonalActivityNew;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

import rxhttp.wrapper.entity.Response;

/**
 * Desc: 个人页面presenter
 * Author: JS-Kylo
 * Created On: 2019/10/13 20:01
 */
public class InfoPersonalPresenterNew extends BasePresenter<InformationPersonalActivityNew, VoidModel> {
    private PersonalHttpApi httpApi;
    private InforMationHttpApi inforMationHttpApi = new InforMationHttpApi();
    public MutableLiveData<LiveDataResult> followData = new MutableLiveData();

    @Override
    public void onStart() {
        super.onStart();
        httpApi = new PersonalHttpApi();
    }

    //加载用户信息
    //加载用户信息
    /*public void loadUserInfo(String userId){
        add(httpApi.getPersonalInfo(userId,new OnUICallback<PersonalInfo>() {
            @Override
            public void onUISuccess(PersonalInfo data) {
                mView.initUserInfo(data,"");
            }

            @Override
            public void onUIFailed(int errCode, String errMsg) {
                mView.initUserInfo(null,errMsg);
            }
        }));
    }
*/
    public void loadUserInfo(String userId) {
        add(httpApi.getPersonalCommunityInfo(userId, new LifecycleCallback<PersonalInfo>(mView) {
            @Override
            public void onSuccess(PersonalInfo data) {
                mView.initUserInfo(data, "");
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                mView.initUserInfo(null, errMsg);
            }
        }));
    }

    /**
     * 获取举报原因
     *
     * @return
     */
    public void getReportReason() {
        add(httpApi.getReportReasonOfAuthor(new LifecycleCallback<List<ReportAuthorReason>>(mView) {
            @Override
            public void onSuccess(List<ReportAuthorReason> data) {
                mView.initReport(data);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {

            }
        }));
    }

    /**
     * 举报
     */
    public void reportAuthorOrPost(ReportAuthorReason reason, int id) {
        add(httpApi.reportAuthorOrPost(reason.getReason(), id, reason.getId(), 0, new LifecycleCallback<Response>(mView) {
            @Override
            public void onSuccess(Response data) {
                if (data.getCode() == 200)
                    ToastUtils.showToast("已举报");
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                ToastUtils.showToast("网络异常，请稍后再试");
            }
        }));
    }

    public Integer getInt(JSONObject jsonObject, String key, Integer defaultValue) {
        if (jsonObject == null || TextUtils.isEmpty(key)) {
            return defaultValue;
        }

        try {
            return jsonObject.getInt(key);
        } catch (JSONException e) {
            e.printStackTrace();
            return defaultValue;
        }
    }

    /**
     * 关注与取消关注
     *
     * @param focusUserId
     * @param action
     * @param callback
     */
    public void attentionAction(int focusUserId, boolean action, LifecycleCallback callback) {
        if (action) {
            inforMationHttpApi.attentionAuthor(focusUserId, callback);
        } else {
            inforMationHttpApi.attentionAuthorCancel(focusUserId, callback);
        }
    }
}
