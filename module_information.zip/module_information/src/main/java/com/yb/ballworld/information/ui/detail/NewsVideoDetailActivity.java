package com.yb.ballworld.information.ui.detail;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.alibaba.android.arouter.launcher.ARouter;
import com.bfw.util.ToastUtils;
import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.ethanhua.skeleton.Skeleton;
import com.ethanhua.skeleton.SkeletonScreen;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.constant.Constant;
import com.yb.ballworld.baselib.core.RouterHub;
import com.yb.ballworld.baselib.data.UserInfo;
import com.yb.ballworld.baselib.utils.JsonUtils;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.baselib.utils.NetWorkUtils;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.common.base.mvp.BaseMvpActivity;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.sharesdk.ShareSdkParamBean;
import com.yb.ballworld.common.widget.CommonTitleBar;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.data.ArticleBean;
import com.yb.ballworld.information.data.ArticleDetailBean;
import com.yb.ballworld.information.data.CommitBean;
import com.yb.ballworld.information.data.RootBean;
import com.yb.ballworld.information.ui.event.InforCommentCountEvent;
import com.yb.ballworld.information.ui.home.bean.IndexLableDetailBean;
import com.yb.ballworld.information.ui.home.bean.InfoDetailUserFollowBean;
import com.yb.ballworld.information.ui.home.bean.PublishCommentResBean;
import com.yb.ballworld.information.ui.home.constant.PublishIntentParam;
import com.yb.ballworld.information.ui.home.constant.PublishReqCode;
import com.yb.ballworld.information.ui.home.utils.JZReleaseUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.home.view.PublishCommentActivity;
import com.yb.ballworld.information.ui.home.widget.DeleteImgDialog;
import com.yb.ballworld.information.ui.home.widget.InfoDetailUserFollowView;
import com.yb.ballworld.information.ui.personal.view.InformationPersonalActivityNew;
import com.yb.ballworld.information.utils.CommondUtil;
import com.yb.ballworld.information.widget.FlowTagLayout;
import com.yb.ballworld.information.widget.NewsDetailBottomLayout;
import com.yb.ballworld.information.widget.RichWebView;
import com.yb.ballworld.information.widget.TagAdapter;
import com.yb.ballworld.information.widget.bubbleview.BubblePopupWindow;
import com.yb.ballworld.information.widget.bubbleview.BubbleTextView;
import com.yb.ballworld.information.widget.bubbleview.RelativePos;
import com.yb.ballworld.information.widget.listener.OnElementClickListener;

import org.jetbrains.annotations.NotNull;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import cn.jzvd.Jzvd;
import cn.jzvd.JzvdStd;

import static com.yb.ballworld.information.widget.FlowTagLayout.FLOW_TAG_CHECKED_NONE;
import static com.yb.ballworld.information.widget.bubbleview.RelativePos.CENTER_HORIZONTAL;

/**
 * Desc:
 *
 * @author ink
 * created at 2019/10/11 14:51
 */
@Route(path = RouterHub.INFORMATION_VIDEO_DETAIL)
public class NewsVideoDetailActivity extends BaseMvpActivity<NewsVideoDetailPresenter>
        implements /*FlowTagLayout.OnTagClickListener,*/ OnElementClickListener,
        BaseQuickAdapter.OnItemClickListener, BaseQuickAdapter.OnItemChildClickListener, BaseQuickAdapter.OnItemLongClickListener, RecyclerView.OnItemTouchListener, JzvdStd.OnScreenChangedListener {
    private BubblePopupWindow mBubblePopupWindow;
//    private TagAdapter<IndexLableDetailBean> mTagAdapter;
    private TagAdapter mTagAdapter;
    private InforDetailQuickAdapter mNewsAdapter;
    // private GoodView goodView;
   // private boolean isVideo = false;
    private JzvdStd myJzvdStd = null;
    private TextView tvPublisher, tvPublishTime;
    private TextView tvDetailTitle;
    private View  inforDetailTitleLayout;
    // private GoodView goodView;
    private ImageView articleLike;
    private TextView articleLikeCount;
    private RichWebView richWebView;
    private  FlowTagLayout flowTagLayout;
    //相关新闻
    private TextView tvAboutInfo;
    private PlaceholderView placeholderView;
    //底部评论View
    private NewsDetailBottomLayout newsDetailBottomLayout;
    private String newsId = null; //"168977dc0d514b8a98261046d9c6941f";
    private List<MultiItemEntity> mMultiList=new ArrayList<>();
    private SmartRefreshLayout mSmartRefreshLayout;
    private RecyclerView recyclerView;
    private SkeletonScreen skeletonScreen;
    private ShareSdkParamBean mShareSdkParamBean=null;
    private List<Integer> myCommitList=new ArrayList<>();
    private boolean hasAddCommentHead;

    private androidx.lifecycle.Observer<InforCommentCountEvent> mObserver=new Observer<InforCommentCountEvent>() {
        @Override
        public void onChanged(InforCommentCountEvent inforCommentCountEvent) {
            if(parentCommit!=null&&parentCommit.getId()==inforCommentCountEvent.getCommentId()&&parentCommit.getSonNum()<inforCommentCountEvent.getCommentCount()){
                mNewsAdapter.updateCommentCount(parentCommitPosition,inforCommentCountEvent.getCommentCount());
            }
        }
    };
    private InfoDetailUserFollowView followView;

    @Override
    protected void getIntentData() {
        LifecycleAutoManager.join(this);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LiveEventBus.get().with(LiveEventBusKey.KEY_INFOR_COMMENT_COUNT,InforCommentCountEvent.class).observe(this,mObserver);
    }

    @Override
    protected SmartRefreshLayout getSmartRefreshLayout() {
        return mSmartRefreshLayout;
    }

    @Override
    public void initPresenter() {
        if (mPresenter != null) {
            mPresenter.setVM(this);
        }
        // 168977dc0d514b8a98261046d9c6941f
        Intent intent = getIntent();
        if (intent != null) {
            newsId = intent.getStringExtra("NEWS_ID");
            // newsId = "d79eaea47dbf4aadbef9f007c3eeea07";
            mPresenter.init(newsId);
           // isVideo = intent.getBooleanExtra("NEWS_TYPE", true);
        }
        if (TextUtils.isEmpty(newsId)) {
            ToastUtils.showToast(R.string.prompt_articleBeDeleted);
            finish();
        }

    }

    @Override
    public int getLayoutId() {
        return R.layout.item_commit_header2_content;
    }

//    private void loadContentPage() {
//        //getLayoutInflater().inflate(isVideo ? R.layout.item_commit_header2_content : R.layout.item_commit_header1_content, F(R.id.infor_navLayout), true);
//        getLayoutInflater().inflate(R.layout.item_commit_header2_content, F(R.id.infor_navLayout), true);
//    }

    @Override
    public PlaceholderView getPlaceholderView() {
        return placeholderView;
    }


    @Override
    protected void initView() {
        //loadContentPage();
        mSmartRefreshLayout = F(R.id.smartRefreshLayout);
        mSmartRefreshLayout.setRefreshFooter(getRefreshFooter());
        mSmartRefreshLayout.setEnableAutoLoadMore(true);
        initRefreshView();
        enableRefresh(false);
        enableLoadMore(false);
        placeholderView = F(R.id.infor_placeholder);
       // if (isVideo) {//视频
            ((CommonTitleBar) F(R.id.infor_titlebar)).showTitleBar(false);
            myJzvdStd = F(R.id.inforDetail_easyPlayer);
            ((CommonTitleBar) F(R.id.infor_titlebar)).setStatusBarMode(1);
            ((CommonTitleBar) F(R.id.infor_titlebar)).setStatusBarColor(getResources().getColor(R.color.transparent_cc00));
//        } else {      //图文
//            tvAboutInfo = F(R.id.tv_about_info);
//            tvAboutInfo.setVisibility(View.GONE);
//        }


        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerView = F(R.id.recyclerView);
        recyclerView.setLayoutManager(linearLayoutManager);
        mNewsAdapter = new InforDetailQuickAdapter(null, this);
        mNewsAdapter.bindToRecyclerView(recyclerView);
        //recyclerView.setAdapter(mNewsAdapter);
        newsDetailBottomLayout = F(R.id.nbl_view_header2);
        JZReleaseUtil.observeReleaseVideos(recyclerView,mNewsAdapter.getVideoViewId());

        // goodView = new GoodView(this);
        // goodView.setImage(getResources().getDrawable(R.drawable.icon_priase_info));
    }

    @Override
    protected void bindEvent() {
        //if (isVideo) {
            F(R.id.infor_titlebar_back).setOnClickListener(this);
            F(R.id.infor_titlebar_share).setOnClickListener(this);
//        } else {
//            ((CommonTitleBar) F(R.id.infor_titlebar)).setListener((v, action, extra) -> {
//                if (action == ACTION_LEFT_BUTTON) {
//                    finish();
//                }
//            });
//        }
        if (getPlaceholderView() != null) {
            getPlaceholderView().setPageErrorRetryListener(v -> initData());
        }
        myJzvdStd.setOnScreenChagnedListener(this);
        mNewsAdapter.setOnItemClickListener(this);
        mNewsAdapter.setOnElementClickListener(this);
        mNewsAdapter.setOnItemChildClickListener(this);
        mNewsAdapter.setOnItemLongClickListener(this);
        recyclerView.addOnItemTouchListener(this);
        JZReleaseUtil.observeReleaseVideos(recyclerView,mNewsAdapter.getVideoViewId());
        setHeader(recyclerView);
    }

    private void setHeader(RecyclerView view) {
        View header = LayoutInflater.from(this).inflate(R.layout.item_detail_header, view, false);
        richWebView = header.findViewById(R.id.richWebView2);
        richWebView.setOnElementClick(this);
        mNewsAdapter.setHeaderView(header);
        tvPublisher = header.findViewById(R.id.tvPublisher);
        tvPublishTime = header.findViewById(R.id.tvPublishTime);
        tvDetailTitle = header.findViewById(R.id.tvDetailTitle);
        articleLike = header.findViewById(R.id.articleLike);
        tvAboutInfo=header.findViewById(R.id.inforDetail_title);
        tvAboutInfo.setText(R.string.txt_relativeVideo);
        inforDetailTitleLayout=header.findViewById(R.id.inforDetail_titleLayout);
        articleLikeCount = header.findViewById(R.id.inforDetail_likeCount);
        flowTagLayout = header.findViewById(R.id.inforDetail_flowTagLayout);
        flowTagLayout.setTagCheckedMode(FLOW_TAG_CHECKED_NONE);
        flowTagLayout.setAdapter(mTagAdapter = new TagAdapter<>(this));
        flowTagLayout.setVisibility(View.GONE);

//        flowTagLayout.setOnTagClickListener(this);
        articleLike.setOnClickListener(this);
        header.findViewById(R.id.inforDetail_shareLayout).setOnClickListener(this);

        //处理关注作者
        followView = header.findViewById(R.id.follow_view_info_user);
    }

    private void setFollowView(int userId,String name,String time,String headImgUrl,boolean isAttention) {
        InfoDetailUserFollowBean followBean = new InfoDetailUserFollowBean();
        followBean.setUserHeadImg(headImgUrl);
        followBean.setTime(time);
        followBean.setUserName(name);
        followBean.setUserId(String.valueOf(userId));
        followBean.setHasFollow(isAttention);
        followView.setUserInfo(followBean);
        followView.setOnFollowClickListener(view -> {
            if (followBean.isHasFollow()) { //已经关注了 点击取消关注
                DeleteImgDialog dialog = new DeleteImgDialog(NewsVideoDetailActivity.this,
                        NewsVideoDetailActivity.this.getResources().getString(R.string.info_detail_dialog_quit_follow));
                dialog.show();
                dialog.setSureOrCancelListener(new DeleteImgDialog.SureOrCancelListener() {
                    @Override
                    public void cancel() {
                        dialog.dismiss();
                    }

                    @Override
                    public void sure() {
                        dialog.dismiss();
                        // TODO: 2019/11/8 请求接口

                        //请求取消关注接口
                        reqFollowOrCancel(userId,false,view,followBean);

//                        followBean.setHasFollow(false);
//                        followView.changeFollow(view,followBean);
                    }
                });

            } else {                        //没有关注 点击关注
                // TODO: 2019/11/8 请求接口

                //请求关注接口
                reqFollowOrCancel(userId,true,view,followBean);
//                followBean.setHasFollow(true);
//                followView.changeFollow(view,followBean);
            }

        });
    }

    /**
     * 关注或者取消关注
     * @param followUserId
     * @param isFollow
     * @param view
     * @param followBean
     */
    private void reqFollowOrCancel(int followUserId,boolean isFollow,View view,InfoDetailUserFollowBean followBean) {
        mPresenter.attentionAction(followUserId, isFollow, new LifecycleCallback(this) {
            @Override
            public void onSuccess(Object data) {
                //关注或者取消关注成功
                followBean.setHasFollow(isFollow);
                followView.changeFollow(view,followBean);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                ToastUtils.showToast(getResources().getString(R.string.prompt_followFailed));
            }
        });
    }

    @Override
    protected void initData() {
        View rootView = F(R.id.rootView);
        skeletonScreen = Skeleton.bind(rootView)
                .load(R.layout.layout_place_detail_loading)
                .duration(1000)
                .shimmer(true)//是否开启动画
                .color(R.color.white)
                .angle(0)
                .show();
        mPresenter.loadInfor();
    }

    /**
     * 显示文章详情
     *
     * @param detail
     */
    public void showInfor(ArticleDetailBean detail) {
        if (skeletonScreen != null) {
            skeletonScreen.hide();
        }
        showPageContent();
        ArticleBean article = detail.getNews();
        if (article != null) {
            article.setItemType(InforConstant.ItemType.DETAIL_HEADER_NEWS);
            richWebView.setHtml(article.getContent());

            int commentStatus = article.getCommentStatus();
            String replyId = "";// TODO: 2019/10/22 回复id需要修改
            mShareSdkParamBean=new ShareSdkParamBean(article.getTitle(),article.getWebShareUrl(),article.getPreview(),article.getImgUrl(),article.getWebShareUrl());
            newsDetailBottomLayout.setParam(commentStatus, newsId, replyId,article.isFavorites());
            newsDetailBottomLayout.setShareSdkParamBean(mShareSdkParamBean);
           //if (isVideo) {
                myJzvdStd.setVisibility(View.VISIBLE);
                if (!TextUtils.isEmpty(article.getImgUrl())) {
                    Glide.with(this).load(article.getImgUrl()).into(myJzvdStd.thumbImageView);
                }
                if (!TextUtils.isEmpty(article.getPlayUrl())) {
                    myJzvdStd.setUp(article.getPlayUrl(), "", JzvdStd.SCREEN_NORMAL);
                    // 判断是否是WiFi
                    if (NetWorkUtils.INSTANCE.isWifiConnected()) {//wifi自动播放
                       myJzvdStd.startVideo();
                    }
                    myJzvdStd.setStartListener(() -> mPresenter.videoLookCompleted());
                }
           // }
            tvPublisher.setText(article.getNickName());
            tvPublishTime.setText(article.getCreatedDate());
           tvDetailTitle.setText(article.getTitle());
            articleLikeCount.setText(String.valueOf(article.getLikeCount()));
            articleLike.setImageResource(article.isLike() ? R.drawable.icon_priase_info : R.drawable.icon_priase_info_normal);
            articleLike.setClickable(!article.isLike());
            articleLike.setTag(article.isLike());

            //显示热门标签
            List<String> tags = CommondUtil.arrayToList(CommondUtil.splitBySign(article.getKeywords(), ","));
            List<IndexLableDetailBean> labels = article.getLabels();

            //判断是否有labels 如果没有 在判断是否有tags 有显示tag 没有则不显示
            if (labels != null && labels.size() != 0) { //新版本有labels
                flowTagLayout.setVisibility(View.VISIBLE);
                mTagAdapter.clearAndAddAll(labels);

            } else {                                    //兼容老版本的tags
                if (tags != null && tags.size() != 0) {
                    flowTagLayout.setVisibility(View.VISIBLE);
                    mTagAdapter.clearAndAddAll(tags);

                } else { //没有标签

                    flowTagLayout.setVisibility(View.GONE);
                }
            }
//            boolean needShow = (labels != null && labels.size() != 0);
////            boolean needShow = tags != null;
//            flowTagLayout.setVisibility(needShow ? View.VISIBLE : View.GONE);
//            if (needShow) {
////                mTagAdapter.clearAndAddAll(tags);
//                mTagAdapter.clearAndAddAll(labels);
//            }
        }
        List<MultiItemEntity> entityList = new ArrayList<>();
        List<ArticleBean> newsList = detail.getCurrentNews();
        if (!CommondUtil.isEmpty(newsList)) {
            //相关新闻有数据
            visibleAboutInfoVideo(true);
            F(R.id.recyclerView).setVisibility(View.VISIBLE);
            entityList.addAll(newsList);
        } else {
            //相关新闻为空
            visibleAboutInfoVideo(false);
        }
        //entityList.add(new RootBean(InforConstant.ItemType.DETAIL_HEADER_COMMENT, 0));
        mMultiList.addAll(entityList);
        mNewsAdapter.addData(entityList);
        mNewsAdapter.notifyDataSetChanged();
        mPresenter.setFristPage(true);
        onLoadMoreData();
        //  autoLoadMore();

        if (article != null) {
            setFollowView(article.getUserId(),article.getNickName(),article.getCreatedDate(),article.getHeadImgUrl(),article.isAttention());
        }
    }

    @Override
    protected void onLoadMoreData() {
        super.onLoadMoreData();
        mPresenter.loadMore();
    }

    /**
     * 判断是否显示相关视频或相关新闻
     *
     * @param isShow  是否显示
     */
    private void visibleAboutInfoVideo(boolean isShow) {
        //显示\隐藏相关
         inforDetailTitleLayout .setVisibility(isShow ? View.VISIBLE : View.GONE);
    }

    private void setCommentHead() {
        if (!hasAddCommentHead) {
            mMultiList.add(new RootBean(InforConstant.ItemType.DETAIL_HEADER_COMMENT, 0));
            hasAddCommentHead = true;
        }
    }

    public void showCommits(List<CommitBean> commitBeanList,boolean firstPage) {
        if(mPresenter.isFristPage()) {
            hideDialogLoading();
        }
        mNewsAdapter.setHasMore(mPresenter.hasMore());
        enableLoadMore(mPresenter.hasMore());
        stopLoadMore();
        if (commitBeanList != null) {
            if(firstPage) {
                List<MultiItemEntity> entityList=new ArrayList<>();
                setCommentHead();
                entityList.addAll(mMultiList);
                entityList.addAll(commitBeanList);
                mNewsAdapter.replaceData(entityList);
                mPresenter.setFristPage(false);
                myCommitList.clear();
//                mNewsAdapter.notifyDataSetChanged();
            }else{
                int size=commitBeanList.size()-1;
                for (int i = size; i >= 0; i--) {
                    if(myCommitList.contains(commitBeanList.get(i).getId())){
                        commitBeanList.remove(i);
                    }
                }
                mNewsAdapter.addData(commitBeanList);

            }
            // mNewsAdapter.notifyDataSetChanged();
        }
    }

    public void showEmpty(int area) {
        if (skeletonScreen != null) {
            skeletonScreen.hide();
        }
        if (area == mPresenter.INFOR_COMMITS) {
            if(mPresenter.isFristPage()) {
                hideDialogLoading();
            }
            stopLoadMore();
            enableLoadMore(false);
        }
    }


    public void showError(int area) {
        if (skeletonScreen != null) {
            skeletonScreen.hide();
        }
        hideDialogLoading();
        hidePageLoading();
        if (area == mPresenter.INFOR_DETAIL) {
            showPageError("拉取文章失败");
            ToastUtils.showToast("拉取文章失败");
            //finish();
        } else if (area == mPresenter.INFOR_COMMITS) {
            stopLoadMore();
            ToastUtils.showToast("拉取评论失败");
        }
    }

    @Override
    protected void processClick(View view) {
        int viewId = view.getId();
        if (viewId == R.id.articleLike) {
            articleLike.setImageResource(R.drawable.icon_priase_info);
            //goodView.show(F(R.id.inforDetail_like));
            if (!(Boolean) articleLike.getTag()) {
                articleLike.setTag(true);
                mPresenter.addArticleLike();
                showLike(mPresenter.INFOR_DETAIL,0,0,true);
            }
        } else if (viewId == R.id.inforDetail_shareLayout || (viewId == R.id.infor_titlebar_share)) {
            //分享
//            ToastUtils.INSTANCE.showToast(R.string.prompt_coding);
            if(mShareSdkParamBean!=null) {
                NavigateToDetailUtil.showShareToast(view, this, mShareSdkParamBean);
            }
        } else if (viewId == R.id.infor_titlebar_back) {
            finish();
        }
    }

    /**
     * 跳转到登陆界面
     */
    private void toLogin() {
        ARouter.getInstance().build(RouterHub.USER_LOGIN_REGISTER_ACTIVITY)
                .navigation(this, Constant.COMMON_LOGIN_REQUEST);
    }

    /**
     * 是否点赞成功/包括评论内的点赞
     *
     * @param area
     * @param id
     * @param isSuccess
     */
    public void showLike(int area, int id, int position, boolean isSuccess) {
        if (area == mPresenter.INFOR_DETAIL) {
            //文章处点赞
            articleLike.setImageResource(isSuccess ? R.drawable.icon_priase_info : R.drawable.icon_priase_info_normal);
            if (isSuccess) {
                TextView likeCountView = F(R.id.inforDetail_likeCount);
                String likeCountstr = likeCountView.getText().toString();
                int likeCount = (TextUtils.isEmpty(likeCountstr) ? 0 : Integer.parseInt(likeCountstr)) + 1;
                ((TextView) F(R.id.inforDetail_likeCount)).setText(String.valueOf(likeCount));
                articleLike.setTag(true);
                LiveEventBus.get().with(LiveEventBusKey.KEY_NEWS_LIKE, String.class).post(mPresenter.getNewsId());
            } else {
                articleLike.setTag(false);
            }
        } else if (area == mPresenter.INFOR_COMMITS) {
            //评论区点赞
            List<MultiItemEntity> entityList = mNewsAdapter.getData();
            if (!CommondUtil.isEmpty(entityList) && position < entityList.size()) {
                MultiItemEntity bean = mNewsAdapter.getItem(position);
                //先用位置判断
                if (bean != null && bean instanceof CommitBean) {
                    CommitBean commitBean = ((CommitBean) bean);
                    if (commitBean.getId() == id) {
                        RecyclerView.ViewHolder viewHolder= recyclerView.findViewHolderForLayoutPosition(position+mNewsAdapter.getHeaderLayoutCount());
                        commitBean.setLike(isSuccess);
                        commitBean.setLikeCount(commitBean.getLikeCount() + (isSuccess?1:0));
                        if(viewHolder!=null){
                            mNewsAdapter.changedLike(commitBean, (BaseViewHolder) viewHolder);
                        }else {
                            mNewsAdapter.notifyItemChanged(position);
                        }
                    }
                } else {
                    //如果不匹配，用commitId去迭代匹配，都没有就放弃吧
                    boolean isMatched;
                    CommitBean commitBean = null;
                    int truthPos = 0;
                    for (MultiItemEntity entity : entityList) {
                        isMatched = entity instanceof CommitBean && (commitBean = (CommitBean) entity).getId() == id;
                        if (isMatched) {
                            RecyclerView.ViewHolder viewHolder= recyclerView.findViewHolderForLayoutPosition(truthPos+mNewsAdapter.getHeaderLayoutCount());
                            commitBean.setLike(isSuccess);
                            commitBean.setLikeCount(commitBean.getLikeCount() + (isSuccess?1:0));
                            if(viewHolder!=null){
                                mNewsAdapter.changedLike(commitBean, (BaseViewHolder) viewHolder);
                            }else {
                                mNewsAdapter.notifyItemChanged(position);
                            }
                            //mNewsAdapter.notifyItemChanged(truthPos);
                        }
                        truthPos++;
                    }
                }
            }
        }
//        if (!isSuccess) {
//            ToastUtils.INSTANCE.showToast(R.string.prompt_likeFailed);
//        }
    }

//    @Override
//    public void onItemClick(FlowTagLayout parent, View view, int position) {
//        if (mTagAdapter.getCount() > position) {
//            ToastUtils.INSTANCE.showToast(mTagAdapter.getItem(position).toString());
//        }
//    }

    @Override
    public void onElementClick(@NotNull String url, int type, int position, List<String> peerList) {
        if (type == InforConstant.WebMediaType.TYPE_IMG) {
            if (!CommondUtil.isEmpty(peerList)) {
                if (mShareSdkParamBean != null) {

                        String title = mShareSdkParamBean.getTitle();
                        String titleUrl = mShareSdkParamBean.getTitleUrl();
                        String text = mShareSdkParamBean.getText();
                        String imageUrl = mShareSdkParamBean.getImageUrl();
                        String shareUrl = mShareSdkParamBean.getUrl();
                        NavigateToDetailUtil.navigateToGalleryActivity(this,peerList,position,
                                title,titleUrl,text,shareUrl);

                } else {

                    NavigateToDetailUtil.navigateToGalleryActivityWithoutShare(this,peerList,position);
                }
            }
        } else if (type == InforConstant.WebMediaType.TYPE_LINK) {
            InformationLinkNewActivity.start(this, url, "", true, true, 0);
        }
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
        if (adapter.getItemCount() > position) {
            InforDetailQuickAdapter inforDetailQuickAdapter = (InforDetailQuickAdapter) adapter;
            MultiItemEntity entity = inforDetailQuickAdapter.getItem(position );
            if (entity instanceof CommitBean) {
                    parentCommit = (CommitBean) entity;
                    parentCommitPosition = position;
                    NavigateToDetailUtil.navigateToCommentList(this, mPresenter.getNewsId(), (Serializable) entity);
            } else if (entity instanceof ArticleBean) {
                NavigateToDetailUtil.navigateToDetail(this, ((ArticleBean) adapter.getItem(position)).getId(), ((ArticleBean) adapter.getItem(position)).getMediaType() == 1);
            }
//            Intent intent = new Intent(this, NewsVideoDetailActivity.class);
//            intent.putExtra("NEWS_ID", ((ArticleBean) adapter.getItem(position)).getId());
//            intent.putExtra("NEWS_TYPE", ((ArticleBean) adapter.getItem(position)).getMediaType() == 1);
//            startActivity(intent);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        Jzvd.releaseAllVideos();
    }

    @Override
    public void onBackPressed() {
        if (Jzvd.backPress()) {
            return;
        }
        super.onBackPressed();
    }

    @Override
    public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
        InforDetailQuickAdapter inforDetailQuickAdapter = (InforDetailQuickAdapter) adapter;
        int eventType = inforDetailQuickAdapter.getChildEventType(view);
        MultiItemEntity entity = inforDetailQuickAdapter.getItem(position);
        if (entity != null) {
            switch (eventType) {
                case InforConstant.ItemEvent.USER_COMMENT:
                    InformationPersonalActivityNew.startActivity(this, CommondUtil.fitEmpty(((CommitBean) entity).getUserId()),InformationPersonalActivityNew.TYPE_NEWS);
                    break;
                case InforConstant.ItemEvent.REPLIES_COMMENT:
                    if (entity instanceof CommitBean) {
                        parentCommit = (CommitBean) entity;
                        parentCommitPosition = position;
                        NavigateToDetailUtil.navigateToCommentList(this, mPresenter.getNewsId(), (Serializable) entity);
                    }
                    break;
                case InforConstant.ItemEvent.ROOT_SORT:
                    mPresenter.setHeatSort(mNewsAdapter.isHeat());
                    mPresenter.setFristPage(true);
                    showDialogLoading();
                    mPresenter.loadMore();
                    break;
                case InforConstant.ItemEvent.LIKE_COMMENT:
                    if (!((CommitBean) entity).isLike()) {
                        mPresenter.addCommitLike(((CommitBean) entity).getId(), position);
                        showLike(mPresenter.INFOR_COMMITS,((CommitBean) entity).getId(),position,true);
                    }
                    break;
                default:
                    break;
            }
        }
    }

    @Override
    public boolean onItemLongClick(BaseQuickAdapter adapter, View view, int position) {
        InforDetailQuickAdapter inforDetailQuickAdapter = (InforDetailQuickAdapter) adapter;
        MultiItemEntity entity = inforDetailQuickAdapter.getItem(position );
        boolean ishandle = false;
        if (entity!=null&&entity.getItemType() == InforConstant.ItemType.DETAIL_COMMENT) {
            int mediaType = inforDetailQuickAdapter.getMediaType((CommitBean) entity);
            // View achorView=inforDetailQuickAdapter.getAchorView(view, mediaType);
            parentCommit=(CommitBean) entity;
            parentCommitPosition=position;
            showBubble(recyclerView, ((CommitBean) entity).getId());
            ishandle = true;
        }
        return ishandle;
    }


    private void gotoPublish(int replyId) {
        Intent intent = new Intent(this, PublishCommentActivity.class);
        intent.putExtra(PublishIntentParam.NEWS_ID, mPresenter.getNewsId());
        intent.putExtra(PublishIntentParam.REPLY_ID, String.valueOf(this.replyId=replyId));
        startActivityForResult(intent, PublishReqCode.REQ_CODE);
    }

    private int replyId=0;
    private CommitBean parentCommit=null;
    private int parentCommitPosition=0;
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(data!=null&&PublishReqCode.REQ_CODE==resultCode&&requestCode==PublishReqCode.REQ_CODE){
            PublishCommentResBean resBean= data.getParcelableExtra(PublishIntentParam.RETURN_DATA);
            if(resBean!=null) {
                CommitBean bean = JsonUtils.INSTANCE.fromJson(JsonUtils.INSTANCE.toJson(resBean), CommitBean.class);
                if(bean!=null){
                    if(replyId>0&&String.valueOf(replyId).equals(bean.getReplyId())&&parentCommit!=null){
                        NavigateToDetailUtil.navigateToCommentList(this,mPresenter.getNewsId(), parentCommit);
                    }else {
                        UserInfo infor= LoginOrdinaryUtils.INSTANCE.getUserInfo();
                        if(infor!=null) {
                            bean.setHeadImgUrl(infor.getImg());
                        }
                        myCommitList.add(bean.getId());
                        if (!hasAddCommentHead) {
                            mMultiList.add(new RootBean(InforConstant.ItemType.DETAIL_HEADER_COMMENT, 0));
                            List<MultiItemEntity> tempMulList=new ArrayList<>();
                            tempMulList.addAll(mMultiList);
                            tempMulList.add(bean);
                            mNewsAdapter.replaceData(tempMulList);
                            hasAddCommentHead = true;
                        } else {
                            if (mNewsAdapter.getData() != null
                                    && mNewsAdapter.getData().size() > mMultiList.size()) {
                                mNewsAdapter.addData(mMultiList.size(), bean);
                            }
                        }
                    }
                }
            }
        }
    }


    private BubbleTextView bubbleView;
    private void showBubble(View commitView, int carryId) {
        if (mBubblePopupWindow == null) {
            View rootView = LayoutInflater.from(this).inflate(R.layout.simple_text_bubble, null);
            bubbleView = rootView.findViewById(R.id.popup_bubble);
            mBubblePopupWindow = new BubblePopupWindow(rootView, bubbleView);
            bubbleView.setOnClickListener(v -> {
                v.setEnabled(false);
                gotoPublish((Integer) v.getTag());
                v.setEnabled(true);
            });
            mBubblePopupWindow.setCancelOnTouch(true);
            mBubblePopupWindow.setCancelOnTouchOutside(true);
            mBubblePopupWindow.setCancelOnLater(3000);
        }
            bubbleView.setTag(carryId);

        mBubblePopupWindow.showArrowTo(commitView,new RelativePos(CENTER_HORIZONTAL, RelativePos.ABOVE), -clickX,-clickY);
        // mBubblePopupWindow.showAsDropDown(commitView,clickX,clickY, Gravity.NO_GRAVITY);
    }

    private int clickX;
    private int clickY;
    @Override
    public boolean onInterceptTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
        clickX= (int) e.getX();
        clickY= (int) e.getY();
        return false;
    }

    @Override
    public void onTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {

    }

    @Override
    public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

    }

    @Override
    public void onChanged(int screen) {
        if(screen==JzvdStd.SCREEN_NORMAL){
            F(R.id.infor_titleLayout).bringToFront();
        }
    }
}
