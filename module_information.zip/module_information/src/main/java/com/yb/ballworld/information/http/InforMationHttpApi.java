package com.yb.ballworld.information.http;

import android.annotation.SuppressLint;
import android.text.TextUtils;

import com.rxjava.rxlife.RxLife;
import com.yb.ballworld.common.api.BaseHttpApi;
import com.yb.ballworld.common.api.ErrorInfo;
import com.yb.ballworld.common.api.HttpApiConstant;
import com.yb.ballworld.common.api.OnError;
import com.yb.ballworld.baselib.utils.AppUtils;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.information.data.ArticleDetailBean;
import com.yb.ballworld.information.data.CommitBean;
import com.yb.ballworld.information.data.CommitBeanList;
import com.yb.ballworld.information.data.FileData;
import com.yb.ballworld.information.data.Reply;
import com.yb.ballworld.information.data.Report;
import com.yb.ballworld.information.data.SonCommentList;
import com.yb.ballworld.information.ui.community.bean.AttentionResult;
import com.yb.ballworld.information.ui.community.bean.AuthorBeanList;
import com.yb.ballworld.information.ui.community.bean.PostCollectionEntity;
import com.yb.ballworld.information.ui.community.bean.TopicCommentList;
import com.yb.ballworld.information.ui.community.bean.Topic;
import com.yb.ballworld.information.utils.WebViewUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import rxhttp.RxHttp;

/**
 * Desc: ！！！！！！！暂时只是模仿请求，请勿实际中使用
 *
 * @author ink
 * created at 2019/10/9 20:28
 */
public class InforMationHttpApi extends BaseHttpApi {
    private static final String INFOR_DETAIL = "/qiutx-news/app/news/%s";
    private static final String INFOR_DETAIL_LIKE = "/qiutx-news/app/news/like/%s";
    private static final String INFOR_DETAIL_COMMIT_LIST = "/qiutx-news/app/news/comments";
    private static final String INFOR_DETAIL_COMMIT = "/qiutx-news/app/news/savecomment";
    private static final String INFOR_DETAIL_COMMIT_LIKE = "/qiutx-news/app/news/commentlike/%d";
    private static final String INFOR_DETAIL_COMMIT_DEL = "detail/artcle/commit/delete";
    private static final String INFOR_DETAIL_REPLY_DEL = "detail/artcle/reply/delete";
    private static final String INFOR_DETAIL_REPLY = "detail/artcle/reply";
    private static final String INFOR_DETAIL_REPLY_LIST = "detail/artcle/replylist";
    private static final String INFOR_DETAIL_SHARE_STATICS = "detail/artcle/statics";
    private static final String INFOR_DETAIL_COMMIT_ADD = "detail/commit/statics";
    private static final String INFOR_DETAIL_COMMIT_CANCEL = "detail/commit/statics";
    private static final String INFOR_DETAIL_REPORT = "detail/artcle/report";
    private static final String INFOR_DETAIL_USER_REPORT = "detail/user/report";
    private static final String INFOR_DETAIL_SON_COMMENTS = "/qiutx-news/app/news/soncomments";
    private static final String INFOR_DETAIL_COLLECT = "/qiutx-news/app/news/favorites/%s";
    private static final String INFOR_DETAIL_CANCEL_COLLECT = "/qiutx-news/app/news/favorites/removeConcerns/%s";
    private static final String TOPIC_DETAIL_CANCEL_COLLECT = "/qiutx-news/app/post/favorites/removeConcerns/%s";
    private static final String TOPIC_DETAIL_COLLECT = "/qiutx-news/app/post/favorites/%s";
    // 帖子详情Url
    public static final String URL_TOPIC_DETIAL="/qiutx-news/app/post/%s";
    // 帖子回复
    public static final String URL_TOPIC_DETAIL_COMMENT="/qiutx-news/app/post/reply";
    public static final String URL_TOPIC_DETAIL_COMMENT_LIKE="/qiutx-news/app/post/like/%s";

    private static final String RECOMMEND_AUTHOR_ALL = "/qiutx-news/app/post/index/recommend/author/all";
    private static final String POST_INDEX_FAVORITES = "/qiutx-news/app/post/index/favorites";
    private static final String THIRD_ATTENTION = "/qiutx-news/app/post/attention/%s";
    private static final String THIRD_ATTENTION_CANCEL = "/qiutx-news/app/post/attention/%s/cancel";


    /**
     * 获取文章详情
     *
     * @param articleId
     * @return
     */
    @SuppressLint("DefaultLocale")
    public Disposable getArticleDetail(String articleId, LifecycleCallback<ArticleDetailBean> callback) {
        return getApi(RxHttp.get(String.format(INFOR_DETAIL, articleId)))
                .asResponse(ArticleDetailBean.class)
                .map(new Function<ArticleDetailBean, ArticleDetailBean>() {
                    @Override
                    public ArticleDetailBean apply(ArticleDetailBean articleDetailBean) throws Exception {
                        LogUtils.INSTANCE.d("getArticleDetail-->currentThread:" + Thread.currentThread().getName());
                        if (articleDetailBean != null && articleDetailBean.getNews() != null
                                && !TextUtils.isEmpty(articleDetailBean.getNews().getContent())) {
                            articleDetailBean.setHtmlParseData(WebViewUtils.parseHtmlText(articleDetailBean.getNews()));
                        }
                        return articleDetailBean;
                    }
                })
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 获取文章评论列表，按序列
     *
     * @param newsId
     * @param pageNum
     * @param pageSize
     * @param byHot
     * @param callback
     * @return
     */
    public Disposable getCommitList(String newsId, int pageNum, int pageSize, boolean byHot, LifecycleCallback<CommitBeanList> callback) {
        return addHeader(RxHttp.get(INFOR_DETAIL_COMMIT_LIST))
                .add("newsId", newsId)
                .add("pageNum", pageNum)
                .add("pageSize", pageSize)
                .add("orderField", byHot ? "heat" : "time")
                .asResponse(CommitBeanList.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 获取文章评论列表，按序列
     *
     * @param newsId
     * @param callback
     * @return
     */
    public Disposable submitArticleLike(String newsId, LifecycleCallback<String> callback) {
        return addHeader(RxHttp.postForm(String.format(INFOR_DETAIL_LIKE, newsId)))
                .asResponse(String.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 获取文章评论列表，按序列
     *
     * @param commentId
     * @param callback
     * @return
     */
    @SuppressLint("DefaultLocale")
    public Disposable submitCommitLike(int commentId, LifecycleCallback<String> callback) {
        return addHeader(RxHttp.postForm(String.format(INFOR_DETAIL_COMMIT_LIKE, commentId)))
                .asResponse(String.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 获取文章评论列表，按序列
     *
     * @param commentId
     * @param callback
     * @return
     */
    @SuppressLint("DefaultLocale")
    public Disposable submitTopicCommentLike(int commentId, LifecycleCallback<String> callback) {
        return addHeader(RxHttp.postForm(String.format(URL_TOPIC_DETAIL_COMMENT_LIKE, commentId)))
                .asResponse(String.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 获取评论的回复列表
     * @param commentId
     * @param pageNum
     * @param pageSize
     * @param byHot
     * @param callback
     * @return
     */
    public Disposable getCommitsReplyList(int commentId, int pageNum,int pageSize,boolean byHot,String targetId, LifecycleCallback<SonCommentList> callback) {
        return addHeader(RxHttp.get(INFOR_DETAIL_SON_COMMENTS))
                .add("commentId", commentId)
                .add("pageNum", pageNum)
                .add("pageSize", pageSize)
                .add("targetId", targetId)
                .add("orderField", byHot ? "heat" : "time")
                .asResponse(SonCommentList.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 获取评论的回复列表
     * @param postId
     * @param pageNum
     * @param pageSize
     * @param byHot
     * @param callback
     * @return
     */
    public Disposable getCommunityCommentList(int postId, int pageNum,int pageSize,boolean byHot,String targetId, LifecycleCallback<TopicCommentList> callback) {
        return addHeader(RxHttp.get(URL_TOPIC_DETAIL_COMMENT))
                .add("postId", postId)
                .add("pageNum", pageNum)
                .add("pageSize", pageSize)
                .add("targetId", targetId)
                .add("order",byHot ? "desc" : "asc")
                .add("orderField","created_date" )
                .asResponse(TopicCommentList.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 提交评论
     *
     * @param commit
     * @param userId
     * @param articleId
     * @param callback
     * @return
     */
    public Disposable submitACommit(CommitBean commit, String userId, long articleId, LifecycleCallback<CommitBeanList> callback) {
        return getApi(RxHttp.postForm(INFOR_DETAIL_COMMIT))
                .add("articleId", articleId)
                .add("userId", userId)
                .add("content", commit.getContent())
                .add("type", commit.getCommentType())
                .asResponse(CommitBeanList.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 提交回复
     *
     * @param commit
     * @param userId
     * @param commitId
     * @param callback
     * @return
     */
    public Disposable submitAReply(Reply commit, String userId, long commitId, LifecycleCallback<Reply> callback) {
        return getApi(RxHttp.get(INFOR_DETAIL_REPLY))
                .add("commitId", commitId)
                .add("userId", userId)
                .add("content", commit.getContent())
                .add("type", commit.getType())
                .asResponse(Reply.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 提交评论
     *
     * @param userId
     * @param commitId
     * @param callback
     * @return
     */
    public Disposable deleteACommit(String userId, long commitId, LifecycleCallback<CommitBeanList> callback) {
        return getApi(RxHttp.postForm(INFOR_DETAIL_COMMIT_DEL))
                .add("commitId", commitId)
                .add("userId", userId)
                .asResponse(CommitBeanList.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 删除回复/评论
     *
     * @param userId
     * @param commitId
     * @param callback
     * @return
     */
    public Disposable deleteAReply(String userId, long commitId, LifecycleCallback<String> callback) {
        return getApi(RxHttp.deleteForm(INFOR_DETAIL_REPLY_DEL))
                .add("commitId", commitId)
                .add("userId", userId)
                .asResponse(String.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 统计分享
     *
     * @param articleId
     * @param userId
     * @param shareId
     * @param callback
     * @return
     */
    public Disposable submitArticleStatics(int articleId, String userId, String shareId, LifecycleCallback<String> callback) {
        return getApi(RxHttp.get(INFOR_DETAIL_SHARE_STATICS))
                .add("articleId", articleId)
                .add("userId", userId)
                .add("shareId", shareId)
                .asResponse(String.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 提交点赞、收藏
     *
     * @return
     */
    public Disposable addCommit(long commitId, String userId, int type, LifecycleCallback<String> callback) {
        return getApi(RxHttp.get(INFOR_DETAIL_COMMIT_ADD))
                .add("commitId", commitId)
                .add("userId", userId)
                .add("type", type)
                .asResponse(String.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 提交点赞、收藏
     *
     * @return
     */
    public Disposable canelCommit(long commitId, String userId, int type, LifecycleCallback<String> callback) {
        return getApi(RxHttp.get(INFOR_DETAIL_COMMIT_CANCEL))
                .add("commitId", commitId)
                .add("userId", userId)
                .add("type", type)
                .asResponse(String.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 提交举报
     *
     * @return
     */
    public Disposable submitCommitReport(long commitId, Report report, LifecycleCallback<Report> callback) {
        return getApi(RxHttp.get(INFOR_DETAIL_USER_REPORT))
                .add("commitId", commitId)
                .add("type", report.getType())
                .add("userId", report.getUserId())
                .add("title", report.getTitle())
                .add("content", report.getContent())
                .asResponse(Report.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 上传图片或视频
     *
     * @param file
     * @param type
     * @param callback
     * @return
     */
    public Disposable uploadMedias(File file, String type, LifecycleCallback<FileData> callback) {
        String url = getUploadBaseUrl() + HttpApiConstant.UPLOAD;
        return getUploadApi(RxHttp.postForm(url))
                .addFile("file", file)
                .add("uid", LoginOrdinaryUtils.INSTANCE.getUid())
                .add("type", type)
                .asResponse(FileData.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     *  社区收藏
     * @param newsId  资讯ID
     * @param callback
     * @return
     */
    public Disposable collectTopic(String newsId, LifecycleCallback<String> callback) {
        return addHeader(RxHttp.postForm(String.format(TOPIC_DETAIL_COLLECT, newsId)))
                .asObject(String.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(new Consumer<String>() {
                    @Override
                    public void accept(String data) throws Exception {
                        try{
                            JSONObject jsonObject=new JSONObject(data);
                            String code=jsonObject.optString("code");
                            if("200".equals(code)){
                                callback.onSuccess(data);
                            }else{
                                callback.onFailed(0,"网络异常");
                            }
                        }catch (Exception e){
                            e.printStackTrace();
                            callback.onFailed(0,"网络异常");
                        }
                    }
                }, new OnError() {
                    @Override
                    public void onError(ErrorInfo error) throws Exception {
                        callback.onFailed(error.getErrorCode(), error.getErrorMsg());
                    }
                });
    }

    /**
     *  取消收藏
     * @param newsId id
     * @param callback 回调
     * @return
     */
    public Disposable removeCollectTopic(String newsId,LifecycleCallback<String> callback){
        return addHeader(RxHttp.postForm(String.format(TOPIC_DETAIL_CANCEL_COLLECT, newsId)))
                .asObject(String.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(new Consumer<String>() {
                    @Override
                    public void accept(String data) throws Exception {
                        try{
                            JSONObject jsonObject=new JSONObject(data);
                            String code=jsonObject.optString("code");
                            if("200".equals(code)){
                                callback.onSuccess(data);
                            }else{
                                callback.onFailed(0,"网络异常");
                            }
                        }catch (Exception e){
                            e.printStackTrace();
                            callback.onFailed(0,"网络异常");
                        }
                    }
                }, (OnError) error -> {
                    callback.onFailed(error.getErrorCode(), error.getErrorMsg());
                });
    }


    /**
     *  资讯收藏
     * @param newsId  资讯ID
     * @param callback
     * @return
     */
    public Disposable collectInfo(String newsId, LifecycleCallback<String> callback) {
        return addHeader(RxHttp.postForm(String.format(INFOR_DETAIL_COLLECT, newsId)))
                .asResponse(String.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     *  取消收藏
     * @param newsId id
     * @param callback 回调
     * @return
     */
    public Disposable removeCollectInfo(String newsId,LifecycleCallback<String> callback){
        return addHeader(RxHttp.postForm(String.format(INFOR_DETAIL_CANCEL_COLLECT, newsId)))
                .asResponse(String.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 获取作者列表
     *
     * @param pageNum
     * @param pageSize
     * @param callback
     * @return
     */
    public Disposable getAuthorList(int pageNum, int pageSize, LifecycleCallback<AuthorBeanList> callback){
        return addHeader(RxHttp.get(RECOMMEND_AUTHOR_ALL))
                .add("pageNum", pageNum)
                .add("pageSize", pageSize)
                .asResponse(AuthorBeanList.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /***
     * 收藏-帖子列表数据
     * @return
     */
    public Disposable getIndexCollectionList(int pageNum, int pageSize, LifecycleCallback<PostCollectionEntity> callback) {
        return addHeader((RxHttp.get(POST_INDEX_FAVORITES)))
                .add("pageNum", pageNum)
                .add("pageSize", pageSize)
                .asResponse(PostCollectionEntity.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     *  关注作者
     * @param callback 回调
     * @return
     */
    public Disposable attentionAuthor(int focusUserId,LifecycleCallback<AttentionResult> callback){
        return addHeader(RxHttp.postForm(String.format(THIRD_ATTENTION, focusUserId)))
                .asResponse(AttentionResult.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 取消关注
     */
    public Disposable attentionAuthorCancel(int focusUserId,LifecycleCallback<AttentionResult> callback){
        return addHeader(RxHttp.postForm(String.format(THIRD_ATTENTION_CANCEL, focusUserId)))
                .asResponse(AttentionResult.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    @Override
    public RxHttp getApi(RxHttp rxHttp) {
        RxHttp configHttp = super.getApi(rxHttp);
        long uid = LoginOrdinaryUtils.INSTANCE.getUid();
        if (uid > 0) {
            JSONObject json = new JSONObject();
            try {
                json.put("uid", uid);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            rxHttp.addHeader("x-user-header", json.toString());
        }
        return configHttp;
    }

    @Override
    public RxHttp getUploadApi(RxHttp rxHttp) {
        RxHttp configHttp = super.getUploadApi(rxHttp);
        long uid = LoginOrdinaryUtils.INSTANCE.getUid();
        if (uid > 0) {
            JSONObject json = new JSONObject();
            try {
                json.put("uid", uid);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            rxHttp.addHeader("x-user-header", json.toString());
        }
        return configHttp;
    }

    public RxHttp addHeader(RxHttp rxHttp) {
        RxHttp configHttp = rxHttp;
        long uid = LoginOrdinaryUtils.INSTANCE.getUid();
        String deviceId=AppUtils.INSTANCE.getDeviceId();
        JSONObject json = new JSONObject();
        try {
            json.put("uid", uid);
            json.put("deviceId",deviceId);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        rxHttp.addHeader("x-user-header", json.toString());
        return configHttp;
    }


    /**
     * get请求
     * @param url
     * @param map
     * @param tClass
     * @param callback
     * @param <T>
     * @return
     */
    public <T> Disposable getRequest(String url, Map<String,String> map, Class<T> tClass, LifecycleCallback<T> callback) {
        if(map==null)map=new HashMap<>();
        return getApi(RxHttp.get(url))
                .add(map)
                .asResponse(tClass)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(T -> {
                    callback.onSuccess(T);
                }, (OnError) error -> {
                    callback.onFailed(error.getErrorCode(), error.getErrorMsg());
                });
    }
}
