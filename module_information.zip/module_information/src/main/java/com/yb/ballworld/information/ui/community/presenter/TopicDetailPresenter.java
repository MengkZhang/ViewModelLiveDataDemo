package com.yb.ballworld.information.ui.community.presenter;


import android.util.Log;

import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.MutableLiveData;

import com.bfw.util.ToastUtils;
import com.google.gson.Gson;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.livedata.LiveDataResult;
import com.yb.ballworld.information.http.InforMationHttpApi;
import com.yb.ballworld.information.http.PersonalHttpApi;
import com.yb.ballworld.information.ui.community.bean.AttentionResult;
import com.yb.ballworld.information.ui.community.bean.Topic;
import com.yb.ballworld.information.ui.community.bean.TopicComment;
import com.yb.ballworld.information.ui.community.bean.TopicCommentGroup;
import com.yb.ballworld.information.ui.community.view.TopicDetailActivity;
import com.yb.ballworld.information.ui.detail.InforConstant;
import com.yb.ballworld.information.ui.personal.bean.community.PostHistoryBean;
import com.yb.ballworld.information.ui.personal.bean.community.ReportAuthorReason;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import rxhttp.wrapper.entity.Response;

public class TopicDetailPresenter extends BasePresenter<TopicDetailActivity, VoidModel> {
    public static final String ORDER_BY_DESC = "desc"; // 降序
    public static final String ORDER_BY_ASC = "asc";
    private InforMationHttpApi api = new InforMationHttpApi();
    private PersonalHttpApi personalHttpApi = new PersonalHttpApi();
    // 帖子id
    private String topicId;
    private boolean mIsToFirst;
    // 分页
    private int pageNum = 1;
    // 每页数量
    private int pageSize = 15;

    // 评论排序方式
    private String orderBy = ORDER_BY_DESC;
    // 总分页数
    private int totalPage = Integer.MIN_VALUE;

    public MutableLiveData<LiveDataResult<TopicCommentGroup>> topicData = new MutableLiveData();
    public MutableLiveData<LiveDataResult<List<Topic>>> commentData = new MutableLiveData();


    /**
     * 获取帖子详情
     */
    public void getTopic() {
        /*api.getRequest(String.format(api.URL_TOPIC_DETIAL, topicId), null, String.class, new LifecycleCallback<String>(mView) {
            @Override
            public void onSuccess(String d) {
                LogUtils.INSTANCE.i("arway", "topicData=" + d);
                Topic data = null;
                try {
                    Gson gson = new Gson();
                    data = gson.fromJson(d, Topic.class);
                } catch (Exception e) {
                    e.printStackTrace();
                }


                LiveDataResult<Topic> result = new LiveDataResult<>();
                if (data != null) {
                    // 设置Itemtype类型，用于adapter
                    data.setItemTypeBySelf(InforConstant.TopicDetailItemType.TYPE_TOPIC);
                    // data.setVideoUrl("https://youtu.be/GPk6M0Dr4Pw"); // TODO 测试数据
                    // data.setVideoUrl("http://sta.5yqz2.com/static/avatar/8f21e0904033546126bc1ca2c63acd0e.mp4"); // TODO 测试数据
                    // data.setPostImgLists(null);
                    result.setData(data);
                } else {
                    result.setError(Integer.MIN_VALUE, "暂无数据");
                }
                topicData.postValue(result);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                LiveDataResult<Topic> result = new LiveDataResult<>();
                result.setError(errCode, errMsg == null ? "网络异常" : errMsg);
                topicData.postValue(result);
            }
        });*/

        getTopicComment(topicId, 1, pageSize, orderBy, new LifecycleCallback<TopicCommentGroup>(mView) {
            @Override
            public void onSuccess(TopicCommentGroup comment) {

                LiveDataResult<TopicCommentGroup> result = new LiveDataResult<>();
                if (comment != null && comment.getParent() != null) {
                    // 设置Itemtype类型，用于adapter
                    Topic data = comment.getParent();
                    data.setItemTypeBySelf(InforConstant.TopicDetailItemType.TYPE_TOPIC);
                    result.setData(comment);
                } else {
                    result.setError(Integer.MIN_VALUE, "暂无数据");
                }
                topicData.postValue(result);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                LiveDataResult<TopicCommentGroup> result = new LiveDataResult<>();
                result.setError(errCode, errMsg == null ? "网络异常" : errMsg);
                topicData.postValue(result);
            }
        });
    }

    public void getReasonForReport() {
        personalHttpApi.getReportReasonOfTopic(new LifecycleCallback<List<ReportAuthorReason>>(mView) {
            @Override
            public void onSuccess(List<ReportAuthorReason> data) {
                mView.initReport(data);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {

            }
        });
    }

    public void reportTopic(ReportAuthorReason reason, int id) {
        personalHttpApi.reportAuthorOrPost(reason.getReason(), id, reason.getId(), 1, new LifecycleCallback<Response>(mView) {
            @Override
            public void onSuccess(Response data) {
                if (data.getCode() == 200)
                    ToastUtils.showToast("已举报");
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                ToastUtils.showToast("网络异常，请稍后再试");
            }
        });
    }

    /**
     * 获取帖子评论(共外部使用)
     */
    public void getTopicComment(TopicCommentGroup topicCommentGroup) {
        if (!hasMore()) return;
        LifecycleCallback<TopicCommentGroup> lifecycleCallback= new LifecycleCallback<TopicCommentGroup>(mView) {
            @Override
            public void onSuccess(TopicCommentGroup group) {
                LiveDataResult<List<Topic>> result = new LiveDataResult<>();

                if (group != null && group.getSon() != null) {
                    TopicComment comment = group.getSon();
                    totalPage = comment.getTotalPage();
                    pageNum++;
                    result.setData(comment.getList());
                } else {
                    result.setError(Integer.MIN_VALUE, "暂无数据");
                }
                commentData.postValue(result);


            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                LogUtils.INSTANCE.i("arway", "errMsg=" + errMsg);
                LiveDataResult<List<Topic>> result = new LiveDataResult<>();
                result.setError(errCode, errMsg == null ? "网络异常" : errMsg);
                commentData.postValue(result);

            }
        };

        if(topicCommentGroup!=null){
            lifecycleCallback.onSuccess(topicCommentGroup);
        }else{
            getTopicComment(topicId, pageNum, pageSize, orderBy,lifecycleCallback);
        }
    }


    /**
     * 获取帖子评论
     *
     * @param postId
     * @param pageNum
     * @param pageSize
     * @param order    "
     */
    private void getTopicComment(String postId, int pageNum, int pageSize, String order, LifecycleCallback<TopicCommentGroup> callBack) {
        Map<String, String> map = new HashMap<>();
        map.put("pageNum", String.valueOf(pageNum));
        map.put("pageSize", String.valueOf(pageSize));
        map.put("postId", String.valueOf(postId));
        map.put("order", order);
        map.put("orderField", "created_date");
        api.getRequest(api.URL_TOPIC_DETAIL_COMMENT, map, TopicCommentGroup.class, callBack);
    }


    /**
     * 关注与取消关注
     *
     * @param focusUserId
     * @param action
     * @param callback
     */
    public void attentionAction(int focusUserId, boolean action, LifecycleCallback callback) {
        if (action) {
            api.attentionAuthor(focusUserId, callback);
        } else {
            api.attentionAuthorCancel(focusUserId, callback);
        }
    }


    /**
     * 帖子点赞
     */
    public void postLike(int topicId) {
        add(personalHttpApi.postLike(topicId, new LifecycleCallback<String>(mView) {
            @Override
            public void onSuccess(String data) {

            }

            @Override
            public void onFailed(int errCode, String errMsg) {

            }
        }));
    }

    /**
     * 收藏
     *
     * @param topicId
     * @param action
     * @param callback
     */
    public void favoriteAction(int topicId, boolean action, LifecycleCallback<String> callback) {
        if (action) {
            api.removeCollectTopic("" + topicId, callback);
        } else {
            api.collectTopic("" + topicId, callback);
        }
    }

    public void setTopicId(String topicId) {
        this.topicId = topicId;
    }

    public void setIsToFirst(boolean isToFirst) {
        this.mIsToFirst = isToFirst;
    }

    public boolean isToFirst() {
        return mIsToFirst;
    }

    public String getOrderBy() {
        return orderBy;
    }


    /**
     * 判断是否可以加载更多
     *
     * @return
     */
    public boolean hasMore() {
        return totalPage == Integer.MIN_VALUE || totalPage + 1 > pageNum;
    }

    public void setOrderBy(String orderBy) {
        this.orderBy = orderBy;
    }

    /**
     * 当改变排序状态时重新设置分页信息
     */
    public void resetPageStatus() {
        pageNum = 1;
        totalPage = Integer.MIN_VALUE;
    }

    public String getTopicId() {
        return topicId;
    }

}
