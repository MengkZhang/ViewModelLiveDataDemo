package com.yb.ballworld.information.ui.profile.presenter;

import androidx.lifecycle.LifecycleOwner;

import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.livedata.LiveDataWrap;
import com.yb.ballworld.information.ui.profile.data.PlayerDatumBean;

/**
 * @author Gethin
 * @time 2019/11/9 15:15
 */

public class PlayerDatumPresenter extends BasePresenter<LifecycleOwner, VoidModel> {

    public LiveDataWrap<PlayerDatumBean> datumData = new LiveDataWrap<>();

    public void loadDatum() {

    }
}
