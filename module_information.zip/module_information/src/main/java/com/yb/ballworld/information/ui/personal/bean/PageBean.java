package com.yb.ballworld.information.ui.personal.bean;

import java.util.ArrayList;
import java.util.List;

public class PageBean {
    private int totalCount;
    private int pageNum;
    private int pageSize;
    private int totalPage;
    private List<Follow> list;

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setList(List<Follow> list) {
        this.list = list;
    }

    public List<Follow> getList() {
        return list==null?new ArrayList<>():list;
    }


}
