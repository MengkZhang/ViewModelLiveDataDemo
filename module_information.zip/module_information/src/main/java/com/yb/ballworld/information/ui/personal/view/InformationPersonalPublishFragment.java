package com.yb.ballworld.information.ui.personal.view;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bfw.util.ToastUtils;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshFooter;
import com.scwang.smartrefresh.layout.api.RefreshHeader;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.base.recycler.header.PlayBallHeader;
import com.yb.ballworld.baselib.base.recycler.header.RecyclerClassicsFooter;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.common.base.BaseRefreshFragment;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.community.view.TopicDetailActivity;
import com.yb.ballworld.information.ui.home.utils.JZReleaseUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.personal.adapter.InfoPublishQuickAdapter;
import com.yb.ballworld.information.ui.personal.adapter.ItemPraiseAdapterHelper;
import com.yb.ballworld.information.ui.personal.bean.PersonalInfo;
import com.yb.ballworld.information.ui.personal.bean.PostEntity;
import com.yb.ballworld.information.ui.personal.constant.FailStateConstant;
import com.yb.ballworld.information.ui.personal.constant.LoadMoreType;
import com.yb.ballworld.information.ui.personal.presenter.InfoPersonalPublishContract;
import com.yb.ballworld.information.ui.personal.presenter.InfoPersonalPublishPresenter;
import com.yb.ballworld.information.ui.personal.presenter.ItemPraisePresenter;
import com.yb.ballworld.information.utils.ShareTextUitl;
import com.yb.ballworld.information.widget.GoodView;
import com.yb.ballworld.information.widget.listener.OnElementClickListener2;

import java.util.ArrayList;
import java.util.List;

import cn.jmessage.support.qiniu.android.utils.StringUtils;

/**
 * Desc:  个人-发表
 * Author: JS-Kylo
 * Created On: 2019/10/10 10:58
 */
public class InformationPersonalPublishFragment extends BaseRefreshFragment implements InfoPersonalPublishContract.InfoPublishView {
    public static final String PERSONAL_ID = "personal_user_id";
    public static final int KEY_TYPE_VIDEO=100;
    private String userId;
    private SmartRefreshLayout smartRefreshLayout;
    private RecyclerView recyclerView;
    private PlaceholderView placeholder;
    private LinearLayoutManager layoutManager;
    private InfoPersonalPublishPresenter presenter;
    private List<PostEntity.ListBean> dataList = new ArrayList<>();
    private InfoPublishQuickAdapter adapter;
    private GoodView goodView;
    private LinearLayout lyPlaceView;
    private int type;

    public static InformationPersonalPublishFragment newInstance() {
        return new InformationPersonalPublishFragment();
    }

    public static InformationPersonalPublishFragment newInstance(String uId) {
        InformationPersonalPublishFragment publishFragment = new InformationPersonalPublishFragment();
        Bundle bundle = new Bundle();
        try {
            bundle.putString(PERSONAL_ID, uId);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        publishFragment.setArguments(bundle);
        return publishFragment;
    }

    public static InformationPersonalPublishFragment newInstance(String uId,int type) {
        InformationPersonalPublishFragment publishFragment = new InformationPersonalPublishFragment();
        Bundle bundle = new Bundle();
        try {
            bundle.putString(PERSONAL_ID, uId);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        publishFragment.setArguments(bundle);
        publishFragment.type=type;
        return publishFragment;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.information_fragment_publish;
    }


    @Override
    protected void initView() {
        Bundle bundle = getArguments();
        if (null != bundle)
            userId = bundle.getString(PERSONAL_ID);
        smartRefreshLayout = findView(R.id.smartRefreshLayout);
        recyclerView = findView(R.id.recyclerView);
        placeholder = findView(R.id.placeholder);
        lyPlaceView = findView(R.id.lyPlaceView);
        smartRefreshLayout.setRefreshHeader(getRefreshHeader());
        smartRefreshLayout.setRefreshFooter(getRefreshFooter());
        layoutManager = new LinearLayoutManager(mContext);
        recyclerView.setLayoutManager(layoutManager);
        //publishQuickAdapter = new InfoPublishQuickAdapter(dataList);
        adapter = new InfoPublishQuickAdapter(getContext(), dataList);
        recyclerView.setAdapter(adapter);
        goodView = new GoodView(mContext);
        goodView.setText("+1");
        goodView.setImage(getResources().getDrawable(R.drawable.icon_priase_info));
    }

    @Override
    protected void initData() {
        if (TextUtils.isEmpty(userId)) {
            showPageEmpty("暂无数据");
            return;
        }
        presenter = new InfoPersonalPublishPresenter(userId);
        presenter.attachView(this);
        presenter.setType(type);
        presenter.loadData(1);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void requestLoading() {
      //  showPageLoading();
       /* smartRefreshLayout.setEnableRefresh(false);
        smartRefreshLayout.setEnableLoadMore(false);*/
        LiveEventBus.get().with(LiveEventBusKey.KEY_NEWS_COLLECTION,String.class).observe(this, newsId -> {
            if (dataList.size() != 0) {
                for (int i = 0; i < dataList.size(); i++) {
                    PostEntity.ListBean listBean = dataList.get(i);
                    String listBeanId = listBean.getId();
                    int commentCount = listBean.getCommentCount();
                    if (newsId.equals(listBeanId)) {
                        listBean.setCommentCount(commentCount + 1);
                        adapter .notifyItemChanged(i);
                        break;
                    }
                }
            }
        });
    }

    @Override
    protected void bindEvent() {
        // 加载更多
        smartRefreshLayout.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                presenter.loadMoreData();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                presenter.refreshData();
            }
        });
        // 重新加载
        placeholder.setPageErrorRetryListener(v -> presenter.loadData(1));

        //recyclerView滑动停止播放
        JZReleaseUtil.releaseAllVideos(recyclerView);
        smartRefreshLayout.setEnableLoadMore(false);
        ItemPraiseAdapterHelper.initPublishPraise(adapter, new ItemPraisePresenter(), goodView);
        LiveEventBus.get().with(LiveEventBusKey.KEY_INFO_LIKE,String.class).observe(this, newsId -> {
            if (dataList.size() != 0) {
                for (int i = 0; i < dataList.size(); i++) {
                    PostEntity.ListBean listBean = dataList.get(i);
                    String listBeanId = listBean.getId();
                    if (newsId.equals(listBeanId)) {
                        listBean.setIsLike(true);
                        adapter .notifyItemChanged(i);
                        break;
                    }
                }
            }
        });

        adapter.setmOnElementClickListener(new OnElementClickListener2<PostEntity.ListBean>() {
            @Override
            public void onElementClick(PostEntity.ListBean parentItem, String url, int type, int position, List<String> peerList) {
                // 图片点击跳转
                try{
                    NavigateToDetailUtil.navigateToGalleryActivity(getContext(), peerList, position, ShareTextUitl.getShareTitle(parentItem.getContent()), parentItem.getWebShareUrl(), parentItem.getContent(), parentItem.getWebShareUrl());
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
    }

    @Override
    protected void processClick(View view) {

    }

    @Override
    public void onPause() {
        super.onPause();
        JZReleaseUtil.releaseAllVideos();
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (!getUserVisibleHint()) {
            JZReleaseUtil.releaseAllVideos();
        }
    }

    /**
     * 请求成功回调
     *
     * @param data 列表数据
     */
    @Override
    public void resultSuccess(List<PostEntity.ListBean> data,int page) {
        LogUtils.INSTANCE.e("===z", "列表数据长度data = " + data.size());
        //placeholder.hideLoading();
        hideLoadingView();
        smartRefreshLayout.setEnableRefresh(true);
        smartRefreshLayout.setEnableLoadMore(true);
        if(page<=1){
            dataList.clear();
        }
        dataList.addAll(data);
        adapter.notifyDataSetChanged();
    }

    /**
     * 加载失败
     *
     * @param type 失败的类型
     */
    @Override
    public void resultFail(int type,String errMsg) {
        //placeholder.hideLoading();
        hideLoadingView();
        smartRefreshLayout.setEnableRefresh(true);
        switch (type) {
            case FailStateConstant.TYPE_ERROR:   //加载失败
                if (TextUtils.isEmpty(errMsg)||"null".equals(errMsg))
                    placeholder.showError("服务器连接失败~");
                else
                    placeholder.showError(errMsg);
                break;
            case FailStateConstant.TYPE_EMPTY:   //数据为空
                showPageEmpty("暂无数据");
                break;
            default:
                break;
        }
    }

    /**
     * 刷新成功回调
     */
    @Override
    public void resultRefreshSuccess() {
        placeholder.hideLoading();
        smartRefreshLayout.finishRefresh();
        //刷新成功清理存储的数组
        dataList.clear();
    }

    /**
     * 刷新失败回调
     *
     * @param errorMsg 失败信息
     */
    @Override
    public void resultRefreshFail(String errorMsg) {
       // ToastUtils.INSTANCE.showToastInfo("刷新失败");
        smartRefreshLayout.finishRefresh();
    }

    /**
     * 加载更多成功
     *
     * @param type 成功类型
     */
    @Override
    public void resultLoadMoreSuccess(int type) {
        placeholder.hideLoading();
        smartRefreshLayout.finishLoadMore();
        switch (type) {
            case LoadMoreType.TYPE_SUCCESS:      //加载成功
                // ToastUitl.showShort("加载更多成功");
                break;

            case LoadMoreType.TYPE_ALL_DATA:     //已经全部加载
                ToastUtils.showToast("已经全部加载");
                break;

            default:
                break;
        }
    }

    /**
     * 加载更多失败
     *
     * @param errorMsg 失败信息
     */
    @Override
    public void resultLoadMoreFail(String errorMsg) {
        placeholder.hideLoading();
        //ToastUitl.showShort("加载更多失败");
        smartRefreshLayout.finishLoadMore();
    }

    @Override
    protected RefreshHeader getRefreshHeader() {
        return new PlayBallHeader(mContext).createAnim(PlayBallHeader.FOOTBALL);
    }

    @Override
    protected RefreshFooter getRefreshFooter() {
        return new RecyclerClassicsFooter(mContext);
    }

    @Override
    public PlaceholderView getPlaceholderView() {
        return placeholder;
    }

    private void hideLoadingView(){
        lyPlaceView.setVisibility(View.GONE);
        smartRefreshLayout.setVisibility(View.VISIBLE);
    }
}
