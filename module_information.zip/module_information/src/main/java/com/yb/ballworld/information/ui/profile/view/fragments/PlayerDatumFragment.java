package com.yb.ballworld.information.ui.profile.view.fragments;

import android.view.View;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.util.DensityUtil;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.common.base.mvp.BaseMvpFragment;
import com.yb.ballworld.common.livedata.LiveDataObserver;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.profile.adapter.ChampionAdapter;
import com.yb.ballworld.information.ui.profile.data.ChampionBean;
import com.yb.ballworld.information.ui.profile.data.Player;
import com.yb.ballworld.information.ui.profile.data.PlayerDatumBean;
import com.yb.ballworld.information.ui.profile.presenter.PlayerDatumPresenter;
import com.yb.ballworld.information.widget.GridSpacingItemDecoration;

import java.util.ArrayList;
import java.util.List;

/**
 * 球员资料库-资料
 * @author Gethin
 * @time 2019/11/7 19:01
 */

public class PlayerDatumFragment extends BaseMvpFragment<PlayerDatumPresenter> {

    private SmartRefreshLayout smartRefreshLayout;
    private PlaceholderView placeholderView;
    private Player player;
    private TextView tvName,tvBirthday,tvValidity;

    public static PlayerDatumFragment newInstance(Player player){
        PlayerDatumFragment fragment= new PlayerDatumFragment();
        fragment.player=player;
        return fragment;
    }

    @Override
    public void initPresenter() {
        mPresenter.setVM(this);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_player_datum;
    }

    @Override
    protected void initView() {
        placeholderView = findView(R.id.placeholder);
        smartRefreshLayout = findView(R.id.smart_refresh_layout);
        tvName=findView(R.id.tvName);
        tvBirthday=findView(R.id.tv_birthday);
        tvValidity=findView(R.id.tv_validity);
        initRefreshView();
        enableLoadMore(false);
        enableRefresh(true);

        if(player!=null){
            tvName.setText(player.getCnName());
            tvBirthday.setText(player.getBirthdate());
            tvValidity.setText("-");

        }else{
            showPageEmpty("暂无数据");
        }
        smartRefreshLayout.setEnableRefresh(false);

    }

    @Override
    public PlaceholderView getPlaceholderView() {
        return placeholderView;
    }

    @Override
    protected SmartRefreshLayout getSmartRefreshLayout() {
        return smartRefreshLayout;
    }

    @Override
    protected void onRefreshData() {
        loadData();
    }

    @Override
    protected void bindEvent() {
        placeholderView.setPageErrorRetryListener(view ->  loadData());
        mPresenter.datumData.observe(this, new LiveDataObserver<PlayerDatumBean>() {
            @Override
            public void onSuccess(PlayerDatumBean data) {
                if (data != null) {
                    showPageContent();
                } else {
                    showPageEmpty("");
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                showPageError(errMsg);
            }
        });
    }

    @Override
    protected void initData() {
        loadData();
    }

    @Override
    protected void processClick(View view) {

    }

    private void loadData() {
        mPresenter.loadDatum();
    }

   /* private void testUI() {
        RecyclerView rvEuropeanCup = findView(R.id.rvEuropeanCup);
        GridLayoutManager manager = new GridLayoutManager(mContext, 5);
        rvEuropeanCup.setLayoutManager(manager);
        rvEuropeanCup.addItemDecoration(new GridSpacingItemDecoration(5, DensityUtil.dp2px(16), false));
        ChampionAdapter rvEuropeanCupAdapter = new ChampionAdapter();
        rvEuropeanCup.setAdapter(rvEuropeanCupAdapter);
        List<ChampionBean> datas = new ArrayList<>();
        for (int i = 0; i < 7; i++) {
            ChampionBean championBean = new ChampionBean();
            datas.add(championBean);
        }
        rvEuropeanCupAdapter.setNewData(datas);
    }*/
}
