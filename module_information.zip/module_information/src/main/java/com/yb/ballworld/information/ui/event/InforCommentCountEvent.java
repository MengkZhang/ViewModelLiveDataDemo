package com.yb.ballworld.information.ui.event;

public class InforCommentCountEvent {
    private int commentCount;
    private int commentId;

    public int getCommentCount() {
        return commentCount;
    }

    public InforCommentCountEvent(int commentCount,int commentId) {
        this.commentCount = commentCount;
        this.commentId=commentId;
    }

    public void setCommentCount(int commentCount) {
        this.commentCount = commentCount;
    }

    public int getCommentId() {
        return commentId;
    }

    public void setCommentId(int commentId) {
        this.commentId = commentId;
    }
}
