package com.yb.ballworld.information.ui.home.bean;

import java.io.Serializable;

/**
 * Desc
 * Date 2019/11/9
 * author mengk
 */
public class ParamTagCommitBean implements Serializable {
    private int id;
    private int matchCount;
    private String cnAlias;
    private String headLetter;
    private int isHot;
    private boolean isCheck;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMatchCount() {
        return matchCount;
    }

    public void setMatchCount(int matchCount) {
        this.matchCount = matchCount;
    }

    public String getCnAlias() {
        return cnAlias;
    }

    public void setCnAlias(String cnAlias) {
        this.cnAlias = cnAlias;
    }

    public String getHeadLetter() {
        return headLetter;
    }

    public void setHeadLetter(String headLetter) {
        this.headLetter = headLetter;
    }

    public int getIsHot() {
        return isHot;
    }

    public void setIsHot(int isHot) {
        this.isHot = isHot;
    }

    public boolean isCheck() {
        return isCheck;
    }

    public void setCheck(boolean check) {
        isCheck = check;
    }
}
