package com.yb.ballworld.information.ui.community;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.View;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.google.gson.Gson;
import com.yb.ballworld.baselib.utils.FileProvider7;
import com.yb.ballworld.baselib.utils.Glide4Engine;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.baselib.utils.SpUtils;
import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.utils.videoEncoder.VideoSlimmer;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.community.data.CommunityImageVideoItem;
import com.yb.ballworld.information.ui.community.data.CommunityNew;
import com.yb.ballworld.information.ui.community.data.CommunityPost;
import com.yb.ballworld.information.ui.community.view.CommunityNewActivity;
import com.yb.ballworld.information.ui.home.bean.FileDataBean;
import com.yb.ballworld.information.ui.home.service.InfoHttpApi;
import com.yb.ballworld.information.ui.home.utils.MediaUtils;
import com.yb.ballworld.information.ui.home.widget.DeleteImgDialog;
import com.yb.ballworld.information.widget.CommunityImageVideoChoseDialog;
import com.zhihu.matisse.Matisse;
import com.zhihu.matisse.MimeType;
import com.zhihu.matisse.internal.entity.Item;
import com.zhihu.matisse.internal.utils.PathUtils;
import com.zhihu.matisse.internal.utils.PhotoMetadataUtils;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import static com.yb.ballworld.baselib.utils.AppUtils.getPackageName;

/**
 * Desc: <发帖Presenter>
 * Author: JS-Barder
 * Created On: 2019/11/9 17:30
 */
public class CommunityNewPresenter extends BasePresenter<CommunityNewActivity, VoidModel> implements BaseQuickAdapter.OnItemChildClickListener {
    public static final String COMMUNITY_DRAFT_BOX_HAS_DATA = "draftBoxHasData";
    public static final String COMMUNITY_INPUT_TEXT_CONTENT = "communityInputTextContent";
    public static final String COMMUNITY_IMAGE_VIDEO_ITEMS_JSON = "communityImageVideoItemsJson";
    public static final String IS_VIDEO = "isVideo";

    public static final int REQUEST_CODE_CAPTURE_VIDEO = 0x0012;
    public static final int REQUEST_CODE_CAPTURE_IMAGE = 0x0123;
    public static final int REQUEST_CODE_IMAGE = 0x1234;
    public static final int REQUEST_CODE_PERMISSION_CAPTURE_VIDEO = 0x0111;
    public static final int REQUEST_CODE_PERMISSION_CAPTURE_IMAGE = 0x1111;
    public static final int REQUEST_CODE_PERMISSION_IMAGE = 0x2222;

    public static final String IMAGE_VIDEO_SELECTED_FILE_PATH = Environment.getExternalStorageDirectory() + "/"
            + getPackageName() + "/imageVideo";

    private InfoHttpApi infoHttpApi = new InfoHttpApi();
    private CommunityHttpApi communityHttpApi = new CommunityHttpApi();

    private List<String> mPermissionList = new ArrayList<>();
    //声明一个数组permissions，将需要的权限都放在里面
    private String[] permissions = new String[]{Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE};
    private CommunityNewAdapter mAdapter;
    private List<String> paths = new ArrayList<>();//本地数据地址
    private List<String> imageUrls = new LinkedList<>();//保存图片上传时返回的网络地址
    private List<Item> itemSelected = new ArrayList<>();
    private List<CommunityImageVideoItem> imageVideoItems = new ArrayList<>();//保存草稿箱时，本地数据序列化所保存的数据
    private File videoFaceFile;
    private String videoPath;
    private String videoCompressionPath;
    private File mImageFile;
    private DeleteImgDialog dialog;
    private boolean hasData = false;
    private boolean isVideo;
    private CommunityImageVideoChoseDialog choseDialog;
    private View.OnClickListener addImageListener = null;

    public void setAddImageListener(View.OnClickListener addImageListener) {
        this.addImageListener = addImageListener;
    }

    public CommunityNewPresenter() {
        mAdapter = new CommunityNewAdapter();
        mAdapter.setOnItemChildClickListener(this);
    }

    @Override
    public void onStart() {
        super.onStart();
        dialog = new DeleteImgDialog(mView, "是否将当前内容保存为草稿？");
        dialog.setSureOrCancelListener(new DeleteImgDialog.SureOrCancelListener() {
            @Override
            public void cancel() {
                clearData();
                dialog.dismiss();
                mView.finish();
            }

            @Override
            public void sure() {
                SpUtils.INSTANCE.putBoolean(COMMUNITY_DRAFT_BOX_HAS_DATA, true);
                SpUtils.INSTANCE.putString(COMMUNITY_INPUT_TEXT_CONTENT, mView.getInputText());
                SpUtils.INSTANCE.putString(COMMUNITY_IMAGE_VIDEO_ITEMS_JSON, new Gson().toJson(paths));
                saveImageVideo();
                SpUtils.INSTANCE.putBoolean(IS_VIDEO, isVideo);
                dialog.dismiss();
                mView.finish();
            }
        });
        choseDialog = new CommunityImageVideoChoseDialog(mView);
        choseDialog.setCaptureVideoClickListener(v -> {
            if (hasData) {
                mView.showToastMsgShort("不能同时选择图片和视频");
                return;
            }
            checkPermission(REQUEST_CODE_PERMISSION_CAPTURE_VIDEO);
        });
        choseDialog.setCaptureImageClickListener(v -> {
            if (hasData && isVideo) {
                mView.showToastMsgShort("不能同时选择图片和视频");
                return;
            }
            checkPermission(REQUEST_CODE_PERMISSION_CAPTURE_IMAGE);
        });
        choseDialog.setImageClickListener(v -> {
            if (hasData && isVideo) {
                mView.showToastMsgShort("不能同时选择图片和视频");
                return;
            }
            checkPermission(REQUEST_CODE_PERMISSION_IMAGE);
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        itemSelected.clear();
        imageVideoItems.clear();
        paths.clear();
        imageUrls.clear();
    }

    public CommunityNewAdapter getAdapter() {
        return mAdapter;
    }

    public File getImageFile() {
        return mImageFile;
    }

    public void initData() {
        mAdapter.getData().clear();
        mAdapter.addAdd();
    }

    public void setInitData(List<String> paths, boolean isVideo) {
        if (paths == null) {
            paths = new ArrayList<>();
        }
        this.paths = paths;
        this.isVideo = isVideo;
        mAdapter.getData().clear();
        imageVideoItems = readImageVideo();
        itemSelected = getItems(imageVideoItems);
        if (isVideo) {
            if (!imageVideoItems.isEmpty()) {
                for (CommunityImageVideoItem item : imageVideoItems) {
                    hasData = true;
                    initVideoFacePath(item);
                    return;
                }
            }
        }
        checkAdapterData();
    }

    public void saveImageVideo() {
        ObjectOutputStream stream = null;
        try {
            File file = new File(IMAGE_VIDEO_SELECTED_FILE_PATH);
            stream = new ObjectOutputStream(new FileOutputStream(file));
            stream.writeObject(imageVideoItems);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (stream != null) {
                    stream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     *
     * @return
     */
    @NotNull
    public List<CommunityImageVideoItem> readImageVideo() {
        ObjectInputStream stream = null;
        try {
            stream = new ObjectInputStream(new FileInputStream(new File(IMAGE_VIDEO_SELECTED_FILE_PATH)));
            List<CommunityImageVideoItem> items = (List<CommunityImageVideoItem>) stream.readObject();
            if (items == null) {
                return new ArrayList<>();
            }
            return items;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                if (stream != null) {
                    stream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return new ArrayList<>();
    }

    public List<Item> getItems(List<CommunityImageVideoItem> itemss) {
        ArrayList<Item> items = new ArrayList<>();
        for (CommunityImageVideoItem item : itemss) {
            items.add(item.getItem());
        }
        return items;
    }

    public void addCaptureVideo(String path) {
        isVideo = true;
        hasData = true;
        if (path == null) {
            videoFaceFile = null;
            mView.showToastMsgShort("视频出错");
            return;
        }
        paths.add(path);
        CommunityImageVideoItem videoItem = new CommunityImageVideoItem(0, MimeType.MP4.toString(), 0, 0, CommunityNewAdapter.TYPE_VIDEO);
        videoItem.filePath = path;
        imageVideoItems.add(videoItem);
        initVideoFacePath(videoItem);
    }

    public void addCapturePhoto(String path) {
        hasData = true;
        this.isVideo = false;
        paths.add(path);
        mAdapter.removeAdd();
        //将图片插入到数据库中，并获取对应的Item，以用来添加到默认选中项中
        Item item = new Item(PhotoMetadataUtils.getInsertImageId(mView, mImageFile), MimeType.JPEG.toString(), mImageFile.length(), 0);
        itemSelected.add(item);
        imageVideoItems = initImageItems(itemSelected);
        checkAdapterData();
    }

    public void setItemSelected(List<Item> itemSelected, List<String> paths, boolean isVideo) {
        this.isVideo = isVideo;
        hasData = true;
        if (itemSelected == null) {
            itemSelected = new ArrayList<>();
        }
        this.itemSelected.clear();
        this.imageVideoItems.clear();
        this.itemSelected.addAll(itemSelected);
        if (isVideo) {
            for (Item item : itemSelected) {
                addCaptureVideo(PathUtils.getPath(mView, item.getContentUri()));
//                initVideoFacePath(item);//视频的imageVideoItems数据在获取封面图片回调之后添加
                return;
            }
        } else {
            this.paths.clear();
            if (paths != null) {
                this.paths.addAll(paths);
            }
            this.imageVideoItems = initImageItems(itemSelected);
        }
        checkAdapterData();
    }

    /**
     * 本方法只有在传入的参数全部为图片时才可以
     */
    public List<CommunityImageVideoItem> initImageItems(List<Item> items) {
        ArrayList<CommunityImageVideoItem> imageVideoItems = new ArrayList<>();
        if (items != null) {
            for (Item item : items) {
                CommunityImageVideoItem imageVideoItem = new CommunityImageVideoItem(item.id, item.mimeType, item.size, item.duration, CommunityNewAdapter.TYPE_IMAGE);
                imageVideoItem.filePath = PathUtils.getPath(mView, item.getContentUri());
                imageVideoItems.add(imageVideoItem);
            }
        }
        return imageVideoItems;
    }

    private void initVideoFacePath(CommunityImageVideoItem item) {
        if (item == null) {
            videoFaceFile = null;
            return;
        }
        if (item.filePath != null && item.faceFile != null) {
            videoFaceFile = item.faceFile;
            videoPath = item.filePath;
        }
        mView.showDialogLoading("视频加载中");
        MediaUtils.getImageForVideo(item.filePath, file -> {
            mView.hideDialogLoading();
            hasData = true;
            isVideo = true;
            videoPath = item.filePath;
            videoFaceFile = file;
            item.faceFile = file;
            checkAdapterData();
        });
    }

    public boolean isHasData() {
        return hasData || mView.getInputText().length() > 0;
    }

    public void showSaveDialog() {
        dialog.show();
    }

    @Override
    public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
        int id = view.getId();
        if (R.id.image_add == id) {
            if (addImageListener != null) {
                addImageListener.onClick(view);
            }
            choseDialog.show();
        } else if (R.id.image_del == id) {
            if (paths.size() > position) {
                paths.remove(position);
            }
            if (itemSelected.size() > position) {
                itemSelected.remove(position);
            }
            if (imageVideoItems.size() > position) {
                imageVideoItems.remove(position);
            }
            checkAdapterData();
        }
    }

    private void checkAdapterData() {
        mAdapter.replaceData(imageVideoItems);
        if (mAdapter.getItemCount() == 0) {
            isVideo = false;
            videoFaceFile = null;
            videoPath = null;
            mImageFile = null;
            hasData = false;
            mAdapter.addAdd();
        } else if (mAdapter.getItemCount() == 1 && mAdapter.hasAdd()) {//标志删除图片时，图片全部删除，只剩余一个添加
            isVideo = false;
            videoFaceFile = null;
            videoPath = null;
            mImageFile = null;
            hasData = false;
        } else if (mAdapter.getItemCount() < 9 && !isVideo && !mAdapter.hasAdd()) {
            hasData = true;
            isVideo = false;
            mAdapter.addAdd();
        }
        mView.checkRightEnable();
    }

    public void checkPermission(int state) {
        choseDialog.dismiss();
        //清空没有通过的权限
        mPermissionList.clear();

        //逐个判断你要的权限是否已经通过
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(mView, permission) != PackageManager.PERMISSION_GRANTED) {
                //添加还未授予的权限
                mPermissionList.add(permission);
            }
        }

        //申请权限
        if (mPermissionList.size() > 0) {//有权限没有通过，需要申请
            ActivityCompat.requestPermissions(mView, permissions, state);
        } else {                         //说明权限都已经通过
            if (state == REQUEST_CODE_PERMISSION_CAPTURE_VIDEO) {
                openCaptureVideo();
            } else if (state == REQUEST_CODE_PERMISSION_CAPTURE_IMAGE) {
                openCaptureImage();
            } else if (state == REQUEST_CODE_PERMISSION_IMAGE) {
                openGallery();
            }
        }
    }

    public void openCaptureVideo() {
        Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_SIZE_LIMIT, 50 * 1024 * 1024);
        intent.putExtra(MediaStore.EXTRA_DURATION_LIMIT, 15);
        mView.startActivityForResult(intent, REQUEST_CODE_CAPTURE_VIDEO);
    }

    public void openCaptureImage() {
        mImageFile = createImageFile();//创建用来保存照片的文件
        Uri ImageUri = FileProvider7.INSTANCE.getUriForFile(mView, mImageFile);
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(mView.getPackageManager()) != null) {
            intent.putExtra(MediaStore.EXTRA_OUTPUT, ImageUri);
            mView.startActivityForResult(intent, REQUEST_CODE_CAPTURE_IMAGE);
        }
    }

    public boolean isKeyboardShown(View rootView) {
        final int softKeyboardHeight = 100;
        Rect r = new Rect();
        rootView.getWindowVisibleDisplayFrame(r);
        DisplayMetrics dm = rootView.getResources().getDisplayMetrics();
        int heightDiff = rootView.getBottom() - r.bottom;
        return heightDiff > softKeyboardHeight * dm.density;
    }

    /**
     * 创建用来存储图片的文件，以时间来命名就不会产生命名冲突
     *
     * @return 创建的图片文件
     */
    private File createImageFile() {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = mView.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File imageFile = null;
        try {
            imageFile = File.createTempFile(imageFileName, ".jpg", storageDir);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return imageFile;
    }

    /**
     * 打开相册
     */
    public void openGallery() {
        Matisse.from(mView)
                .choose(MimeType.of(MimeType.JPEG, MimeType.PNG, MimeType.GIF, MimeType.MPEG, MimeType.MP4, MimeType.QUICKTIME, MimeType.THREEGPP,
                        MimeType.THREEGPP2, MimeType.MKV, MimeType.WEBM, MimeType.TS, MimeType.AVI), true)
                .theme(R.style.Matisse_Zhihu)
                .setSelectionItems(itemSelected)
                .countable(true)
                .showSingleMediaType(true)
                .maxSelectablePerMediaType(9,1)
                .thumbnailScale(0.8f)
                .originalEnable(false)
                .maxOriginalSize(10)
                .imageEngine(new Glide4Engine())
                .forResult(REQUEST_CODE_IMAGE);
    }

    private boolean isPosting;

    public void post(String content) {
        LogUtils.INSTANCE.e("isPosting:" + isPosting);
        if (isPosting) {
            return;
        }
        isPosting = true;
        mView.showDialogLoading();
        if (isVideo) {
            checkVideoUpload(content);
        } else {
            checkImagesUpload(content);
        }
    }

    private void checkVideoUpload(String content) {
        if (new File(videoPath) != null && new File(videoPath).exists() &&
                new File(videoPath).length() > 50 * 1024 * 1024) {
            mView.showToastMsgShort("视频大于50M");
            mView.hideDialogLoading();
            isPosting = false;
            return;
        }
        CommunityNew community = new CommunityNew();
        community.content = content;
        pushFile(videoFaceFile, "video", 1, url -> {
            if (url == null) {
                mView.showToastMsgShort("封面图片上传失败");
                mView.hideDialogLoading();
                isPosting = false;
                return;
            }
            community.imgUrl = url;
            videoCompressionPath = videoPath.replace(".mp4", "_compress.mp4");
            VideoSlimmer.convertVideo(videoPath, videoCompressionPath, 0.6, new VideoSlimmer.ProgressListener() {
                @Override
                public void onStart() {

                }

                @Override
                public void onFinish(boolean result) {
                    String path = result ? videoCompressionPath : videoPath;
                    pushFile(new File(path), "video", 0, url1 -> {
                        if (url1 == null) {
                            mView.showToastMsgShort("视频上传失败");
                            mView.hideDialogLoading();
                            isPosting = false;
                            return;
                        }
                        community.videoUrl = url1;
                        post(community);
                    });
                }

                @Override
                public void onProgress(float progress) {

                }
            });
        });
    }

    private void checkImagesUpload(String content) {
        if (paths == null || paths.isEmpty()) {
            CommunityNew community = new CommunityNew();
            community.content = content;
            community.postImgLists = imageUrls;
            post(community);
            return;
        }
        String path = paths.get(0);
        pushFile(new File(path), "image", 1, url -> {
            if (url == null) {
                mView.showToastMsgShort("图片上传失败");
                mView.hideDialogLoading();
                isPosting = false;
                return;
            }
            imageUrls.add(url);
            paths.remove(0);
            checkImagesUpload(content);
        });
    }

    private void post(CommunityNew community) {
        community.userId = LoginOrdinaryUtils.INSTANCE.getUserInfo().getUid() + "";
        communityHttpApi.communityPost(community, new LifecycleCallback<CommunityPost>(mView) {
            @Override
            public void onSuccess(CommunityPost data) {
                clearData();
                mView.finish();
                mView.hideDialogLoading();
                mView.showToastMsgShort("发布成功");
//                isPosting = false;
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                isPosting = false;
                mView.hideDialogLoading();
                mView.showToastMsgShort(errMsg);
            }
        });
    }

    private void pushFile(File file, String type, int imageType, UploadListener listener) {
        if (file == null) {
            listener.result(null);
            return;
        }
        infoHttpApi.uploadFile(file, type,imageType,
                new LifecycleCallback<FileDataBean>(mView) {
                    @Override
                    public void onSuccess(FileDataBean data) {
                        if (data != null) {
                            listener.result(data.getImgUrl());
                        }
                    }

                    @Override
                    public void onFailed(int errCode, String errMsg) {
                        listener.result(null);
                    }
                });
    }

    interface UploadListener {
        void result(String url);
    }

    private void clearData() {
        SpUtils.INSTANCE.putBoolean(COMMUNITY_DRAFT_BOX_HAS_DATA, false);
        SpUtils.INSTANCE.clear(COMMUNITY_INPUT_TEXT_CONTENT);
        SpUtils.INSTANCE.clear(COMMUNITY_IMAGE_VIDEO_ITEMS_JSON);
        SpUtils.INSTANCE.clear(IS_VIDEO);
        itemSelected.clear();
    }
}
