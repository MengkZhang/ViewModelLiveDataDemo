package com.yb.ballworld.information.ui.personal.bean;

/**
 * Desc:
 * Author: JS-Kylo
 * Created On: 2019/10/26 10:43
 */
public class CommentBean {
    /**
     * id : 140
     * commentType : 1
     * newsId : 48c2661e595446bc8c843c389d1200fe
     * replyId : 0
     * userId : 1060
     * content : 不开玩笑😐😑😑环境
     * imgUrl1 : http://sta.5yqz2.com/static/bfw/20190929/10/00/4/e9465017b861be587000c02ec044ce79.jpg
     * imgUrl2 :
     * imgUrl3 :
     * videoUrl :
     * videoCoverUrl :
     * likeCount : 5
     * nickName : qtx76
     * headImgUrl : http://sta.5yqz2.com/static/avatar/6b4a9d89d1d94a02bf8ad44550040772.jpg
     * createdDate : 2019-10-23 17:58:51
     * sonNum : 0
     * isLike : false
     * mainCommentId : 0
     * parent : null
     * title : 祖国70周年华诞！阿瑙托维奇祝大家国庆快乐
     * mediaType : 1
     */

    private int id;
    // 0.评论 1.回复
    private int commentType;
    // 评论的资讯ID
    private String newsId;
    //回复ID
    private String replyId;
    //评论用户ID
    private String userId;
    //评论内容
    private String content;
    //图片1
    private String imgUrl1;
    private String imgUrl2;
    private String imgUrl3;
    //视频链接
    private String videoUrl;
    //视频封面
    private String videoCoverUrl;
    //点赞数
    private int likeCount;
    //用户昵称
    private String nickName;
    private String headImgUrl;
    //创建时间
    private String createdDate;
    //子评论数量
    private int sonNum;
    //是否点赞
    private boolean isLike;
    //主评论ID
    private int mainCommentId;
    //父评论对象
    private CommentBean parent;
    //标题
    private String title;
    //资讯类型（0.新闻 1.视频）
    private int mediaType;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCommentType() {
        return commentType;
    }

    public void setCommentType(int commentType) {
        this.commentType = commentType;
    }

    public String getNewsId() {
        return newsId;
    }

    public void setNewsId(String newsId) {
        this.newsId = newsId;
    }

    public String getReplyId() {
        return replyId;
    }

    public void setReplyId(String replyId) {
        this.replyId = replyId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getImgUrl1() {
        return imgUrl1;
    }

    public void setImgUrl1(String imgUrl1) {
        this.imgUrl1 = imgUrl1;
    }

    public String getImgUrl2() {
        return imgUrl2;
    }

    public void setImgUrl2(String imgUrl2) {
        this.imgUrl2 = imgUrl2;
    }

    public String getImgUrl3() {
        return imgUrl3;
    }

    public void setImgUrl3(String imgUrl3) {
        this.imgUrl3 = imgUrl3;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    public String getVideoCoverUrl() {
        return videoCoverUrl;
    }

    public void setVideoCoverUrl(String videoCoverUrl) {
        this.videoCoverUrl = videoCoverUrl;
    }

    public int getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(int likeCount) {
        this.likeCount = likeCount;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getHeadImgUrl() {
        return headImgUrl;
    }

    public void setHeadImgUrl(String headImgUrl) {
        this.headImgUrl = headImgUrl;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public int getSonNum() {
        return sonNum;
    }

    public void setSonNum(int sonNum) {
        this.sonNum = sonNum;
    }

    public boolean isIsLike() {
        return isLike;
    }

    public void setIsLike(boolean isLike) {
        this.isLike = isLike;
    }

    public int getMainCommentId() {
        return mainCommentId;
    }

    public void setMainCommentId(int mainCommentId) {
        this.mainCommentId = mainCommentId;
    }

    public CommentBean getParent() {
        return parent;
    }

    public void setParent(CommentBean parent) {
        this.parent = parent;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getMediaType() {
        return mediaType;
    }

    public void setMediaType(int mediaType) {
        this.mediaType = mediaType;
    }
}
