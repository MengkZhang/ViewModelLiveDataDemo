package com.yb.ballworld.information.widget;

import android.content.Context;
import android.graphics.drawable.BitmapDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.yb.ballworld.baselib.utils.ViewUtils;
import com.yb.ballworld.baselib.widget.popup.BasePopupWindow;
import com.yb.ballworld.information.R;

import org.jetbrains.annotations.NotNull;

/**
 * Desc: <帖子详情window>
 * Author: JS-Barder
 * Created On: 2019/11/13 18:09
 */
public class TopicDetailWindow extends PopupWindow {

    private Context mContext;
    private View.OnClickListener clickListener;

    public TopicDetailWindow(@NotNull Context context) {
        super(context);
        this.mContext = context;
        initView();
    }

    public void setClickListener(View.OnClickListener clickListener) {
        this.clickListener = clickListener;
    }

    protected void initView() {
        LayoutInflater inflater = LayoutInflater.from(mContext);
        View view = inflater.inflate(R.layout.layout_window_topic_detail, null);
        setContentView(view);

        TextView share = view.findViewById(R.id.tv_share);
        TextView report = view.findViewById(R.id.tv_report);

        setOutsideTouchable(true);
        setBackgroundDrawable(new BitmapDrawable());
        setWidth(ViewUtils.dp2px(84));
        setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);

        share.setOnClickListener(v -> {
            if (clickListener != null) {
                clickListener.onClick(v);
            }
        });
        report.setOnClickListener(v -> {
            if (clickListener != null) {
                clickListener.onClick(v);
            }
        });
    }
}
