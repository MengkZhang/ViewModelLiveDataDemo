package com.yb.ballworld.information.ui.profile.presenter;

import android.text.TextUtils;

import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.information.ui.profile.data.DataSubTotalBean;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Gethin
 * @time 2019/11/9 15:19
 */

public  class DataCupPresenter extends DataSubTotalPresenter {

    @Override
    public void loadDataSubTotal() {
        http.getPlayerData(playerId, "2", new LifecycleCallback<List<DataSubTotalBean>>(mView) {
            @Override
            public void onSuccess(List<DataSubTotalBean> data) {
                dataSubTotalData.setData(data);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                dataSubTotalData.setError(errCode, TextUtils.isEmpty(errMsg)?"网络异常，请稍后再试":errMsg);
            }
        });
    }
}
