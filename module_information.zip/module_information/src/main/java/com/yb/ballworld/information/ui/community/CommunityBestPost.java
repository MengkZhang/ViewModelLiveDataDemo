package com.yb.ballworld.information.ui.community;

import com.chad.library.adapter.base.entity.MultiItemEntity;

/**
 * Desc: <精贴实体类>
 * Author: JS-Barder
 * Created On: 2019/11/8 17:15
 */
public class CommunityBestPost implements MultiItemEntity {
    public int id;
    public int sorted;
    public String content;

    @Override
    public int getItemType() {
        return CommunityAdapter.TYPE_BEST_POST;
    }
}
