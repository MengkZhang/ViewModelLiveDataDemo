package com.yb.ballworld.information.ui.profile.view.fragments;

import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.lifecycle.Observer;

import com.jeremyliao.liveeventbus.LiveEventBus;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.common.base.mvp.BaseMvpFragment;
import com.yb.ballworld.common.livedata.LiveDataObserver;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.profile.data.ClubBasicsInfoBean;
import com.yb.ballworld.information.ui.profile.data.ClubDatumBean;
import com.yb.ballworld.information.ui.profile.presenter.ClubDatumPresenter;
import com.yb.ballworld.information.ui.profile.view.ProfileClubActivity;

/**
 * 俱乐部资料库-资料
 * @author Gethin
 * @time 2019/11/9 17:23
 */

public class ClubDatumFragment extends BaseMvpFragment<ClubDatumPresenter> {

    private SmartRefreshLayout smartRefreshLayout;
    private PlaceholderView placeholderView;
    private TextView tvTime;
    private TextView tvZone;
    private TextView tvPark;
    private TextView tvAddress;
    private TextView tvPhone;
    private TextView tvEmail;

    @Override
    public void initPresenter() {
        mPresenter.setVM(this);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_club_datum;
    }

    @Override
    protected void initView() {
        tvTime = findView(R.id.tvTime);
        tvZone = findView(R.id.tvZone);
        tvPark = findView(R.id.tvPark);
        tvPhone = findView(R.id.tvPhone);
        tvEmail = findView(R.id.tvEmail);
        tvAddress = findView(R.id.tvAddress);
        placeholderView = findView(R.id.placeholder);
        smartRefreshLayout = findView(R.id.smart_refresh_layout);
        initRefreshView();
        enableLoadMore(false);
        enableRefresh(false);
    }

    @Override
    public PlaceholderView getPlaceholderView() {
        return placeholderView;
    }

    @Override
    protected SmartRefreshLayout getSmartRefreshLayout() {
        return smartRefreshLayout;
    }

    @Override
    protected void onRefreshData() {
        loadData();
    }

    @Override
    protected void bindEvent() {
        placeholderView.setPageErrorRetryListener(view ->  loadData());
        mPresenter.clubDatum.observe(this, new LiveDataObserver<ClubDatumBean>() {
            @Override
            public void onSuccess(ClubDatumBean data) {
                if (data != null) {
                    showPageContent();
                } else {
                    showPageEmpty("");
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                showPageError(errMsg);
            }
        });

        LiveEventBus.get()
                .with(ProfileClubActivity.KEY_DISPATCH_CLUB_BASICS_INFO_EVENT, ClubBasicsInfoBean.class)
                .observe(this, clubBasicsInfoBean -> {
                    ClubBasicsInfoBean.TeamBean team = clubBasicsInfoBean.getTeam();
                    if (team != null) {
                        tvTime.setText(TextUtils.isEmpty(team.getEstablishDate()) ? "-" : team.getEstablishDate() + "年");
                        tvZone.setText(TextUtils.isEmpty(team.getAddress()) ? "-" : team.getAddress());
                        tvPark.setText(TextUtils.isEmpty(team.getStadiumName()) ? "-" :team.getStadiumName());
                    }
                    tvPhone.setText("-");
                    tvEmail.setText("-");
                    tvAddress.setText("-");
                });
    }

    @Override
    protected void initData() {
        loadData();
    }

    @Override
    protected void processClick(View view) {

    }

    private void loadData() {
        mPresenter.loadClubDatum();
    }
}
