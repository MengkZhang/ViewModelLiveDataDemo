package com.yb.ballworld.information.ui.personal.view;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.jeremyliao.liveeventbus.LiveEventBus;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshHeader;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.base.activity.BaseActivity;
import com.yb.ballworld.baselib.base.recycler.header.PlayBallHeader;
import com.yb.ballworld.baselib.widget.placeholder.HomePlaceholderView;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.common.widget.CommonTitleBar;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.utils.JZReleaseUtil;
import com.yb.ballworld.information.ui.home.utils.softkey.IFSPanelConflictLayout;
import com.yb.ballworld.information.ui.personal.adapter.InfoCollectionQuickAdapter;
import com.yb.ballworld.information.ui.personal.adapter.ItemPraiseAdapterHelper;
import com.yb.ballworld.information.ui.personal.bean.CollectionEntity;
import com.yb.ballworld.information.ui.personal.constant.FailStateConstant;
import com.yb.ballworld.information.ui.personal.presenter.InfoCollectionContract;
import com.yb.ballworld.information.ui.personal.presenter.InfoCollectionPresenter;
import com.yb.ballworld.information.ui.personal.presenter.ItemPraisePresenter;
import com.yb.ballworld.information.widget.GoodView;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;

import static com.yb.ballworld.common.widget.CommonTitleBar.ACTION_LEFT_BUTTON;

/**
 * Desc:
 * Author: JS-Kylo
 * Created On: 2019/10/10 11:49
 */
public class InformationCollectionActivity extends BaseActivity {
    private CommonTitleBar commonTitleBar;

    public static void startActivity(Activity activity) {
        Intent intent = new Intent(activity, InformationCollectionActivity.class);
        activity.startActivity(intent);
    }

    @Override
    public int getLayoutResID() {
        return R.layout.activity_infor_collection_2;
    }

    @Override
    protected void initView() {
        super.initView();
        commonTitleBar = findViewById(R.id.commonTitleBar);
        commonTitleBar.setListener((v, action, extra) -> {
            if (action == ACTION_LEFT_BUTTON) {
                finish();
            }
        });
    }

    @Override
    public void setTextSize(int id, Float size) {

    }

    @Override
    public void setTextSize(TextView textView, Float size) {

    }
}