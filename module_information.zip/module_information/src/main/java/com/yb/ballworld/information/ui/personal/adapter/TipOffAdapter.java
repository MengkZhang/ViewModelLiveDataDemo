package com.yb.ballworld.information.ui.personal.adapter;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.util.DensityUtil;
import com.yb.ballworld.baselib.R;
import com.yb.ballworld.information.ui.personal.bean.community.ReportAuthorReason;

import java.util.List;

/**
 * Desc 分享adapter
 * Date 2019/10/19
 * author mengk
 */
public class TipOffAdapter extends BaseQuickAdapter<ReportAuthorReason, BaseViewHolder> {
    public TipOffAdapter(@Nullable List<ReportAuthorReason> data) {
        super(R.layout.item_tip_off_layout, data);
    }


    @Override
    protected void convert(BaseViewHolder helper, ReportAuthorReason item, int pos) {
        if (item == null) return;
        TextView tvReason = helper.getView(R.id.tv_reason);
        tvReason.setText(item.getReason());
        tvReason.setTextColor(ContextCompat.getColor(mContext, R.color.color_FF333333));
        tvReason.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OnItemClickListener listener=TipOffAdapter.this.getOnItemClickListener();
                if(listener!=null){
                    tvReason.setTextColor(tvReason.getResources().getColor(R.color.color_ffff6b00));
                    tvReason.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            tvReason.setTextColor(tvReason.getResources().getColor(R.color.color_ff333333));
                            listener.onItemClick(TipOffAdapter.this,v,pos);
                        }
                    },200);
                }
            }
        });

    }
}
