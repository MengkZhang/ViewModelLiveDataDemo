package com.yb.ballworld.information.ui.community;

import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.pingerx.player.utils.PlayerUtils;
import com.yb.ballworld.baselib.data.UserInfo;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.baselib.utils.ViewUtils;
import com.yb.ballworld.common.utils.TimeUtil;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.community.adapter.CommunitySingleImageAdapter;
import com.yb.ballworld.information.ui.community.data.CommunityPost;
import com.yb.ballworld.information.ui.community.data.CommunityPostAuthor;
import com.yb.ballworld.information.ui.home.utils.ClickQuitUtil;
import com.yb.ballworld.information.ui.home.utils.GlideLoadImgUtil;
import com.yb.ballworld.information.widget.GridSpacingItemDecoration;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import cn.jzvd.Jzvd;
import cn.jzvd.JzvdStd;

import static android.text.TextUtils.isEmpty;

/**
 * Desc: <社区视频器>
 * Author: JS-Barder
 * Created On: 2019/11/8 11:20
 */
public class CommunityAdapter extends BaseMultiItemQuickAdapter<MultiItemEntity, BaseViewHolder> {
    public static final int TYPE_POST_AUTHOR = 1000;
    public static final int TYPE_BEST_POST = 1001;
    public static final int TYPE_CONTENT_POST = 1002;

    private List<CommunityPostAuthor> postAuthorRecommends = new LinkedList<>();
    private List<CommunityBestPost> postRecommends = new LinkedList<>();
    private List<CommunityPost> data = new LinkedList<>();

    private boolean hasBestTopic = true;

    private View.OnClickListener authorClickListener;

    public CommunityAdapter() {
        super(new ArrayList<>());
        addItemType(TYPE_POST_AUTHOR, R.layout.item_community_recommend);
        addItemType(TYPE_BEST_POST, R.layout.item_community_best_topic);
        addItemType(TYPE_CONTENT_POST, R.layout.item_community_content);
    }

    public void setPostAuthorRecommends(List<CommunityPostAuthor> postAuthorRecommends) {
        this.postAuthorRecommends = postAuthorRecommends;
        notifyDataSetChanged();
    }

    public void setPostRecommends(List<CommunityBestPost> postRecommends) {
        this.postRecommends = postRecommends;
        notifyDataSetChanged();
    }

    public void setData(List<CommunityPost> data) {
        if (data == null) {
            data = new ArrayList<>();
        }
        this.data = data;
        notifyDataSetChanged();
    }

    public void addCommunityPost(CommunityPost post) {
        if (data == null) {
            data = new LinkedList<>();
        }
        data.add(0, post);
        notifyDataSetChanged();
    }

    public void updateItem(CommunityPost post) {
        for (int index = 0; index < getItemCount(); index++) {
            MultiItemEntity item = getItem(index);
            if (item != null && item instanceof CommunityPost) {
                if (((CommunityPost) item).userId.equals(post.userId)) {//判断当前列表数据中所有当前作者数据
                    if (((CommunityPost) item).isAttention != post.isAttention) {
                        ((CommunityPost) item).isAttention = post.isAttention;
                    }
                    if (((CommunityPost) item).isLike != post.isLike) {
                        ((CommunityPost) item).isLike = post.isLike;
                        ((CommunityPost) item).likeCount = post.likeCount;
                    }
                }
            }
        }
        notifyDataSetChanged();
    }

    public void setAuthorClickListener(View.OnClickListener authorClickListener) {
        this.authorClickListener = authorClickListener;
    }

    @Override
    protected void convert(BaseViewHolder helper, MultiItemEntity item, int pos) {
        int viewType = getItemViewType(pos);
        if (viewType == TYPE_POST_AUTHOR) {
            bindAuthor(helper);
        } else if (viewType == TYPE_BEST_POST && item != null) {
            if (item instanceof CommunityBestPost)
                bindBestPost(helper, (CommunityBestPost) item);
        } else if (viewType == TYPE_CONTENT_POST && item != null) {
            if (item instanceof CommunityPost)
                bindPostContent(helper, (CommunityPost) item, pos);
        }
    }

    private void bindAuthor(BaseViewHolder helper) {
        LinearLayout layout = helper.getView(R.id.layout_authors);
        layout.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(mContext);
        int screenWidth = PlayerUtils.INSTANCE.getScreenWidth(mContext);
        int itemWidth = (screenWidth - PlayerUtils.INSTANCE.dp2px(mContext, 24)) / 5;
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(itemWidth, ViewGroup.LayoutParams.WRAP_CONTENT);
//        params.leftMargin = PlayerUtils.INSTANCE.dp2px(mContext, 12);
        for (int index = 0; index < postAuthorRecommends.size() && index < 4; index++) {
            CommunityPostAuthor author = postAuthorRecommends.get(index);
            View view = inflater.inflate(R.layout.layout_auther_recommend, null);
            ImageView avatar = view.findViewById(R.id.avatar_author);
            ;
            TextView name = view.findViewById(R.id.name_author);
            name.setText(author.nickname);
            GlideLoadImgUtil.loadImgHead(mContext, author.headImgUrl, avatar);
            view.setTag(author);
            name.setTag(author);
            view.setOnClickListener(v -> {
                if (authorClickListener != null) {
                    authorClickListener.onClick(v);
                }
            });
            name.setOnClickListener(v -> {
                if (authorClickListener != null) {
                    authorClickListener.onClick(v);
                }
            });
            view.setLayoutParams(params);
            layout.addView(view);
        }
        if (postAuthorRecommends.size() > 3) {
            View view = inflater.inflate(R.layout.layout_auther_recommend, null);
            ImageView avatar = view.findViewById(R.id.avatar_author);
            TextView name = view.findViewById(R.id.name_author);
            avatar.setImageResource(R.mipmap.many);
            name.setText("全部");
            avatar.setOnClickListener(v -> {
                if (authorClickListener != null) {
                    authorClickListener.onClick(v);
                }
            });
            name.setOnClickListener(v -> {
                if (authorClickListener != null) {
                    authorClickListener.onClick(v);
                }
            });
            view.setLayoutParams(params);
            layout.addView(view);
        }
        helper.setGone(R.id.view_community_recommend_bottom, hasBestTopic);
    }

    private void bindBestPost(BaseViewHolder helper, CommunityBestPost bestPost) {
        helper.setText(R.id.tv_item_community_best_topic, bestPost.content);
        helper.addOnClickListener(R.id.tv_item_community_best_topic);
    }

    private void bindPostContent(BaseViewHolder helper, CommunityPost post, int pos) {
        GlideLoadImgUtil.loadImgHead(mContext, post.headImgUrl, helper.getView(R.id.avatar));
        helper.setText(R.id.tv_name, post.nickname);
        helper.setText(R.id.tv_time_topic, TimeUtil.formatPostTime(post.postDate));
        helper.setGone(R.id.tv_content_topic, post.content != null && !isEmpty(post.content));
        helper.setText(R.id.tv_content_topic, post.content);
        initImageVideoShow(helper, pos, post, R.id.recycler_images, R.id.card_player_community, R.id.player_community, true);
        TextView attention = helper.getView(R.id.tv_attention);
        UserInfo userInfo = LoginOrdinaryUtils.INSTANCE.getUserInfo();
        if (userInfo != null && post.userId.equals(userInfo.getUid() + "")) {
            helper.setGone(R.id.tv_attention, false);
        } else {
            helper.setGone(R.id.tv_attention, true);
        }
        attention.setSelected(post.isAttention);
        helper.setText(R.id.tv_count_reply, post.sonNum + "");
        helper.setText(R.id.tv_count_likes, post.likeCount + "");
        if (post.latestPost != null && post.latestPost.content != null) {//该评论有回复
            helper.setGone(R.id.layout_reply, true);
            helper.setText(R.id.tv_name_comment, post.latestPost.nickname);
            helper.setText(R.id.tv_time_comment, TimeUtil.formatPostTime(post.latestPost.postDate));
            helper.setText(R.id.tv_content_comment, post.latestPost.content);
            helper.setGone(R.id.tv_content_comment, post.latestPost.content != null && !isEmpty(post.latestPost.content));
            GlideLoadImgUtil.loadImgHead(mContext, post.latestPost.headImgUrl, helper.getView(R.id.avatar_comment));
            initImageVideoShow(helper, pos, post.latestPost, R.id.recycler_images_comment, R.id.card_player_community_comment, R.id.player_community_comment, false);
        } else {
            helper.setGone(R.id.layout_reply, false);
        }

        initPostAndUserIsLike(post, helper.getView(R.id.tv_attention), helper.getView(R.id.tv_count_likes));

        helper.addOnClickListener(R.id.avatar, R.id.tv_name,
                R.id.avatar_comment, R.id.tv_name_comment, R.id.tv_attention,
                R.id.tv_count_reply, R.id.tv_count_likes);
    }

    private void initImageVideoShow(BaseViewHolder helper, int pos, CommunityPost post, int imageRecyclerId, int cardResId, int playerResId, boolean isContent) {
        if (!isEmpty(post.videoUrl)) {
            helper.setGone(cardResId, true);
            helper.setGone(imageRecyclerId, false);
            JzvdStd player = helper.getView(playerResId);
            GlideLoadImgUtil.loadImg(mContext, post.imgUrl, player.thumbImageView);
            player.setUp(post.videoUrl, "", Jzvd.SCREEN_NORMAL);
        } else if (post.postImgLists != null && !post.postImgLists.isEmpty()) {
            helper.setGone(cardResId, false);
            helper.setGone(imageRecyclerId, true);
            RecyclerView images = helper.getView(imageRecyclerId);
            if (isContent) {
                GridLayoutManager manager = new GridLayoutManager(mContext, post.postImgLists.size() < 3 ? post.postImgLists.size() : 3);
                images.setLayoutManager(manager);
            } else {
                GridLayoutManager manager = new GridLayoutManager(mContext, 3);
                images.setLayoutManager(manager);
            }
            ArrayList<String> postImgLists = post.postImgLists;
            BaseQuickAdapter adapter = new CommunityImageAdapter(post.postImgLists, isContent);
            if (postImgLists!=null && isContent && postImgLists.size() == 1) {
                adapter = new CommunitySingleImageAdapter(postImgLists);
            }
            adapter.setOnItemChildClickListener((adapter1, view, position) -> {
                OnItemChildClickListener childClickListener = getOnItemChildClickListener();
                if (childClickListener != null) {

                    //双击限制 一秒之内只能点击一次
                    if (!ClickQuitUtil.isFastClick()) {
                        view.setTag(pos);
                        childClickListener.onItemChildClick(adapter1, view, position);
                    }
                }
            });
            images.setAdapter(adapter);
            if (images.getItemDecorationCount() == 0) {
                images.addItemDecoration(new GridSpacingItemDecoration(3, ViewUtils.dp2px(6), false));
            }
//            if (postImgLists.size() == 1 && isContent) {
//                CommunitySingleImageAdapter singleImageAdapter = new CommunitySingleImageAdapter(postImgLists);
//                singleImageAdapter.setOnItemChildClickListener((adapter1, view, position) -> {
//                    OnItemChildClickListener childClickListener = getOnItemChildClickListener();
//                    if (childClickListener != null) {
//
//                        //双击限制 一秒之内只能点击一次
//                        if (!ClickQuitUtil.isFastClick()) {
//                            view.setTag(pos);
//                            childClickListener.onItemChildClick(adapter1, view, position);
//                        }
//                    }
//                });
//                images.setAdapter(singleImageAdapter);
//            }  else {
//                CommunityImageAdapter adapter = new CommunityImageAdapter(post.postImgLists, isContent);
//                adapter.setOnItemChildClickListener((adapter1, view, position) -> {
//                    OnItemChildClickListener childClickListener = getOnItemChildClickListener();
//                    if (childClickListener != null) {
//
//                        //双击限制 一秒之内只能点击一次
//                        if (!ClickQuitUtil.isFastClick()) {
//                            view.setTag(pos);
//                            childClickListener.onItemChildClick(adapter1, view, position);
//                        }
//                    }
//                });
//                images.setAdapter(adapter);
//            }
        }else {
            helper.setGone(cardResId, false);
            helper.setGone(imageRecyclerId, false);
        }
    }

    private void initPostAndUserIsLike(CommunityPost post, TextView attention, TextView like) {
        attention.setSelected(post.isAttention);
        attention.setText(post.isAttention ? "已关注" : "关注");
        like.setSelected(post.isLike);
        like.setText(post.likeCount + "");
        Drawable drawableLeft;
        if (post.isLike) {
            drawableLeft = mContext.getResources().getDrawable(R.mipmap.zan_3);
        } else {
            drawableLeft = mContext.getResources().getDrawable(R.mipmap.zan_2);
        }
        drawableLeft.setBounds(0, 0, drawableLeft.getMinimumWidth(), drawableLeft.getMinimumHeight());
        like.setCompoundDrawables(drawableLeft, null, null, null);
    }

    @Nullable
    @Override
    public MultiItemEntity getItem(int position) {
        if (postAuthorRecommends != null && !postAuthorRecommends.isEmpty()) {
            if (position == 0) {
                return null;//当位置为站长推荐作者时，数组直接使用属性postAuthorRecommends
            }
            position--;
        }
        if (postRecommends != null && !postRecommends.isEmpty()) {
            if (0 <= position && position < postRecommends.size()) {
                return postRecommends.get(position);
            }
            position -= postRecommends.size();
        }
        if (0 <= position && position < data.size()) {
            return data.get(position);
        }
        return null;
    }

    @Override
    public int getItemCount() {
        int count = super.getItemCount();
        if (postAuthorRecommends != null && !postAuthorRecommends.isEmpty()) {
            count++;
        }
        if (postRecommends != null && !postRecommends.isEmpty()) {
            count += postRecommends.size();
            hasBestTopic = true;
        }else {
            hasBestTopic = false;
        }
        if (data != null && !data.isEmpty()) {
            count += data.size();
        }
        return count;
    }

    @Override
    public int getItemViewType(int position) {
        if (postAuthorRecommends != null && !postAuthorRecommends.isEmpty()) {
            if (position == 0) {
                return TYPE_POST_AUTHOR;
            }
            position--;
        }
        if (postRecommends != null && !postRecommends.isEmpty()) {
            if (position < postRecommends.size()) {
                return TYPE_BEST_POST;
            }
        }
        return TYPE_CONTENT_POST;
    }
}
