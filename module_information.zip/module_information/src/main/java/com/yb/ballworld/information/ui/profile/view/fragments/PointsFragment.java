package com.yb.ballworld.information.ui.profile.view.fragments;

import android.os.Bundle;
import android.view.View;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.yb.ballworld.common.livedata.LiveDataObserver;
import com.yb.ballworld.information.ui.profile.adapter.PointsAdapter;
import com.yb.ballworld.information.ui.profile.data.PointData;
import com.yb.ballworld.information.ui.profile.data.PointsBean;
import com.yb.ballworld.information.ui.profile.presenter.MatchScorePresenter;

import java.util.ArrayList;
import java.util.List;

/**
 * 赛事资料库-积分
 * @author Gethin
 * @time 2019/11/7 18:23
 */
public class PointsFragment extends RvBaseFragment<MatchScorePresenter> {

    public static PointsFragment newInstance(String seasonId, String groupId) {
        PointsFragment fragment = new PointsFragment();
        Bundle bundle = new Bundle();
        bundle.putString("seasonId", seasonId);
        bundle.putString("groupId", groupId);
        fragment.setArguments(bundle);
        return fragment;
    }

    private PointsAdapter adapter = new PointsAdapter(new ArrayList<>());

    @Override
    protected void loadData() {
        Bundle bundle = getArguments();
        if (bundle != null) {
            String seasonId = bundle.getString("seasonId");
            String groupId = bundle.getString("groupId");
            mPresenter.setSeasonId(seasonId);
            mPresenter.setGroupId(groupId);
        }
    }

    @Override
    protected BaseQuickAdapter getAdapter() {
        return adapter;
    }

    @Override
    public void initPresenter() {
        mPresenter.setVM(this);
    }

    @Override
    protected void bindEvent() {
        smartRefreshLayout.setEnableLoadMore(false);
        mPresenter.getDataWrap().observe(this, new LiveDataObserver<List<PointData>>() {
            @Override
            public void onSuccess(List<PointData> data) {
                smartRefreshLayout.finishRefresh(true);
                if (data != null && data.size() > 0) {
                    showPageContent();
                    adapter.setNewData(initPointData(data));
                } else {
                    showPageEmpty("");
                }

            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                smartRefreshLayout.finishRefresh(false);
                showPageError(errMsg);
            }
        });
    }

    @Override
    protected void processClick(View view) {

    }

    private List<PointsBean> initPointData(List<PointData> datas) {
        ArrayList<PointsBean> pointsBeans = new ArrayList<>();
        for (PointData data : datas) {
            PointsBean pointsBean = new PointsBean();
            pointsBean.groupName = data.groupName;
            pointsBean.setItemType(PointsBean.HEADER);
            pointsBeans.add(pointsBean);
            for (int index = 0; data.stat != null  && index < data.stat.size(); index++) {
                PointsBean bean = data.stat.get(index);
                if (index > 2) {
                    bean.isNormal = true;
                }
                bean.setContentPos(PointsBean.CONTENT_START);
                pointsBeans.add(bean);
            }
        }
        return pointsBeans;
    }
}
