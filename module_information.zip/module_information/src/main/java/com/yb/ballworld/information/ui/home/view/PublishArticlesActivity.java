package com.yb.ballworld.information.ui.home.view;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bfw.util.ToastUtils;
import com.gyf.immersionbar.ImmersionBar;
import com.tbruyelle.rxpermissions2.RxPermissions;
import com.yb.ballworld.baselib.constant.Constant;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.utils.SpUtils;
import com.yb.ballworld.common.base.mvp.BaseMvpActivity;
import com.yb.ballworld.common.livedata.LiveDataObserver;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.adapter.TagCommitAdapter;
import com.yb.ballworld.information.ui.home.bean.IndexLableLetterBean;
import com.yb.ballworld.information.ui.home.bean.PublishArticleUploadFilePostBean;
import com.yb.ballworld.information.ui.home.constant.InsertImgType;
import com.yb.ballworld.information.ui.home.constant.TagParams;
import com.yb.ballworld.information.ui.home.constant.TagReqCode;
import com.yb.ballworld.information.ui.home.presenter.PublishArticlePresenter;
import com.yb.ballworld.information.ui.home.utils.EditDataUtil;
import com.yb.ballworld.information.ui.home.utils.GalleryUtil;
import com.yb.ballworld.information.ui.home.utils.HtmlImgUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.home.utils.ProgressDialogUtil;
import com.yb.ballworld.information.ui.home.utils.RichGlideUtil;
import com.yb.ballworld.information.ui.home.utils.StatusBarHeightUtil;
import com.yb.ballworld.information.ui.home.widget.DeleteImgDialog;
import com.yb.ballworld.information.ui.home.widget.bfrich.RichTextEditor;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import io.reactivex.disposables.Disposable;


/**
 * Desc 发布文章activity
 * Date 2019/11/5
 * author mengk
 */

/**
 * 过时api 建议使用PublishArticleActivity替代
 * @deprecated Use {@link PublishArticleActivity} instead.
 */
@Deprecated
public class PublishArticlesActivity extends BaseMvpActivity<PublishArticlePresenter> {

    private RichTextEditor mRichTextEditor;
    private Disposable subsInsert;
    private RxPermissions rxPermissions;
    private Disposable permissionDisposable;
    private ProgressDialog dialog;
    private RecyclerView rvTag;
    private TextView tvAddTag;
    private ArrayList<IndexLableLetterBean> listTag = new ArrayList<>();
    private ArrayList<String> ids = new ArrayList<>();
    private TagCommitAdapter tagCommitAdapter;

    /**
     * 初始化沉浸式
     */
    protected void initImmersionBar() {
        // 设置共同沉浸式样式
        ImmersionBar.with(this).statusBarDarkFont(true, 0.2f).statusBarColor(getStatusBarColor()).navigationBarColor(R.color.white).init();
    }

    @Override
    public void initPresenter() {
        mPresenter.setVM(this);
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_publish_article;
    }

    @Override
    protected boolean isTouchHideSoftInput() {
        return false;
    }

    @Override
    protected void initView() {
        StatusBarHeightUtil.getStatusBarHeight(F(R.id.statusbar_new), getStatusHeight());
        F(R.id.statusbar_new).setVisibility(View.GONE);
        rxPermissions = new RxPermissions(this);
        RichGlideUtil.initXRichTextImgLoad(PublishArticlesActivity.this);
        mRichTextEditor = F(R.id.et_new_content);
        tvAddTag = F(R.id.tv_add_tag_info);
        rvTag = F(R.id.rv_tag_publish);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(RecyclerView.HORIZONTAL);
        rvTag.setLayoutManager(layoutManager);
        tagCommitAdapter = new TagCommitAdapter(listTag);
        rvTag.setAdapter(tagCommitAdapter);
        getDataFromCache();
    }

    private void getDataFromCache() {
        String data = SpUtils.INSTANCE.getString(TagParams.PUBLISH_ARTICLE_DATA, "");
        if (!TextUtils.isEmpty(data)) {

            LogUtils.INSTANCE.e("===z","缓存的数据 data = " + data);
            try {
               // JSONObject jsonObject = new JSONObject();
                JSONArray jsonArray= new JSONArray(data);
                //JSONArray jsonArray = jsonObject.getJSONArray(data);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    if(jsonObject.has("txt")){
                        String txt = jsonObject.getString("txt");
                        mRichTextEditor.addEditTextAtIndex(i,txt);
                    }else if(jsonObject.has("img")){
                        String img = jsonObject.getString("img");
                        mRichTextEditor.insertImage(img, mRichTextEditor.getMeasuredWidth(),true);
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            mRichTextEditor.removeFirstEditText();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void bindEvent() {
        F(R.id.rl_publish_img_info).setOnClickListener(v -> ifOpenGallery());

        F(R.id.title_bar_sure).setOnClickListener(v -> uploadFile());

        F(R.id.title_bar_back).setOnClickListener(v -> showSaveDialog());

        if (ids.size() == 0) {
            F(R.id.rl_add_tag_info).setOnClickListener(v -> NavigateToDetailUtil.navigateToTagSort(PublishArticlesActivity.this, new ArrayList<>()));
        }

        callBackUploadFile();

        callBackInsertImg();
    }

    private void showSaveDialog() {
        DeleteImgDialog dialog = new DeleteImgDialog(this, getResources().getString(R.string.info_detail_dialog_save_to_file));
        dialog.show();
        dialog.setSureOrCancelListener(new DeleteImgDialog.SureOrCancelListener() {
            @Override
            public void cancel() {
                dialog.dismiss();
                SpUtils.INSTANCE.putString(TagParams.PUBLISH_ARTICLE_DATA, "");
                finish();
            }

            @Override
            public void sure() {
                dialog.dismiss();
                // TODO: 2019/11/9 存储数据
                saveDataToFile();
            }
        });
    }

    private void saveDataToFile() {
        String editData = EditDataUtil.getEditDataJsonArrays(mRichTextEditor);
        if (!TextUtils.isEmpty(editData)) {
            SpUtils.INSTANCE.putString(TagParams.PUBLISH_ARTICLE_DATA,editData);
            ToastUtils.showToast("保存成功");
            finish();
        }
    }


    /**
     * 插入图片回调
     */
    private void callBackInsertImg() {
        mPresenter.getInsertImageBean().observe(this, insertImageBean -> {
            int state = insertImageBean.getState();
            LogUtils.INSTANCE.e("===z", "state = " + state);
            switch (state) {

                case InsertImgType.TYPE_EMITTER_ONNEXT:
                    mRichTextEditor.measure(0, 0);
                    break;

                case InsertImgType.TYPE_ONNEXT:
                    String data = (String) insertImageBean.getData();
                    mRichTextEditor.insertImage(data, mRichTextEditor.getMeasuredWidth(),false);
                    break;

                case InsertImgType.TYPE_ONCOMPLETE:
                    ProgressDialogUtil.dismissProgressDialog(dialog);
                    ToastUtils.showToast("图片插入成功");
                    break;

                case InsertImgType.TYPE_ONSUBSCRIBE:
                    subsInsert = (Disposable) insertImageBean.getData();
                    ProgressDialogUtil.dismissProgressDialog(dialog);
                    break;

                default:
                    ToastUtils.showToast("图片插入失败");
                    Throwable e = (Throwable) insertImageBean.getData();
                    LogUtils.INSTANCE.e("===z", "图片插入异常 e = " + e.getMessage());
                    break;
            }
        });
    }

    /**
     * 长传文件回调
     */
    private void callBackUploadFile() {
        mPresenter.getFileUploadData().observe(this, new LiveDataObserver<PublishArticleUploadFilePostBean>() {
            @Override
            public void onSuccess(PublishArticleUploadFilePostBean data) {
                hideDialogLoading();
                boolean uploadSuccess = data.isUploadSuccess();
                if (uploadSuccess) {
                    Map<String, String> imgUrlMap = data.getImgUrlMap();
                    LogUtils.INSTANCE.e("===z", "上传成功 map = " + imgUrlMap);
                    String uploadData = EditDataUtil.getUploadData(mRichTextEditor, imgUrlMap);
                    LogUtils.INSTANCE.e("===z", "上传成功 uploadData = " + uploadData);
                    ToastUtils.showToast("上传成功");
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                LogUtils.INSTANCE.e("===z", "上传失败 errCode = " + errCode + "   ---errMsg = " + errMsg);
                hideDialogLoading();
            }
        });
    }

    /**
     * 上传文件
     */
    private void uploadFile() {
        List<File> files = new ArrayList<>();
        String editData = EditDataUtil.getEditData(mRichTextEditor);
        if (TextUtils.isEmpty(editData)) {
            ToastUtils.showToast("请输入内容");
            return;
        }

        List<String> pathList = HtmlImgUtil.getImgStrList(editData);
        if (pathList == null || pathList.size() == 0) {//没有图片上传 传内容
            // TODO: 2019/11/5
            return;
        }

        for (String path : pathList) {
            File file = new File(path);
            files.add(file);
        }
        mPresenter.uploadFiles(files, "image");
        showDialogLoading();

    }

    @SuppressLint("CheckResult")
    private void ifOpenGallery() {
        ToastUtils.showToast("click_me");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {//Android6.0及其以上
            permissionDisposable = rxPermissions.request(Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.CAMERA)
                    .subscribe(granted -> {
                        if (granted) { //权限通过
                            openGallery();
                        } else {       //权限拒绝
                            ToastUtils.showToast("权限已被拒绝");
                        }
                    });
        } else {                                             //Android6.0以下
            openGallery();
        }
    }

    @Override
    protected void initData() {

    }

    @Override
    protected void processClick(View view) {

    }

    /**
     * 打开相册
     */
    private void openGallery() {
        GalleryUtil.openGallery(this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (data != null) {
                if (requestCode == Constant.REQUEST_CODE_CHOOSE) { //插入图片回调
                    //异步方式插入图片
                    insertImagesSync(data);
                }
            }
        }

        //选择标签回调
        if (requestCode == TagReqCode.REQ_CODE_PUBLISH_TO_TAG) {
            LogUtils.INSTANCE.e("===z", "选择标签回调");
            if (data == null) return;
            ArrayList<IndexLableLetterBean> resultData = (ArrayList<IndexLableLetterBean>) data.getSerializableExtra(TagParams.INTENT_PARAM_DATA);
            if (resultData != null) {
                listTag.clear();
                listTag.addAll(resultData);
                tagCommitAdapter.notifyDataSetChanged();
                for (IndexLableLetterBean resultDatum : resultData) {
                    ids.add(String.valueOf(resultDatum.getId()));
                    LogUtils.INSTANCE.e("===z", "返回的数据 = " + resultDatum.getLable() + "");
                }
                F(R.id.rl_add_tag_info).setOnClickListener(v -> NavigateToDetailUtil.navigateToTagSort(PublishArticlesActivity.this, ids));
                if (listTag.size() == 0) {
                    tvAddTag.setText("添加标签");
                } else {
                    tvAddTag.setText("添加标签(" + listTag.size()+")");
                }
            }
        }
    }

    /**
     * 异步方式插入图片
     */
    private void insertImagesSync(final Intent data) {
        dialog = ProgressDialogUtil.initDialog(this, "正在插入图片...");
        mPresenter.insertImagesSync(data);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        dispose(permissionDisposable);
        dispose(subsInsert);
    }

    private void dispose(Disposable disposable) {
        if (disposable != null && disposable.isDisposed()) {
            disposable.dispose();
        }
    }


}
