package com.yb.ballworld.information.ui.personal.bean.community;

import android.text.TextUtils;

import com.chad.library.adapter.base.entity.MultiItemEntity;

import java.util.List;

/**
 * Desc:
 * Author: JS-Kylo
 * Created On: 2019/11/11 20:39
 */
public class PostReleaseBean implements MultiItemEntity {

    /**
     * content :
     * createdDate :
     * headImgUrl :
     * id : 0
     * imgUrl :
     * isAttention : true
     * isLike : true
     * lastModifiedDate :
     * latestPost : {}
     * likeCount : 0
     * mainPostId : 0
     * nickname :
     * pageViews : 0
     * parent : {}
     * postImgLists : []
     * postType : 0
     * replyId : 0
     * sex : 0
     * sonNum : 0
     * userId : 0
     * videoUrl :
     */

    private String content;
    private String createdDate;
    private String headImgUrl;
    private int id;
    private String imgUrl;
    private boolean isAttention;
    private boolean isLike;
    private String lastModifiedDate;
    private PostReleaseBean latestPost;
    private int likeCount;
    private int mainPostId;
    private String nickname;
    private int pageViews;
    private PostReleaseBean parent;
    private int postType;
    private int replyId;
    private int sex;
    private int sonNum;
    private int userId;
    private String videoUrl;
    private List<String> postImgLists;
    private String webShareUrl;
    private String postDate;

    public String getPostDate() {
        return !TextUtils.isEmpty(postDate) ? postDate : "";
    }

    public void setPostDate(String postDate) {
        this.postDate = postDate;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getHeadImgUrl() {
        return headImgUrl;
    }

    public void setHeadImgUrl(String headImgUrl) {
        this.headImgUrl = headImgUrl;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public boolean isIsAttention() {
        return isAttention;
    }

    public void setIsAttention(boolean isAttention) {
        this.isAttention = isAttention;
    }

    public boolean isIsLike() {
        return isLike;
    }

    public void setIsLike(boolean isLike) {
        this.isLike = isLike;
    }

    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public PostReleaseBean getLatestPost() {
        return latestPost;
    }

    public void setLatestPost(PostReleaseBean latestPost) {
        this.latestPost = latestPost;
    }

    public int getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(int likeCount) {
        this.likeCount = likeCount;
    }

    public int getMainPostId() {
        return mainPostId;
    }

    public void setMainPostId(int mainPostId) {
        this.mainPostId = mainPostId;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public int getPageViews() {
        return pageViews;
    }

    public void setPageViews(int pageViews) {
        this.pageViews = pageViews;
    }

    public PostReleaseBean getParent() {
        return parent;
    }

    public void setParent(PostReleaseBean parent) {
        this.parent = parent;
    }

    public int getPostType() {
        return postType;
    }

    public void setPostType(int postType) {
        this.postType = postType;
    }

    public int getReplyId() {
        return replyId;
    }

    public void setReplyId(int replyId) {
        this.replyId = replyId;
    }

    public int getSex() {
        return sex;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public int getSonNum() {
        return sonNum;
    }

    public void setSonNum(int sonNum) {
        this.sonNum = sonNum;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    public List<String> getPostImgLists() {
        return postImgLists;
    }

    public void setPostImgLists(List<String> postImgLists) {
        this.postImgLists = postImgLists;
    }

    public String getWebShareUrl() {
        return webShareUrl;
    }

    public void setWebShareUrl(String webShareUrl) {
        this.webShareUrl = webShareUrl;
    }

    private int itemViewType;


    @Override
    public int getItemType() {
        return itemViewType;
    }

    public void setItemViewType(int itemViewType) {
        this.itemViewType = itemViewType;
    }

    public PostReleaseBean() {
    }

    //测试用
    public PostReleaseBean(String content, String createdDate, String headImgUrl, int id, String nickname, int userId, String videoUrl, List<String> postImgLists) {
        this.content = content;
        this.createdDate = createdDate;
        this.headImgUrl = headImgUrl;
        this.id = id;
        this.nickname = nickname;
        this.userId = userId;
        this.videoUrl = videoUrl;
        this.postImgLists = postImgLists;
    }
}
