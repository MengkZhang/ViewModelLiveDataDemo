package com.yb.ballworld.information.ui.home.bean;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * Desc
 * Date 2019/11/9
 * author mengk
 */
/**
 * 过时api 建议使用OutSideIndexNewBean替代
 * @deprecated Use {@link TagOutSideListBean2} instead.
 */
@Deprecated
public class TagOutSideListBean implements Parcelable {
    private String title;
    private List<OutSideIndexNewBean.IndexBean> list;

    public TagOutSideListBean() {
    }

    public TagOutSideListBean(String title, List<OutSideIndexNewBean.IndexBean> list) {
        this.title = title;
        this.list = list;
    }

    protected TagOutSideListBean(Parcel in) {
        title = in.readString();
    }

    public static final Creator<TagOutSideListBean> CREATOR = new Creator<TagOutSideListBean>() {
        @Override
        public TagOutSideListBean createFromParcel(Parcel in) {
            return new TagOutSideListBean(in);
        }

        @Override
        public TagOutSideListBean[] newArray(int size) {
            return new TagOutSideListBean[size];
        }
    };

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<OutSideIndexNewBean.IndexBean> getList() {
        return list;
    }

    public void setList(List<OutSideIndexNewBean.IndexBean> list) {
        this.list = list;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
    }
}
