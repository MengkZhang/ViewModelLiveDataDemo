package com.yb.ballworld.information.ui.home.constant;

import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Desc 加载失败的类型区分
 * Date 2019/10/7
 * author mengk
 */
@IntDef({
        FailStateConstant.TYPE_ERROR,
        FailStateConstant.TYPE_EMPTY
})

@Retention(RetentionPolicy.SOURCE)

public @interface FailStateConstant {
    //加载错误
    int TYPE_ERROR = 0;
    //数据为空
    int TYPE_EMPTY= 1;
}


