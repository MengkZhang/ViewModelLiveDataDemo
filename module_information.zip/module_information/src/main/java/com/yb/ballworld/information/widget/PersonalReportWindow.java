package com.yb.ballworld.information.widget;

import android.content.Context;
import android.graphics.drawable.BitmapDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;

import com.yb.ballworld.baselib.utils.ViewUtils;
import com.yb.ballworld.information.R;

/**
 * Desc: <个人中心举报window>
 * Author: JS-Barder
 * Created On: 2019/11/13 15:08
 */
public class PersonalReportWindow extends PopupWindow {

    private Context context;

    private View.OnClickListener reportClickListener;

    public PersonalReportWindow(Context context) {
        super(context);
        this.context = context;
        initView();
    }

    private void initView() {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.layout_window_personal_report, null);
        setContentView(view);

        setOutsideTouchable(true);

        setBackgroundDrawable(new BitmapDrawable());

        setWidth(ViewUtils.dp2px(84));
        setHeight(ViewUtils.dp2px(38));

        view.setOnClickListener(v -> {
            if (reportClickListener != null) {
                reportClickListener.onClick(v);
            }
        });
    }

    public void setReportClickListener(View.OnClickListener reportClickListener) {
        this.reportClickListener = reportClickListener;
    }
}
