package com.yb.ballworld.information.ui.profile.adapter;

import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.yb.ballworld.common.widget.MultTextView;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.profile.data.DataSubTotalBean;

import java.util.List;

/**
 * @author Gethin
 * @time 2019/11/9 15:24
 */

public class DataSubTotalAdapter extends BaseQuickAdapter<DataSubTotalBean, BaseViewHolder> {

    public DataSubTotalAdapter(int layoutResId) {
        super(layoutResId);
    }

    @Override
    protected void convert(BaseViewHolder helper, DataSubTotalBean item, int pos) {
        if (item == null) return;
        MultTextView tvTime = helper.getView(R.id.mtTimeSection);
        MultTextView tvTitle = helper.getView(R.id.mtTitleSection);
        MultTextView tvContent = helper.getView(R.id.mtDataTotal);

        String time = item.getYear() + " " + item.getLeaugeName();
        tvTime.setTexts(time);
        tvTitle.setTexts("出场/首发", "出场时间", "进球/助攻", "黄牌/红牌");

        String s1 = item.getPresence() + "/" + item.getStartingNum();
        String s2 = item.getPlayTime();
        String s3 = item.getGoals() + "/" + item.getAssist();
        String s4 = item.getYellow() + "/" + item.getRed();
        tvContent.setTexts(s1, s2, s3, s4);


    }
}
