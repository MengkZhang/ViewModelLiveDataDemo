package com.yb.ballworld.information.ui.profile.adapter;

import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.yb.ballworld.baselib.utils.ImageManager;
import com.yb.ballworld.common.widget.MultTextView;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.profile.data.PlayerStat;

import java.util.List;

/**
 * 球员列表适配器
 * 三种类型，第一类型：头布局教练，第二类型：球员分区布局，分区里再取前锋后卫守门员等，第三类型球员信息布局
 * @author Gethin
 * @time 2019/11/9 10:21
 */

public class PlayerAdapter extends BaseMultiItemQuickAdapter<PlayerStat, BaseViewHolder> {

    public PlayerAdapter(List<PlayerStat> data) {
        super(data);
        addItemType(PlayerStat.COACH, R.layout.rv_item_player_coach);
        addItemType(PlayerStat.SECTION, R.layout.rv_item_player_section);
        addItemType(PlayerStat.CONTENT, R.layout.rv_item_player_content);
    }

    @Override
    protected void convert(BaseViewHolder helper, PlayerStat item, int pos) {
        switch (item.getItemType()) {
            case PlayerStat.COACH:
                TextView tvCoachName = helper.getView(R.id.tvCoachName);
                ImageView ivCoachPortrait = helper.getView(R.id.ivCoachPortrait);
                tvCoachName.setText(item.getName());
                ImageManager.INSTANCE.loadBallUser(item.getPicUrl(), ivCoachPortrait);
                break;
            case PlayerStat.SECTION:
                MultTextView mtTitle = helper.getView(R.id.mtTitle);
                TextView tvPoSection = helper.getView(R.id.tvPoSection);
                switch (item.getPosSection()) {
                    case 1:
                        tvPoSection.setText("前锋");
                        break;
                    case 2:
                        tvPoSection.setText("中场");
                        break;
                    case 3:
                        tvPoSection.setText("后卫");
                        break;
                    case 4:
                        tvPoSection.setText("门将");
                        break;
                    case 5:
                        tvPoSection.setText("其它");
                        break;
                }
                mtTitle.setTexts("出场", "进球", "助攻", "周薪(欧)");
                break;
            case PlayerStat.CONTENT:
                LinearLayout llContentRoot = helper.getView(R.id.ll_content_root);
                if (PlayerStat.CONTENT_START == item.getContentPos()) {
                    llContentRoot.setBackgroundResource(R.drawable.rectangle_white_top_radius_bg);
                } else if (PlayerStat.CONTENT_END == item.getContentPos()) {
                    llContentRoot.setBackgroundResource(R.drawable.rectangle_white_bottom_radius_bg);
                } else {
                    llContentRoot.setBackgroundResource(R.drawable.rectangle_white_bg);
                }
                ImageView ivPlayerAvatar = helper.getView(R.id.ivPlayerAvatar);
                TextView tvPlayerName = helper.getView(R.id.tvPlayerName);
                TextView tvShirtNum = helper.getView(R.id.tvShirtNum);
                TextView tvPlayerPos = helper.getView(R.id.tvPlayerPos);
                View dot = helper.getView(R.id.vDot);
                ImageManager.INSTANCE.loadBallUser(item.getPicUrl(), ivPlayerAvatar);
                tvPlayerName.setText(item.getName());
                tvShirtNum.setText(item.getShirtNumber());
                tvPlayerPos.setText(item.getPosition());
                if (TextUtils.isEmpty(item.getPosition())) {
                    dot.setVisibility(View.GONE);
                } else {
                    dot.setVisibility(View.VISIBLE);
                }
                String playerIn = item.getPlayerIn();
                String goal = item.getGoal();
                String assist = item.getAssist();
                MultTextView mtPlayerInfo = helper.getView(R.id.mtPlayerInfo);
                mtPlayerInfo.setTexts(playerIn, goal, assist, "-");
                break;
        }
    }
}
