package com.yb.ballworld.information.ui.profile.view.fragments;

import android.os.Bundle;
import android.view.View;

import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.yb.ballworld.baselib.widget.tab.OnTabSelectListener;
import com.yb.ballworld.baselib.widget.tab.XTabLayout;
import com.yb.ballworld.common.base.BaseFragment;
import com.yb.ballworld.common.base.BaseFragmentStateAdapter;
import com.yb.ballworld.information.R;

import java.util.ArrayList;
import java.util.List;

/**
 * 赛事资料库-球员榜
 * @author Gethin
 * @time 2019/11/7 18:28
 */

public class PlayerRankFragment extends BaseFragment {

    public static PlayerRankFragment newInstance(String seasonId) {
        PlayerRankFragment fragment = new PlayerRankFragment();
        Bundle bundle = new Bundle();
        bundle.putString("seasonId", seasonId);
        fragment.setArguments(bundle);
        return fragment;
    }

    private XTabLayout tabLayout;
    private ViewPager viewPager;
    private List<String> titles = new ArrayList<>();
    private List<Fragment> fragments = new ArrayList<>();

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_data_player;
    }

    @Override
    protected void initView() {
        tabLayout=findView(R.id.x_tab);
        viewPager=findView(R.id.viewPager);
        titles.add("射手榜");
        titles.add("助攻榜");
        Bundle bundle = getArguments();
        if (bundle == null) {
            return;
        }
        String seasonId = bundle.getString("seasonId");
        fragments.add(PlayerRankDataFragment.newInstance(seasonId, "1"));
        fragments.add(PlayerRankDataFragment.newInstance(seasonId, "2"));

        BaseFragmentStateAdapter viewPagerAdapter = new BaseFragmentStateAdapter(getChildFragmentManager(), fragments, titles);
        viewPager.setAdapter(viewPagerAdapter);
        viewPager.setOffscreenPageLimit(fragments.size());
        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                tabLayout.setCurrentTabForce(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        tabLayout.setOnTabSelectListener(new OnTabSelectListener() {
            @Override
            public void onTabSelect(int position) {
                viewPager.setCurrentItem(position);
            }

            @Override
            public void onTabReselect(int position) {

            }
        });
        tabLayout.setViewPager(viewPager);
        tabLayout.setCurrentTabForce(0);
    }

    @Override
    protected void bindEvent() {

    }

    @Override
    protected void initData() {

    }

    @Override
    protected void processClick(View view) {

    }
}

