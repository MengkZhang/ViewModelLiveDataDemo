package com.yb.ballworld.information.ui.profile.view.fragments;

import android.os.Bundle;
import android.view.View;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.yb.ballworld.information.ui.home.adapter.InfoHotAdapter;
import com.yb.ballworld.information.ui.home.bean.IndexHotEntity;
import com.yb.ballworld.information.ui.profile.presenter.MatchMomentsPresenter;

import java.util.ArrayList;
import java.util.List;

/**
 * 资料库-动态
 * @author Gethin
 * @time 2019/11/7 19:05
 */
public class MomentsFragment extends RvBaseFragment<MatchMomentsPresenter> {

    private InfoHotAdapter adapter = new InfoHotAdapter(new ArrayList<>());

    public static MomentsFragment newInstance(String leagueId) {
        MomentsFragment fragment = new MomentsFragment();
        Bundle bundle = new Bundle();
        bundle.putString("leagueId", leagueId);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected void loadData() {

        // test UI
//        List<IndexHotEntity.NewsBean.ListBean> moments = new ArrayList<>();
//        for (int i = 0; i < 5; i++) {
//            moments.add(new IndexHotEntity.NewsBean.ListBean());
//        }
//        adapter.setNewData(moments);
    }

    @Override
    protected BaseQuickAdapter getAdapter() {
        return adapter;
    }

    @Override
    public void initPresenter() {
        mPresenter.setVM(this);
    }

    @Override
    protected void bindEvent() {
        Bundle bundle = getArguments();
        if (bundle != null) {
            String leagueId = bundle.getString("leagueId");
            mPresenter.setLeagueId(leagueId);
            mPresenter.getDataWrap().observe(this, data -> {

            });
        }
    }

    @Override
    protected void processClick(View view) {

    }
}
