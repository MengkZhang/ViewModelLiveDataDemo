package com.yb.ballworld.information.ui.community.bean;

import java.util.ArrayList;
import java.util.List;

public class TopicComment {
    int totalCount;
    int pageNum;
    int pageSize;
    int totalPage;
    List<Topic> list;

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<Topic> getList() {
        return list == null ? new ArrayList<>() : list;
    }

    public void setList(List<Topic> list) {
        this.list = list;
    }


}
