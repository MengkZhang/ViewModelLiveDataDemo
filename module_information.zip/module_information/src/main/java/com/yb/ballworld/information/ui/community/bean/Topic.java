
package com.yb.ballworld.information.ui.community.bean;


import android.text.TextUtils;

import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.yb.ballworld.baselib.utils.TimeUtils;
import com.yb.ballworld.information.ui.detail.InforConstant;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Topic implements MultiItemEntity , Serializable {
    private String content;
    private String createdDate;
    private String postDate;
    private String headImgUrl;
    private int id;
    private String imgUrl;
    private boolean isAttention;
    private boolean isLike;
    private boolean  isFavorites;
    private String lastModifiedDate;
    private Topic latestPost;
    private int likeCount;
    private int mainPostId;
    private String nickname;
    private int pageViews;
    private Topic parent;
    private List<String> postImgLists;
    private int postType;
    private int replyId;
    private int sex;
    private int sonNum;
    private int userId;
    private String videoUrl;
    private int topicType;
    private long createdTime;
    private int commentStatus;
    private String webShareUrl;
    private int replyMainId;

    private int itemType= InforConstant.TopicDetailItemType.TYPE_TOPIC_COMMENT_TEXT;

    public void setContent(String content) {
        this.content = content;
    }

    public String getContent() {
        return defaultValue(content);
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getPostDate() {
        return defaultValue(postDate);
    }

    public void setPostDate(String postDate) {
        this.postDate = postDate;
    }

    public String getCreatedDate() {
        return defaultValue(createdDate);
    }

    public long getCreatedTime() {
        if (this.createdTime <= 0) {
            if (!TextUtils.isEmpty(getCreatedDate())) {
                this.createdTime = TimeUtils.INSTANCE.toTimestamp(getCreatedDate());
            } else {
                this.createdTime = System.currentTimeMillis();
            }
        }
        return createdTime;
    }

    public void setHeadImgUrl(String headImgUrl) {
        this.headImgUrl = headImgUrl;
    }

    public String getHeadImgUrl() {
        return defaultValue(headImgUrl);
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getImgUrl() {
        return defaultValue(imgUrl);
    }

    public void setIsAttention(boolean isAttention) {
        this.isAttention = isAttention;
    }

    public boolean getIsAttention() {
        return isAttention;
    }

    public void setIsLike(boolean isLike) {
        this.isLike = isLike;
    }

    public boolean getIsLike() {
        return isLike;
    }

    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLastModifiedDate() {
        return defaultValue(lastModifiedDate);
    }

    public void setLatestPost(Topic latestPost) {
        this.latestPost = latestPost;
    }

    public Topic getLatestPost() {
        return latestPost;
    }

    public void setLikeCount(int likeCount) {
        this.likeCount = likeCount;
    }

    public int getLikeCount() {
        return likeCount;
    }

    public void setMainPostId(int mainPostId) {
        this.mainPostId = mainPostId;
    }

    public int getMainPostId() {
        return mainPostId;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getNickname() {
        return defaultValue(nickname);
    }

    public void setPageViews(int pageViews) {
        this.pageViews = pageViews;
    }

    public int getPageViews() {
        return pageViews;
    }

    public void setParent(Topic parent) {
        this.parent = parent;
    }

    public Topic getParent() {
        return parent;
    }

    public void setPostImgLists(List<String> postImgLists) {
        this.postImgLists = postImgLists;
    }

    public List<String> getPostImgLists() {
        return postImgLists == null ? new ArrayList<>() : postImgLists;
    }

    public void setPostType(int postType) {
        this.postType = postType;
    }

    public int getPostType() {
        return postType;
    }

    public void setReplyId(int replyId) {
        this.replyId = replyId;
    }

    public int getReplyId() {
        return replyId;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public int getSex() {
        return sex;
    }

    public void setSonNum(int sonNum) {
        this.sonNum = sonNum;
    }

    public int getSonNum() {
        return sonNum;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getUserId() {
        return userId;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    public String getVideoUrl() {
        return defaultValue(videoUrl);
    }


    private String defaultValue(String d) {
        return d == null ? "" : d;
    }


    public int getTopicType() {
        if (!getPostImgLists().isEmpty()) {
            return TopicConstant.TYPE_TOPIC_IMAGE;
        } else if (!TextUtils.isEmpty(getVideoUrl())) {
            return TopicConstant.TYPE_TOPIC_VIDEO;
        }
        return TopicConstant.TYPE_TOPIC_TEXT;
    }

    public void setTopicType(int topicType) {
        this.topicType = topicType;
    }

    @Override
    public int getItemType() {
        if(itemType==InforConstant.TopicDetailItemType.TYPE_TOPIC){
            return itemType;
        }

        int topicType=getTopicType();
        if(topicType== TopicConstant.TYPE_TOPIC_TEXT){
            return InforConstant.TopicDetailItemType.TYPE_TOPIC_COMMENT_TEXT;
        }else if(getTopicType()==TopicConstant.TYPE_TOPIC_IMAGE){
            return InforConstant.TopicDetailItemType.TYPE_TOPIC_COMMENT_IMAGE;
        }else if(getTopicType()==TopicConstant.TYPE_TOPIC_VIDEO){
            return InforConstant.TopicDetailItemType.TYPE_TOPIC_COMMENT_VIDEO;
        }
        return itemType;
    }

    public void setItemTypeBySelf(int type){
        itemType=type;
    }

    public boolean isFavorites() {
        return isFavorites;
    }

    public void setFavorites(boolean favorites) {
        isFavorites = favorites;
    }

    public int getCommentStatus() {
        return commentStatus;
    }

    public void setCommentStatus(int commentStatus) {
        this.commentStatus = commentStatus;
    }

    public String getWebShareUrl() {
        return webShareUrl;
    }

    public void setWebShareUrl(String webShareUrl) {
        this.webShareUrl = webShareUrl;
    }

    public int getReplyMainId() {
        return replyMainId;
    }

    public void setReplyMainId(int replyMainId) {
        this.replyMainId = replyMainId;
    }
}