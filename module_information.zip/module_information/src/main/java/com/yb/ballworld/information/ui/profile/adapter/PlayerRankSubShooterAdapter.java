package com.yb.ballworld.information.ui.profile.adapter;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.yb.ballworld.common.widget.MultTextView;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.profile.data.MatchPlayerBean;

/**
 * @author Gethin
 * @time 2019/11/9 18:57
 */

public class PlayerRankSubShooterAdapter extends BaseQuickAdapter<MatchPlayerBean, BaseViewHolder>{

    public PlayerRankSubShooterAdapter() {
        super(R.layout.rv_item_player_rank_shooter);
    }

    @Override
    protected void convert(BaseViewHolder helper, MatchPlayerBean item, int pos) {
        MultTextView mtPlayerRanShooterInfo  = helper.getView(R.id.mtPlayerRanShooterInfo);
        helper.setText(R.id.tvPos, String.valueOf(pos + 1));
        helper.setText(R.id.tvName, item.playerName);
        helper.setText(R.id.tvTeam, item.teamName);
        mtPlayerRanShooterInfo.setTexts(String.valueOf(item.presence), String.valueOf(item.goals));

    }
}
