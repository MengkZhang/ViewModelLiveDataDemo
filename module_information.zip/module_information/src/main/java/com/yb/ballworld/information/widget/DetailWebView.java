package com.yb.ballworld.information.widget;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.net.http.SslError;
import android.os.Build;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.yb.ballworld.information.utils.HtmlParseData;
import com.yb.ballworld.information.widget.helper.WebViewTouchHelper;
import com.yb.ballworld.information.widget.listener.OnElementClickListener;
import com.yb.ballworld.information.widget.listener.OnScrollBarShowListener;

import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc: <功能简述>
 * Author: JS-Dugu
 * Created On: 2019/10/15 21:23
 */
public class DetailWebView extends WebView implements IDetailWebView {

    private List<String> imgUrls = new ArrayList<String>();
    private List<String> aUrls = new ArrayList<String>();
    private long startClickTime = 0;
    private View.OnClickListener onClickListener;
    private OnElementClickListener onElementClick;
    private String cacheText;

    private WebViewTouchHelper mHelper;
    private OnScrollBarShowListener mScrollBarShowListener;

    public DetailWebView(Context context) {
        super(context);
        init();
    }

    public DetailWebView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init();
    }

    public DetailWebView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init();
    }

    protected void init() {
        setVerticalScrollBarEnabled(false);
        setScrollBarStyle(View.SCROLLBARS_OUTSIDE_OVERLAY);
        setOverScrollMode(OVER_SCROLL_NEVER);
        getSettings().setSupportZoom(false);
        getSettings().setJavaScriptEnabled(true);
        getSettings().setDomStorageEnabled(true);
        //TAG1 TAG2
        addJavascriptInterface(new RichTextJs(), "RichTextJs");

        setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                super.onReceivedSslError(view, handler, error);
                handler.proceed();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                super.shouldOverrideUrlLoading(view, url);
                DetailWebView.this.loadUrl(url);
                return true;
            }

            @TargetApi(Build.VERSION_CODES.KITKAT)
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);

                evaluateJavascript("document.body.removeAttribute('style')", null);
                //evaluateJavascript("alert(document.body.style.fontSize)", null);
                //evaluateJavascript("alert(document.querySelector('html').style.fontSize)", null);
                view.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        loadUrl("javascript:RichTextJs.resize(document.body.scrollHeight)");
                    }
                }, 500);
            }
        });
    }

    @Override
    public void setScrollView(DetailScrollView scrollView) {
        mHelper = new WebViewTouchHelper(scrollView, this);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        if (mHelper == null) {
            return super.onTouchEvent(ev);
        }
        return mHelper.onTouchEvent(ev) && super.onTouchEvent(ev);
    }

    @Override
    public void customScrollBy(int dy) {
        scrollBy(0, dy);
    }

    @Override
    public void customScrollTo(int toY) {
        scrollTo(0, toY);
    }

    @Override
    public void startFling(int vy) {
        DetailScrollView.LogE("DetailWebView...startFling:" + (-vy));
        flingScroll(0, vy);
    }

    @Override
    public int customGetContentHeight() {
        return (int) (getContentHeight() * getScale());
    }

    @Override
    public int customGetWebScrollY() {
        return getScrollY();
    }

    @Override
    public int customComputeVerticalScrollRange() {
        return super.computeVerticalScrollRange();
    }

    @Override
    public void setOnScrollBarShowListener(OnScrollBarShowListener listener) {
        mScrollBarShowListener = listener;
    }

    @Override
    public WebView getView() {
        return this;
    }

    @Override
    protected boolean overScrollBy(int deltaX, int deltaY, int scrollX, int scrollY, int scrollRangeX, int scrollRangeY,
                                   int maxOverScrollX, int maxOverScrollY, boolean isTouchEvent) {
        boolean b = super.overScrollBy(deltaX, deltaY, scrollX, scrollY, scrollRangeX, scrollRangeY, maxOverScrollX, maxOverScrollY, isTouchEvent);
        if (mScrollBarShowListener != null) {
            mScrollBarShowListener.onShow();
        }
        if (mHelper != null) {
            mHelper.overScrollBy(deltaY, scrollY, scrollRangeY, isTouchEvent);
        }
        return b;
    }

    public void setHtml(String text) {
        if (text == null) {
            return;
        }
        cacheText = text;
        loadDataWithBaseURL(null, cacheText, "text/html", "UTF-8", null);
    }


    @Override
    public void setOnClickListener(View.OnClickListener onClickListener) {
        this.onClickListener = onClickListener;
    }

    public String getHtml() {
        return TextUtils.isEmpty(cacheText) ? "" : cacheText;
    }

    /**
     * 修复 img 标签
     **/
    private void fixImg(Document doc) {
        // 使用 jsoup 修改 img 的属性:
        Elements images = doc.getElementsByTag("img");
        for (int i = 0; i < images.size(); i++) {
            // 宽度最大100%，高度自适应
            images.get(i).attr("style", "max-width: 100%; height: auto;")
                    //.attr("onclick", "RichTextJs.onTagClick(this.src, this.getAttribute('data-filename'))")
                    .attr("onclick", "RichTextJs.onTagClick(this.src," + HtmlParseData.TYPE_IMG + "," + i + ")");
            imgUrls.add(images.get(i).attr("src"));
        }
    }

    private class RichTextJs {
        @JavascriptInterface
        public void onTagClick(String url, int type, int position) {
            if (type == HtmlParseData.TYPE_IMG) {
                onElementClick.onElementClick(url, type, position, imgUrls);
            } else if (type == HtmlParseData.TYPE_LINK) {
                onElementClick.onElementClick(url, type, position, aUrls);
            } else {
                onElementClick.onElementClick(url, type, position, null);
            }
        }

        @JavascriptInterface
        public void resize(int height) {
            if (getContext() instanceof Activity) {
                Activity activity = (Activity) getContext();
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        getLayoutParams().height = (int) (height * getResources().getDisplayMetrics().density + 0.5f);
                    }
                });
            }
        }
    }

    public void setOnElementClick(OnElementClickListener onElementClick) {
        this.onElementClick = onElementClick;
    }

}
