package com.yb.ballworld.information.ui.detail;

import androidx.lifecycle.LifecycleOwner;

import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.information.data.CommitBeanList;


public abstract class CommentLifecycleCallback<T> extends LifecycleCallback<T> {
    private BaseCommentPresenter presenter;
    public CommentLifecycleCallback(LifecycleOwner owner,BaseCommentPresenter presenter) {
        super(owner);
        this.presenter=presenter;
    }

    @Override
    public void onSuccess(T data) {
        handleSuccess(data);
        presenter.setTargetId(-1);
    }

    public abstract void handleSuccess(T data);

    protected void setValue(CommitBeanList beanList){
        if(presenter.isFristPage()) {
            presenter.firstPage(beanList.getList().size(),beanList.getTotalCount(),beanList.getTotalPage(),beanList.getPageNum());
        }else{
            presenter.otherPage(beanList.getTotalCount(),beanList.getTotalPage());
        }
        presenter.showCommits(beanList.getList(),presenter.getCommentParent(),presenter.isFristPage());
    }

    @Override
    public void onFailed(int errCode, String errMsg) {
        presenter.showError(presenter.INFOR_COMMITS);
    }
}
