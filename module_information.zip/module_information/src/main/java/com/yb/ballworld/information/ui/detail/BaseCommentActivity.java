package com.yb.ballworld.information.ui.detail;

import android.content.Intent;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bfw.util.ToastUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.ethanhua.skeleton.Skeleton;
import com.ethanhua.skeleton.SkeletonScreen;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.data.UserInfo;
import com.yb.ballworld.baselib.utils.JsonUtils;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.common.base.mvp.BaseMvpActivity;
import com.yb.ballworld.common.widget.CommonTitleBar;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.data.CommitBean;
import com.yb.ballworld.information.data.RootBean;
import com.yb.ballworld.information.data.SonCommentList;
import com.yb.ballworld.information.ui.event.InforCommentCountEvent;
import com.yb.ballworld.information.ui.home.bean.PublishCommentResBean;
import com.yb.ballworld.information.ui.home.constant.PublishIntentParam;
import com.yb.ballworld.information.ui.home.constant.PublishReqCode;
import com.yb.ballworld.information.ui.home.utils.JZReleaseUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.home.view.PublishCommentActivity;
import com.yb.ballworld.information.ui.personal.view.InformationPersonalActivity;
import com.yb.ballworld.information.ui.personal.view.InformationPersonalActivityNew;
import com.yb.ballworld.information.utils.CommondUtil;
import com.yb.ballworld.information.widget.NewsDetailBottomLayout;
import com.yb.ballworld.information.widget.bubbleview.BubblePopupWindow;
import com.yb.ballworld.information.widget.bubbleview.BubbleTextView;
import com.yb.ballworld.information.widget.bubbleview.RelativePos;
import com.yb.ballworld.information.widget.listener.OnElementClickListener;

import java.util.ArrayList;
import java.util.List;

import cn.jzvd.Jzvd;

import static com.yb.ballworld.common.widget.CommonTitleBar.ACTION_LEFT_BUTTON;
import static com.yb.ballworld.information.widget.bubbleview.RelativePos.CENTER_HORIZONTAL;

/**
 * Desc:
 *
 * @author ink
 * created at 2019/11/11 21:52
 */
public abstract class BaseCommentActivity<P extends BaseCommentPresenter> extends BaseMvpActivity<P> implements OnElementClickListener,
        BaseQuickAdapter.OnItemClickListener, BaseQuickAdapter.OnItemChildClickListener, BaseQuickAdapter.OnItemLongClickListener, RecyclerView.OnItemTouchListener {

    //长按或单击出现的PopupWindow
    protected BubblePopupWindow mBubblePopupWindow;

    protected BaseCommentQuickAdapter mCommentAdpater;

    //异常情况占位
    protected PlaceholderView placeholderView;

    //底部评论View
    protected NewsDetailBottomLayout newsDetailBottomLayout;

    //评论主体
    protected SmartRefreshLayout mSmartRefreshLayout;

    //评论列表
    protected RecyclerView recyclerView;

    //用来包揽评论之上的部分
    protected List<MultiItemEntity> mMultiList = new ArrayList<>();

    //骨架页显示器
    protected SkeletonScreen skeletonScreen;

    //如果是自己发表的回复把ID装在这里
    protected List<Integer> myCommitList = new ArrayList<>();

    //用于显示骨架页的容器
    protected View replaceView;

    //头部显示的消息|楼主|贴子
    protected MultiItemEntity commentParent;

    //是否需要在评论后跳转到评论列表
    protected boolean isNeedJump = false;

    protected boolean isChanged = false;

    protected int clickX;
    protected int clickY;
    protected CommitBean parentCommit = null;

    //弹窗文字
    protected BubbleTextView bubbleView;

    @Override
    public void initPresenter() {
        if (mPresenter != null) {
            mPresenter.setVM(this);
        }

        Intent intent = getIntent();
        if (intent == null) {
            ToastUtils.showToast("评论不翼而飞?!");
        } else {
            commentParent = (MultiItemEntity) intent.getSerializableExtra("COMMENT");
            if (commentParent != null) {
                fillPreseneter(commentParent);
            } else {
                isNeedJump = true;

                mPresenter.setCommentId(intent.getIntExtra("COMMENT_ID", -1));
                int commentType = intent.getIntExtra("COMMENT_TYPE", -1);
                int targetId = intent.getIntExtra("MAIN_COMMENT_ID", -1);
                if (commentType > 0) {
                    mPresenter.setTargetId(targetId);
                }
            }
        }
    }

    //====================================UI区===============================================

    @Override
    public int getLayoutId() {
        return R.layout.activity_infor_comment;
    }

    public abstract BaseCommentQuickAdapter getCommentAdapter();

    @Override
    protected void initView() {
        mSmartRefreshLayout = F(R.id.smartRefreshLayout);
        mSmartRefreshLayout.setRefreshFooter(getRefreshFooter());
        mSmartRefreshLayout.setRefreshHeader(getRefreshHeader());
        mSmartRefreshLayout.setEnableAutoLoadMore(true);
        initRefreshView();
        enableRefresh(false);
        enableLoadMore(false);
        placeholderView = F(R.id.placeholderView);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerView = F(R.id.recyclerView);
        recyclerView.setLayoutManager(linearLayoutManager);
        mCommentAdpater = getCommentAdapter();
        recyclerView.setAdapter(mCommentAdpater);
        newsDetailBottomLayout = F(R.id.nbl_view_header2);
        newsDetailBottomLayout.switchStyle(NewsDetailBottomLayout.STYLE_TEXT_ONLY);
        JZReleaseUtil.observeReleaseVideos(recyclerView, mCommentAdpater.getVideoViewId());
        if (!isNeedJump) {
            fillBottomLayout();
        }
        mPresenter.setFristPage(true);

        if (commentParent == null) {
            replaceView = F(R.id.replaceView);
            skeletonScreen = Skeleton.bind(replaceView)
                    .load(R.layout.infor_comment_loading)
                    .duration(1000)
                    .shimmer(true)//是否开启动画
                    .color(R.color.white)
                    .angle(0)
                    .show();
        }
    }

    /**
     *  {
     *         //newsDetailBottomLayout.setParam(1, commit.getNewsId(), String.valueOf(commit.getId()), NewsDetailBottomLayout.TYPE_COMMENT);
     *     }
     */
    protected abstract void fillBottomLayout();

    /**
     *  {
     * //        mPresenter.setNewsId(commit.getNewsId());
     * //        mPresenter.setCommentId(commit.getId());
     *     }
     * @param multiItemEntity
     */
    protected abstract void fillPreseneter(MultiItemEntity multiItemEntity);

    @Override
    protected SmartRefreshLayout getSmartRefreshLayout() {
        return mSmartRefreshLayout;
    }

    @Override
    public PlaceholderView getPlaceholderView() {
        return placeholderView;
    }

    private void showBubble(View commitView, int carryId) {
        if (mBubblePopupWindow == null) {
            View rootView = LayoutInflater.from(this).inflate(R.layout.simple_text_bubble, null);
            bubbleView = rootView.findViewById(R.id.popup_bubble);
            mBubblePopupWindow = new BubblePopupWindow(rootView, bubbleView);
            bubbleView.setOnClickListener(v -> {
                v.setEnabled(false);
                NavigateToDetailUtil.navigateToPublishComment(this,mPresenter.getNewsId(), (String) v.getTag());
                v.setEnabled(true);
            });
            mBubblePopupWindow.setCancelOnTouch(true);
            mBubblePopupWindow.setCancelOnTouchOutside(true);
            mBubblePopupWindow.setCancelOnLater(3000);
        }
        bubbleView.setTag(String.valueOf(carryId));
        mBubblePopupWindow.showArrowTo(commitView, new RelativePos(CENTER_HORIZONTAL, RelativePos.ABOVE), -clickX, -clickY);
    }

    //====================================事件区====================================================

    @Override
    protected void bindEvent() {
        ((CommonTitleBar) F(R.id.infor_titlebar)).setListener((v, action, extra) -> {
            if (action == ACTION_LEFT_BUTTON) {
                finish();
            }
        });
        if (getPlaceholderView() != null) {
            getPlaceholderView().setPageErrorRetryListener(v -> initData());
        }

        mCommentAdpater.setOnItemClickListener(this);
        mCommentAdpater.setOnElementClickListener(this);
        mCommentAdpater.setOnItemChildClickListener(this);
        mCommentAdpater.setOnItemLongClickListener(this);
        recyclerView.addOnItemTouchListener(this);
    }

    @Override
    protected void processClick(View view) {

    }

    @Override
    public boolean onInterceptTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
        clickX = (int) e.getX();
        clickY = (int) e.getY();
        return false;
    }

    @Override
    public void onTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {

    }

    @Override
    public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

    }

    @Override
    public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
        BaseCommentQuickAdapter commentQuickAdapter= (BaseCommentQuickAdapter) adapter;
        int eventType = commentQuickAdapter.getChildEventType(view);
        MultiItemEntity entity = (MultiItemEntity) commentQuickAdapter.getItem(position );
        if (entity != null) {
            switch (eventType) {
                case InforConstant.ItemEvent.USER_COMMENT:
                    InformationPersonalActivityNew.startActivity(this, CommondUtil.fitEmpty(((CommitBean) entity).getUserId()),InformationPersonalActivityNew.TYPE_COMMUNITY);
                    break;
                case InforConstant.ItemEvent.REPLIES_COMMENT:
                    onItemLongClick(adapter, view, position);
                    break;
                case InforConstant.ItemEvent.ROOT_SORT:
                    mPresenter.setHeatSort(commentQuickAdapter.isHeat());
                    mPresenter.setFristPage(true);
                    mPresenter.initLoad();
                    showDialogLoading();
                    break;
                case InforConstant.ItemEvent.LIKE_COMMENT:
                    if (!((CommitBean) entity).isLike()) {
                        mPresenter.addCommitLike(((CommitBean) entity).getId(), position);
                        showLike(mPresenter.INFOR_COMMITS, ((CommitBean) entity).getId(), position, true);
                    }
                    break;
                default:
                    break;
            }
        }
    }

    @Override
    public boolean onItemLongClick(BaseQuickAdapter adapter, View view, int position) {
        BaseCommentQuickAdapter commentQuickAdapter = (BaseCommentQuickAdapter) adapter;
        MultiItemEntity entity = (MultiItemEntity) commentQuickAdapter.getItem(position);
        boolean ishandle = false;
        if (entity!=null&&entity.getItemType() == InforConstant.ItemType.DETAIL_COMMENT&&position>0) {
            parentCommit = (CommitBean) entity;
            showBubble(recyclerView, ((CommitBean) entity).getId());
            ishandle = true;
        }
        return ishandle;
    }

    @Override
    public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
        if (adapter.getItemCount() > position) {
            BaseCommentQuickAdapter commentQuickAdapter = (BaseCommentQuickAdapter) adapter;
            MultiItemEntity entity = (MultiItemEntity) commentQuickAdapter.getItem(position);
            if (position>0&&entity instanceof CommitBean) {
                onItemLongClick(adapter,view,position);
            }
        }
    }

    @Override
    public void onElementClick(String url, int type, int position, List<String> peerList) {
        if (type == InforConstant.WebMediaType.TYPE_IMG) {
            if (!CommondUtil.isEmpty(peerList)) {
                Intent intent = new Intent(this, InformationGalleryActivity.class);
                intent.putStringArrayListExtra("IMG_ARRAY", (ArrayList<String>) peerList);
                intent.putExtra("IMG_INDEX", position);
                startActivity(intent);
            }
        } else if (type == InforConstant.WebMediaType.TYPE_LINK) {
            InformationLinkNewActivity.start(this, url, "", true, true, 0);
        } else if (type == InforConstant.WebMediaType.TYPE_VIDEO) {

        }
    }

    //====================================数据区====================================================

    @Override
    protected void initData() {
        if (commentParent != null) {
            List<MultiItemEntity> entityList = new ArrayList<>();
            entityList.add(commentParent);
            entityList.add(new RootBean(InforConstant.ItemType.DETAIL_HEADER_COMMENT, 0));
            mMultiList.addAll(entityList);
            mCommentAdpater.addData(entityList);
            mCommentAdpater.notifyDataSetChanged();
            showPageContent();
        }
        enableRefresh(true);
        showDialogLoading();
        onRefreshData();
    }

    public MultiItemEntity getCommentParent() {
        return commentParent;
    }

    public void setCommentParent(MultiItemEntity parent) {
        this.commentParent = parent;
    }

    @Override
    protected void onRefreshData() {
        super.onRefreshData();
        mPresenter.setFristPage(true);
        mPresenter.initLoad();
    }

    @Override
    protected void onLoadMoreData() {
        super.onLoadMoreData();
        mPresenter.pullUp();
    }

    //====================================显示区====================================================

    public void showEmpty(int area) {
        if (area == mPresenter.INFOR_COMMITS) {
            if (skeletonScreen != null) {
                skeletonScreen.hide();
                if (replaceView != null) {
                    replaceView.setVisibility(View.GONE);
                }
            }
            if (mPresenter.isFristPage()) {
                hideDialogLoading();
            }
            stopLoadMore();
            stopRefresh();
            enableLoadMore(false);
        }
    }


    public void showError(int area) {
        if (skeletonScreen != null) {
            skeletonScreen.hide();
            if (replaceView != null) {
                replaceView.setVisibility(View.GONE);
            }
        }
        hideDialogLoading();
        hidePageLoading();
        if (area == mPresenter.INFOR_COMMITS) {
            stopLoadMore();
            stopRefresh();
            ToastUtils.showToast("拉取评论失败");
        }
    }

    public void showCommits(List<CommitBean> commentList,MultiItemEntity commentParent,boolean isFirstPage) {
        if (skeletonScreen != null) {
            skeletonScreen.hide();
            if (replaceView != null) {
                replaceView.setVisibility(View.GONE);
            }
        }
        if (mPresenter.isFristPage()) {
            hideDialogLoading();

        }
        mCommentAdpater.setHasMore(mPresenter.hasPullUpMore());
        enableLoadMore(mPresenter.hasPullUpMore());
        stopLoadMore();
        stopRefresh();
        if (commentList != null) {
            MultiItemEntity tempCommit=commentParent;
            if (tempCommit != null) {
               this.commentParent=commentParent;
               commentHeaderHandle(tempCommit);
            }
            if (isFirstPage) {
                List<MultiItemEntity> multiItemEntities = new ArrayList<>();
                if (mMultiList.isEmpty()) {
                    mMultiList.add(tempCommit);
                    mMultiList.add(new RootBean(InforConstant.ItemType.DETAIL_HEADER_COMMENT, 0));
                    multiItemEntities.addAll(mMultiList);
                    if (isListNotEmpty(commentList)) {
                        multiItemEntities.addAll(commentList);
                    } else {
                        //添加空提示item
                    }
                } else {
                    multiItemEntities.addAll(mMultiList);
                    if (isListNotEmpty(commentList)) {
                        multiItemEntities.addAll(commentList);
                    } else {
                        //添加空提示item
                    }
                }

                mCommentAdpater.replaceData(multiItemEntities);
                mPresenter.setFristPage(false);
                moveToPosition(1);
                myCommitList.clear();
            } else {
                if (isListNotEmpty(commentList)) {
                    List<CommitBean> commitBeans=commentList;
                    int size=commitBeans.size()-1;
                    for (int i = size; i >= 0; i--) {
                        if(myCommitList.contains(commitBeans.get(i).getId())){
                            commitBeans.remove(i);
                        }
                    }
                    mCommentAdpater.addData(commitBeans);
                }
            }
        }
    }

    /**
     * {
     * //        mCommentAdpater.setCommentId(tempCommit.getId());
     * //        newsDetailBottomLayout.setParam(1, tempCommit.getNewsId(), String.valueOf(tempCommit.getId()), NewsDetailBottomLayout.TYPE_COMMENT);
     * //        mPresenter.setCommentId(tempCommit.getId());
     *     }
     * @param commentParent
     */
    protected abstract void commentHeaderHandle(MultiItemEntity commentParent);

    private boolean isListNotEmpty(List<CommitBean> commentList) {
        return commentList != null && !CommondUtil.isEmpty(commentList);
    }

    private void moveToPosition(int position) {
        if (position != -1 && !isChanged) {
            isChanged = true;
            recyclerView.scrollToPosition(position);
            LinearLayoutManager mLayoutManager =
                    (LinearLayoutManager) recyclerView.getLayoutManager();
            mLayoutManager.scrollToPositionWithOffset(position, 0);
        }
    }

    /**
     * 是否点赞成功/包括评论内的点赞
     *
     * @param area
     * @param id
     * @param isSuccess
     */
    public void showLike(int area, int id, int position, boolean isSuccess) {
        if (area == mPresenter.INFOR_DETAIL) {
            //文章处点赞
            ImageView likeView = F(R.id.inforDetail_like);
            likeView.setImageResource(isSuccess ? R.drawable.icon_priase_info : R.drawable.icon_priase_info_normal);
            if (isSuccess) {
                TextView likeCountView = F(R.id.inforDetail_likeCount);
                String likeCountstr = likeCountView.getText().toString();
                int likeCount = (TextUtils.isEmpty(likeCountstr) ? 0 : Integer.parseInt(likeCountstr)) + 1;
                ((TextView) F(R.id.inforDetail_likeCount)).setText(String.valueOf(likeCount));
                likeView.setTag(true);
                LiveEventBus.get().with(LiveEventBusKey.KEY_NEWS_LIKE, String.class).post(mPresenter.getNewsId());
            } else {
                likeView.setTag(false);
            }
        } else if (area == mPresenter.INFOR_COMMITS) {
            //评论区点赞
            List<MultiItemEntity> entityList = mCommentAdpater.getData();
            if (!CommondUtil.isEmpty(entityList) && position < entityList.size()) {
                MultiItemEntity bean = (MultiItemEntity) mCommentAdpater.getItem(position);
                //先用位置判断
                if (bean != null && bean instanceof CommitBean) {
                    CommitBean commitBean = ((CommitBean) bean);
                    if (commitBean.getId() == id) {
                        RecyclerView.ViewHolder viewHolder = recyclerView.findViewHolderForLayoutPosition(position);
                        commitBean.setLike(isSuccess);
                        commitBean.setLikeCount(commitBean.getLikeCount() + (isSuccess ? 1 : 0));
                        if (viewHolder != null) {
                            mCommentAdpater.changedLike(commitBean, (BaseViewHolder) viewHolder);
                        } else {
                            mCommentAdpater.notifyItemChanged(position);
                        }
                    }
                } else {
                    //如果不匹配，用commitId去迭代匹配，都没有就放弃吧
                    boolean isMatched;
                    CommitBean commitBean = null;
                    int truthPos = 0;
                    for (MultiItemEntity entity : entityList) {
                        isMatched = entity instanceof CommitBean && (commitBean = (CommitBean) entity).getId() == id;
                        if (isMatched) {
                            RecyclerView.ViewHolder viewHolder = recyclerView.findViewHolderForLayoutPosition(truthPos);
                            commitBean.setLike(isSuccess);
                            commitBean.setLikeCount(commitBean.getLikeCount() + (isSuccess ? 1 : 0));
                            if (viewHolder != null) {
                                mCommentAdpater.changedLike(commitBean, (BaseViewHolder) viewHolder);
                            } else {
                                mCommentAdpater.notifyItemChanged(position);
                            }
                            //mNewsAdapter.notifyItemChanged(truthPos);
                        }
                        truthPos++;
                    }
                }
            }
        }
        if (!isSuccess) {
            ToastUtils.showToast(R.string.prompt_likeFailed);
        }
    }


    //=======================================系统方法===============================================

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data != null && PublishReqCode.REQ_CODE == resultCode && requestCode == PublishReqCode.REQ_CODE) {
            PublishCommentResBean resBean = data.getParcelableExtra(PublishIntentParam.RETURN_DATA);
            if (resBean != null) {
                CommitBean bean = JsonUtils.INSTANCE.fromJson(JsonUtils.INSTANCE.toJson(resBean), CommitBean.class);
                if (bean != null) {
                    if (parentCommit != null && String.valueOf(parentCommit.getId()).equals(bean.getReplyId())) {
                        bean.setParent(parentCommit);
                    }
                    myCommitList.add(bean.getId());
                    UserInfo infor= LoginOrdinaryUtils.INSTANCE.getUserInfo();
                    if(infor!=null) {
                        bean.setHeadImgUrl(infor.getImg());
                    }
                    mCommentAdpater.addData(mMultiList.size(), bean);
                    mPresenter.setTotalcount(mPresenter.getTotalcount()+1);
                }
            }
        }
    }

    @Override
    public void finish() {
        super.finish();
        LiveEventBus.get().with(LiveEventBusKey.KEY_INFOR_COMMENT_COUNT, InforCommentCountEvent.class).post(new InforCommentCountEvent(mPresenter.getTotalcount(),mPresenter.getCommentId()));
    }

    @Override
    protected void onPause() {
        super.onPause();
        Jzvd.releaseAllVideos();
    }

    @Override
    public void onBackPressed() {
        if (Jzvd.backPress()) {
            return;
        }
        super.onBackPressed();
    }


}
