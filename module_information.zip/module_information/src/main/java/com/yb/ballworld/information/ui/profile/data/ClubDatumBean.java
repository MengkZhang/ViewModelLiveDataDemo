package com.yb.ballworld.information.ui.profile.data;

/**
 * @author Gethin
 * @time 2019/11/9 17:29
 */

public class ClubDatumBean {
}
