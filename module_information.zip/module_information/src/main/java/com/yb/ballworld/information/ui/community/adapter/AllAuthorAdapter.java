package com.yb.ballworld.information.ui.community.adapter;

import android.content.Context;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.utils.GlideLoadImgUtil;
import com.yb.ballworld.information.ui.community.bean.AuthorBeanList;

import java.util.List;

/**
 * Desc:  作者列表adapter
 * Author: JS-Kylo
 * Created On: 2019/11/8 18:12
 */
public class AllAuthorAdapter extends BaseQuickAdapter<AuthorBeanList.ListBean, BaseViewHolder> {
    private Context mContext;
    public AllAuthorAdapter(Context context, @Nullable List<AuthorBeanList.ListBean> data) {
        super(R.layout.item_author,data);
        this.mContext = context;
    }

    @Override
    protected void convert(BaseViewHolder helper, AuthorBeanList.ListBean item, int pos) {
        //头像
        ImageView ivUserHeader = helper.getView(R.id.ivUserHeader);
        //作者
        helper.setText(R.id.tv_name,item.getNickname());
        //人气值
        helper.setText(R.id.tv_populars,"人气值"+item.getPopularity());
        //粉丝数
        helper.setText(R.id.tv_fans,"粉丝数"+item.getFollowerCount());
        //帖子数
        helper.setText(R.id.tv_post_count,"帖子数"+item.getPostCount());
        // 关注
        TextView tv_attention = helper.getView(R.id.tv_attention);
        helper.addOnClickListener(R.id.tv_attention, R.id.ivUserHeader, R.id.tv_name);
        GlideLoadImgUtil.loadImgHead(mContext, item.getHeadImgUrl(),ivUserHeader);
        tv_attention.setSelected(item.isIsAttention());
//        if (item.isIsAttention()) {
//            tv_attention.setBackground(ContextCompat.getDrawable(mContext, R.drawable.shape_author_focused));
//            tv_attention.setTextColor(ContextCompat.getColor(mContext, R.color.color_999999));
//            tv_attention.setText("已关注");
//        }
//        else {
//            tv_attention.setBackground(ContextCompat.getDrawable(mContext, R.drawable.shape_author_unfocused));
//            tv_attention.setTextColor(ContextCompat.getColor(mContext,R.color.color_ff6b00));
//            tv_attention.setText("关注");
//        }
    }
}
