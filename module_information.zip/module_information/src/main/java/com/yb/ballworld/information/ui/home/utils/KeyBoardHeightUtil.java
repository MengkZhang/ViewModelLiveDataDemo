package com.yb.ballworld.information.ui.home.utils;

import android.graphics.Rect;
import android.util.DisplayMetrics;
import android.view.View;

/**
 * Desc
 * Date 2019/11/15
 * author mengk
 */
public class KeyBoardHeightUtil {
    public static boolean isKeyboardShown(View rootView) {
        final int softKeyboardHeight = 100;
        Rect r = new Rect();
        rootView.getWindowVisibleDisplayFrame(r);
        DisplayMetrics dm = rootView.getResources().getDisplayMetrics();
        int heightDiff = rootView.getBottom() - r.bottom;
        return heightDiff > softKeyboardHeight * dm.density;
    }
}
