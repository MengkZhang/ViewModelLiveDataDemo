package com.yb.ballworld.information.ui.home.widget.bfrich;

import android.widget.ImageView;

public interface IImageLoader {
    void loadImage(String imagePath, ImageView imageView, boolean centerCrop);
}
