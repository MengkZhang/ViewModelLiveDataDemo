package com.yb.ballworld.information.ui.home.bean;

import android.text.TextUtils;

import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.yb.ballworld.information.ui.home.constant.ItemTypeConstant;

import java.util.List;

/**
 * Desc 主页热门列表返回数据
 * Date 2019/10/9
 * author mengk
 */
public class IndexHotEntity {


    /**
     * bulletBlocks : [{"id":0,"imgUrl":"","jumpId":"","jumpType":0,"jumpUrl":"","title":""}]
     * news : {"list":[{"appShowType":0,"commentCount":0,"id":"","imgUrl":"","likeCount":0,"mediaType":0,"newsImgs":[{"content":"","imgUrl":"","newsId":""}],"playUrl":"","preview":"","showType":0,"title":"","user":{"articleCount":0,"followerCount":0,"headImgUrl":"","id":0,"nickname":"","personalDesc":""},"userId":0}],"pageNum":0,"pageSize":0,"totalCount":0,"totalPage":0}
     * newsTopBlocks : [{"appShowType":0,"commentCount":0,"id":0,"imgUrl":"","likeCount":0,"mediaType":0,"newsId":"","newsImgs":[{"content":"","imgUrl":"","newsId":""}],"playUrl":"","preview":"","showType":0,"title":"","user":{"articleCount":0,"followerCount":0,"headImgUrl":"","id":0,"nickname":"","personalDesc":""}}]
     * specialBlocks : [{"id":0,"imgUrl":"","jumpId":"","jumpType":0,"jumpUrl":"","matchId":"","specialType":0,"sportId":"","title":""}]
     * topBlocks : [{"id":0,"imgUrl":"","jumpId":"","jumpType":0,"jumpUrl":"","title":""}]
     */

    private NewsBean news;
    private List<BulletBlocksBean> bulletBlocks;
    private List<NewsTopBlocksBean> newsTopBlocks;
    private SpecialBlocksBean specialBlocks;
    private List<TopBlocksBean> topBlocks;

    public NewsBean getNews() {
        return news;
    }

    public void setNews(NewsBean news) {
        this.news = news;
    }

    public List<BulletBlocksBean> getBulletBlocks() {
        return bulletBlocks;
    }

    public void setBulletBlocks(List<BulletBlocksBean> bulletBlocks) {
        this.bulletBlocks = bulletBlocks;
    }

    public List<NewsTopBlocksBean> getNewsTopBlocks() {
        return newsTopBlocks;
    }

    public void setNewsTopBlocks(List<NewsTopBlocksBean> newsTopBlocks) {
        this.newsTopBlocks = newsTopBlocks;
    }

    public SpecialBlocksBean getSpecialBlocks() {
        return specialBlocks;
    }

    public void setSpecialBlocks(SpecialBlocksBean specialBlocks) {
        this.specialBlocks = specialBlocks;
    }

    public List<TopBlocksBean> getTopBlocks() {
        return topBlocks;
    }

    public void setTopBlocks(List<TopBlocksBean> topBlocks) {
        this.topBlocks = topBlocks;
    }

    public static class NewsBean {
        /**
         * list : [{"appShowType":0,"commentCount":0,"id":"","imgUrl":"","likeCount":0,"mediaType":0,"newsImgs":[{"content":"","imgUrl":"","newsId":""}],"playUrl":"","preview":"","showType":0,"title":"","user":{"articleCount":0,"followerCount":0,"headImgUrl":"","id":0,"nickname":"","personalDesc":""},"userId":0}]
         * pageNum : 0
         * pageSize : 0
         * totalCount : 0
         * totalPage : 0
         */

        private int pageNum;
        private int pageSize;
        private int totalCount;
        private int totalPage;
        private List<ListBean> list;

        public int getPageNum() {
            return pageNum;
        }

        public void setPageNum(int pageNum) {
            this.pageNum = pageNum;
        }

        public int getPageSize() {
            return pageSize;
        }

        public void setPageSize(int pageSize) {
            this.pageSize = pageSize;
        }

        public int getTotalCount() {
            return totalCount;
        }

        public void setTotalCount(int totalCount) {
            this.totalCount = totalCount;
        }

        public int getTotalPage() {
            return totalPage;
        }

        public void setTotalPage(int totalPage) {
            this.totalPage = totalPage;
        }

        public List<ListBean> getList() {
            return list;
        }

        public void setList(List<ListBean> list) {
            this.list = list;
        }

        public static class ListBean implements MultiItemEntity {
            /**
             * appShowType : 0
             * commentCount : 0
             * id :
             * imgUrl :
             * likeCount : 0
             * mediaType : 0
             * newsImgs : [{"content":"","imgUrl":"","newsId":""}]
             * playUrl :
             * preview :
             * showType : 0
             * title :
             * user : {"articleCount":0,"followerCount":0,"headImgUrl":"","id":0,"nickname":"","personalDesc":""}
             * userId : 0
             */

            private int appShowType;
            private int commentCount;
            private String id;
            private String imgUrl;
            private int likeCount;
            private int mediaType;
            private String playUrl;
            private String webShareUrl;
            private String preview;
            private int showType;
            private String title;
            private UserBean user;
            private int userId;
            private List<NewsImgsBean> newsImgs;
            private boolean isLike;
            private String newsId;
            private boolean isTop;

            public boolean isTop() {
                return isTop;
            }

            public void setTop(boolean top) {
                isTop = top;
            }

            public String getWebShareUrl() {
                return webShareUrl;
            }

            public void setWebShareUrl(String webShareUrl) {
                this.webShareUrl = webShareUrl;
            }

            public String getNewsId() {
                return newsId;
            }

            public void setNewsId(String newsId) {
                this.newsId = newsId;
            }

            public boolean isLike() {
                return isLike;
            }

            public void setLike(boolean like) {
                isLike = like;
            }

            public int getAppShowType() {
                return appShowType;
            }

            public void setAppShowType(int appShowType) {
                this.appShowType = appShowType;
            }

            public int getCommentCount() {
                return commentCount;
            }

            public void setCommentCount(int commentCount) {
                this.commentCount = commentCount;
            }

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public String getImgUrl() {
                return imgUrl;
            }

            public void setImgUrl(String imgUrl) {
                this.imgUrl = imgUrl;
            }

            public int getLikeCount() {
                return likeCount;
            }

            public void setLikeCount(int likeCount) {
                this.likeCount = likeCount;
            }

            public int getMediaType() {
                return mediaType;
            }

            public void setMediaType(int mediaType) {
                this.mediaType = mediaType;
            }

            public String getPlayUrl() {
                return playUrl;
            }

            public void setPlayUrl(String playUrl) {
                this.playUrl = playUrl;
            }

            public String getPreview() {
                return preview;
            }

            public void setPreview(String preview) {
                this.preview = preview;
            }

            public int getShowType() {
                return showType;
            }

            public void setShowType(int showType) {
                this.showType = showType;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public UserBean getUser() {
                return user;
            }

            public void setUser(UserBean user) {
                this.user = user;
            }

            public int getUserId() {
                return userId;
            }

            public void setUserId(int userId) {
                this.userId = userId;
            }

            public List<NewsImgsBean> getNewsImgs() {
                return newsImgs;
            }

            public void setNewsImgs(List<NewsImgsBean> newsImgs) {
                this.newsImgs = newsImgs;
            }

            /**
             * 图文
             *   非特约
             *     单图0
             *     双图1
             *     三图2
             *     图集3
             *   特约
             *     单图4
             *     双图5
             *     三图6
             *     图集7
             * 视频
             *   非特约8
             *   特约9
             * @return
             */
            @Override
            public int getItemType() {
                if (user == null) return ItemTypeConstant.TYPE_IMG_WITHOUT_HEAD;
                int isEditor = user.getIsEditor();
                if (isEditor == 1) {//特约
                    if (mediaType == 1) {//视频
                        return ItemTypeConstant.TYPE_VIDEO_WITH_HEAD;
                    } else {             //非视频 单图 双图 三图
                        if (showType == 0) {
                            return ItemTypeConstant.TYPE_IMG_WITH_HEAD;
                        } else if (showType == 1) {
                            return ItemTypeConstant.TYPE_IMGS_WITH_HEAD;
                        } else {
                            return ItemTypeConstant.TYPE_IMGS3_WITH_HEAD;
                        }
                    }
                } else {            //非特约
                    if (mediaType == 1) {//视频
                        return ItemTypeConstant.TYPE_VIDEO_WITHOUT_HEAD;
                    } else {             //非视频 一张图片居右

                        //判断 单图 双图 三图 和多图  0: 正常, 1: 双图展示，2: 三图展示，3: 图集
                        //一张图片居右 单图是从imgUrl取  多图是从NewsImgs数组中取第一个

                        if (showType == 0) {
                            if (TextUtils.isEmpty(getImgUrl())) {

                                List<NewsImgsBean> newsImgs = getNewsImgs();
                                if (newsImgs != null && newsImgs.size() != 0) {
                                    NewsImgsBean newsImgsBean = newsImgs.get(0);
                                    if (newsImgsBean != null) {
                                        setImgUrl(newsImgsBean.getImgUrl());
                                    }
                                }

                            }
                        } else {
                            List<NewsImgsBean> newsImgs = getNewsImgs();
                            if (newsImgs != null && newsImgs.size() != 0) {
                                NewsImgsBean newsImgsBean = newsImgs.get(0);
                                if (newsImgsBean != null) {
                                    setImgUrl(newsImgsBean.getImgUrl());
                                }
                            }
                        }

                        return ItemTypeConstant.TYPE_IMG_WITHOUT_HEAD;
                    }
                }
            }

            public static class UserBean {

                /**
                 * id : 999
                 * nickname : fanatik
                 * headImgUrl : http://sta.5yqz2.com/static/avatar/73ff1f3e8f368b611986b9025b648471.jpg
                 * personalDesc : null
                 * followerCount : null
                 * articleCount : null
                 */

                private String id;
                private String nickname;
                private String headImgUrl;
                private String personalDesc;
                private int followerCount;
                private int articleCount;
                private int isEditor;//0 非特约 1特约

                public int getIsEditor() {
                    return isEditor;
                }

                public void setIsEditor(int isEditor) {
                    this.isEditor = isEditor;
                }

                public String getId() {
                    return id;
                }

                public void setId(String id) {
                    this.id = id;
                }

                public String getNickname() {
                    return nickname;
                }

                public void setNickname(String nickname) {
                    this.nickname = nickname;
                }

                public String getHeadImgUrl() {
                    return headImgUrl;
                }

                public void setHeadImgUrl(String headImgUrl) {
                    this.headImgUrl = headImgUrl;
                }

                public String getPersonalDesc() {
                    return personalDesc;
                }

                public void setPersonalDesc(String personalDesc) {
                    this.personalDesc = personalDesc;
                }

                public int getFollowerCount() {
                    return followerCount;
                }

                public void setFollowerCount(int followerCount) {
                    this.followerCount = followerCount;
                }

                public int getArticleCount() {
                    return articleCount;
                }

                public void setArticleCount(int articleCount) {
                    this.articleCount = articleCount;
                }
            }


            public static class NewsImgsBean {
                /**
                 * content :
                 * imgUrl :
                 * newsId :
                 */

                private String content;
                private String imgUrl;
                private String newsId;

                public String getContent() {
                    return content;
                }

                public void setContent(String content) {
                    this.content = content;
                }

                public String getImgUrl() {
                    return imgUrl;
                }

                public void setImgUrl(String imgUrl) {
                    this.imgUrl = imgUrl;
                }

                public String getNewsId() {
                    return newsId;
                }

                public void setNewsId(String newsId) {
                    this.newsId = newsId;
                }
            }
        }
    }

    public static class BulletBlocksBean {
        /**
         * id : 0
         * imgUrl :
         * jumpId :
         * jumpType : 0
         * jumpUrl :
         * title :
         */

        private String id;
        private String imgUrl;
        private String jumpId;
        private int jumpType;
        private String jumpUrl;
        private String title;
        private String sportId;

        public String getSportId() {
            return sportId;
        }

        public void setSportId(String sportId) {
            this.sportId = sportId;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getImgUrl() {
            return imgUrl;
        }

        public void setImgUrl(String imgUrl) {
            this.imgUrl = imgUrl;
        }

        public String getJumpId() {
            return jumpId;
        }

        public void setJumpId(String jumpId) {
            this.jumpId = jumpId;
        }

        public int getJumpType() {
            return jumpType;
        }

        public void setJumpType(int jumpType) {
            this.jumpType = jumpType;
        }

        public String getJumpUrl() {
            return jumpUrl;
        }

        public void setJumpUrl(String jumpUrl) {
            this.jumpUrl = jumpUrl;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }
    }

    public static class NewsTopBlocksBean implements MultiItemEntity {
        /**
         * appShowType : 0
         * commentCount : 0
         * id : 0
         * imgUrl :
         * likeCount : 0
         * mediaType : 0
         * newsId :
         * newsImgs : [{"content":"","imgUrl":"","newsId":""}]
         * playUrl :
         * preview :
         * showType : 0
         * title :
         * user : {"articleCount":0,"followerCount":0,"headImgUrl":"","id":0,"nickname":"","personalDesc":""}
         */

        private int appShowType;
        private int commentCount;
        private String id;
        private String imgUrl;
        private int likeCount;
        private int mediaType;
        private String newsId;
        private String playUrl;
        private String webShareUrl;
        private String preview;
        private int showType;
        private String title;
        private UserBeanX user;
        private List<NewsImgsBeanX> newsImgs;
        private boolean isLike;

        public String getWebShareUrl() {
            return webShareUrl;
        }

        public void setWebShareUrl(String webShareUrl) {
            this.webShareUrl = webShareUrl;
        }

        public boolean isLike() {
            return isLike;
        }

        public void setLike(boolean like) {
            isLike = like;
        }

        public int getAppShowType() {
            return appShowType;
        }

        public void setAppShowType(int appShowType) {
            this.appShowType = appShowType;
        }

        public int getCommentCount() {
            return commentCount;
        }

        public void setCommentCount(int commentCount) {
            this.commentCount = commentCount;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getImgUrl() {
            return imgUrl;
        }

        public void setImgUrl(String imgUrl) {
            this.imgUrl = imgUrl;
        }

        public int getLikeCount() {
            return likeCount;
        }

        public void setLikeCount(int likeCount) {
            this.likeCount = likeCount;
        }

        public int getMediaType() {
            return mediaType;
        }

        public void setMediaType(int mediaType) {
            this.mediaType = mediaType;
        }

        public String getNewsId() {
            return newsId;
        }

        public void setNewsId(String newsId) {
            this.newsId = newsId;
        }

        public String getPlayUrl() {
            return playUrl;
        }

        public void setPlayUrl(String playUrl) {
            this.playUrl = playUrl;
        }

        public String getPreview() {
            return preview;
        }

        public void setPreview(String preview) {
            this.preview = preview;
        }

        public int getShowType() {
            return showType;
        }

        public void setShowType(int showType) {
            this.showType = showType;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public UserBeanX getUser() {
            return user;
        }

        public void setUser(UserBeanX user) {
            this.user = user;
        }

        public List<NewsImgsBeanX> getNewsImgs() {
            return newsImgs;
        }

        public void setNewsImgs(List<NewsImgsBeanX> newsImgs) {
            this.newsImgs = newsImgs;
        }

        /**
         * 图文
         *   非特约
         *     单图0
         *     双图1
         *     三图2
         *     图集3
         *   特约
         *     单图4
         *     双图5
         *     三图6
         *     图集7
         * 视频
         *   非特约8
         *   特约9
         * @return 类型
         */
        @Override
        public int getItemType() {

            if (user == null) return ItemTypeConstant.TYPE_IMG_WITHOUT_HEAD;
            int isEditor = user.getIsEditor();
            if (isEditor == 1) {//特约
                if (mediaType == 1) {//视频
                    return ItemTypeConstant.TYPE_VIDEO_WITH_HEAD;
                } else {             //非视频 单图 双图 三图
                    if (showType == 0) {
                        return ItemTypeConstant.TYPE_IMG_WITH_HEAD;
                    } else if (showType == 1) {
                        return ItemTypeConstant.TYPE_IMGS_WITH_HEAD;
                    } else {
                        return ItemTypeConstant.TYPE_IMGS3_WITH_HEAD;
                    }
                }
            } else {            //非特约
                if (mediaType == 1) {//视频
                    return ItemTypeConstant.TYPE_VIDEO_WITHOUT_HEAD;
                } else {             //非视频 一张图片居右

                    //判断 单图 双图 三图 和多图  0: 正常, 1: 双图展示，2: 三图展示，3: 图集
                    //一张图片居右 单图是从imgUrl取  多图是从NewsImgs数组中取第一个

                    if (showType == 0) {

                        if (TextUtils.isEmpty(getImgUrl())) {

                            List<NewsImgsBeanX> newsImgs = getNewsImgs();
                            if (newsImgs != null && newsImgs.size() != 0) {
                                NewsImgsBeanX newsImgsBeanX = newsImgs.get(0);
                                if (newsImgsBeanX != null) {
                                    setImgUrl(newsImgsBeanX.getImgUrl());
                                }
                            }

                        }

                    } else {

                        List<NewsImgsBeanX> newsImgs = getNewsImgs();
                        if (newsImgs != null && newsImgs.size() != 0) {
                            NewsImgsBeanX newsImgsBeanX = newsImgs.get(0);
                            if (newsImgsBeanX != null) {
                                setImgUrl(newsImgsBeanX.getImgUrl());
                            }
                        }

                    }

                    return ItemTypeConstant.TYPE_IMG_WITHOUT_HEAD;
                }
            }
        }

        public static class UserBeanX {
            /**
             * articleCount : 0
             * followerCount : 0
             * headImgUrl :
             * id : 0
             * nickname :
             * personalDesc :
             */

            private int articleCount;
            private int followerCount;
            private int isEditor;
            private String headImgUrl;
            private String id;
            private String nickname;
            private String personalDesc;

            public int getIsEditor() {
                return isEditor;
            }

            public void setIsEditor(int isEditor) {
                this.isEditor = isEditor;
            }

            public int getArticleCount() {
                return articleCount;
            }

            public void setArticleCount(int articleCount) {
                this.articleCount = articleCount;
            }

            public int getFollowerCount() {
                return followerCount;
            }

            public void setFollowerCount(int followerCount) {
                this.followerCount = followerCount;
            }

            public String getHeadImgUrl() {
                return headImgUrl;
            }

            public void setHeadImgUrl(String headImgUrl) {
                this.headImgUrl = headImgUrl;
            }

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public String getNickname() {
                return nickname;
            }

            public void setNickname(String nickname) {
                this.nickname = nickname;
            }

            public String getPersonalDesc() {
                return personalDesc;
            }

            public void setPersonalDesc(String personalDesc) {
                this.personalDesc = personalDesc;
            }
        }

        public static class NewsImgsBeanX {
            /**
             * content :
             * imgUrl :
             * newsId :
             */

            private String content;
            private String imgUrl;
            private String newsId;

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public String getImgUrl() {
                return imgUrl;
            }

            public void setImgUrl(String imgUrl) {
                this.imgUrl = imgUrl;
            }

            public String getNewsId() {
                return newsId;
            }

            public void setNewsId(String newsId) {
                this.newsId = newsId;
            }
        }
    }

    public static class SpecialBlocksBean {


        /**
         * specialType : 1
         * specialBlockVo : [{"id":"6","specialType":1,"title":"test23444","imgUrl":"","jumpType":0,"jumpId":"","jumpUrl":"","matchId":"179","sportId":"5","matchData":[{"animUrl":null,"guestTeamId":1829,"guestTeamLogo":"https://img.qiutianxia.com/imgs/teams/20190219230818650_100x100.png","guestTeamName":"塞拉利昂","enGuestTeamName":"Sierra Leone","guestTeamScore":0,"guestTeamNormalScore":0,"hostTeamId":3026,"hostTeamLogo":"https://img.qiutianxia.com/imgs/teams/20190219231001624_100x100.png","hostTeamName":"赤道几内亚","enHostTeamName":"Equatorial Guinea","hostTeamScore":2,"hostTeamNormalScore":0,"leagueId":6,"leagueLevelColor":"FFFF00","leagueLogo":"","leagueName":"世界杯非洲区预选赛","enLeagueName":"WC Qualification, CAF","leagueNick":"非洲世预","enLeagueNick":"WC Qualification, CAF","liveFlvUrl":"","liveM3u8Url":"","thumb1":"","matchId":179,"matchStatus":3,"matchStatusCode":100,"matchStatusDesc":"完场","matchTime":"1212330600000","round":"决赛","sportId":1,"timePlayed":0,"vid":"","hasLive":0,"hasVid":0,"hostRank":"","guestRank":"","groupName":"分组赛","seasonId":59,"asiaRate":"","dxRate":"","asiaHalfRate":"","dxHalfRate":"","weather":"","weatherDesc":"","temperature":"","hostHalfScore":0,"guestHalfScore":0,"focus":0,"roomId":"","side":"","gameScore":"","hostGameScore":"","guestGameScore":"","hostTeamLogo2":"","guestTeamLogo2":"","hostTeamName2":"","guestTeamName2":"","enHostTeamName2":"","enGuestTeamName2":"","hostCurrentDisk":"","guestCurrentDisk":"","thumbVid":""}],"createdDate":"2019-10-11 17:12:24"},{"id":"8","specialType":1,"title":"1231241241","imgUrl":"","jumpType":0,"jumpId":"","jumpUrl":"","matchId":"100","sportId":"5","matchData":[{"animUrl":null,"guestTeamId":1887,"guestTeamLogo":"https://img.qiutianxia.com/imgs/teams/20190219230824334_90x90.png","guestTeamName":"阿根廷","enGuestTeamName":"Argentina","guestTeamScore":2,"guestTeamNormalScore":0,"hostTeamId":1815,"hostTeamLogo":"https://img.qiutianxia.com/imgs/teams/20190219230817231_90x90.png","hostTeamName":"委内瑞拉","enHostTeamName":"Venezuela","hostTeamScore":0,"hostTeamNormalScore":0,"leagueId":121,"leagueLevelColor":"FFFF00","leagueLogo":null,"leagueName":"世界杯南美洲区预选赛","enLeagueName":"WC Qual, CONMEBOL","leagueNick":"南美世预","enLeagueNick":"WC Qual, CONMEBOL","liveFlvUrl":"","liveM3u8Url":"","thumb1":"","matchId":100,"matchStatus":3,"matchStatusCode":100,"matchStatusDesc":"完场","matchTime":"1192581600000","round":"半决赛","sportId":1,"timePlayed":0,"vid":"","hasLive":0,"hasVid":0,"hostRank":"","guestRank":"","groupName":"资格赛","seasonId":1666,"asiaRate":"","dxRate":"","asiaHalfRate":"","dxHalfRate":"","weather":"","weatherDesc":"","temperature":"","hostHalfScore":0,"guestHalfScore":2,"focus":0,"roomId":"","side":"","gameScore":"","hostGameScore":"","guestGameScore":"","hostTeamLogo2":"","guestTeamLogo2":"","hostTeamName2":"","guestTeamName2":"","enHostTeamName2":"","enGuestTeamName2":"","hostCurrentDisk":"","guestCurrentDisk":"","thumbVid":""},{"animUrl":"","guestTeamId":1829,"guestTeamLogo":"https://img.qiutianxia.com/imgs/teams/20190219230818650_100x100.png","guestTeamName":"塞拉利昂","enGuestTeamName":"Sierra Leone","guestTeamScore":0,"guestTeamNormalScore":0,"hostTeamId":3026,"hostTeamLogo":"https://img.qiutianxia.com/imgs/teams/20190219231001624_100x100.png","hostTeamName":"赤道几内亚","enHostTeamName":"Equatorial Guinea","hostTeamScore":2,"hostTeamNormalScore":0,"leagueId":6,"leagueLevelColor":"FFFF00","leagueLogo":null,"leagueName":"世界杯非洲区预选赛","enLeagueName":"WC Qualification, CAF","leagueNick":"非洲世预","enLeagueNick":"WC Qualification, CAF","liveFlvUrl":null,"liveM3u8Url":null,"thumb1":null,"matchId":179,"matchStatus":3,"matchStatusCode":100,"matchStatusDesc":"完场","matchTime":"1212330600000","round":"决赛","sportId":1,"timePlayed":0,"vid":"","hasLive":0,"hasVid":0,"hostRank":"","guestRank":"","groupName":"分组赛","seasonId":59,"asiaRate":"","dxRate":"","asiaHalfRate":"","dxHalfRate":"","weather":"","weatherDesc":"","temperature":"","hostHalfScore":0,"guestHalfScore":0,"focus":0,"roomId":"","side":"","gameScore":"","hostGameScore":"","guestGameScore":"","hostTeamLogo2":"","guestTeamLogo2":"","hostTeamName2":"","guestTeamName2":"","enHostTeamName2":"","enGuestTeamName2":"","hostCurrentDisk":"","guestCurrentDisk":"","thumbVid":""}],"createdDate":"2019-10-11 19:52:24"}]
         */

        private int specialType;
        private List<SpecialBlockVoBean> specialBlockVo;

        public int getSpecialType() {
            return specialType;
        }

        public void setSpecialType(int specialType) {
            this.specialType = specialType;
        }

        public List<SpecialBlockVoBean> getSpecialBlockVo() {
            return specialBlockVo;
        }

        public void setSpecialBlockVo(List<SpecialBlockVoBean> specialBlockVo) {
            this.specialBlockVo = specialBlockVo;
        }

        public static class SpecialBlockVoBean {
            /**
             * id : 6
             * specialType : 1
             * title : test23444
             * imgUrl :
             * jumpType : 0
             * jumpId :
             * jumpUrl :
             * matchId : 179
             * sportId : 5
             * matchData : [{"animUrl":null,"guestTeamId":1829,"guestTeamLogo":"https://img.qiutianxia.com/imgs/teams/20190219230818650_100x100.png","guestTeamName":"塞拉利昂","enGuestTeamName":"Sierra Leone","guestTeamScore":0,"guestTeamNormalScore":0,"hostTeamId":3026,"hostTeamLogo":"https://img.qiutianxia.com/imgs/teams/20190219231001624_100x100.png","hostTeamName":"赤道几内亚","enHostTeamName":"Equatorial Guinea","hostTeamScore":2,"hostTeamNormalScore":0,"leagueId":6,"leagueLevelColor":"FFFF00","leagueLogo":"","leagueName":"世界杯非洲区预选赛","enLeagueName":"WC Qualification, CAF","leagueNick":"非洲世预","enLeagueNick":"WC Qualification, CAF","liveFlvUrl":"","liveM3u8Url":"","thumb1":"","matchId":179,"matchStatus":3,"matchStatusCode":100,"matchStatusDesc":"完场","matchTime":"1212330600000","round":"决赛","sportId":1,"timePlayed":0,"vid":"","hasLive":0,"hasVid":0,"hostRank":"","guestRank":"","groupName":"分组赛","seasonId":59,"asiaRate":"","dxRate":"","asiaHalfRate":"","dxHalfRate":"","weather":"","weatherDesc":"","temperature":"","hostHalfScore":0,"guestHalfScore":0,"focus":0,"roomId":"","side":"","gameScore":"","hostGameScore":"","guestGameScore":"","hostTeamLogo2":"","guestTeamLogo2":"","hostTeamName2":"","guestTeamName2":"","enHostTeamName2":"","enGuestTeamName2":"","hostCurrentDisk":"","guestCurrentDisk":"","thumbVid":""}]
             * createdDate : 2019-10-11 17:12:24
             */

            private String id;
            private int specialType;
            private String title;
            private String imgUrl;
            private int jumpType;
            private String jumpId;
            private String jumpUrl;
            private String matchId;
            private String sportId;
            private String createdDate;
            private List<MatchDataBean> matchData;

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public int getSpecialType() {
                return specialType;
            }

            public void setSpecialType(int specialType) {
                this.specialType = specialType;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getImgUrl() {
                return imgUrl;
            }

            public void setImgUrl(String imgUrl) {
                this.imgUrl = imgUrl;
            }

            public int getJumpType() {
                return jumpType;
            }

            public void setJumpType(int jumpType) {
                this.jumpType = jumpType;
            }

            public String getJumpId() {
                return jumpId;
            }

            public void setJumpId(String jumpId) {
                this.jumpId = jumpId;
            }

            public String getJumpUrl() {
                return jumpUrl;
            }

            public void setJumpUrl(String jumpUrl) {
                this.jumpUrl = jumpUrl;
            }

            public String getMatchId() {
                return matchId;
            }

            public void setMatchId(String matchId) {
                this.matchId = matchId;
            }

            public String getSportId() {
                return sportId;
            }

            public void setSportId(String sportId) {
                this.sportId = sportId;
            }

            public String getCreatedDate() {
                return createdDate;
            }

            public void setCreatedDate(String createdDate) {
                this.createdDate = createdDate;
            }

            public List<MatchDataBean> getMatchData() {
                return matchData;
            }

            public void setMatchData(List<MatchDataBean> matchData) {
                this.matchData = matchData;
            }

            public static class MatchDataBean {
                /**
                 * animUrl : null
                 * guestTeamId : 1829
                 * guestTeamLogo : https://img.qiutianxia.com/imgs/teams/20190219230818650_100x100.png
                 * guestTeamName : 塞拉利昂
                 * enGuestTeamName : Sierra Leone
                 * guestTeamScore : 0
                 * guestTeamNormalScore : 0
                 * hostTeamId : 3026
                 * hostTeamLogo : https://img.qiutianxia.com/imgs/teams/20190219231001624_100x100.png
                 * hostTeamName : 赤道几内亚
                 * enHostTeamName : Equatorial Guinea
                 * hostTeamScore : 2
                 * hostTeamNormalScore : 0
                 * leagueId : 6
                 * leagueLevelColor : FFFF00
                 * leagueLogo :
                 * leagueName : 世界杯非洲区预选赛
                 * enLeagueName : WC Qualification, CAF
                 * leagueNick : 非洲世预
                 * enLeagueNick : WC Qualification, CAF
                 * liveFlvUrl :
                 * liveM3u8Url :
                 * thumb1 :
                 * matchId : 179
                 * matchStatus : 3
                 * matchStatusCode : 100
                 * matchStatusDesc : 完场
                 * matchTime : 1212330600000
                 * round : 决赛
                 * sportId : 1
                 * timePlayed : 0
                 * vid :
                 * hasLive : 0
                 * hasVid : 0
                 * hostRank :
                 * guestRank :
                 * groupName : 分组赛
                 * seasonId : 59
                 * asiaRate :
                 * dxRate :
                 * asiaHalfRate :
                 * dxHalfRate :
                 * weather :
                 * weatherDesc :
                 * temperature :
                 * hostHalfScore : 0
                 * guestHalfScore : 0
                 * focus : 0
                 * roomId :
                 * side :
                 * gameScore :
                 * hostGameScore :
                 * guestGameScore :
                 * hostTeamLogo2 :
                 * guestTeamLogo2 :
                 * hostTeamName2 :
                 * guestTeamName2 :
                 * enHostTeamName2 :
                 * enGuestTeamName2 :
                 * hostCurrentDisk :
                 * guestCurrentDisk :
                 * thumbVid :
                 */

                private Object animUrl;
                private int guestTeamId;
                private String guestTeamLogo;
                private String guestTeamName;
                private String enGuestTeamName;
                private int guestTeamScore;
                private int guestTeamNormalScore;
                private int hostTeamId;
                private String hostTeamLogo;
                private String hostTeamName;
                private String enHostTeamName;
                private int hostTeamScore;
                private int hostTeamNormalScore;
                private int leagueId;
                private String leagueLevelColor;
                private String leagueLogo;
                private String leagueName;
                private String enLeagueName;
                private String leagueNick;
                private String enLeagueNick;
                private String liveFlvUrl;
                private String liveM3u8Url;
                private String thumb1;
                private int matchId;
                private int matchStatus;
                private int matchStatusCode;
                private String matchStatusDesc;
                private String matchTime;
                private String round;
                private int sportId;
                private int timePlayed;
                private String vid;
                private int hasLive;
                private int hasVid;
                private String hostRank;
                private String guestRank;
                private String groupName;
                private int seasonId;
                private String asiaRate;
                private String dxRate;
                private String asiaHalfRate;
                private String dxHalfRate;
                private String weather;
                private String weatherDesc;
                private String temperature;
                private int hostHalfScore;
                private int guestHalfScore;
                private int focus;
                private String roomId;
                private String side;
                private String gameScore;
                private String hostGameScore;
                private String guestGameScore;
                private String hostTeamLogo2;
                private String guestTeamLogo2;
                private String hostTeamName2;
                private String guestTeamName2;
                private String enHostTeamName2;
                private String enGuestTeamName2;
                private String hostCurrentDisk;
                private String guestCurrentDisk;
                private String thumbVid;

                public Object getAnimUrl() {
                    return animUrl;
                }

                public void setAnimUrl(Object animUrl) {
                    this.animUrl = animUrl;
                }

                public int getGuestTeamId() {
                    return guestTeamId;
                }

                public void setGuestTeamId(int guestTeamId) {
                    this.guestTeamId = guestTeamId;
                }

                public String getGuestTeamLogo() {
                    return guestTeamLogo;
                }

                public void setGuestTeamLogo(String guestTeamLogo) {
                    this.guestTeamLogo = guestTeamLogo;
                }

                public String getGuestTeamName() {
                    return guestTeamName;
                }

                public void setGuestTeamName(String guestTeamName) {
                    this.guestTeamName = guestTeamName;
                }

                public String getEnGuestTeamName() {
                    return enGuestTeamName;
                }

                public void setEnGuestTeamName(String enGuestTeamName) {
                    this.enGuestTeamName = enGuestTeamName;
                }

                public int getGuestTeamScore() {
                    return guestTeamScore;
                }

                public void setGuestTeamScore(int guestTeamScore) {
                    this.guestTeamScore = guestTeamScore;
                }

                public int getGuestTeamNormalScore() {
                    return guestTeamNormalScore;
                }

                public void setGuestTeamNormalScore(int guestTeamNormalScore) {
                    this.guestTeamNormalScore = guestTeamNormalScore;
                }

                public int getHostTeamId() {
                    return hostTeamId;
                }

                public void setHostTeamId(int hostTeamId) {
                    this.hostTeamId = hostTeamId;
                }

                public String getHostTeamLogo() {
                    return hostTeamLogo;
                }

                public void setHostTeamLogo(String hostTeamLogo) {
                    this.hostTeamLogo = hostTeamLogo;
                }

                public String getHostTeamName() {
                    return hostTeamName;
                }

                public void setHostTeamName(String hostTeamName) {
                    this.hostTeamName = hostTeamName;
                }

                public String getEnHostTeamName() {
                    return enHostTeamName;
                }

                public void setEnHostTeamName(String enHostTeamName) {
                    this.enHostTeamName = enHostTeamName;
                }

                public int getHostTeamScore() {
                    return hostTeamScore;
                }

                public void setHostTeamScore(int hostTeamScore) {
                    this.hostTeamScore = hostTeamScore;
                }

                public int getHostTeamNormalScore() {
                    return hostTeamNormalScore;
                }

                public void setHostTeamNormalScore(int hostTeamNormalScore) {
                    this.hostTeamNormalScore = hostTeamNormalScore;
                }

                public int getLeagueId() {
                    return leagueId;
                }

                public void setLeagueId(int leagueId) {
                    this.leagueId = leagueId;
                }

                public String getLeagueLevelColor() {
                    return leagueLevelColor;
                }

                public void setLeagueLevelColor(String leagueLevelColor) {
                    this.leagueLevelColor = leagueLevelColor;
                }

                public String getLeagueLogo() {
                    return leagueLogo;
                }

                public void setLeagueLogo(String leagueLogo) {
                    this.leagueLogo = leagueLogo;
                }

                public String getLeagueName() {
                    return leagueName;
                }

                public void setLeagueName(String leagueName) {
                    this.leagueName = leagueName;
                }

                public String getEnLeagueName() {
                    return enLeagueName;
                }

                public void setEnLeagueName(String enLeagueName) {
                    this.enLeagueName = enLeagueName;
                }

                public String getLeagueNick() {
                    return leagueNick;
                }

                public void setLeagueNick(String leagueNick) {
                    this.leagueNick = leagueNick;
                }

                public String getEnLeagueNick() {
                    return enLeagueNick;
                }

                public void setEnLeagueNick(String enLeagueNick) {
                    this.enLeagueNick = enLeagueNick;
                }

                public String getLiveFlvUrl() {
                    return liveFlvUrl;
                }

                public void setLiveFlvUrl(String liveFlvUrl) {
                    this.liveFlvUrl = liveFlvUrl;
                }

                public String getLiveM3u8Url() {
                    return liveM3u8Url;
                }

                public void setLiveM3u8Url(String liveM3u8Url) {
                    this.liveM3u8Url = liveM3u8Url;
                }

                public String getThumb1() {
                    return thumb1;
                }

                public void setThumb1(String thumb1) {
                    this.thumb1 = thumb1;
                }

                public int getMatchId() {
                    return matchId;
                }

                public void setMatchId(int matchId) {
                    this.matchId = matchId;
                }

                public int getMatchStatus() {
                    return matchStatus;
                }

                public void setMatchStatus(int matchStatus) {
                    this.matchStatus = matchStatus;
                }

                public int getMatchStatusCode() {
                    return matchStatusCode;
                }

                public void setMatchStatusCode(int matchStatusCode) {
                    this.matchStatusCode = matchStatusCode;
                }

                public String getMatchStatusDesc() {
                    return matchStatusDesc;
                }

                public void setMatchStatusDesc(String matchStatusDesc) {
                    this.matchStatusDesc = matchStatusDesc;
                }

                public String getMatchTime() {
                    return matchTime;
                }

                public void setMatchTime(String matchTime) {
                    this.matchTime = matchTime;
                }

                public String getRound() {
                    return round;
                }

                public void setRound(String round) {
                    this.round = round;
                }

                public int getSportId() {
                    return sportId;
                }

                public void setSportId(int sportId) {
                    this.sportId = sportId;
                }

                public int getTimePlayed() {
                    return timePlayed;
                }

                public void setTimePlayed(int timePlayed) {
                    this.timePlayed = timePlayed;
                }

                public String getVid() {
                    return vid;
                }

                public void setVid(String vid) {
                    this.vid = vid;
                }

                public int getHasLive() {
                    return hasLive;
                }

                public void setHasLive(int hasLive) {
                    this.hasLive = hasLive;
                }

                public int getHasVid() {
                    return hasVid;
                }

                public void setHasVid(int hasVid) {
                    this.hasVid = hasVid;
                }

                public String getHostRank() {
                    return hostRank;
                }

                public void setHostRank(String hostRank) {
                    this.hostRank = hostRank;
                }

                public String getGuestRank() {
                    return guestRank;
                }

                public void setGuestRank(String guestRank) {
                    this.guestRank = guestRank;
                }

                public String getGroupName() {
                    return groupName;
                }

                public void setGroupName(String groupName) {
                    this.groupName = groupName;
                }

                public int getSeasonId() {
                    return seasonId;
                }

                public void setSeasonId(int seasonId) {
                    this.seasonId = seasonId;
                }

                public String getAsiaRate() {
                    return asiaRate;
                }

                public void setAsiaRate(String asiaRate) {
                    this.asiaRate = asiaRate;
                }

                public String getDxRate() {
                    return dxRate;
                }

                public void setDxRate(String dxRate) {
                    this.dxRate = dxRate;
                }

                public String getAsiaHalfRate() {
                    return asiaHalfRate;
                }

                public void setAsiaHalfRate(String asiaHalfRate) {
                    this.asiaHalfRate = asiaHalfRate;
                }

                public String getDxHalfRate() {
                    return dxHalfRate;
                }

                public void setDxHalfRate(String dxHalfRate) {
                    this.dxHalfRate = dxHalfRate;
                }

                public String getWeather() {
                    return weather;
                }

                public void setWeather(String weather) {
                    this.weather = weather;
                }

                public String getWeatherDesc() {
                    return weatherDesc;
                }

                public void setWeatherDesc(String weatherDesc) {
                    this.weatherDesc = weatherDesc;
                }

                public String getTemperature() {
                    return temperature;
                }

                public void setTemperature(String temperature) {
                    this.temperature = temperature;
                }

                public int getHostHalfScore() {
                    return hostHalfScore;
                }

                public void setHostHalfScore(int hostHalfScore) {
                    this.hostHalfScore = hostHalfScore;
                }

                public int getGuestHalfScore() {
                    return guestHalfScore;
                }

                public void setGuestHalfScore(int guestHalfScore) {
                    this.guestHalfScore = guestHalfScore;
                }

                public int getFocus() {
                    return focus;
                }

                public void setFocus(int focus) {
                    this.focus = focus;
                }

                public String getRoomId() {
                    return roomId;
                }

                public void setRoomId(String roomId) {
                    this.roomId = roomId;
                }

                public String getSide() {
                    return side;
                }

                public void setSide(String side) {
                    this.side = side;
                }

                public String getGameScore() {
                    return gameScore;
                }

                public void setGameScore(String gameScore) {
                    this.gameScore = gameScore;
                }

                public String getHostGameScore() {
                    return hostGameScore;
                }

                public void setHostGameScore(String hostGameScore) {
                    this.hostGameScore = hostGameScore;
                }

                public String getGuestGameScore() {
                    return guestGameScore;
                }

                public void setGuestGameScore(String guestGameScore) {
                    this.guestGameScore = guestGameScore;
                }

                public String getHostTeamLogo2() {
                    return hostTeamLogo2;
                }

                public void setHostTeamLogo2(String hostTeamLogo2) {
                    this.hostTeamLogo2 = hostTeamLogo2;
                }

                public String getGuestTeamLogo2() {
                    return guestTeamLogo2;
                }

                public void setGuestTeamLogo2(String guestTeamLogo2) {
                    this.guestTeamLogo2 = guestTeamLogo2;
                }

                public String getHostTeamName2() {
                    return hostTeamName2;
                }

                public void setHostTeamName2(String hostTeamName2) {
                    this.hostTeamName2 = hostTeamName2;
                }

                public String getGuestTeamName2() {
                    return guestTeamName2;
                }

                public void setGuestTeamName2(String guestTeamName2) {
                    this.guestTeamName2 = guestTeamName2;
                }

                public String getEnHostTeamName2() {
                    return enHostTeamName2;
                }

                public void setEnHostTeamName2(String enHostTeamName2) {
                    this.enHostTeamName2 = enHostTeamName2;
                }

                public String getEnGuestTeamName2() {
                    return enGuestTeamName2;
                }

                public void setEnGuestTeamName2(String enGuestTeamName2) {
                    this.enGuestTeamName2 = enGuestTeamName2;
                }

                public String getHostCurrentDisk() {
                    return hostCurrentDisk;
                }

                public void setHostCurrentDisk(String hostCurrentDisk) {
                    this.hostCurrentDisk = hostCurrentDisk;
                }

                public String getGuestCurrentDisk() {
                    return guestCurrentDisk;
                }

                public void setGuestCurrentDisk(String guestCurrentDisk) {
                    this.guestCurrentDisk = guestCurrentDisk;
                }

                public String getThumbVid() {
                    return thumbVid;
                }

                public void setThumbVid(String thumbVid) {
                    this.thumbVid = thumbVid;
                }
            }
        }
    }

    public static class TopBlocksBean {
        /**
         * id : 0
         * imgUrl :
         * jumpId :
         * jumpType : 0
         * jumpUrl :
         * title :
         */

        private String id;
        private String imgUrl;
        private String jumpId;
        private int jumpType;
        private String jumpUrl;
        private String title;
        private String sportId;

        public String getSportId() {
            return sportId;
        }

        public void setSportId(String sportId) {
            this.sportId = sportId;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getImgUrl() {
            return imgUrl;
        }

        public void setImgUrl(String imgUrl) {
            this.imgUrl = imgUrl;
        }

        public String getJumpId() {
            return jumpId;
        }

        public void setJumpId(String jumpId) {
            this.jumpId = jumpId;
        }

        public int getJumpType() {
            return jumpType;
        }

        public void setJumpType(int jumpType) {
            this.jumpType = jumpType;
        }

        public String getJumpUrl() {
            return jumpUrl;
        }

        public void setJumpUrl(String jumpUrl) {
            this.jumpUrl = jumpUrl;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }
    }
}
