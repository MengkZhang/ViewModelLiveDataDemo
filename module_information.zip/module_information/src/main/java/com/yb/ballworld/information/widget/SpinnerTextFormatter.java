package com.yb.ballworld.information.widget;

import android.text.Spannable;

/**
* Desc:
* @author ink
* created at 2019/10/7 23:04
*/
public interface SpinnerTextFormatter<T> {

    Spannable format(T item);
}
