package com.yb.ballworld.information.data;

/**
* Desc: 资讯内的图片列表及要表达的文本内容
* @author ink
* created at 2019/10/10 13:42
*/
public class ImageBean {
    //内容
    private String content;

    //图片
    private String imgUrl;

    //资讯ID（新闻、视频）
    private String newsId;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getNewsId() {
        return newsId;
    }

    public void setNewsId(String newsId) {
        this.newsId = newsId;
    }
}
