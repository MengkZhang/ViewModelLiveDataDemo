package com.yb.ballworld.information.ui.community.bean;

import java.util.List;

/**
 * Desc: 作者列表
 * Author: JS-Kylo
 * Created On: 2019/11/8 21:31
 */
public class AuthorBeanList {

    /**
     * totalCount : 1
     * pageNum : 1
     * pageSize : 10
     * totalPage : 1
     * list : [{"id":"240","userId":"1040","sorted":1,"nickname":"1111111111","headImgUrl":"http://sta.5yqz2.com/static/avatar/5f5806e5a06e730a5f9a8f5c6c002b7d.jpg","followerCount":0,"isAttention":false,"popularity":"0","postCount":0,"sex":0}]
     */

    private int totalCount;
    private int pageNum;
    private int pageSize;
    private int totalPage;
    private List<ListBean> list;

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    public static class ListBean {
        /**
         * id : 240
         * userId : 1040
         * sorted : 1
         * nickname : 1111111111
         * headImgUrl : http://sta.5yqz2.com/static/avatar/5f5806e5a06e730a5f9a8f5c6c002b7d.jpg
         * followerCount : 0
         * isAttention : false
         * popularity : 0
         * postCount : 0
         * sex : 0
         */

        private String id;
        private int userId;
        private int sorted;
        private String nickname;
        private String headImgUrl;
        private int followerCount;
        private boolean isAttention;
        private String popularity;
        private int postCount;
        private int sex;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public int getUserId() {
            return userId;
        }

        public void setUserId(int userId) {
            this.userId = userId;
        }

        public int getSorted() {
            return sorted;
        }

        public void setSorted(int sorted) {
            this.sorted = sorted;
        }

        public String getNickname() {
            return nickname;
        }

        public void setNickname(String nickname) {
            this.nickname = nickname;
        }

        public String getHeadImgUrl() {
            return headImgUrl;
        }

        public void setHeadImgUrl(String headImgUrl) {
            this.headImgUrl = headImgUrl;
        }

        public int getFollowerCount() {
            return followerCount;
        }

        public void setFollowerCount(int followerCount) {
            this.followerCount = followerCount;
        }

        public boolean isIsAttention() {
            return isAttention;
        }

        public void setIsAttention(boolean isAttention) {
            this.isAttention = isAttention;
        }

        public String getPopularity() {
            return popularity;
        }

        public void setPopularity(String popularity) {
            this.popularity = popularity;
        }

        public int getPostCount() {
            return postCount;
        }

        public void setPostCount(int postCount) {
            this.postCount = postCount;
        }

        public int getSex() {
            return sex;
        }

        public void setSex(int sex) {
            this.sex = sex;
        }
    }
}
