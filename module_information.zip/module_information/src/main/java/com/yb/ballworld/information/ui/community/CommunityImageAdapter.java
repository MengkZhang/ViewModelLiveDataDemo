package com.yb.ballworld.information.ui.community;

import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.yb.ballworld.baselib.utils.ViewUtils;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.utils.GlideLoadImgUtil;

import java.util.List;

/**
 * Desc: <>
 * Author: JS-Barder
 * Created On: 2019/11/9 17:11
 */
public class CommunityImageAdapter extends BaseQuickAdapter<String, BaseViewHolder> {

    private boolean isContent;

    public CommunityImageAdapter(List<String> urls, boolean isContent) {
        super(isContent ? R.layout.item_community_image_content : R.layout.item_community_image_commpent, urls);
        this.isContent = isContent;
    }

    public void setContent(boolean content) {
        isContent = content;
    }

    @Override
    protected void convert(BaseViewHolder helper, String item, int pos) {
        ImageView image = helper.getView(R.id.iv_image);
//        ViewGroup.LayoutParams params = image.getLayoutParams();
//        if (isContent) {
//            params.height = ViewUtils.dp2px(113);
////            image.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewUtils.dp2px(113)));
//        } else {
//            params.height = ViewUtils.dp2px(66);
////            image.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewUtils.dp2px(66)));
//        }
//        image.setLayoutParams(params);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GlideLoadImgUtil.loadImg(mContext, item, image);

        helper.addOnClickListener(R.id.iv_image);
    }
}
