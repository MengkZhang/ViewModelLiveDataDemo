package com.yb.ballworld.information.ui.home.service;

import android.annotation.SuppressLint;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.rxjava.rxlife.RxLife;
import com.yb.ballworld.baselib.data.UserInfo;
import com.yb.ballworld.common.api.BaseHttpApi;
import com.yb.ballworld.common.api.ErrorInfo;
import com.yb.ballworld.common.api.HttpApiConstant;
import com.yb.ballworld.common.api.OnError;
import com.yb.ballworld.baselib.utils.AppUtils;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.callback.OnUICallback;
import com.yb.ballworld.information.ui.community.bean.PostCollectionEntity;
import com.yb.ballworld.information.ui.home.bean.FileDataBean;
import com.yb.ballworld.information.ui.home.bean.IndexLableLetterBean;
import com.yb.ballworld.information.ui.home.bean.InfoPublishCategoryBean;
import com.yb.ballworld.information.ui.home.bean.OutSideIndexLableLetterBean;
import com.yb.ballworld.information.ui.home.bean.OutSideLableGroupBean;
import com.yb.ballworld.information.ui.home.bean.PublishArticleOrVideoReqBody;
import com.yb.ballworld.information.ui.home.bean.PublishCommentResBean;
import com.yb.ballworld.information.ui.home.bean.IndexHotEntity;
import com.yb.ballworld.information.ui.home.bean.InfoListEntity;
import com.yb.ballworld.information.ui.home.bean.TabEntity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import rxhttp.RxHttp;
import rxhttp.wrapper.entity.Response;

/**
 * Desc 资讯列表请求model
 * Date 2019/10/7
 * author mengk
 */
public class InfoHttpApi extends BaseHttpApi {

    //资讯列表(视频和非热门)
    private static final String INFO_LIST_NEWS_PAGE = "/qiutx-news/app/news/page";
    //最终tab数据
    private static final String INFO_TAB_DATA = "/qiutx-news/app/custom/lables";
    //主页热门列表(单独接口)
    private static final String INFO_HOME_HOT_DATA_APP_INDEX = "/qiutx-news/app/index/";
    //资讯列表点赞 post请求
    private static final String INFO_HOME_PRAISE_DATA = "/qiutx-news/app/news/like/%s";
    //发表评论
    private static final String INFO_SAVE_COMMENT = "/qiutx-news/app/news/savecomment";

    //帖子收藏列表
    private static final String POST_INDEX_FAVORITES = "/qiutx-news/app/post/index/favorites";

    //查询球队标签 按字母排序
    private static final String INFO_INDEX_LABLE_LIST_LETTER = "/jmfen-sport-scoreapi/lable/list/letter";

    //查询标签列表-按照类型分组返回
    private static final String INFO_INDEX_LABLE_LIST_GROUP = "/jmfen-sport-scoreapi/lable/list/group";

    //客户端发布
    private static final String INFO_INDEX_NEWS_RELEASE = "/qiutx-news/app/news/release";

    //发布时请求分类
    private static final String INFO_INDEX_NEWS_RELEASE_CATEGORY = "/qiutx-news/app/news/category";

    public InfoHttpApi() {
        RxHttp.setDebug(true);
    }

    /**
     * 发表评论/回复
     * @param newsId 资讯ID
     * @param content 评论内容
     * @param imgUrl1 图片1
     * @param imgUrl2 图片2
     * @param imgUrl3 图片3
     * @param replyId 回复ID
     * @param videoUrl 视频链接
     * @param callback 回调
     * @return
     */
    public Disposable saveComment(String id,
                                  String commentType,
                                  String createdBy,
                                  String createdDate,
                                  String lastModifiedBy,
                                  String lastModifiedDate,
                                  String likeCount,
                                  String mainCommentId,
                                  String nickName,
                                  String userId,
                                  String newsId,
                                  String content,
                                  String imgUrl1,
                                  String imgUrl2,
                                  String imgUrl3,
                                  String replyId,
                                  String videoUrl,
                                  String videoCoverUrl,
                                  LifecycleCallback<PublishCommentResBean> callback) {
        JSONObject json = new JSONObject();
        try {
            json.put("commentType", commentType);//0.评论 1.回复
            json.put("content", content);//评论内容
            json.put("createdBy", createdBy);//创建人
            json.put("createdDate", createdDate);//创建时间
            json.put("id", id);//唯一主键
            json.put("imgUrl1", imgUrl1);//图片1
            json.put("imgUrl2", imgUrl2);//图片2
            json.put("imgUrl3", imgUrl3);//图片3
            json.put("lastModifiedBy", lastModifiedBy);//最近操作人
            json.put("lastModifiedDate", lastModifiedDate);//更新时间
            json.put("likeCount", likeCount);//点赞数
            json.put("mainCommentId", mainCommentId);//主评论ID
            json.put("newsId", newsId);//评论的资讯ID
            json.put("nickName", nickName);//用户昵称
            json.put("replyId", replyId);//回复ID
            json.put("userId", userId);//评论用户ID
            json.put("videoUrl", videoUrl);//视频链接
            json.put("videoCoverUrl", videoCoverUrl);//视频封面
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return getInfoPraiseApi(RxHttp.postJson(INFO_SAVE_COMMENT))
                .setJsonParams(json.toString())
                .asResponse(PublishCommentResBean.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error ->
                        callback.onFailed(error.getErrorCode(), error.getErrorMsg()));

    }

    /**
     * 上传文件
     * @param file
     * @param type 文件类型,1=图片|2=视频
     * @param callback
     * @return
     */
    public Disposable uploadFile(File file, String type,int isNeedWater,LifecycleCallback<FileDataBean> callback) {
        String url = getUploadBaseUrl() + HttpApiConstant.UPLOAD;
        return getUploadApi(RxHttp.postForm(url))
                .addFile("file", file)
                .add("uid", LoginOrdinaryUtils.INSTANCE.getUid())
                .add("type", type)
                .add("isNeedWater", isNeedWater)
                .asResponse(FileDataBean.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(new Consumer<FileDataBean>() {
                    @Override
                    public void accept(FileDataBean data) throws Exception {
                        callback.onSuccess(data);
                    }
                }, new OnError() {
                    @Override
                    public void onError(ErrorInfo error) throws Exception {
                        callback.onFailed(error.getErrorCode(), error.getErrorMsg());
                    }
                });
    }

    /**
     * 请求点赞
     *
     * @param newsId
     * @param callback
     */
    @SuppressLint("CheckResult")
    public void praiseInfo(String newsId, OnUICallback<Response> callback) {
        getInfoPraiseApi(RxHttp.postForm(String.format(INFO_HOME_PRAISE_DATA, newsId)))
                .asObject(Response.class)
                .subscribe(data -> callback.onSuccess(data), (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));

    }

    /**
     * 获取首页热门列表
     *
     * @param callback
     */
    @SuppressLint("CheckResult")
    public void getIndexHotData(int labelType, String categoryId, String mediaType, String sportType, int pageNum, int pageSize, LifecycleCallback<IndexHotEntity> callback) {

        switch (labelType) {
            case 0://如果是0，则点击该标签时去调用 /qiutx-news/app/news/page
                getApiNewsPage(categoryId, mediaType, sportType, pageNum, pageSize, callback);
                break;
            case 2://如果是2，则调用app首页接口
                getApiHomeHotAppIndex(categoryId, mediaType, sportType, pageNum, pageSize, callback);
                break;
            default:
                getApiNewsPage(categoryId, mediaType, sportType, pageNum, pageSize, callback);
                break;
        }
    }

    /**
     * 获取首页热门列表
     *
     * @param categoryId
     * @param mediaType
     * @param sportType
     * @param pageNum
     * @param pageSize
     * @param callback
     */
    private void getApiHomeHotAppIndex(String categoryId, String mediaType, String sportType, int pageNum, int pageSize, LifecycleCallback<IndexHotEntity> callback) {
        getInfoPraiseApi(RxHttp.get(INFO_HOME_HOT_DATA_APP_INDEX))
                .add("pageNum", pageNum)
                .add("pageSize", pageSize)
                .add("categoryId", categoryId)
                .add("mediaType", mediaType)
                .add("sportType", sportType)
                .asResponse(IndexHotEntity.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 获取新闻列表（最新修改后的）
     *
     * @param categoryId
     * @param mediaType
     * @param sportType
     * @param pageNum
     * @param pageSize
     * @param callback
     */
    private void getApiNewsPage(String categoryId, String mediaType, String sportType, int pageNum, int pageSize, LifecycleCallback<IndexHotEntity> callback) {
        getInfoPraiseApi(RxHttp.get(INFO_LIST_NEWS_PAGE))
                .add("pageNum", pageNum)
                .add("pageSize", pageSize)
                .add("mediaType", mediaType)
                .add("categoryId", categoryId)
                .add("sportType", sportType)
                .asResponse(String.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(new Consumer<String>() {
                    @Override
                    public void accept(String s) throws Exception {
                        try {
                            IndexHotEntity indexHotEntity = new IndexHotEntity();
                            Gson gson = new Gson();
                            IndexHotEntity.NewsBean infoListEntity = gson.fromJson(s, IndexHotEntity.NewsBean.class);
                            indexHotEntity.setNews(infoListEntity);

//                            testShowType(indexHotEntity.getNews());

                            callback.onSuccess(indexHotEntity);

                        } catch (Exception e) {
                            e.printStackTrace();
                            callback.onFailed(0, "转换异常");
                        }
                    }
                }, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 设置ShowType类型 用于测试
     * @param news
     */
    private void testShowType(IndexHotEntity.NewsBean news) {
        List<IndexHotEntity.NewsBean.ListBean> listBeanList = news.getList();
        for (int i = 0; i < listBeanList.size(); i++) {
            IndexHotEntity.NewsBean.ListBean listBean = listBeanList.get(i);
            listBean.setShowType(i);
        }
    }

    /**
     * 获取tab数据
     *
     * @param callback 回调
     */
    @SuppressLint("CheckResult")
    public void getInfoTabData(LifecycleCallback<TabEntity> callback) {
        getInfoPraiseApi(RxHttp.get(INFO_TAB_DATA))
                .asResponse(TabEntity.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }
    /**
     * 请求视频和资讯列表
     *
     * 新绑定请求生命周期 废弃以前的getNewsList()方法
     *
     * @param pageNum   当前页数
     * @param pageSize  每页的大小
     * @param mediaType 资讯类型 0 新闻 1 视频
     * @param callback  回调
     * @return 返回值
     */
    public Disposable getNewsListData(String categoryId,String sportType,int pageNum, int pageSize, String mediaType, LifecycleCallback<InfoListEntity> callback) {
        return getInfoPraiseApi(RxHttp.get(INFO_LIST_NEWS_PAGE))
                .add("pageNum", pageNum)
                .add("pageSize", pageSize)
                .add("mediaType", mediaType)
                .add("categoryId", categoryId)
                .add("sportType", sportType)
                .asResponse(InfoListEntity.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 请求视频和资讯列表
     *
     * @param pageNum   当前页数
     * @param pageSize  每页的大小
     * @param mediaType 资讯类型 0 新闻 1 视频
     * @param callback  回调
     * @return 返回值
     */
    public Disposable getNewsList(String categoryId,String sportType,int pageNum, int pageSize, String mediaType, LifecycleCallback<InfoListEntity> callback) {
        return getInfoApi(RxHttp.get(INFO_LIST_NEWS_PAGE))
                .add("pageNum", pageNum)
                .add("pageSize", pageSize)
                .add("mediaType", mediaType)
                .add("categoryId", categoryId)
                .add("sportType", sportType)
                .asResponse(InfoListEntity.class)
                .subscribe(new Consumer<InfoListEntity>() {
                    @Override
                    public void accept(InfoListEntity data) throws Exception {
                        callback.onSuccess(data);
                    }
                }, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }


    /***
     * 收藏-帖子列表数据
     * @return
     */
    public Disposable getIndexCollectionList(int pageNum, int pageSize, LifecycleCallback<PostCollectionEntity> callback) {
        return getInfoPraiseApi(RxHttp.get(POST_INDEX_FAVORITES))
                .add("pageNum", pageNum)
                .add("pageSize", pageSize)
                .asResponse(PostCollectionEntity.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 查询标签 按照字母排序
     * @param type 默认查询全部类型。1球员，2俱乐部球队，3国家队，4赛事
     * @param searchKey 模糊匹配
     * @param callback
     * @return
     */
    public Disposable getLableListLetter(String type, String searchKey, LifecycleCallback<OutSideIndexLableLetterBean> callback) {
        return getInfoApi((RxHttp.get(INFO_INDEX_LABLE_LIST_LETTER)))
                .add("type",type)
                .add("searchKey",searchKey)
                .asResponse(OutSideIndexLableLetterBean.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 标签-查询标签列表-按照类型分组返回
     * @param type 默认查询全部类型。1球员，2俱乐部球队，3国家队，4赛事
     * @param searchKey 模糊匹配
     * @param callback
     * @return
     */
    public Disposable getLableListGroup(String type, String searchKey, LifecycleCallback<OutSideLableGroupBean> callback) {
        return getInfoApi((RxHttp.get(INFO_INDEX_LABLE_LIST_GROUP)))
                .add("type",type)
                .add("searchKey",searchKey)
                .asResponse(OutSideLableGroupBean.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 			"lable": "",
     * 			"newId": "",
     * 			"picUrl": "",
     * 			"referId": "",
     * 			"type": 0
     * 客户端发布
     * @param body
     * @param callback
     * @return
     */
    public Disposable publishArticleOrVideo(PublishArticleOrVideoReqBody body,LifecycleCallback<Response> callback) {
        JSONObject json = new JSONObject();
        ArrayList<IndexLableLetterBean> lableBeanList = body.getLabels();
        try {
            //组装labels数组
            JSONArray labelsArray = new JSONArray();
            for (IndexLableLetterBean lableBean : lableBeanList) {
                JSONObject labelJs = new JSONObject();
                labelJs.put("lable",lableBean.getLable());
                labelJs.put("newsId","");
                labelJs.put("picUrl",lableBean.getPicUrl());
                labelJs.put("referId",lableBean.getReferId());
                labelJs.put("type",lableBean.getType());
                labelsArray.put(labelJs);
            }

            json.put("categoryId", body.getCategoryId());//分类ID
            json.put("content", body.getContent());//内容文字
            json.put("imgUrl", body.getImgUrl());//图片地址
            json.put("keywords", body.getKeywords());//关键词
            json.put("labels", labelsArray);//标签的ID地址，逗号分隔
            json.put("mediaType", body.getMediaType());//0.新闻 1.视频
            json.put("pageViews", body.getPageViews());//浏览量
            json.put("playUrl", body.getPlayUrl());//播放地址
            json.put("preview", body.getPreview());//预览文字
            json.put("releaseSource", body.getReleaseSource());//发布来源
            json.put("sportType", body.getSportType());//资讯类别 1.足球 2.篮球
            json.put("title", body.getTitle());//标题
            json.put("userId", String.valueOf(LoginOrdinaryUtils.INSTANCE.getUid()));//用户Id


        } catch (JSONException e) {
            e.printStackTrace();
        }
        return getInfoApi(RxHttp.postJson(INFO_INDEX_NEWS_RELEASE))
                .setJsonParams(json.toString())
                .asObject(Response.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error ->
                        callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 请求分类
     * @param callback
     * @return
     */
    public Disposable getCategoryList(LifecycleCallback<String> callback) {
        return getInfoApi(RxHttp.get(INFO_INDEX_NEWS_RELEASE_CATEGORY))
                .asResponse(String.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 获取默认的 Service
     * <p>
     * 需要子类绑定URL
     */
    private RxHttp getInfoApi(RxHttp rxHttp) {
        String token = LoginOrdinaryUtils.INSTANCE.getToken();
        long uid = LoginOrdinaryUtils.INSTANCE.getUid();
        String uidOrDeviceId;

        JSONObject json = new JSONObject();
        try {
            json.put("uid", uid);
            uidOrDeviceId = json.toString();
        } catch (JSONException e) {
            e.printStackTrace();
            uidOrDeviceId = getDeviceId();
        }

        if (TextUtils.isEmpty(token)) {
            UserInfo userInfo = LoginOrdinaryUtils.INSTANCE.getUserInfo();
            if (userInfo != null) {
                token = userInfo.getToken();
            }
        }
        if (token != null && !token.isEmpty()) {
            rxHttp.addHeader("Authorization", "Bearer " + token);
        } else {
            rxHttp.addHeader("Authorization", "Basic YXBwOmFwcA==");
        }
        rxHttp.addHeader("channel", getAppChannelValue());
        rxHttp.addHeader("version", AppUtils.INSTANCE.getVersionName());
        rxHttp.addHeader("client-type", "android"); // h5, web, android,ios
        rxHttp.addHeader("deviceId", getDeviceId()); //资讯带设备id
        rxHttp.addHeader("x-user-header", uidOrDeviceId); //资讯带uid
        return rxHttp;
    }

    /**
     * 点赞的api
     * todo 测试用的
     * @param rxHttp
     * @return
     */
    private RxHttp getInfoPraiseApi1(RxHttp rxHttp) {
        String token = LoginOrdinaryUtils.INSTANCE.getToken();
        long uid = LoginOrdinaryUtils.INSTANCE.getUid();
        String uidOrDeviceId = "";
        JSONObject json = new JSONObject();
        if (uid > 0) {//用户id
            try {
                json.put("uid", 999);
                uidOrDeviceId = json.toString();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        if (TextUtils.isEmpty(token)) {
            UserInfo userInfo = LoginOrdinaryUtils.INSTANCE.getUserInfo();
            if (userInfo != null) {
                token = userInfo.getToken();
            }
        }
        if (token != null && !token.isEmpty()) {
            rxHttp.addHeader("Authorization", "Bearer " + token);
        } else {
            rxHttp.addHeader("Authorization", "Basic YXBwOmFwcA==");
        }
        rxHttp.addHeader("channel", getAppChannelValue());
        rxHttp.addHeader("version", AppUtils.INSTANCE.getVersionName());
        rxHttp.addHeader("client-type", "android"); // h5, web, android,ios
        rxHttp.addHeader("deviceId", getDeviceId()); //资讯带设备id
        rxHttp.addHeader("x-user-header", uidOrDeviceId); //资讯带uid
        return rxHttp;
    }

    /**
     * 点赞的api
     * @param rxHttp
     * @return
     */
    private RxHttp getInfoPraiseApi(RxHttp rxHttp) {
        String token = LoginOrdinaryUtils.INSTANCE.getToken();
        long uid = LoginOrdinaryUtils.INSTANCE.getUid();
        String uidOrDeviceId = "";
        JSONObject json = new JSONObject();
        if (uid > 0) {//用户id
            try {
                json.put("uid", uid);
                uidOrDeviceId = json.toString();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        if (TextUtils.isEmpty(token)) {
            UserInfo userInfo = LoginOrdinaryUtils.INSTANCE.getUserInfo();
            if (userInfo != null) {
                token = userInfo.getToken();
            }
        }
        if (token != null && !token.isEmpty()) {
            rxHttp.addHeader("Authorization", "Bearer " + token);
        } else {
            rxHttp.addHeader("Authorization", "Basic YXBwOmFwcA==");
        }
        rxHttp.addHeader("channel", getAppChannelValue());
        rxHttp.addHeader("version", AppUtils.INSTANCE.getVersionName());
        rxHttp.addHeader("client-type", "android"); // h5, web, android,ios
        rxHttp.addHeader("deviceId", getDeviceId()); //资讯带设备id
        rxHttp.addHeader("x-user-header", uidOrDeviceId); //资讯带uid
        return rxHttp;
    }

    /**
     * 获取设备id
     *
     * @return
     */
    public static String getDeviceId() {
        String deviceId = AppUtils.INSTANCE.getDeviceId();
        return deviceId;
    }

}
