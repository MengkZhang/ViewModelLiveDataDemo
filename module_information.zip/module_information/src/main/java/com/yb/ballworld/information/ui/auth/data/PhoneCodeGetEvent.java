package com.yb.ballworld.information.ui.auth.data;

/**
 * @author Gethin
 * @time 2019/11/20 17:15
 */

public class PhoneCodeGetEvent {
    public static final int SUCCESS = 0;
    public static final int FAILURE = -1;

    private int state;
    private int errCode;
    private String errMsg;

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public int getErrCode() {
        return errCode;
    }

    public void setErrCode(int errCode) {
        this.errCode = errCode;
    }

    public String getErrMsg() {
        return errMsg;
    }

    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }

    public PhoneCodeGetEvent(int state) {
        this.state = state;
    }
}
