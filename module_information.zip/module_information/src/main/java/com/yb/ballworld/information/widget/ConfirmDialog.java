package com.yb.ballworld.information.widget;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.yb.ballworld.baselib.R;
import com.yb.ballworld.baselib.utils.BlurScreenUtils;


public class ConfirmDialog extends Dialog implements View.OnClickListener {

    private Context mContext;
    private String content;
    private SpannableString spannableContent;
    private OnCloseListener listener;
    private String positiveName;
    private String negativeName;
    private String title;
    private int btnCancelColor = 0;//R.color.color_ff333333;
    private int btnSubmitColor = 0;//R.color.color_ff333333;
    private boolean titleVisible = true;
    private BlurScreenUtils blurScreenUtils;
    private int layoutId = 0;

    public ConfirmDialog(Context context) {
        super(context);
        this.mContext = context;
    }

    public ConfirmDialog(Context context, String content) {
        super(context, R.style.dialogBlack);
        this.mContext = context;
        this.content = content;
    }

    public ConfirmDialog(Context context, String content, OnCloseListener listener) {
        super(context, R.style.dialogBlack);
        this.mContext = context;
        this.content = content;
        this.listener = listener;
    }

    public ConfirmDialog(Context context,String title, String content, OnCloseListener listener) {
        super(context, R.style.dialogBlack);
        this.mContext = context;
        this.title = title;
        this.content = content;
        this.listener = listener;
    }

    public ConfirmDialog(Context context,String title, String content, int theme,OnCloseListener listener) {
        super(context, theme);
        this.mContext = context;
        this.title = title;
        this.content = content;
        this.listener = listener;
    }

    public ConfirmDialog(Context context, SpannableString content, OnCloseListener listener) {
        super(context, R.style.dialogBlack);
        this.mContext = context;
        this.spannableContent = content;
        this.listener = listener;
    }

    public ConfirmDialog(Context context, String content, int style, OnCloseListener listener) {
        super(context, style);
        this.mContext = context;
        this.content = content;
        this.listener = listener;
    }

    public ConfirmDialog(Context context, String content, int btnCancelColor, int btnSubmitColor, OnCloseListener listener) {
        super(context, R.style.dialogBlack);
        this.mContext = context;
        this.content = content;
        this.listener = listener;
        this.btnCancelColor = btnCancelColor;
        this.btnSubmitColor = btnSubmitColor;
    }

    protected ConfirmDialog(Context context, boolean cancelable, OnCancelListener cancelListener) {
        super(context, cancelable, cancelListener);
        this.mContext = context;
    }

    public ConfirmDialog setTitle(String title) {
        this.title = title;
        return this;
    }

    public ConfirmDialog setLayout(int layoutId) {
        this.layoutId = layoutId;
        return this;
    }

    public ConfirmDialog setPositiveButton(String name) {
        this.positiveName = name;
        return this;
    }

    public ConfirmDialog setNegativeButton(String name) {
        this.negativeName = name;
        return this;
    }

    /**
     * 设置是否显示标题栏
     */
    public ConfirmDialog setTitleVisible(boolean visible) {
        this.titleVisible = visible;
        return this;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layoutId == 0 ? R.layout.dialog_attention_confirm : layoutId);
        setCanceledOnTouchOutside(false);
        initView();
    }

    private void initView() {
        TextView contentTxt = findViewById(R.id.contentTv);
        TextView titleTxt = findViewById(R.id.titleTv);
        TextView submitTxt = findViewById(R.id.submitTv);
        TextView cancelTxt = findViewById(R.id.cancelTv);
        submitTxt.setOnClickListener(this);
        cancelTxt.setOnClickListener(this);
        if (titleVisible) {
            titleTxt.setVisibility(View.VISIBLE);
        } else {
            titleTxt.setVisibility(View.GONE);
        }
        if (!TextUtils.isEmpty(spannableContent))
            contentTxt.setText(spannableContent);
        else
            contentTxt.setText(content);
        if (!TextUtils.isEmpty(positiveName)) {
            submitTxt.setText(positiveName);
        }

        if (!TextUtils.isEmpty(negativeName)) {
            cancelTxt.setText(negativeName);
        }

        if (!TextUtils.isEmpty(title)) {
            titleTxt.setText(title);
        }
        setCanceledOnTouchOutside(true);
        if(btnCancelColor>0) {
            cancelTxt.setTextColor(mContext.getResources().getColor(btnCancelColor));
        }
        if(btnSubmitColor>0) {
            submitTxt.setTextColor(mContext.getResources().getColor(btnSubmitColor));
        }

        setOnDismissListener(dialog ->{if(blurScreenUtils!=null) {
            blurScreenUtils.remove();
        }
        });
    }

    /**
     * 背景模糊对话框显示
     */
    public void show(Activity activity) {
        blurScreenUtils = new BlurScreenUtils(activity);
        blurScreenUtils.showPopBlur();
        super.show();
    }

    /**
     * 背景模糊对话框显示
     */
    public void showNoBlur(Activity activity) {
        super.show();
    }

    @Override
    public void onClick(View v) {
        int i = v.getId();
        if (i == R.id.cancelTv) {
            if (listener != null) {
                listener.onClick(this, false);
            }
            this.dismiss();

        } else if (i == R.id.submitTv) {
            if (listener != null) {
                listener.onClick(this, true);
            }
            this.dismiss();
        }
    }

    public interface OnCloseListener {
        void onClick(Dialog dialog, boolean confirm);
    }
}
