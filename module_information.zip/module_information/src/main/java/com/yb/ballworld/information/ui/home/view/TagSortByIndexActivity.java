package com.yb.ballworld.information.ui.home.view;

import android.content.Intent;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.gyf.immersionbar.ImmersionBar;
import com.yb.ballworld.baselib.widget.placeholder.HomePlaceholderView;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.common.base.mvp.BaseMvpActivity;
import com.yb.ballworld.common.livedata.LiveDataObserver;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.adapter.TagSortByIndexInSideLabelLetterAdapter;
import com.yb.ballworld.information.ui.home.adapter.TagSortByIndexOutSideLabelLetterAdapter;
import com.yb.ballworld.information.ui.home.bean.OutSideIndexLableLetterBean;
import com.yb.ballworld.information.ui.home.bean.OutSideIndexListLableLetterBean;
import com.yb.ballworld.information.ui.home.presenter.TagSortByIndexPresenter;
import com.yb.ballworld.information.ui.home.utils.IndexStringUtil;
import com.yb.ballworld.information.ui.home.utils.StatusBarHeightUtil;
import com.yb.ballworld.information.ui.home.widget.BfSideIndexBar;

import java.util.ArrayList;
import java.util.List;


/**
 * Desc 球队标签库 按照字母排序 activity
 * Date 2019/11/6
 * author mengk
 */
public class TagSortByIndexActivity extends BaseMvpActivity<TagSortByIndexPresenter> {

    private TextView tvTitle;
    private RelativeLayout rlRightSure;
    //加载状态缺省图
    private HomePlaceholderView placeholder;
    private BfSideIndexBar bfSideIndexBar;
    private RecyclerView rvOutSideList;
    private TextView tvSideBarOverlay;
    private LinearLayoutManager layoutManager;
    private TagSortByIndexOutSideLabelLetterAdapter outSideLebelLetterAdapter;
    private ArrayList<String> ids;
    private List<OutSideIndexListLableLetterBean> labelLetterOutSideList = new ArrayList<>();
    private String type;
    private int position;

    /**
     * 初始化沉浸式
     */
    protected void initImmersionBar() {
        // 设置共同沉浸式样式
        ImmersionBar.with(this).statusBarDarkFont(true, 0.2f).statusBarColor(getStatusBarColor()).navigationBarColor(R.color.white).init();
    }

    @Override
    public void initPresenter() {
        mPresenter.setVM(this);
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_tag_index;
    }

    @Override
    protected void initView() {
        StatusBarHeightUtil.getStatusBarHeight(F(R.id.status_bar_new_tag),getStatusHeight());
        placeholder = F(R.id.placeholder_lable_letter);
        F(R.id.rl_left_back).setOnClickListener(v -> finish());
        tvTitle = F(R.id.title_bar_title);
        bfSideIndexBar = F(R.id.bfSideIndexBar);
        rlRightSure = F(R.id.rl_right_sure);
        rvOutSideList = F(R.id.rv_outside_list);
        tvSideBarOverlay = F(R.id.tvSideBarOverlay);
        layoutManager = new LinearLayoutManager(this);
        rvOutSideList.setLayoutManager(layoutManager);
        outSideLebelLetterAdapter = new TagSortByIndexOutSideLabelLetterAdapter(labelLetterOutSideList);
        rvOutSideList.setAdapter(outSideLebelLetterAdapter);
        getIdsFromUp();
    }

    private void getIdsFromUp() {
        Intent intent = getIntent();
        if (intent == null) return;
        ids = mPresenter.getIds(intent);
        type = mPresenter.getType(intent);
        position = mPresenter.getPosition(intent);
        tvTitle.setText(mPresenter.getTitleFromUp(position));
    }


    /**
     * 初始化重新加载数据
     */
    private void initReLoadEvent() {
        placeholder.setPageErrorRetryListener(v -> mPresenter.getLableLetterListData(type,""));
    }

    @Override
    public PlaceholderView getPlaceholderView() {
        return placeholder;
    }

    @Override
    protected void bindEvent() {
        //初始化重新加载数据
        initReLoadEvent();

        //绑定列表和BfSideIndexBar事件
        bindRvSideIndexBar();

        choiceEvent();

        //确认按钮
        sureBtn();

        callBackGetLableLetterListData();

        callBackRequestLoading();
    }

    private void callBackRequestLoading() {
        mPresenter.getReqLoading().observe(this, aBoolean -> {
            if (aBoolean) {
                showPageLoading();
            }
        });
    }


    /**
     * 获取标签回调
     */
    private void callBackGetLableLetterListData() {
        mPresenter.getmOutSideIndexLableLetterBean().observe(this, new LiveDataObserver<OutSideIndexLableLetterBean>() {
            @Override
            public void onSuccess(OutSideIndexLableLetterBean data) {
                hidePageLoading();
                List<OutSideIndexListLableLetterBean> outSideListLableLetterData = IndexStringUtil.getOutSideListLableLetterData(data);
                if (outSideListLableLetterData != null && outSideListLableLetterData.size() != 0) {

                    showPageContent();

                    //绑定adapter数据 并筛选上个页面选中的数据
                    mPresenter.adapterListAddAllDataAndFilter(labelLetterOutSideList,outSideListLableLetterData,ids);
                    outSideLebelLetterAdapter.notifyDataSetChanged();

                    //绑定字母排序的数据
                    bfSideIndexBar.setIndexItems(mPresenter.getIndexListData(labelLetterOutSideList));
                    bfSideIndexBar.postInvalidate();

                } else {//letterData为空
                    showPageEmpty(getResources().getString(R.string.info_place_holder_no_data));
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                hidePageLoading();
                showPageError(getResources().getString(R.string.info_place_holder_no_net));
            }
        });
    }

    /**
     * 确认
     */
    private void sureBtn() {

        rlRightSure.setOnClickListener(v -> {
            mPresenter.clickSureBtnAndHandleData(TagSortByIndexActivity.this,labelLetterOutSideList,position);
            finish();
        });

    }

    /**
     * 多选事件处理
     */
    private void choiceEvent() {
        if (outSideLebelLetterAdapter == null) return;
        outSideLebelLetterAdapter.setOnClickTagListener((view, position, bean) -> {
            if (bean.isCheck()) {
                bean.setCheck(false);
            } else {
                bean.setCheck(true);
            }

            TagSortByIndexInSideLabelLetterAdapter tagSortByIndexInSideAdapter = outSideLebelLetterAdapter.getTagSortByIndexInSideAdapter();
            if (tagSortByIndexInSideAdapter == null) return;
            tagSortByIndexInSideAdapter.changeCheck(TagSortByIndexActivity.this,view,bean);
        });
    }


    /**
     * 绑定列表和BfSideIndexBar事件
     */
    private void bindRvSideIndexBar() {
        bfSideIndexBar.setOverlayTextView(tvSideBarOverlay).setOnIndexChangedListener((index, position) -> layoutManager.scrollToPositionWithOffset(position,0));

        rvOutSideList.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                bfSideIndexBar.setScrollPosition(layoutManager.findFirstVisibleItemPosition());
            }
        });
    }

    @Override
    protected void initData() {
        //请求数据
        mPresenter.getLableLetterListData(type,"");
    }


    @Override
    protected void processClick(View view) {

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

}
