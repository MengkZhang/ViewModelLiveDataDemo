package com.yb.ballworld.information.widget;

import android.content.Context;
import android.os.Handler;
import android.os.SystemClock;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatTextView;

import com.yb.ballworld.information.ui.detail.OnTimeRefreshHandler;


public class TimerTextView extends AppCompatTextView {

    private Runnable mTicker;
    private Handler mHandler;
    private boolean mTickerStopped = false;//是否定时1秒刷新
    private OnTimeRefreshListener onTimeRefreshListener;

    public OnTimeRefreshListener getOnTimeRefreshListener() {
        return onTimeRefreshListener;
    }

    public void setOnTimeRefreshListener(OnTimeRefreshListener onTimeRefreshListener) {
        this.onTimeRefreshListener = onTimeRefreshListener;
    }

    public TimerTextView(Context context) {
        super(context);
    }

    public TimerTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }


    private long time;
    public void setDefiniteTime(long time){
        this.time=time;
    }

    protected void flicker() {
        mHandler = new Handler();

        /**
         * requests a tick on the next hard-second boundary
         */
        mTicker = () -> {
            if (mTickerStopped || time <= 0) {
                return;
            }
            if(getOnTimeRefreshListener()!=null) {
                setText(getOnTimeRefreshListener().onTimeRefresh(time));
            }else{
                setOnTimeRefreshListener(new OnTimeRefreshHandler());
                setText(getOnTimeRefreshListener().onTimeRefresh(time));
            }
            invalidate();
            long now = SystemClock.uptimeMillis();
            long next = now + (10000 - now % 10000);
            mHandler.postAtTime(mTicker, next);
        };
        mTicker.run();
    }

    @Override
    protected void onAttachedToWindow() {
        mTickerStopped = false;
        super.onAttachedToWindow();
        flicker();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        mTickerStopped = true;
    }

    public static interface OnTimeRefreshListener{
        String onTimeRefresh(long time);
    }

}
