package com.yb.ballworld.information.ui.home.view;

import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bfw.util.ToastUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshFooter;
import com.scwang.smartrefresh.layout.api.RefreshHeader;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.base.fragment.BasePageFragment;
import com.yb.ballworld.baselib.base.recycler.header.PlayBallHeader;
import com.yb.ballworld.baselib.base.recycler.header.RecyclerClassicsFooter;
import com.yb.ballworld.baselib.data.UserInfo;
import com.yb.ballworld.baselib.entity.LogoutEvent;
import com.yb.ballworld.baselib.utils.AppUtils;
import com.yb.ballworld.baselib.utils.JsonUtils;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.common.im.ImPushParser;
import com.yb.ballworld.common.im.entity.BaseballScore;
import com.yb.ballworld.common.im.entity.PushScore;
import com.yb.ballworld.common.im.entity.PushStatus;
import com.yb.ballworld.common.im.entity.QttName;
import com.yb.ballworld.common.im.entity.TennisballScore;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.adapter.InfoAdapterHelper;
import com.yb.ballworld.information.ui.home.adapter.InfoHotAdapter;
import com.yb.ballworld.information.ui.home.adapter.InfoPraiseAdapterHelper;
import com.yb.ballworld.information.ui.home.bean.HomeIndexBannerBean;
import com.yb.ballworld.information.ui.home.bean.HomeIndexHotRunBean;
import com.yb.ballworld.information.ui.home.bean.IndexHotEntity;
import com.yb.ballworld.information.ui.home.constant.FailStateConstant;
import com.yb.ballworld.information.ui.home.constant.InfoSpecialPushParams;
import com.yb.ballworld.information.ui.home.constant.LoadMoreType;
import com.yb.ballworld.information.ui.home.presenter.InfoIndexHotContract;
import com.yb.ballworld.information.ui.home.presenter.InfoIndexHotPresenter;
import com.yb.ballworld.information.ui.home.presenter.InfoIndexHotSupportPresenter;
import com.yb.ballworld.information.ui.home.presenter.InfoPraisePresenter;
import com.yb.ballworld.information.ui.home.utils.JZReleaseUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.home.widget.PlaceholderViewInfo;
import com.yb.ballworld.information.ui.home.widget.bfFab.FabAlphaAnimate;
import com.yb.ballworld.information.ui.home.widget.bfFab.FabAttributes;
import com.yb.ballworld.information.ui.home.widget.bfFab.OnFabClickListener;
import com.yb.ballworld.information.ui.home.widget.bfFab.SuspensionFab;
import com.yb.ballworld.information.utils.CommondUtil;
import com.yb.ballworld.information.widget.GoodView;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc 资讯热门fragment
 * Date 2019/10/7
 * author mengk
 */
public class InformationIndexHotFragment extends BasePageFragment implements InfoIndexHotContract.IInfoIndexHotView {

    //fragment传递参数的key
    private static final String LABELTYPE = "LABELTYPE";
    private static final String CATEGORYID = "CATEGORYID";
    private static final String MEDIATYPE = "MEDIATYPE";
    private static final String SPORTTYPE = "SPORTTYPE";

    //数据
    private List<IndexHotEntity.NewsBean.ListBean> dataList = new ArrayList<>();
    //adapter
    private InfoHotAdapter adapter;

    //刷新控件
    private SmartRefreshLayout smartRefreshLayout;
    //列表控件
    private RecyclerView recyclerView;
    //缺省图状态控件
    private PlaceholderViewInfo placeholder;
    //layoutManager
    private LinearLayoutManager layoutManager;
    //presenter
//    private InfoIndexHotPresenter presenter;
    private InfoIndexHotSupportPresenter presenter;
    //banner数组
    private List<HomeIndexBannerBean> mHomeIndexBannerBeanList = new ArrayList<>();
    //子弹推数组
    private List<HomeIndexHotRunBean> mHomeIndexHotRunBeanList = new ArrayList<>();
    //专栏数组
    private IndexHotEntity.SpecialBlocksBean mSpecialBlocksBean;
    //置顶数组
    private List<IndexHotEntity.NewsTopBlocksBean> mHomeIndexTopBeanList = new ArrayList<>();
    private GoodView goodView;
    //首页热门的线
    private View viewLineHomeHot;
    private int labelType;
    private String categoryId;
    private String mediaType;
    private String sportType;
//    private SkeletonScreen skeletonScreen;

    public static InformationIndexHotFragment newInstance(int labelType, String categoryId, String mediaType, String sportType) {
        InformationIndexHotFragment fragment = new InformationIndexHotFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(InformationIndexHotFragment.LABELTYPE, labelType);
        bundle.putString(InformationIndexHotFragment.CATEGORYID, categoryId);
        bundle.putString(InformationIndexHotFragment.MEDIATYPE, mediaType);
        bundle.putString(InformationIndexHotFragment.SPORTTYPE, sportType);
        fragment.setArguments(bundle);
        return fragment;
    }


    @Override
    protected void initView() {
        super.initView();
        initArguments();
        initViews();
    }

    @Override
    protected void initData() {
        super.initData();
        //初始化presenter
//        presenter = new InfoIndexHotPresenter(labelType,categoryId,mediaType,sportType);
        presenter = new InfoIndexHotSupportPresenter(labelType, categoryId, mediaType, sportType);
        presenter.attachView(this);
        presenter.loadData(1);
    }

    @Override
    public void onPause() {
        super.onPause();
        JZReleaseUtil.releaseAllVideos();
    }

    /**
     * 初始化参数
     */
    private void initArguments() {
        Bundle bundle = getArguments();
        if (bundle == null) return;
        labelType = bundle.getInt(InformationIndexHotFragment.LABELTYPE);
        categoryId = bundle.getString(InformationIndexHotFragment.CATEGORYID);
        mediaType = bundle.getString(InformationIndexHotFragment.MEDIATYPE);
        sportType = bundle.getString(InformationIndexHotFragment.SPORTTYPE);
    }

    private void initViews() {
        goodView = new GoodView(getPageActivity());
        goodView.setText("+1");
        goodView.setImage(getResources().getDrawable(R.drawable.icon_priase_info));

        placeholder = findView(R.id.placeholder);
        recyclerView = findView(R.id.recyclerView);
        smartRefreshLayout = findView(R.id.smartRefreshLayout);
        smartRefreshLayout.setRefreshHeader(getRefreshHeader());
        smartRefreshLayout.setRefreshFooter(getRefreshFooter());
        layoutManager = new LinearLayoutManager(getPageActivity());
        recyclerView.setLayoutManager(layoutManager);
        adapter = new InfoHotAdapter(dataList);
        recyclerView.setAdapter(adapter);

        findView(R.id.view_line_info_under).setVisibility(View.GONE);
        viewLineHomeHot = findView(R.id.view_line_info);
        viewLineHomeHot.setVisibility(View.GONE);

    }


    @Override
    protected void initEvent() {
        super.initEvent();
        initRefreshLoadMoreEvent();
        initReLoadEvent();
        initScrollEvent();
        initObserverEvent();
        initAdapterEvent();
    }

    /**
     * 初始化adapter事件
     */
    private void initAdapterEvent() {
        //点赞事件
        InfoPraiseAdapterHelper.initPraiseHot(adapter, new InfoPraisePresenter(getPageActivity()), goodView);
    }

    /**
     * 接受停止正在播放的视频事件
     */
    private void initObserverEvent() {
        //接收停止视频
        LiveEventBus.get()
                .with(LiveEventBusKey.KEY_INFO_PAUSE_PLAY, Boolean.class)
                .observe(getPageActivity(), aBoolean -> {
                    if (aBoolean) {
                        JZReleaseUtil.releaseAllVideos();
                    }
                });

        //接收评论事件top
        LiveEventBus.get().with(LiveEventBusKey.KEY_NEWS_COLLECTION, String.class).observe(getPageActivity(), newsId -> {
            if (mHomeIndexTopBeanList.size() != 0) {
                for (int i = 0; i < mHomeIndexTopBeanList.size(); i++) {
                    IndexHotEntity.NewsTopBlocksBean newsTopBlocksBean = mHomeIndexTopBeanList.get(i);
                    String listBeanId = newsTopBlocksBean.getNewsId();
                    int commentCount = newsTopBlocksBean.getCommentCount();
                    if (newsId.equals(listBeanId)) {
                        try {
                            newsTopBlocksBean.setCommentCount(commentCount + 1);
                            RecyclerView view = InfoAdapterHelper.getRV();
                            if (view != null) {
                                RecyclerView.Adapter adapter = view.getAdapter();
                                if (adapter != null) {
                                    adapter.notifyItemChanged(i);
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    }
                }
            }
        });

        //接收评论事件
        LiveEventBus.get().with(LiveEventBusKey.KEY_NEWS_COLLECTION, String.class).observe(getPageActivity(), newsId -> {
            if (dataList.size() != 0) {
                for (int i = 0; i < dataList.size(); i++) {
                    IndexHotEntity.NewsBean.ListBean listBean = dataList.get(i);
                    String listBeanId = listBean.getId();
                    int commentCount = listBean.getCommentCount();
                    if (newsId.equals(listBeanId)) {
                        listBean.setCommentCount(commentCount + 1);
                        adapter.notifyItemChanged(i + 1);
                        break;
                    }
                }
            }
        });

        //接收来自详情页的点赞事件 LiveEventBusKey.KEY_NEWS_LIKE
        LiveEventBus.get().with(LiveEventBusKey.KEY_NEWS_LIKE, String.class).observe(getPageActivity(), id -> {
            LogUtils.INSTANCE.e("===z", "收到事件点赞");
//            Toast.makeText(getPageActivity(), "praise", Toast.LENGTH_SHORT).show();
            if (dataList.size() != 0) {
                for (int i = 0; i < dataList.size(); i++) {
                    IndexHotEntity.NewsBean.ListBean listBean = dataList.get(i);
                    String listBeanId = listBean.getId();
                    int likeCount = listBean.getLikeCount();
                    if (id.equals(listBeanId)) {
                        listBean.setLike(true);
                        listBean.setLikeCount(likeCount + 1);
                        adapter.notifyItemChanged(i + 1);
                        break;
                    }
                }
            }
        });

        //接收来自详情页的点赞事件top LiveEventBusKey.KEY_NEWS_LIKE
        LiveEventBus.get().with(LiveEventBusKey.KEY_NEWS_LIKE, String.class).observe(getPageActivity(), id -> {
            LogUtils.INSTANCE.e("===z", "收到事件点赞");
//            Toast.makeText(getPageActivity(), "praise", Toast.LENGTH_SHORT).show();
            if (mHomeIndexTopBeanList.size() != 0) {
                for (int i = 0; i < mHomeIndexTopBeanList.size(); i++) {
                    IndexHotEntity.NewsTopBlocksBean newsTopBlocksBean = mHomeIndexTopBeanList.get(i);
                    String listBeanId = newsTopBlocksBean.getNewsId();
                    int likeCount = newsTopBlocksBean.getLikeCount();
                    if (id.equals(listBeanId)) {
                        try {
                            newsTopBlocksBean.setLike(true);
                            newsTopBlocksBean.setLikeCount(likeCount + 1);
                            RecyclerView view = InfoAdapterHelper.getRV();
                            if (view != null) {
                                RecyclerView.Adapter adapter = view.getAdapter();
                                if (adapter != null) {
                                    adapter.notifyItemChanged(i);
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        break;
                    }
                }
            }
        });

        //接收登录的广播事件
        LiveEventBus.get().with(LiveEventBusKey.KEY_UserLoginSuccess, UserInfo.class).observe(this, new Observer<UserInfo>() {
            @Override
            public void onChanged(UserInfo userInfo) {
                if (userInfo == null) return;
                if (presenter == null) return;
                // TODO: 2019/10/25 这里应该添加类型
                initArguments();
                presenter.setParams(labelType, categoryId, mediaType, sportType);
                presenter.loadData(1);
            }
        });
        //接收退出登录的广播事件
        LiveEventBus.get().with(LiveEventBusKey.KEY_LogoutEvent, LogoutEvent.class).observe(this, new Observer<LogoutEvent>() {
            @Override
            public void onChanged(LogoutEvent logoutEvent) {
                if (logoutEvent == null) return;
                if (presenter == null) return;
                // TODO: 2019/10/25 这里应该添加类型
                initArguments();
                presenter.setParams(labelType, categoryId, mediaType, sportType);
                presenter.loadData(1);
            }
        });

        statusEvent();
        //接收状态消息

        //接收进球消息
        scoreEvent();

    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (!getUserVisibleHint()) {
            JZReleaseUtil.releaseAllVideos();
        }
    }

    /**
     * 初始化滑动事件
     */
    private void initScrollEvent() {
        //recyclerView滑动停止播放
        JZReleaseUtil.releaseAllVideos(recyclerView);

        //上滑动
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                //-1代表顶部,返回true表示没到顶,还可以滑
                boolean top = recyclerView.canScrollVertically(-1);
                if (top) {//不是顶部显示Line
                    viewLineHomeHot.setVisibility(View.VISIBLE);
                } else {//顶部隐藏Line
                    viewLineHomeHot.setVisibility(View.GONE);
                }
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

            }
        });
    }

    /**
     * 初始化重新加载数据
     */
    private void initReLoadEvent() {
        placeholder.setPageErrorRetryListener(v -> presenter.loadData(1));
    }

    /**
     * 初始化刷新和加载更多
     */
    private void initRefreshLoadMoreEvent() {
        smartRefreshLayout.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                presenter.loadMoreData();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                presenter.refreshData();
            }
        });
    }


    /**
     * 获取刷新头部
     *
     * @return 头部
     */
    private RefreshHeader getRefreshHeader() {
        return new PlayBallHeader(getPageActivity()).createAnim(PlayBallHeader.FOOTBALL);
    }

    /**
     * 获取刷新底部
     *
     * @return 底部
     */
    private RefreshFooter getRefreshFooter() {
        return new RecyclerClassicsFooter(getPageActivity());
    }

    @Override
    public int getLayoutResID() {
        return R.layout.fragment_info;
    }

    @Override
    public void setTextSize(int id, Float size) {

    }

    @Override
    public void setTextSize(TextView textView, Float size) {

    }

    @Override
    public Fragment getFragment() {
        return this;
    }

    @Override
    public void requestLoading() {
//        skeletonScreen = Skeleton.bind(placeholder)
//                .load(R.layout.layout_place_info_loading)
//                .duration(1000)
//                .shimmer(true)//是否开启动画
//                .color(R.color.color_ffffff)
//                .angle(0)
//                .show();
        showLoading(placeholder);
        smartRefreshLayout.setEnableRefresh(false);
        smartRefreshLayout.setEnableLoadMore(false);
    }


    /**
     * 请求成功回调
     *
     * @param data 列表数据
     */
    @Override
    public void resultSuccess(List<IndexHotEntity.NewsBean.ListBean> data, int page) {
//        if(skeletonScreen != null){
//            skeletonScreen.hide();
//        }
        LogUtils.INSTANCE.e("===z", "列表数据长度data = " + data.size());
        placeholder.hideLoading();
        smartRefreshLayout.setEnableRefresh(true);
        smartRefreshLayout.setEnableLoadMore(true);
        InfoAdapterHelper.addHeader(adapter, getPageActivity(),
                mHomeIndexBannerBeanList, mHomeIndexHotRunBeanList, mSpecialBlocksBean, null, goodView);
        if (page == 1) {
            dataList.clear();
        }
        dataList.addAll(data);
        adapter.notifyDataSetChanged();
    }

    /**
     * 加载失败
     *
     * @param type 失败的类型
     */
    @Override
    public void resultFail(int type) {
//        if(skeletonScreen != null){
//            skeletonScreen.hide();
//        }
        switch (type) {
            case FailStateConstant.TYPE_ERROR:   //加载失败
                showError(placeholder, "网络出了小差，连接失败~");
                break;
            case FailStateConstant.TYPE_EMPTY:   //数据为空
                smartRefreshLayout.setEnableRefresh(true);
                showEmpty(placeholder, "暂无数据");
                break;

            default:
                break;
        }
    }

    /**
     * 刷新成功回调
     */
    @Override
    public void resultRefreshSuccess() {
        //Toast.makeText(getPageActivity(), "刷新成功", Toast.LENGTH_SHORT).show();
        smartRefreshLayout.finishRefresh();
        //刷新成功清理存储的数组
        dataList.clear();
    }

    /**
     * 刷新失败回调
     *
     * @param errorMsg 失败信息
     */
    @Override
    public void resultRefreshFail(String errorMsg) {
//        Toast.makeText(getPageActivity(), "刷新失败", Toast.LENGTH_SHORT).show();
        smartRefreshLayout.finishRefresh();
    }

    /**
     * 加载更多成功
     *
     * @param type 成功类型
     */
    @Override
    public void resultLoadMoreSuccess(int type) {
        smartRefreshLayout.finishLoadMore();
        switch (type) {
            case LoadMoreType.TYPE_SUCCESS:      //加载成功
//                Toast.makeText(getPageActivity(), "加载更多成功", Toast.LENGTH_SHORT).show();
                break;

            case LoadMoreType.TYPE_ALL_DATA:     //已经全部加载
//                Toast.makeText(getPageActivity(), "已经全部加载", Toast.LENGTH_SHORT).show();
                ToastUtils.showToast("已经全部加载");
                //已经全部加载 就不允许继续上拉加载了
                smartRefreshLayout.setEnableLoadMore(false);
                break;

            default:
                break;
        }
    }

    /**
     * 加载更多失败
     *
     * @param errorMsg 失败信息
     */
    @Override
    public void resultLoadMoreFail(String errorMsg) {
//        Toast.makeText(getPageActivity(), "加载更多失败", Toast.LENGTH_SHORT).show();
        smartRefreshLayout.finishLoadMore();
    }

    /**
     * 加载banner成功回调
     *
     * @param bannerBeans banners
     */
    @Override
    public void resultBannerSuccess(List<HomeIndexBannerBean> bannerBeans) {
        if (mHomeIndexBannerBeanList != null) {
            mHomeIndexBannerBeanList.clear();
        }
        if (mHomeIndexBannerBeanList != null && bannerBeans != null && bannerBeans.size() != 0) {
            mHomeIndexBannerBeanList.addAll(bannerBeans);
        }
    }

    /**
     * 加载banner失败回调
     */
    @Override
    public void resultBannerFail(int page) {
//        Toast.makeText(getPageActivity(), "banner失败", Toast.LENGTH_SHORT).show();
        if (page <= 1) {
            mHomeIndexBannerBeanList.clear();
        }
    }

    /**
     * 加载子弹推数据成功回调
     *
     * @param hotRunBeans 子弹推数据
     */
    @Override
    public void resultHotRunSuccess(List<HomeIndexHotRunBean> hotRunBeans) {
        if (mHomeIndexHotRunBeanList != null) {
            mHomeIndexHotRunBeanList.clear();
        }
        if (mHomeIndexHotRunBeanList != null && hotRunBeans != null && hotRunBeans.size() != 0) {
            mHomeIndexHotRunBeanList.addAll(hotRunBeans);
        }
    }

    /**
     * 加载子弹推数据失败
     */
    @Override
    public void resultHotRunFail(int page) {
//        Toast.makeText(getPageActivity(), "子弹推失败", Toast.LENGTH_SHORT).show();
        if (page <= 1) {
            mHomeIndexHotRunBeanList.clear();
        }
    }

    /**
     * 收到推送数据并刷新
     * @param adapter
     * @param matchId
     * @param hostScore
     * @param guestScore
     */
    private void getPushDataAndNotify(InfoHotAdapter adapter,int matchId,int hostScore,int guestScore) {
        try {
            BaseQuickAdapter rvSpecialAdapter = getSpecialAdapter(adapter);
            if (rvSpecialAdapter == null) return;

            List data = rvSpecialAdapter.getData();
            if (data.size() != 0) {
                for (Object datum : data) {
                    if (datum instanceof IndexHotEntity.SpecialBlocksBean.SpecialBlockVoBean.MatchDataBean) {

                        if (matchId == ((IndexHotEntity.SpecialBlocksBean.SpecialBlockVoBean.MatchDataBean) datum).getMatchId()) {
                            ((IndexHotEntity.SpecialBlocksBean.SpecialBlockVoBean.MatchDataBean) datum).setHostTeamScore(hostScore);
                            ((IndexHotEntity.SpecialBlocksBean.SpecialBlockVoBean.MatchDataBean) datum).setGuestTeamScore(guestScore);
                            rvSpecialAdapter.notifyDataSetChanged();
                        }

                    }
                }

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 接收进球消息
     */
    private void scoreEvent() {
        LiveEventBus.get().with(InfoSpecialPushParams.RECEIPT_KEY_SCORE, PushScore.class).observe(this, new Observer<PushScore>() {
            @Override
            public void onChanged(PushScore o) {
                LogUtils.INSTANCE.e("===zll --1", JsonUtils.INSTANCE.toJson(o));

                getPushDataAndNotify(adapter,o.getMatchId(),o.getHostTeamScore(),o.getGuestTeamScore());

            }
        });

        LiveEventBus.get().with(InfoSpecialPushParams.RECEIPT_KEY_SCORE, TennisballScore.class).observe(this, new Observer<TennisballScore>() {
            @Override
            public void onChanged(TennisballScore o) {
                LogUtils.INSTANCE.e("===zll --2", JsonUtils.INSTANCE.toJson(o));
                getPushDataAndNotify(adapter,o.getMatchId(),o.getHostTeamScore(),o.getGuestTeamScore());

            }
        });

        LiveEventBus.get().with(InfoSpecialPushParams.RECEIPT_KEY_SCORE, BaseballScore.class).observe(this, new Observer<BaseballScore>() {
            @Override
            public void onChanged(BaseballScore o) {
                LogUtils.INSTANCE.e("===zll --3", JsonUtils.INSTANCE.toJson(o));
                getPushDataAndNotify(adapter,o.getMatchId(),o.getHostTeamScore(),o.getGuestTeamScore());

            }
        });
    }

    /**
     * 接收状态消息
     */
    private void statusEvent() {

        LiveEventBus.get().with(InfoSpecialPushParams.RECEIPT_KEY_STATUS, PushStatus.class).observe(this, pushStatus -> {
            LogUtils.INSTANCE.e("===zll --0", JsonUtils.INSTANCE.toJson(pushStatus));

            long timePlayed = pushStatus.getTimePlayed();


            //1 未开始    2 比赛中  3 结束  4 异常
            int status = pushStatus.getStatus();

            // 比赛时间状态显示
            //未开赛时显示开赛时间
            //已开始后显示比赛时间（正常显示比赛时间）
            //比赛结束后显示结束

            try {
                BaseQuickAdapter rvSpecialAdapter = getSpecialAdapter(adapter);
                if (rvSpecialAdapter != null) {
                    List data = rvSpecialAdapter.getData();
                    if (data.size() != 0) {
                        for (Object datum : data) {
                            if (datum instanceof IndexHotEntity.SpecialBlocksBean.SpecialBlockVoBean.MatchDataBean) {

                                String matchTime = ((IndexHotEntity.SpecialBlocksBean.SpecialBlockVoBean.MatchDataBean) datum).getMatchTime();
                                int matchTimes = Integer.parseInt(!TextUtils.isEmpty(matchTime) ? matchTime : "0");
                                int matchStatus = ((IndexHotEntity.SpecialBlocksBean.SpecialBlockVoBean.MatchDataBean) datum).getMatchStatus();

                                ((IndexHotEntity.SpecialBlocksBean.SpecialBlockVoBean.MatchDataBean) datum).setMatchStatus(matchStatus);

                                if (status == 1) {
                                    ((IndexHotEntity.SpecialBlocksBean.SpecialBlockVoBean.MatchDataBean) datum).setMatchTime(matchTime);

                                } else if (status == 2) {
                                    String timePlay = presenter.changeTimePlay(matchTimes, timePlayed);
                                    ((IndexHotEntity.SpecialBlocksBean.SpecialBlockVoBean.MatchDataBean) datum).setMatchStatusDesc(timePlay);

                                }

                                rvSpecialAdapter.notifyDataSetChanged();

                            }
                        }

                    }

                }

            } catch (Exception e) {
                e.printStackTrace();
            }


        });
    }



    private BaseQuickAdapter getSpecialAdapter(InfoHotAdapter adapter) {
        if (adapter == null) return null;

        LinearLayout headerLayout = adapter.getHeaderLayout();
        if (headerLayout != null) {
            RecyclerView rvSpecial = headerLayout.findViewById(R.id.rv_special);
            return (BaseQuickAdapter) rvSpecial.getAdapter();
        }
        return null;
    }


    @Override
    public void resultSpecialSuccess(IndexHotEntity.SpecialBlocksBean specialBeans) {
        if (mSpecialBlocksBean != null) mSpecialBlocksBean = null;
        mSpecialBlocksBean = specialBeans;

        //presenter.testSendPush();

        //发送推送事件
        presenter.sendPush(specialBeans);

    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (presenter == null) return;
        presenter.unregisterPush(mSpecialBlocksBean);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

    }

    /**
     * 加载专栏数据失败回调
     */
    @Override
    public void resultSpecialFail(int page) {
//        Toast.makeText(getPageActivity(), "专栏失败", Toast.LENGTH_SHORT).show();
        if (page <= 1) {
            mSpecialBlocksBean = null;
        }
    }


    /**
     * 加载置顶数据成功回调
     *
     * @param topBeans 置顶数据
     */
    @Override
    public void resultTopSuccess(List<IndexHotEntity.NewsTopBlocksBean> topBeans) {
        LogUtils.INSTANCE.e("===z", "置顶数据回调成功");
        if (mHomeIndexTopBeanList.size() != 0) {
            mHomeIndexTopBeanList.clear();
        }
        mHomeIndexTopBeanList.addAll(topBeans);
        for (IndexHotEntity.NewsTopBlocksBean topBean : topBeans) {
            int appShowType = topBean.getAppShowType();
            LogUtils.INSTANCE.e("===z", "置顶类型itemType = " + appShowType);
        }
    }

    /**
     * 加载置顶数据失败
     */
    @Override
    public void resultTopFail(int page) {
//        Toast.makeText(getPageActivity(), "置顶失败", Toast.LENGTH_SHORT).show();
        if (page <= 1) {
            mHomeIndexTopBeanList.clear();
        }
    }
}
