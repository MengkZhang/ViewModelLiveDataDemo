package com.yb.ballworld.information.ui.auth.utils;

import android.content.res.Resources;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.yb.ballworld.baselib.utils.AppUtils;
import com.yb.ballworld.information.R;

/**
 * @author Gethin
 * @time 2019/11/5 19:00
 */

public class SpecialAuthUtils {

    public static class Companion {
        public static SpecialAuthUtils newInstance() {
           return new SpecialAuthUtils();
        }
    }

    private TextView textView;
    private EditText editText;
    private Resources resources;

    private long mCountTime = 60;

    private Handler mHandler = new Handler(Looper.getMainLooper());

    public void start(TextView tv, EditText et, Resources rs) {
        textView = tv;
        editText = et;
        resources = rs;
        textView.setTag("1"); //设置TextView正在进行倒计时的标记 1代表正在倒计时 2代表倒计时完成
        mHandler.postDelayed(countDown, 0);
    }

    private Runnable countDown = new Runnable() {
        @Override
        public void run() {
            textView.setText(mCountTime + "秒后重发");
            textView.setEnabled(false);
            textView.setBackgroundResource(R.drawable.shape_special_auth_verifycode_bg2);
            textView.setTextColor(resources.getColor(R.color.color_FF999999));
            if (mCountTime > 0) {
                mHandler.postDelayed(this, 1000);
            } else {
                textView.setTag("2");//倒计时完成
                resetCounter();
            }
            mCountTime--;
        }
    };

    public void removeRunable() {
        textView.setTag(null);
        mHandler.removeCallbacks(countDown);
    }

    //重置按钮状态
    private void resetCounter(String... text) {
        if (!TextUtils.isEmpty(editText.getText().toString())) {
            textView.setEnabled(true);
            textView.setTextColor(resources.getColor(R.color.color_ff6b00));
            textView.setBackgroundResource(R.drawable.shape_special_auth_verifycode_bg);
        } else {
            textView.setEnabled(false);
            textView.setBackgroundResource(R.drawable.shape_special_auth_verifycode_bg2);
            textView.setTextColor(resources.getColor(R.color.color_FF999999));
        }
        if (text.length > 0 && TextUtils.isEmpty(text[0])) {
            textView.setText(text[0]);
        } else {
            textView.setText("重新获取");
        }
        mCountTime = 60;
    }

    private Toast toast = new Toast(AppUtils.getContext());

    //错误Toast
    public void showLoginError(LayoutInflater inflater, String meg, int img) {
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.CENTER, 0, 0);
        View toastLayout = inflater.inflate(com.yb.ballworld.baselib.R.layout.view_login_error_toast, null);
        TextView tv = toastLayout.findViewById(R.id.tvToastStr);
        ImageView ivToastIcon = toastLayout.findViewById(R.id.ivToastIcon);
        ivToastIcon.setImageResource(img);
        tv.setText(meg);
        toast.setView(toastLayout);
        toast.show();
    }

    //错误Toast
    public void showLoginError(LayoutInflater inflater, String meg) {
        showLoginError(inflater, meg, R.mipmap.aw_dc);
    }
}
