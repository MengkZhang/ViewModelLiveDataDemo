package com.yb.ballworld.information.utils;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.media.MediaMetadataRetriever;
import android.os.Build;
import android.text.TextUtils;
import android.view.Display;
import android.view.View;

import com.yb.ballworld.baselib.utils.TimeUtils;
import com.yb.ballworld.information.R;

import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.List;

public class CommondUtil {
    /**
     * 计算评论、回复列表里的时间：5分钟前...
     *
     * @param fixedTime
     * @param context
     * @return
     */
    public static String calcCommentTime(long fixedTime, Context context) {
        //得到分钟
        int diffTime = (int) ((System.currentTimeMillis() - fixedTime) / (60000));
        //5分钟
        final int fiveMins = 15;
        //一小时
        final int hour = 60;
        //一天
        final int day = hour * 24;
        //一个月
        final int month = day * 30;
        //一年
        final int year = day * 365;

        String diffText;
        if (diffTime > year) {
            diffText = context.getString(R.string.func_beforeYear, diffTime / year);
        } else if (diffTime > month) {
            diffText = context.getString(R.string.func_beforeMonth, diffTime / month);
        } else if (diffTime > day) {
            diffText = context.getString(R.string.func_beforeDay, diffTime / day);
        } else if (diffTime > hour) {
            diffText = context.getString(R.string.func_beforehour, diffTime / hour);
        } else if (diffTime > fiveMins) {
            diffText = context.getString(R.string.func_beforeMinute, diffTime);
        } else {
            diffText = context.getString(R.string.func_now);
        }
        return diffText;
    }

    /**
     * 计算发表的时间：
     * 刚刚、今天、昨天、多少号
     *
     * @param fixedTime
     * @param context
     * @return
     */
    public static String calcPublishTime(long fixedTime, Context context) {
        //得到分钟
        TimeUtils timeUtils = TimeUtils.INSTANCE;
        boolean isToday = timeUtils.isToday(fixedTime);
        boolean isYesterday = timeUtils.isYesterday(fixedTime);
        String publishTime;
        if (fixedTime < System.currentTimeMillis()) {
            if (isToday) {
                publishTime = context.getString(R.string.func_publishToday, timeUtils.getHourMinute(fixedTime));
            } else if (isYesterday) {
                publishTime = context.getString(R.string.func_publishYesterday, timeUtils.getHourMinute(fixedTime));
            } else {
                publishTime = timeUtils.getYearMDHM(fixedTime);
            }
        } else {
            publishTime = context.getString(R.string.func_publishToday, "");
        }
        return publishTime;
    }

    /**
     * 范围内取有效值
     *
     * @param min 最小值
     * @param val 原始值
     * @param max 最大值
     * @return 符合最大最小范围的有效值
     */
    public static float bound(float min, float val, float max) {
        return Math.min(Math.max(val, min), max);
    }

    /**
     * dp转为px
     *
     * @param dp dp值
     * @return px值
     */
    public static int dp2px(int dp) {
        return (int) (dp * Resources.getSystem().getDisplayMetrics().density);
    }

    /**
     * 获得View所在界面 NavigationBar 高度
     *
     * @param view 目标View
     * @return 如果存在NavigationBar则返回高度，否则0
     */
    public static int getNavigationBarHeight(View view) {
        Activity activity = getActivity(view);
        if (activity != null) {
            // 方法一
            {
                Display display = activity.getWindowManager().getDefaultDisplay();
                Point size = new Point();
                display.getSize(size);
                int usableHeight = size.y;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                    display.getRealSize(size); // getRealMetrics is only available with API 17 and +
                } else {
                    try {
                        size.x = (Integer) Display.class.getMethod("getRawWidth").invoke(display);
                        size.y = (Integer) Display.class.getMethod("getRawHeight").invoke(display);
                    } catch (Exception e) {
                        // LogUtils.INSTANCE.w(TAG, "getNavigationBarHeight: error", e);
                    }
                }
                int realHeight = size.y;
                return realHeight > usableHeight ? realHeight - usableHeight : 0;
            }

            // 方法二：不能确定当前屏幕上是否有NaviBar
            // 不能
//                Resources resources = activity.getResources();
//                try {
//                    int resourceId = resources.getIdentifier("navigation_bar_height", "dimen", "android");
//                    if (resourceId > 0) {
//                        return resources.getDimensionPixelSize(resourceId);
//                    }
//                } catch (Exception ignored) {
//                    LogUtils.INSTANCE.w(TAG, "getNavigationBarHeight error", ignored);
//                }
        }

        return 0;
    }

    private static Activity getActivity(View view) {
        Context context = view.getContext();
        while (context instanceof ContextWrapper) {
            if (context instanceof Activity) {
                return (Activity) context;
            }
            context = ((ContextWrapper) context).getBaseContext();
        }
        return null;
    }

    /**
     * 通过标识符截取数组
     *
     * @param content
     * @param sign
     * @return
     */
    public static String[] splitBySign(String content, String sign) {
        String[] strArray = null;
        boolean isEmpty = TextUtils.isEmpty(content);
        if (!isEmpty) {
            isEmpty = TextUtils.isEmpty(sign);
            if (!isEmpty) {
                strArray = content.split(sign);
            } else {
                strArray = new String[]{content};
            }
        }
        return strArray;
    }

    public static <T> List<T> arrayToList(T[] array) {
        List<T> arrayList = null;
        if (array != null) {
            arrayList = Arrays.asList(array);
        }
        return arrayList;
    }

    public static boolean isEmpty(Collection list) {
        return list == null || list.isEmpty();
    }

    public static String likeCount(int likeCount, Context context) {
        final int tenThousand = 10000;
        final int hundredMillion = tenThousand * tenThousand;
        String result;
        DecimalFormat decimalFormat = new DecimalFormat("0.0");
        if (likeCount >= hundredMillion) {
            result = context.getString(R.string.func_likeCountHM, decimalFormat.format(likeCount / (double) hundredMillion));
        } else if (likeCount >= tenThousand) {
            result = context.getString(R.string.func_likeCountTT, decimalFormat.format(likeCount / (double) tenThousand));
        } else {
            result = String.valueOf(likeCount);
        }
        return result;
    }

    public static String commentCount(int commentCount, Context context) {
        final int tenThousand = 10000;
        final int hundredMillion = tenThousand * tenThousand;
        String result;
        DecimalFormat decimalFormat = new DecimalFormat("0.0");
        if (commentCount >= hundredMillion) {
            result = context.getString(R.string.func_likeCountHM, decimalFormat.format(commentCount / (double) hundredMillion));
        } else if (commentCount >= tenThousand) {
            result = context.getString(R.string.func_likeCountTT, decimalFormat.format(commentCount / (double) tenThousand));
        } else {
            result = String.valueOf(commentCount);
        }
        result=context.getString(R.string.func_commentCount,result);
        return result;
    }

    public static String commentCountOnlyNum(int commentCount, Context context) {
        final int tenThousand = 10000;
        final int hundredMillion = tenThousand * tenThousand;
        String result;
        DecimalFormat decimalFormat = new DecimalFormat("0.0");
        if (commentCount >= hundredMillion) {
            result = context.getString(R.string.func_likeCountHM, decimalFormat.format(commentCount / (double) hundredMillion));
        } else if (commentCount >= tenThousand) {
            result = context.getString(R.string.func_likeCountTT, decimalFormat.format(commentCount / (double) tenThousand));
        } else {
            result = String.valueOf(commentCount);
        }
        //result=context.getString(R.string.func_commentCount,result);
        return result;
    }

    public static String convertTime(String timestamp,Context context) {
        final long tenThousand =TextUtils.isEmpty(timestamp)?System.currentTimeMillis():TimeUtils.INSTANCE.getDate(timestamp).getTime();
        return calcCommentTime(tenThousand,context);
    }

    /**
     * 获取视频第一帧
     * @param urlOrPath
     * @return
     */
    public static Bitmap getVideoFirstFrame(String urlOrPath) {
        Bitmap bitmap = null;
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            //根据url获取缩略图
            retriever.setDataSource(urlOrPath);
            //获得第一帧图片
            bitmap = retriever.getFrameAtTime();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } finally {
            retriever.release();
        }
        return bitmap;
    }

    public static String  fitEmpty(String origin){
        return origin==null?"":origin;
    }


    public static int str2Int(String str){
        int value=0;
        if(!TextUtils.isEmpty(str.trim())){
            try {
                value = Integer.parseInt(str);
            }catch (NumberFormatException e){

            }
        }
        return value;
    }

    public static long str2Long(String str){
        long value=0;
        if(!TextUtils.isEmpty(str.trim())){
            try {
                value = Long.parseLong(str);
            }catch (NumberFormatException e){

            }
        }
        return value;
    }

    public static float str2Float(String str){
        float value=0;
        if(!TextUtils.isEmpty(str.trim())){
            try {
                value = Float.parseFloat(str);
            }catch (NumberFormatException e){

            }
        }
        return value;
    }

    public static double str2Double(String str){
        double value=0;
        if(!TextUtils.isEmpty(str.trim())){
            try {
                value = Double.parseDouble(str);
            }catch (NumberFormatException e){

            }
        }
        return value;
    }

    public static boolean str2Boolean(String str){
        boolean value=false;
        if(!TextUtils.isEmpty(str.trim())){
            try {
                value = Boolean.parseBoolean(str);
            }catch (NumberFormatException e){

            }
        }
        return value;
    }
}
