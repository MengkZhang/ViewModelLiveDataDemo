package com.yb.ballworld.information.ui.home.utils;

import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.information.R;

import cn.jzvd.Jzvd;
import cn.jzvd.JzvdStd;

/**
 * Desc 停止视频播放 释放资源
 * Date 2019/10/10
 * author mengk
 */
public class JZReleaseUtil {
    /**
     * 停止播放
     */
    public static void releaseAllVideos() {
        try {
            Jzvd.releaseAllVideos();
        } catch (Exception e) {
            e.printStackTrace();
            LogUtils.INSTANCE.e("===z", "停止播放异常");
        }
    }

    /**
     * 正在播放的视频 滑动停止播放
     *
     * @param recyclerView 列表
     */
    public static void releaseAllVideos(RecyclerView recyclerView) {
        //recyclerView滑动停止播放
        recyclerView.addOnChildAttachStateChangeListener(new RecyclerView.OnChildAttachStateChangeListener() {
            @Override
            public void onChildViewAttachedToWindow(@NonNull View view) {
            }

            @Override
            public void onChildViewDetachedFromWindow(@NonNull View view) {
                try {
                    Jzvd jzvd = view.findViewById(R.id.js_player);
                    if (jzvd != null && Jzvd.CURRENT_JZVD != null &&
                            jzvd.jzDataSource.containsTheUrl(Jzvd.CURRENT_JZVD.jzDataSource.getCurrentUrl())) {
                        if (Jzvd.CURRENT_JZVD != null && Jzvd.CURRENT_JZVD.screen != Jzvd.SCREEN_FULLSCREEN) {
                            Jzvd.releaseAllVideos();
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                    LogUtils.INSTANCE.e("===z", "正在播放的视频 滑动停止播放异常");
                }
            }
        });
    }

    /**
     * 正在播放的视频 滑动停止播放
     *
     * @param recyclerView 列表
     */
    public static void releaseAllVideos(RecyclerView recyclerView, int playerId) {
        //recyclerView滑动停止播放
        recyclerView.addOnChildAttachStateChangeListener(new RecyclerView.OnChildAttachStateChangeListener() {
            @Override
            public void onChildViewAttachedToWindow(@NonNull View view) {
            }

            @Override
            public void onChildViewDetachedFromWindow(@NonNull View view) {
                try {
                    Jzvd jzvd = view.findViewById(playerId);
                    if (jzvd != null && Jzvd.CURRENT_JZVD != null &&
                            jzvd.jzDataSource.containsTheUrl(Jzvd.CURRENT_JZVD.jzDataSource.getCurrentUrl())) {
                        if (Jzvd.CURRENT_JZVD != null && Jzvd.CURRENT_JZVD.screen != Jzvd.SCREEN_FULLSCREEN) {
                            Jzvd.releaseAllVideos();
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                    LogUtils.INSTANCE.e("===z", "正在播放的视频 滑动停止播放异常");
                }
            }
        });
    }

    /**
     * 正在播放的视频 滑动停止播放
     *
     * @param recyclerView 列表
     */
    public static void observeReleaseVideos(RecyclerView recyclerView,int jzvdViewId) {
        //recyclerView滑动停止播放
        recyclerView.addOnChildAttachStateChangeListener(new RecyclerView.OnChildAttachStateChangeListener() {
            @Override
            public void onChildViewAttachedToWindow(@NonNull View view) {

            }

            @Override
            public void onChildViewDetachedFromWindow(@NonNull View view) {
                    Jzvd jzvd = view.findViewById(jzvdViewId);
                boolean ispass=jzvd!=null&&Jzvd.CURRENT_JZVD != null&&jzvd.jzDataSource!=null&&Jzvd.CURRENT_JZVD.jzDataSource!=null&&jzvd.jzDataSource.containsTheUrl(Jzvd.CURRENT_JZVD.jzDataSource.getCurrentUrl())&& Jzvd.CURRENT_JZVD.screen != Jzvd.SCREEN_FULLSCREEN;
                if(ispass){
                    releaseAllVideos();
                }
            }
        });
    }

    /**
     * 继续播放
     */
    public static void onResume() {
        //home back
        JzvdStd.goOnPlayOnResume();
    }

    /**
     * 暂停播放
     */
    public static void onPause() {
        //home back
        JzvdStd.goOnPlayOnPause();
    }

}
