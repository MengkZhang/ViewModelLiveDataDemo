package com.yb.ballworld.information.ui.personal.bean;

import android.text.TextUtils;

/**
 * Desc: 个人页实体类，2019/10/21 修改  2019/10/24 修改
 * Author: JS-Kylo
 * Created On: 2019/10/17 16:43
 */
public class PersonalInfo {

    /**
     * id : 999
     * nickname : fanatik
     * headImgUrl :
     * personalDesc : 我的个人简介
     * followerCount : 5
     * articleCount : 371
     * attentionStatus : null
     * commentCount : 6
     * focusCount : 1
     * dynamicCount : 0
     */

    private String id;
    private String nickname;
    private String headImgUrl;
    private String background;
    private String personalDesc;
    private int followerCount;
    private int articleCount;
    private String  attentionStatus;
    private int commentCount;
    private int focusCount;
    private int dynamicCount;
    private long createTs; // 注册时间

    private int fansCount;
    private int favoriteCount;
    private int footprintCount;
    private boolean isAnchor;
    private boolean isAttention;
    private boolean isAuthor;
    private int postCount;
    private String createTime;
    private int videoCount; // 资讯视频数量
    private int newsCommentCount; // 资讯评论数
    private int newsFavoriteCount; // 资讯收藏数
    private int newsFootprintCount; // 资讯足迹数

    private int  isEditor; // 0为非特约认证，1为特约认证


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getHeadImgUrl() {
        return headImgUrl;
    }

    public void setHeadImgUrl(String headImgUrl) {
        this.headImgUrl = headImgUrl;
    }

    public String getBackground() {
        return background;
    }

    public void setBackground(String background) {
        this.background = background;
    }

    public String getPersonalDesc() {
        return personalDesc;
    }

    public void setPersonalDesc(String personalDesc) {
        this.personalDesc = personalDesc;
    }

    public int getFollowerCount() {
        return followerCount;
    }

    public void setFollowerCount(int followerCount) {
        this.followerCount = followerCount;
    }

    public int getArticleCount() {
        return articleCount;
    }

    public void setArticleCount(int articleCount) {
        this.articleCount = articleCount;
    }

    public String getAttentionStatus() {
        return attentionStatus;
    }

    public void setAttentionStatus(String attentionStatus) {
        this.attentionStatus = attentionStatus;
    }

    public int getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(int commentCount) {
        this.commentCount = commentCount;
    }

    public int getFocusCount() {
        return focusCount;
    }

    public void setFocusCount(int focusCount) {
        this.focusCount = focusCount;
    }

    public int getDynamicCount() {
        return dynamicCount;
    }

    public void setDynamicCount(int dynamicCount) {
        this.dynamicCount = dynamicCount;
    }

    public long getCreateTs() {
        return createTs;
    }

    public void setCreateTs(long createTs) {
        this.createTs = createTs;
    }


    public int getFansCount() {
        return fansCount;
    }

    public void setFansCount(int fansCount) {
        this.fansCount = fansCount;
    }

    public int getFavoriteCount() {
        return favoriteCount;
    }

    public void setFavoriteCount(int favoriteCount) {
        this.favoriteCount = favoriteCount;
    }

    public int getFootprintCount() {
        return footprintCount;
    }

    public void setFootprintCount(int footprintCount) {
        this.footprintCount = footprintCount;
    }

    public boolean isAnchor() {
        return isAnchor;
    }

    public void setAnchor(boolean anchor) {
        isAnchor = anchor;
    }

    public boolean isAttention() {
        return isAttention;
    }

    public void setAttention(boolean attention) {
        isAttention = attention;
    }

    public boolean isAuthor() {
        return isAuthor;
    }

    public void setAuthor(boolean author) {
        isAuthor = author;
    }

    public int getPostCount() {
        return postCount;
    }

    public void setPostCount(int postCount) {
        this.postCount = postCount;
    }

    public String getCreateTime() {
        return createTime==null?"":createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public int getVideoCount() {
        return videoCount;
    }

    public void setVideoCount(int videoCount) {
        this.videoCount = videoCount;
    }

    public int getNewsCommentCount() {
        return newsCommentCount;
    }

    public void setNewsCommentCount(int newsCommentCount) {
        this.newsCommentCount = newsCommentCount;
    }

    public int getNewsFavoriteCount() {
        return newsFavoriteCount;
    }

    public void setNewsFavoriteCount(int newsFavoriteCount) {
        this.newsFavoriteCount = newsFavoriteCount;
    }

    public int getNewsFootprintCount() {
        return newsFootprintCount;
    }

    public void setNewsFootprintCount(int newsFootprintCount) {
        this.newsFootprintCount = newsFootprintCount;
    }

    public int getIsEditor() {
        return isEditor;
    }

    public void setIsEditor(int isEditor) {
        this.isEditor = isEditor;
    }
}
