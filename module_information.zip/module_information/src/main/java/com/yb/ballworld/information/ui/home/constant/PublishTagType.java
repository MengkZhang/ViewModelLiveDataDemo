package com.yb.ballworld.information.ui.home.constant;

import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Desc
 * Date 2019/11/6
 * author mengk
 *
 * 默认查询全部类型。1球员，2俱乐部球队，3国家队，4赛事
 */
@IntDef({
        PublishTagType.TYPE_PERSON,
        PublishTagType.TYPE_TEAM,
        PublishTagType.TYPE_COUNTRY_TEAM,
        PublishTagType.TYPE_MATCH
})

@Retention(RetentionPolicy.SOURCE)

public @interface PublishTagType {
    int TYPE_PERSON = 1;
    int TYPE_TEAM = 2;
    int TYPE_COUNTRY_TEAM = 3;
    int TYPE_MATCH = 4;
}
