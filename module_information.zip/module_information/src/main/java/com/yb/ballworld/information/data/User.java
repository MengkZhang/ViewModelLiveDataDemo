package com.yb.ballworld.information.data;

/**
 * Desc: 作者\评论者\回复者
 *
 * @author ink
 * created at 2019/10/9 20:53
 */
public class User {
    private long id;
    private String userId;
    private String userNick;
    private String userPhoto;
    //其他


    public String getUserNick() {
        return userNick;
    }

    public void setUserNick(String userNick) {
        this.userNick = userNick;
    }

    public String getUserPhoto() {
        return userPhoto;
    }

    public void setUserPhoto(String userPhoto) {
        this.userPhoto = userPhoto;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
