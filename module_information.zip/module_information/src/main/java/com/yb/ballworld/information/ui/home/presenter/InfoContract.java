package com.yb.ballworld.information.ui.home.presenter;

import androidx.fragment.app.Fragment;

import com.yb.ballworld.information.ui.home.bean.HomeInfoListBean;
import com.yb.ballworld.information.ui.home.bean.InfoListEntity;

import java.util.List;

/**
 * Desc 资讯列表协议类
 * Date 2019/10/7
 * author mengk
 */
public class InfoContract {

    //--------------------------------View层----------------------------
    public interface IInfoView {
        Fragment getFragment();

        //请求加载中
        void requestLoading();

        //请求成功
        void resultSuccess(List<InfoListEntity.ListBean> data,int page);

        //请求失败
        void resultFail(int type);

        //刷新成功
        void resultRefreshSuccess();

        //刷新失败
        void resultRefreshFail(String errorMsg);

        //加载更多成功
        void resultLoadMoreSuccess(int type);

        //加载更多失败
        void resultLoadMoreFail(String errorMsg);
    }

    //--------------------------------Presenter层----------------------------
    public interface IInfoPresenter {

        //请求数据方法
        void loadData(int page);

        //刷新
        void refreshData();

        //加载更多
        void loadMoreData();

        //绑定View
        void attachView(IInfoView view);

        //解绑View
        void detachView();
    }

}
