package com.yb.ballworld.information.ui.personal.bean;

import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.yb.ballworld.information.ui.personal.constant.AdapterConstant;

import java.util.List;

import static android.text.TextUtils.isEmpty;

/**
 * Desc: 收藏实体类
 * Author: JS-Kylo
 * Created On: 2019/10/10 13:37
 */
public class CollectionEntity {

    /**
     * totalCount : 1
     * pageNum : 1
     * pageSize : 10
     * totalPage : 1
     * list : [{"id":"0060e019e5654a7bb2251a9d158efdc2","title":"格纳布里赛后本想带球回家 却被马丁内斯踢向了看台","imgUrl":"http://tu.duoduocdn.com/v/img/191003/274915_02092424336.jpg","preview":"格纳布里赛后本想带球回家 却被马丁内斯踢向了看台","mediaType":1,"playUrl":"http://1251542705.vod2.myqcloud.com/9665f9bfvodgzp1251542705/ab681f415285890794546965484/xfWZkDfgbksA.mp4","showType":0,"userId":"999","newsImgs":null,"likeCount":9,"commentCount":66,"appShowType":3,"user":{"id":"999","nickname":"fanatik","headImgUrl":"http://sta.5yqz2.com/static/avatar/73ff1f3e8f368b611986b9025b648471.jpg","personalDesc":null,"followerCount":null,"articleCount":null,"attentionStatus":null},"isLike":true,"createdDate":"2019-10-07 11:36:12"}]
     */

    private int totalCount;
    private int pageNum;
    private int pageSize;
    private int totalPage;
    private List<ListBean> list;

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    public static class ListBean implements MultiItemEntity{
        /**
         * id : 0060e019e5654a7bb2251a9d158efdc2
         * title : 格纳布里赛后本想带球回家 却被马丁内斯踢向了看台
         * imgUrl : http://tu.duoduocdn.com/v/img/191003/274915_02092424336.jpg
         * preview : 格纳布里赛后本想带球回家 却被马丁内斯踢向了看台
         * mediaType : 1
         * playUrl : http://1251542705.vod2.myqcloud.com/9665f9bfvodgzp1251542705/ab681f415285890794546965484/xfWZkDfgbksA.mp4
         * showType : 0
         * userId : 999
         * newsImgs : null
         * likeCount : 9
         * commentCount : 66
         * appShowType : 3
         * user : {"id":"999","nickname":"fanatik","headImgUrl":"http://sta.5yqz2.com/static/avatar/73ff1f3e8f368b611986b9025b648471.jpg","personalDesc":null,"followerCount":null,"articleCount":null,"attentionStatus":null}
         * isLike : true
         * createdDate : 2019-10-07 11:36:12
         */

        private String id;
        private String newsId;
        private String title;
        private String imgUrl;
        private String preview;
        private int mediaType;
        private String playUrl;
        private int showType;
        private String userId;
        private List<NewsImgsBean> newsImgs;
        private int likeCount;
        private int commentCount;
        private int appShowType;
        private UserBean user;
        private boolean isLike;
        private boolean isFavorite;
        private String createdDate;
        private String showDate;
        private String webShareUrl;
        private int itemViewType;
        private boolean isTitle;
        private String reviewStatus;

        public String getWebShareUrl() {
            return webShareUrl;
        }

        public void setWebShareUrl(String webShareUrl) {
            this.webShareUrl = webShareUrl;
        }

        public String getId() {
            if (isEmpty(id)) {
                id = getNewsId();
            }
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getNewsId() {
            return newsId;
        }

        public void setNewsId(String newsId) {
            this.newsId = newsId;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getImgUrl() {
            return imgUrl;
        }

        public void setImgUrl(String imgUrl) {
            this.imgUrl = imgUrl;
        }

        public String getPreview() {
            return preview;
        }

        public void setPreview(String preview) {
            this.preview = preview;
        }

        public int getMediaType() {
            return mediaType;
        }

        public void setMediaType(int mediaType) {
            this.mediaType = mediaType;
        }

        public String getPlayUrl() {
            return playUrl;
        }

        public void setPlayUrl(String playUrl) {
            this.playUrl = playUrl;
        }

        public int getShowType() {
            return showType;
        }

        public void setShowType(int showType) {
            this.showType = showType;
        }

        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public List<NewsImgsBean> getNewsImgs() {
            return newsImgs;
        }

        public void setNewsImgs(List<NewsImgsBean> newsImgs) {
            this.newsImgs = newsImgs;
        }

        public int getLikeCount() {
            return likeCount;
        }

        public void setLikeCount(int likeCount) {
            this.likeCount = likeCount;
        }

        public int getCommentCount() {
            return commentCount;
        }

        public void setCommentCount(int commentCount) {
            this.commentCount = commentCount;
        }

        public int getAppShowType() {
            return appShowType;
        }

        public void setAppShowType(int appShowType) {
            this.appShowType = appShowType;
        }

        public UserBean getUser() {
            return user;
        }

        public void setUser(UserBean user) {
            this.user = user;
        }

        public boolean isIsLike() {
            return isLike;
        }

        public void setIsLike(boolean isLike) {
            this.isLike = isLike;
        }

        public boolean isFavorite() {
            return isFavorite;
        }

        public void setFavorite(boolean favorite) {
            isFavorite = favorite;
        }

        public String getCreatedDate() {
            return createdDate;
        }

        public void setCreatedDate(String createdDate) {
            this.createdDate = createdDate;
        }


        public boolean isLike() {
            return isLike;
        }

        public void setLike(boolean like) {
            isLike = like;
        }

        public String getShowDate() {
            return showDate;
        }

        public void setShowDate(String showDate) {
            this.showDate = showDate;
        }

        public boolean isTitle() {
            return isTitle;
        }

        public void setTitle(boolean title) {
            isTitle = title;
        }

        @Override
        public int getItemType() {
            return itemViewType;
        }

        public void setItemViewType(int itemViewType) {
            this.itemViewType = itemViewType;
        }

        public int getItemViewType() {
            return itemViewType;
        }

        public String getReviewStatus() {
            return reviewStatus==null?"":reviewStatus;
        }

        public void setReviewStatus(String reviewStatus) {
            this.reviewStatus = reviewStatus;
        }

        public static class UserBean {
            /**
             * id : 999
             * nickname : fanatik
             * headImgUrl : http://sta.5yqz2.com/static/avatar/73ff1f3e8f368b611986b9025b648471.jpg
             * personalDesc : null
             * followerCount : null
             * articleCount : null
             * attentionStatus : null
             */

            private int id;
            private String nickname;
            private String headImgUrl;
            private String personalDesc;
            private int followerCount;
            private int articleCount;
            private boolean attentionStatus;
            private int isEditor;
            private int sex;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getNickname() {
                return nickname;
            }

            public void setNickname(String nickname) {
                this.nickname = nickname;
            }

            public String getHeadImgUrl() {
                return headImgUrl;
            }

            public void setHeadImgUrl(String headImgUrl) {
                this.headImgUrl = headImgUrl;
            }

            public String getPersonalDesc() {
                return personalDesc;
            }

            public void setPersonalDesc(String personalDesc) {
                this.personalDesc = personalDesc;
            }

            public int getFollowerCount() {
                return followerCount;
            }

            public void setFollowerCount(int followerCount) {
                this.followerCount = followerCount;
            }

            public int getArticleCount() {
                return articleCount;
            }

            public void setArticleCount(int articleCount) {
                this.articleCount = articleCount;
            }

            public boolean getAttentionStatus() {
                return attentionStatus;
            }

            public void setAttentionStatus(boolean attentionStatus) {
                this.attentionStatus = attentionStatus;
            }

            public int getIsEditor() {
                return isEditor;
            }

            public void setIsEditor(int isEditor) {
                this.isEditor = isEditor;
            }

            public int getSex() {
                return sex;
            }

            public void setSex(int sex) {
                this.sex = sex;
            }
        }

        public static class NewsImgsBean {
            /**
             * content :
             * imgUrl :
             * newsId :
             */

            private String content;
            private String imgUrl;
            private String newsId;

            public String getContent() {
                return content;
            }

            public void setContent(String content) {
                this.content = content;
            }

            public String getImgUrl() {
                return imgUrl;
            }

            public void setImgUrl(String imgUrl) {
                this.imgUrl = imgUrl;
            }

            public String getNewsId() {
                return newsId;
            }

            public void setNewsId(String newsId) {
                this.newsId = newsId;
            }
        }
    }
}
