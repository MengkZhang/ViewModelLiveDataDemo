package com.yb.ballworld.information.ui.community.view;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bfw.util.ToastUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yb.ballworld.baselib.data.UserInfo;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.baselib.utils.ViewUtils;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.common.base.mvp.BaseMvpActivity;
import com.yb.ballworld.common.widget.CommonTitleBar;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.constant.FailStateConstant;
import com.yb.ballworld.information.ui.home.constant.LoadMoreType;
import com.yb.ballworld.information.ui.community.adapter.AllAuthorAdapter;
import com.yb.ballworld.information.ui.community.bean.AttentionResult;
import com.yb.ballworld.information.ui.community.bean.AuthorBeanList;
import com.yb.ballworld.information.ui.community.presenter.AuthorListPresenter;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.personal.view.InformationPersonalActivityNew;
import com.yb.ballworld.information.utils.ShareTextUitl;
import com.yb.ballworld.information.widget.ConfirmDialog;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc:  作者列表
 * Author: JS-Kylo
 * Created On: 2019/11/8 13:20
 */
public class AuthorListActivity extends BaseMvpActivity<AuthorListPresenter> {
    private SmartRefreshLayout smartRefreshLayout;
    private RecyclerView recyclerView;
    private PlaceholderView placeholder;
    private LinearLayoutManager layoutManager;
    private AllAuthorAdapter authorAdapter;
    private CommonTitleBar commonTitleBar;
    private List<AuthorBeanList.ListBean> dataList = new ArrayList<>();

    public static void startActivity(Activity activity, String userId) {
        Intent intent = new Intent(activity, AuthorListActivity.class);
        intent.putExtra("userId", userId);
        activity.startActivity(intent);
    }

    @Override
    public void initPresenter() {
        mPresenter.setVM(this);
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_author_list;
    }

    @Override
    protected void initView() {
        commonTitleBar = F(R.id.commonTitleBar);
        smartRefreshLayout = F(R.id.smartRefreshLayout);
        recyclerView = F(R.id.recyclerView);
        placeholder = F(R.id.placeholder);
        smartRefreshLayout.setRefreshHeader(getRefreshHeader());
        smartRefreshLayout.setRefreshFooter(getRefreshFooter());
        layoutManager = new LinearLayoutManager(mContext);
        recyclerView.setLayoutManager(layoutManager);
        authorAdapter = new AllAuthorAdapter(this,dataList);
        recyclerView.setAdapter(authorAdapter);
    }

    @Override
    protected void bindEvent() {
        commonTitleBar.setListener(new CommonTitleBar.OnTitleBarListener() {
            @Override
            public void onClicked(View v, int action, String extra) {
                if (action == CommonTitleBar.ACTION_LEFT_BUTTON) {
                    finish();
                }
            }
        });
        authorAdapter.setOnItemChildClickListener(new BaseQuickAdapter.OnItemChildClickListener() {
            @Override
            public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
                Object item = adapter.getItem(position);
                if (item instanceof AuthorBeanList.ListBean){
                    AuthorBeanList.ListBean bean = (AuthorBeanList.ListBean)item;
                    boolean isFocus = bean.isIsAttention();
                    if (view.getId() == R.id.tv_attention){
                        UserInfo userInfo = LoginOrdinaryUtils.INSTANCE.getUserInfo();
                        if (userInfo == null) {
                            NavigateToDetailUtil.toLogin(AuthorListActivity.this);
                            return;
                        }
                        if (ViewUtils.INSTANCE.isFastClick())
                            return;
                        if (isFocus){  //已经关注状态
                            SpannableString builder = new SpannableString("确定取消对【"+((AuthorBeanList.ListBean) item)
                            .getNickname()+"】的关注？");
                            ForegroundColorSpan colorSpan = new ForegroundColorSpan(ContextCompat.getColor(AuthorListActivity.this,R.color.color_ff6b00));
                            builder.setSpan(colorSpan,5,5+((AuthorBeanList.ListBean) item).getNickname().length()+2, Spannable.SPAN_EXCLUSIVE_INCLUSIVE);
                            String title = "“"+((AuthorBeanList.ListBean) item).getNickname()+"”";
                            new ConfirmDialog(AuthorListActivity.this, ShareTextUitl.getMarksText(title), "是否取消对ta的关注？", R.style.common_dialog,new ConfirmDialog.OnCloseListener() {
                                @Override
                                public void onClick(Dialog dialog, boolean confirm) {
                                    if (confirm){
                                        //取消关注
                                        mPresenter.cancelAttentionAuthor(bean,position);
                                    }
                                }
                            }).show();
                        }else { //未关注状态
                            // 关注
                            mPresenter.payAttentionAuthor(bean,position);
                        }
                    } else if (view.getId() == R.id.ivUserHeader || view.getId() == R.id.tv_name) {
                        if (bean != null) {
                            InformationPersonalActivityNew.startActivity(mContext, bean.getUserId() + "",InformationPersonalActivityNew.TYPE_COMMUNITY);
                        }
                    }
                }
            }
        });
        initRefreshLoadMoreEvent();
        initReLoadEvent();
    }

    /**
     * 关注成功
     */
    public void attentionSucceed(AttentionResult result, int position){
        AuthorBeanList.ListBean bean = dataList.get(position);
        bean.setIsAttention(true);
        bean.setFollowerCount(result.getFollowerCount());
        authorAdapter.notifyItemChanged(position);
        ToastUtils.showToast("已关注");
        //ToastUtils.INSTANCE.showInfo("已关注");
    }

    /**
     * 取消关注成功
     */
    public void cancelAttentionSucceed(AttentionResult result, int position){
        AuthorBeanList.ListBean bean = dataList.get(position);
        bean.setIsAttention(false);
        bean.setFollowerCount(result.getFollowerCount());
        authorAdapter.notifyItemChanged(position);
        ToastUtils.showToast("已取消");
    }
    /**
     * 关注成功
     */
    /*public void attentionSucceed(AuthorBeanList.ListBean bean, int position){
        bean.setIsAttention(true);
        int followCount = bean.getFollowerCount();
        bean.setFollowerCount(followCount+1);
        authorAdapter.notifyItemChanged(position);
        ToastUtils.INSTANCE.showToast("已关注");
        //ToastUtils.INSTANCE.showInfo("已关注");
    }*/

    /**
     * 取消关注成功
     */
   /* public void cancelAttentionSucceed(AuthorBeanList.ListBean bean, int position){
        bean.setIsAttention(false);
        int followCount = bean.getFollowerCount();
        if (followCount>0)
                followCount = followCount-1;
        else
            followCount = 0;
        bean.setFollowerCount(followCount);
        authorAdapter.notifyItemChanged(position);
        ToastUtils.INSTANCE.showToast("已取消");
    }*/

    @Override
    protected void initData() {
        mPresenter.loadAuthorList(1);
    }

    @Override
    protected void processClick(View view) {

    }

    /**
     * 请求中
     */
    public void requestLoading() {
        placeholder.showLoading();
        smartRefreshLayout.setEnableRefresh(false);
        smartRefreshLayout.setEnableLoadMore(false);
    }

    /**
     * 请求成功回调
     * @param data 列表数据
     */
    public void resultSuccess(List<AuthorBeanList.ListBean> data) {
        placeholder.hideLoading();
        smartRefreshLayout.setEnableRefresh(true);
        smartRefreshLayout.setEnableLoadMore(true);
        dataList.clear();
        dataList.addAll(data);
        authorAdapter.notifyDataSetChanged();
    }

    /**
     * 请求失败回调
     */
    public void resultFail(int type) {
        switch (type) {
            case FailStateConstant.TYPE_ERROR:   //加载失败
                placeholder.showError("加载失败");
                break;
            case FailStateConstant.TYPE_EMPTY:   //数据为空
                smartRefreshLayout.setEnableRefresh(true);
                placeholder.showEmpty("暂无数据");
                break;

            default:
                break;
        }
    }


    /**
     * 刷新成功
     */
    public void resultRefreshSuccess() {
        //Toast.makeText(this, "刷新成功", Toast.LENGTH_SHORT).show();
        smartRefreshLayout.finishRefresh();
        //刷新成功清理存储的数组
        dataList.clear();
    }

    /**
     * 刷新失败
     */
    public void resultRefreshFail(String errorMsg) {
        smartRefreshLayout.finishRefresh();
    }

    /**
     * 加载更多成功
     */
    public void resultLoadMoreSuccess(int type) {
        smartRefreshLayout.finishLoadMore();
        switch (type) {
            case LoadMoreType.TYPE_SUCCESS:      //加载成功
                break;

            case LoadMoreType.TYPE_ALL_DATA:     //已经全部加载
                ToastUtils.showToast("已经全部加载");
                //已经全部加载 就不允许继续上拉加载了
                smartRefreshLayout.setEnableLoadMore(false);
                break;

            default:
                break;
        }
    }

    /**
     * 加载更多失败
     */
    public void resultLoadMoreFail(String errorMsg) {
        smartRefreshLayout.finishLoadMore();
    }

    /**
     * 初始化刷新和加载更多
     */
    private void initRefreshLoadMoreEvent() {
        smartRefreshLayout.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                mPresenter.loadMoreData();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                mPresenter.refreshData();
            }
        });
    }

    /**
     * 初始化重新加载数据
     */
    private void initReLoadEvent() {
        placeholder.setPageErrorRetryListener(v -> mPresenter.loadAuthorList(1));
    }

}
