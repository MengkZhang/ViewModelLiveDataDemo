package com.yb.ballworld.information.ui.home.presenter;

import android.app.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.yb.ballworld.information.ui.community.bean.Topic;
import com.yb.ballworld.information.ui.home.bean.FileDataBean;
import com.yb.ballworld.information.ui.home.bean.InfoPublishImgBean;
import com.yb.ballworld.information.ui.home.bean.PublishCommentReqBean;
import com.yb.ballworld.information.ui.home.bean.PublishCommentResBean;
import com.yb.ballworld.information.ui.home.bean.TabEntity;

import java.io.File;
import java.util.List;

/**
 * Desc 发表评论协议类
 * Date 2019/10/7
 * author mengk
 */
public class PublishCommentContract {

    //--------------------------------View层----------------------------
    public interface IInfoPublishCommentView {

        AppCompatActivity getActivity();

        //请求加载中
        void requestLoading();

        //请求失败
        void resultUploadFileFail(int type);

        //请求成功
        void resultUploadFileSuccess(PublishCommentResBean data);
        // 社区成功返回
        void resultUploadFileSuccess(Topic topic);

    }

    //--------------------------------Presenter层----------------------------
    public interface IPublishCommentPresenter {

        //上传图片
        void uploadFile(List<File> mFiles,String type);

        //上传视频
        void uploadVideoFile(File faceImgFile,File videoFile,String type);

        //发表评论
//        void publishComment(String newsId,String content,String replyId,List<String> images);
        void publishComment(PublishCommentReqBean bean,List<String> images);

        //绑定View
        void attachView(IInfoPublishCommentView view);

    }

}
