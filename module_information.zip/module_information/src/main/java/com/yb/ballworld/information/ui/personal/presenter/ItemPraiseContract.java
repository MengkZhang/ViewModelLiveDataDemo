package com.yb.ballworld.information.ui.personal.presenter;

import com.yb.ballworld.information.ui.personal.constant.PraiseCallbackListener;

/**
 * Desc 资讯点赞协议类
 * Date 2019/10/7
 * author mengk
 */
public class ItemPraiseContract {


    //--------------------------------Presenter层----------------------------
    public interface IItemPraisePresenter {

        //请求数据方法
        void loadData(String newsId,String commentId, PraiseCallbackListener callBack);

    }


}
