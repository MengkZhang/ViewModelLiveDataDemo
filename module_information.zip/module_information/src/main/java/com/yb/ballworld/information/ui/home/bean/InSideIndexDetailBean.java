package com.yb.ballworld.information.ui.home.bean;

/**
 * Desc 外层索引列表数据
 * Date 2019/11/7
 * author mengk
 */
public class InSideIndexDetailBean {

    /**
     * id : 566
     * matchCount : 1
     * cnAlias : 英南超
     * headLetter : Y
     * isHot : 0
     */

    private int id;
    private int matchCount;
    private String cnAlias;
    private String headLetter;
    private int isHot;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMatchCount() {
        return matchCount;
    }

    public void setMatchCount(int matchCount) {
        this.matchCount = matchCount;
    }

    public String getCnAlias() {
        return cnAlias;
    }

    public void setCnAlias(String cnAlias) {
        this.cnAlias = cnAlias;
    }

    public String getHeadLetter() {
        return headLetter;
    }

    public void setHeadLetter(String headLetter) {
        this.headLetter = headLetter;
    }

    public int getIsHot() {
        return isHot;
    }

    public void setIsHot(int isHot) {
        this.isHot = isHot;
    }
}
