package com.yb.ballworld.information.ui.home.constant;

import androidx.annotation.IntDef;
import androidx.annotation.StringDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Desc
 * Date 2019/11/21
 * author mengk
 */
@StringDef({
        InfoSpecialPushParams.RECEIPT_KEY_STATUS,
        InfoSpecialPushParams.RECEIPT_KEY_SCORE,
        InfoSpecialPushParams.ID_TAG
})

@Retention(RetentionPolicy.SOURCE)

public @interface InfoSpecialPushParams {
    String RECEIPT_KEY_STATUS = "info_hot_special_receipt_key_status";
    String RECEIPT_KEY_SCORE = "info_hot_special_receipt_key_score";
    String ID_TAG = "info_hot_special_id_tag";
}
