package com.yb.ballworld.information.ui.home.adapter;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.util.DensityUtil;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.bean.JumpBean;
import com.yb.ballworld.information.ui.home.constant.ImgSupportType;
import com.yb.ballworld.information.ui.home.utils.GlideLoadImgUtil;

import java.util.List;

/**
 * Desc cell图片适配器 兼容类
 * Date 2019/10/10
 * author mengk
 */
public class CellImgSupportAdapter extends BaseQuickAdapter<String, BaseViewHolder> {

    private List<String> data;
    //0 单图 1 双图 2 三图 3 多图
    private boolean isSingle;

    public CellImgSupportAdapter(@Nullable List<String> data, boolean isSingle) {
        super(isSingle ? R.layout.cell_img_list_just_one_new : R.layout.item_img_face, data);
        this.data = data;
        this.isSingle = isSingle;
    }

    @Override
    public int getItemCount() {
        int size = data.size();
        if (size > 0) {
            if (isSingle) {
                return 1;
            } else {
                if (size >= 2 && size <= 3) {
                    return size;
                } else if (size > 3 && size <= 6) {
                    return 6;
                } else if (size > 6) {
                    return 6;
                }
            }
        }
        return 0;
    }

    @Override
    protected void convert(BaseViewHolder helper, String item, int pos) {
        if (isSingle) { //单张
            ImageView imageView = helper.getView(R.id.iv_img_multi);
            GlideLoadImgUtil.loadImg(mContext, item, imageView);
            helper.addOnClickListener(R.id.iv_img_multi);

        } else {        //双图 三图 和多图

            int size = data.size();
            ImageView imageView = helper.getView(R.id.iv_img_multi);
            TextView tvTotal = helper.getView(R.id.tv_total_img_info);
            if (size > 6) {
                if (pos == getItemCount() - 1) {
                    tvTotal.setVisibility(View.VISIBLE);
                    StringBuilder sb = new StringBuilder();
                    sb.append("共").append(size).append("张");
                    tvTotal.setText(sb.toString());
                } else {
                    tvTotal.setVisibility(View.GONE);
                }
            } else {
                tvTotal.setVisibility(View.GONE);
            }
            GlideLoadImgUtil.loadImg(mContext, item, imageView);
            helper.addOnClickListener(R.id.iv_img_multi);

            RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) (helper.getView(R.id.cv_img_face)).getLayoutParams();
            if (size <= 3) {
                layoutParams.topMargin = 0;
            } else {
                layoutParams.topMargin = DensityUtil.dp2px(6);
            }

        }

    }
}
