//package com.yb.ballworld.information.ui.home.view;
//
//import android.graphics.Color;
//import android.os.Bundle;
//import android.util.Log;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import androidx.annotation.NonNull;
//import androidx.recyclerview.widget.LinearLayoutManager;
//import androidx.recyclerview.widget.RecyclerView;
//
//import com.scwang.smartrefresh.layout.SmartRefreshLayout;
//import com.scwang.smartrefresh.layout.api.RefreshFooter;
//import com.scwang.smartrefresh.layout.api.RefreshHeader;
//import com.scwang.smartrefresh.layout.api.RefreshLayout;
//import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
//import com.yb.ballworld.baselib.base.fragment.BasePageFragment;
//import com.yb.ballworld.baselib.base.recycler.decorate.DividerItemDecoration;
//import com.yb.ballworld.baselib.base.recycler.header.PlayBallHeader;
//import com.yb.ballworld.baselib.base.recycler.header.RecyclerClassicsFooter;
//import com.yb.ballworld.baselib.utils.ViewUtils;
//import com.yb.ballworld.baselib.widget.placeholder.HomePlaceholderView;
//import com.yb.ballworld.information.R;
//import com.yb.ballworld.information.ui.home.adapter.InfoHotAdapter;
//import com.yb.ballworld.information.ui.home.bean.HomeIndexBannerBean;
//import com.yb.ballworld.information.ui.home.bean.HomeIndexHotRunBean;
//import com.yb.ballworld.information.ui.home.bean.HomeInfoListBean;
//import com.yb.ballworld.information.ui.home.constant.FailStateConstant;
//import com.yb.ballworld.information.ui.home.constant.HotVideoType;
//import com.yb.ballworld.information.ui.home.constant.LoadMoreType;
//import com.yb.ballworld.information.ui.home.presenter.InfoContract;
//import com.yb.ballworld.information.ui.home.presenter.InfoPresenter;
//
//import java.util.ArrayList;
//import java.util.List;
//
///**
// * Desc 资讯fragment（除热门和视频外的其他fragment）
// * Date 2019/10/7
// * author mengk
// */
//public class InformationFragment extends BasePageFragment implements InfoContract.IInfoView {
//
//    //fragment传递参数的key
//    private static final String INFO_TYPE = "typeIndex";
//    //type banner类型
//    private static final String INFO_BANNER = "typeBanner";
//    //type 子弹推类型
//    private static final String INFO_HOT_RUN = "typeHotRun";
//
//    //fragment区分的索引
//    private int index;
//
//    //数据
//    private List<HomeInfoListBean> dataList = new ArrayList<>();
//    //adapter
//    private InfoHotAdapter adapter;
//
//    //刷新控件
//    private SmartRefreshLayout smartRefreshLayout;
//    //列表控件
//    private RecyclerView recyclerView;
//    //缺省图状态控件
//    private HomePlaceholderView placeholder;
//    //layoutManager
//    private LinearLayoutManager layoutManager;
//    //presenter
//    private InfoPresenter presenter;
//
//    public static InformationFragment newInstance(int index, ArrayList<HomeIndexBannerBean> banner, ArrayList<HomeIndexHotRunBean> hotRun) {
//        InformationFragment fragment = new InformationFragment();
//        Bundle bundle = new Bundle();
//        bundle.putInt(INFO_TYPE, index);
//        bundle.putParcelableArrayList(INFO_BANNER, banner);
//        bundle.putParcelableArrayList(INFO_HOT_RUN, hotRun);
//        fragment.setArguments(bundle);
//        return fragment;
//    }
//
//    public static InformationFragment newInstance(int index) {
//        InformationFragment fragment = new InformationFragment();
//        Bundle bundle = new Bundle();
//        bundle.putInt(INFO_TYPE, index);
//        fragment.setArguments(bundle);
//        return fragment;
//    }
//
//    @Override
//    protected void initView() {
//        super.initView();
//        initArguments();
//        initViews();
//    }
//
//    @Override
//    protected void initData() {
//        super.initData();
//        //初始化presenter
//        presenter = new InfoPresenter(HotVideoType.TYPE_NEWS);
//        presenter.attachView(this);
//        presenter.loadData(1);
//    }
//
//
//    /**
//     * 初始化参数
//     */
//    private void initArguments() {
//        Bundle bundle = getArguments();
//        if (bundle == null) return;
//        index = bundle.getInt(INFO_TYPE);
////        mHomeIndexBannerBeanList = bundle.getParcelableArrayList(INFO_BANNER);
////        mHomeIndexHotRunBeanList = bundle.getParcelableArrayList(INFO_HOT_RUN);
//    }
//
//    private void initViews() {
//        placeholder = findView(R.id.placeholder);
//        recyclerView = findView(R.id.recyclerView);
//        //设置分割线
////        recyclerView.addItemDecoration(getDividerItemDecoration());
//        smartRefreshLayout = findView(R.id.smartRefreshLayout);
//        smartRefreshLayout.setRefreshHeader(getRefreshHeader());
//        smartRefreshLayout.setRefreshFooter(getRefreshFooter());
//        layoutManager = new LinearLayoutManager(getPageActivity());
//        recyclerView.setLayoutManager(layoutManager);
//        adapter = new InfoHotAdapter(dataList);
//        recyclerView.setAdapter(adapter);
//    }
//
//    @Override
//    protected void initEvent() {
//        super.initEvent();
//        initRefreshLoadMoreEvent();
//        initReLoadEvent();
//    }
//
//    /**
//     * 初始化重新加载数据
//     */
//    private void initReLoadEvent() {
//        placeholder.setPageErrorRetryListener(v -> presenter.loadData(1));
//    }
//
//    /**
//     * 初始化刷新和加载更多
//     */
//    private void initRefreshLoadMoreEvent() {
//        smartRefreshLayout.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
//            @Override
//            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
//                presenter.loadMoreData();
//            }
//
//            @Override
//            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
//                presenter.refreshData();
//            }
//        });
//    }
//
//
//    /**
//     * 获取分割线
//     *
//     * @return 分割线
//     */
//    private DividerItemDecoration getDividerItemDecoration() {
//        return new DividerItemDecoration(getColor(R.color.grey_f8),
//                ViewUtils.dp2px(7), 0, 0,
//                Color.TRANSPARENT).setDrawFirstDivider(true).setDrawLatDivider(true).setDrawLastItem(true);
//    }
//
//    /**
//     * 获取刷新头部
//     *
//     * @return 头部
//     */
//    private RefreshHeader getRefreshHeader() {
//        return new PlayBallHeader(getPageActivity()).createAnim(PlayBallHeader.FOOTBALL);
//    }
//
//    /**
//     * 获取刷新底部
//     *
//     * @return 底部
//     */
//    private RefreshFooter getRefreshFooter() {
//        return new RecyclerClassicsFooter(getPageActivity());
//    }
//
//    @Override
//    public int getLayoutResID() {
//        return R.layout.fragment_info;
//    }
//
//    @Override
//    public void setTextSize(int id, Float size) {
//
//    }
//
//    @Override
//    public void setTextSize(TextView textView, Float size) {
//
//    }
//
//    @Override
//    public void requestLoading() {
//        showLoading(placeholder);
//        smartRefreshLayout.setEnableRefresh(false);
//        smartRefreshLayout.setEnableLoadMore(false);
//    }
//
//    /**
//     * 请求成功回调
//     *
//     * @param data 列表数据
//     */
//    @Override
//    public void resultSuccess(List<HomeInfoListBean> data) {
//        LogUtils.INSTANCE.e("===z", "列表数据长度data = " + data.size());
//        placeholder.hideLoading();
//        smartRefreshLayout.setEnableRefresh(true);
//        smartRefreshLayout.setEnableLoadMore(true);
//        dataList.clear();
//        dataList.addAll(data);
//        adapter.notifyDataSetChanged();
//    }
//
//    /**
//     * 加载失败
//     *
//     * @param type 失败的类型
//     */
//    @Override
//    public void resultFail(int type) {
//        switch (type) {
//            case FailStateConstant.TYPE_ERROR:   //加载失败
//                showError(placeholder, "加载失败");
//                break;
//            case FailStateConstant.TYPE_EMPTY:   //数据为空
//                showEmpty(placeholder, "暂无数据");
//                break;
//
//            default:
//                break;
//        }
//    }
//
//    /**
//     * 刷新成功回调
//     */
//    @Override
//    public void resultRefreshSuccess() {
//        Toast.makeText(getPageActivity(), "刷新成功", Toast.LENGTH_SHORT).show();
//        smartRefreshLayout.finishRefresh();
//        //刷新成功清理存储的数组
//        dataList.clear();
//    }
//
//    /**
//     * 刷新失败回调
//     *
//     * @param errorMsg 失败信息
//     */
//    @Override
//    public void resultRefreshFail(String errorMsg) {
//        Toast.makeText(getPageActivity(), "刷新失败", Toast.LENGTH_SHORT).show();
//        smartRefreshLayout.finishRefresh();
//    }
//
//    /**
//     * 加载更多成功
//     *
//     * @param type 成功类型
//     */
//    @Override
//    public void resultLoadMoreSuccess(int type) {
//        smartRefreshLayout.finishLoadMore();
//        switch (type) {
//            case LoadMoreType.TYPE_SUCCESS:      //加载成功
//                Toast.makeText(getPageActivity(), "加载更多成功", Toast.LENGTH_SHORT).show();
//                break;
//
//            case LoadMoreType.TYPE_ALL_DATA:     //已经全部加载
//                Toast.makeText(getPageActivity(), "已经全部加载", Toast.LENGTH_SHORT).show();
//                break;
//
//            default:
//                break;
//        }
//    }
//
//    /**
//     * 加载更多失败
//     *
//     * @param errorMsg 失败信息
//     */
//    @Override
//    public void resultLoadMoreFail(String errorMsg) {
//        Toast.makeText(getPageActivity(), "加载更多失败", Toast.LENGTH_SHORT).show();
//        smartRefreshLayout.finishLoadMore();
//    }
//}
