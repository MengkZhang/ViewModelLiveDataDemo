package com.yb.ballworld.information.ui.auth.adapter;

import android.view.View;
import android.widget.ImageView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.util.DensityUtil;
import com.yb.ballworld.baselib.utils.ImageManager;
import com.yb.ballworld.common.baseapp.AppContext;
import com.yb.ballworld.common.utils.ScreenUtils;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.auth.data.AuthImgBean;

import java.util.List;

/**
 * @author Gethin
 * @time 2019/11/8 13:25
 */

public class AuthImgAdapter extends BaseQuickAdapter<AuthImgBean, BaseViewHolder> {

    private int itemWidth;

    public AuthImgAdapter() {
        super(R.layout.item_auth_img);
        itemWidth = (ScreenUtils.getScreenWidth(AppContext.getAppContext()) - DensityUtil.dp2px(36))/3;
    }

    @Override
    protected void convert(BaseViewHolder helper, AuthImgBean item, int pos) {
        ImageView ivAuthImg = helper.getView(R.id.ivAuthImg);
        ImageView ivDelete = helper.getView(R.id.ivDelete);
        if (item.getUri() == null) {
            ivAuthImg.setScaleType(ImageView.ScaleType.FIT_XY);
            ImageManager.INSTANCE.loadReportRoundIcon(item.getUri(), (int) mContext.getResources().getDimension(R.dimen.dp_5), ivAuthImg);
            ivDelete.setVisibility(View.GONE);
        } else {
            ivAuthImg.setScaleType(ImageView.ScaleType.CENTER_CROP);
            ImageManager.INSTANCE.loadReportRoundIcon(item.getUri(), (int) mContext.getResources().getDimension(R.dimen.dp_5),  ivAuthImg);
            ivDelete.setVisibility(View.VISIBLE);
        }
        ivDelete.setOnClickListener(v -> {
            List<AuthImgBean> data = getData();
            if (listener != null) {
                listener.onChanged(data, pos);
            }
        });
    }

    private DataChangedListener listener = null;
    public void setOnDataChangedListener(DataChangedListener listener) {
        this.listener = listener;
    }

    public interface DataChangedListener{
        void onChanged(List<AuthImgBean> data, int pos);
    }
}
