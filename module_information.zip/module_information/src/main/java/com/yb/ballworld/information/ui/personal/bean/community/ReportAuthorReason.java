package com.yb.ballworld.information.ui.personal.bean.community;

/**
 * Desc:
 * Author: JS-Kylo
 * Created On: 2019/11/12 21:49
 */
public class ReportAuthorReason {

    /**
     * id : 0
     * reason :
     * reportType : 0
     * sort : 0
     */

    private int id;
    private String reason;
    private int reportType;
    private int sort;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public int getReportType() {
        return reportType;
    }

    public void setReportType(int reportType) {
        this.reportType = reportType;
    }

    public int getSort() {
        return sort;
    }

    public void setSort(int sort) {
        this.sort = sort;
    }
}
