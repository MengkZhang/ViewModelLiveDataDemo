package com.yb.ballworld.information.ui.home.utils;

import android.text.TextUtils;
import android.util.Log;

import com.yb.ballworld.information.ui.home.widget.bfrich.RichTextEditor;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;
import java.util.Map;

/**
 * Desc
 * Date 2019/11/5
 * author mengk
 */
public class EditDataUtil {
    /**
     * 负责处理编辑数据提交等事宜
     */
    public static String getEditDataJsonArrays(RichTextEditor mRichTextEditor) {
        StringBuilder content = new StringBuilder();
        JSONArray jsonArray = new JSONArray();
        try {
            List<RichTextEditor.EditData> editList = mRichTextEditor.buildEditData();
            int length = editList.size();
            for (int i = 0; i < length; i++) {
                String inputStr = editList.get(i).inputStr;
                String imagePath = editList.get(i).imagePath;
                if (inputStr != null) {
                    if ((i == length - 1 && !TextUtils.isEmpty(inputStr)) || i < length - 1) {
                        content.append(inputStr);
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("txt", inputStr);
                        jsonArray.put(jsonObject);
                    }
                } else if (imagePath != null) {
                    content.append("<img src=\"").append(imagePath).append("\"/>");
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("img", imagePath);
                    jsonArray.put(jsonObject);
                }

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsonArray.toString();
    }


    /**
     * 负责处理编辑数据提交等事宜
     */
    public static String getEditData(RichTextEditor mRichTextEditor) {
        StringBuilder content = new StringBuilder();
        try {
            List<RichTextEditor.EditData> editList = mRichTextEditor.buildEditData();
            for (RichTextEditor.EditData itemData : editList) {
                if (itemData.inputStr != null) {
                    content.append(itemData.inputStr);
                } else if (itemData.imagePath != null) {
                    content.append("<img src=\"").append(itemData.imagePath).append("\"/>");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return content.toString();
    }

    /**
     * 负责处理编辑数据提交等事宜
     */
    public static String getUploadData(RichTextEditor mRichTextEditor, Map<String, String> map) {
        StringBuilder content = new StringBuilder();
        try {
            List<RichTextEditor.EditData> editList = mRichTextEditor.buildEditData();
            for (RichTextEditor.EditData itemData : editList) {
                if (itemData.inputStr != null) {
//                    content.append(itemData.inputStr);
                    content.append("<p>").append(itemData.inputStr).append("</p>");
                } else if (itemData.imagePath != null) {
                    content.append("<img src=\"").append(map.get(itemData.imagePath)).append("\"/>");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return content.toString();
    }

    /**
     * 判断富文本是否为空
     * @param richContent
     * @return
     */
    public static boolean judgeRichContentNotEmpty(String richContent) {
        if (!TextUtils.isEmpty(richContent)) {
            return !"[]".equals(richContent);
        }
        return false;
    }
}
