package com.yb.ballworld.information.ui.home.utils;

import android.content.Context;

import com.yb.ballworld.information.ui.home.adapter.InfoShareAdapter;
import com.yb.ballworld.information.ui.home.bean.InfoShareBean;
import com.yb.ballworld.information.ui.home.widget.InfoShareDialog;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc 分享帮助类
 * Date 2019/10/19
 * author mengk
 */
public class InfoShareUtil {
    public static void share(Context context) {
        InfoShareDialog dialog = new InfoShareDialog(context);
        dialog.show();
    }


}
