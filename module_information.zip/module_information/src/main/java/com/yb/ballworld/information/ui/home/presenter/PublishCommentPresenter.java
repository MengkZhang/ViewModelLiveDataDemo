package com.yb.ballworld.information.ui.home.presenter;

import android.text.TextUtils;
import android.util.Log;

import com.bfw.util.ToastUtils;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.information.ui.home.bean.FileDataBean;
import com.yb.ballworld.information.ui.home.bean.InfoPublishImgBean;
import com.yb.ballworld.information.ui.home.bean.PublishCommentReqBean;
import com.yb.ballworld.information.ui.home.bean.PublishCommentResBean;
import com.yb.ballworld.information.ui.home.constant.FailStateConstant;
import com.yb.ballworld.information.ui.home.service.InfoHttpApi;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Desc
 * Date 2019/10/20
 * author mengk
 */
public class PublishCommentPresenter implements PublishCommentContract.IPublishCommentPresenter {
    private InfoHttpApi httpApi;
    protected PublishCommentContract.IInfoPublishCommentView mView;
    private int count = 0;
    private int successCount = 0;
    private PublishCommentReqBean bean;

    /**
     * 设置请求参数实体
     * @param bean 请求参数
     */
    public void setParamsBean(PublishCommentReqBean bean) {
        this.bean = bean;
    }

   public PublishCommentPresenter() {
        httpApi = new InfoHttpApi();
    }

    @Override
    public void uploadFile(List<File> mFiles, String type) {
        List<String> images = new ArrayList<>();
        int length = mFiles.size();
        mView.requestLoading();
        for (File mFile : mFiles) {
            httpApi.uploadFile(mFile, type,1,
                    new LifecycleCallback<FileDataBean>(mView.getActivity()) {
                        @Override
                        public void onSuccess(FileDataBean data) {
                            if (data != null) {    //data不为空

                                String imgUrl = data.getImgUrl();
                                if (!TextUtils.isEmpty(imgUrl)) {
                                    images.add(imgUrl);
                                    LogUtils.INSTANCE.e("===z", "img URL = " + imgUrl);
                                    countImgs(length, true, images);
                                } else {
                                    mView.resultUploadFileFail(FailStateConstant.TYPE_EMPTY);
                                }

                            } else {               //data为空

                                mView.resultUploadFileFail(FailStateConstant.TYPE_EMPTY);

                            }
                        }

                        @Override
                        public void onFailed(int errCode, String errMsg) {
                            LogUtils.INSTANCE.e("===z", "上传失败");
                            countImgs(length, false, null);
                            mView.resultUploadFileFail(FailStateConstant.TYPE_ERROR);
                        }
                    });
        }
    }

    /**
     * 长传视频文件
     * @param faceImgFile
     * @param videoFile
     * @param type
     */
    @Override
    public void uploadVideoFile(File faceImgFile, File videoFile, String type) {
        if (videoFile != null && videoFile.exists() &&
                videoFile.length() > 50 * 1024 * 1024) {
            mView.resultUploadFileFail(3);
            ToastUtils.showToast("视频大于50M");
            return;
        }
        mView.requestLoading();
        httpApi.uploadFile(faceImgFile, type,1,
                new LifecycleCallback<FileDataBean>(mView.getActivity()) {
                    @Override
                    public void onSuccess(FileDataBean data) {
                        if (data != null) {  //data不为空

                            //上传成功
                            String videoCoverUrl = data.getImgUrl();
                            if (!TextUtils.isEmpty(videoCoverUrl)) {
                                //上传视频
                                mView.requestLoading();
                                httpApi.uploadFile(videoFile, type,0,
                                        new LifecycleCallback<FileDataBean>(mView.getActivity()) {
                                            @Override
                                            public void onSuccess(FileDataBean data) {
                                                //上传视频成功
                                                String videoUrl = data.getImgUrl();
                                                if (videoUrl != null) {
                                                    publishComment(bean,videoCoverUrl,videoUrl);
                                                } else {//返回视频为空
                                                    mView.resultUploadFileFail(FailStateConstant.TYPE_EMPTY);
                                                }
                                            }

                                            @Override
                                            public void onFailed(int errCode, String errMsg) {
                                                //上传视频失败
                                                mView.resultUploadFileFail(FailStateConstant.TYPE_ERROR);
                                            }
                                        });
                            } else {//封面为空

                                mView.resultUploadFileFail(FailStateConstant.TYPE_EMPTY);

                            }

                        } else {             //data为空

                            mView.resultUploadFileFail(FailStateConstant.TYPE_EMPTY);

                        }
                    }

                    @Override
                    public void onFailed(int errCode, String errMsg) {
                        LogUtils.INSTANCE.e("===z", "上传封面失败");
                        mView.resultUploadFileFail(FailStateConstant.TYPE_ERROR);
                    }
                });
    }

    /**
     * 发表评论
     *
     */
    @Override
    public void publishComment(PublishCommentReqBean bean,List<String> images) {
        if (bean == null) return;
        mView.requestLoading();
        String img1;
        String img2;
        String img3;
        if (images != null && images.size() > 0) {//有图片
            if (images.size() == 1) {
                img1 = images.get(0);
                img2 = "";
                img3 = "";
            } else if (images.size() == 2) {
                img1 = images.get(0);
                img2 = images.get(1);
                img3 = "";
            } else {
                img1 = images.get(0);
                img2 = images.get(1);
                img3 = images.get(2);
            }
        } else {//没有图片
            img1 = "";
            img2 = "";
            img3 = "";
        }
        httpApi.saveComment(bean.getId(),
                bean.getCommentType(),
                bean.getCreatedBy(),
                bean.getCreatedDate(),
                bean.getLastModifiedBy(),
                bean.getLastModifiedDate(),
                bean.getLikeCount(),
                bean.getMainCommentId(),
                bean.getNickName(),
                bean.getUserId(),
                bean.getNewsId(),
                bean.getContent(),
                img1,
                img2,
                img3,
                bean.getReplyId(),
                bean.getVideoUrl(),
                "",
                new LifecycleCallback<PublishCommentResBean>(mView.getActivity()) {
            @Override
            public void onSuccess(PublishCommentResBean data) {
                if (data != null) {
                    mView.resultUploadFileSuccess(data);
                } else {
                    mView.resultUploadFileFail(FailStateConstant.TYPE_EMPTY);
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                LogUtils.INSTANCE.e("===", "发表 data = 失败");
                mView.resultUploadFileFail(FailStateConstant.TYPE_ERROR);
            }
        });

    }

    /**
     *
     */
    protected void publishComment(PublishCommentReqBean bean,String videoCoverUrl,String videoUrl) {
        if (bean == null) return;
        mView.requestLoading();
        httpApi.saveComment(bean.getId(),
                bean.getCommentType(),
                bean.getCreatedBy(),
                bean.getCreatedDate(),
                bean.getLastModifiedBy(),
                bean.getLastModifiedDate(),
                bean.getLikeCount(),
                bean.getMainCommentId(),
                bean.getNickName(),
                bean.getUserId(),
                bean.getNewsId(),
                bean.getContent(),
                "",
                "",
                "",
                bean.getReplyId(),
                videoUrl,
                videoCoverUrl,
                new LifecycleCallback<PublishCommentResBean>(mView.getActivity()) {
            @Override
            public void onSuccess(PublishCommentResBean data) {
                if (data != null) {
                    mView.resultUploadFileSuccess(data);
                } else {
                    mView.resultUploadFileFail(FailStateConstant.TYPE_EMPTY);
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                LogUtils.INSTANCE.e("===", "发表 data = 失败");
                mView.resultUploadFileFail(FailStateConstant.TYPE_ERROR);
            }
        });

    }

    /**
     * 统计了上传的张数 只有全部上传成功之后 才会走提交接口
     *
     * @param total
     * @param success
     * @param images
     */
    private void countImgs(int total, boolean success, List<String> images) {
        count += 1;
        if (success) {
            successCount += 1;
        }
        if (count >= total) {
            if (successCount >= total) {
                LogUtils.INSTANCE.e("===z", "全部上传成功 走提交接口 successCount = " + successCount);
//                publishComment(newsId, content, replyId, images);
                publishComment(bean, images);
            }
            count = 0;
            successCount = 0;
        }
    }


    @Override
    public void attachView(PublishCommentContract.IInfoPublishCommentView view) {
        this.mView = view;
    }
}
