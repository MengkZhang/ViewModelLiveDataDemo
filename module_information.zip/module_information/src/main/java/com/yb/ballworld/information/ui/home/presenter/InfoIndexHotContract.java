package com.yb.ballworld.information.ui.home.presenter;

import androidx.fragment.app.Fragment;

import com.yb.ballworld.information.ui.home.bean.HomeIndexBannerBean;
import com.yb.ballworld.information.ui.home.bean.HomeIndexHotRunBean;
import com.yb.ballworld.information.ui.home.bean.HomeIndexSpecialBean;
import com.yb.ballworld.information.ui.home.bean.HomeIndexTopBean;
import com.yb.ballworld.information.ui.home.bean.HomeInfoListBean;
import com.yb.ballworld.information.ui.home.bean.IndexHotEntity;

import java.util.List;

/**
 * Desc 资讯首页热门协议类
 * Date 2019/10/7
 * author mengk
 */
public class InfoIndexHotContract {

    //--------------------------------View层----------------------------
    public interface IInfoIndexHotView {

        Fragment getFragment();

        //请求加载中
        void requestLoading();

        //请求成功
        void resultSuccess(List<IndexHotEntity.NewsBean.ListBean> data, int page);

        //请求失败
        void resultFail(int type);

        //刷新成功
        void resultRefreshSuccess();

        //刷新失败
        void resultRefreshFail(String errorMsg);

        //加载更多成功
        void resultLoadMoreSuccess(int type);

        //加载更多失败
        void resultLoadMoreFail(String errorMsg);

        //加载banner成功
        void resultBannerSuccess(List<HomeIndexBannerBean> bannerBeans);
        //加载banner失败

        void resultBannerFail(int page);
        //加载子弹推成功

        void resultHotRunSuccess(List<HomeIndexHotRunBean> hotRunBeans);

        //加载子弹推失败
        void resultHotRunFail(int page);

        //加载专栏数据成功
        void resultSpecialSuccess(IndexHotEntity.SpecialBlocksBean specialBeans);

        //加载专栏失败
        void resultSpecialFail(int page);

        //加载置顶成功
//        void resultTopSuccess(List<HomeIndexTopBean> topBeans);
//        void resultTopSuccess(List<HomeInfoListBean> topBeans);
        void resultTopSuccess(List<IndexHotEntity.NewsTopBlocksBean> topBeans);

        //加载置顶失败
        void resultTopFail(int page);
    }

    //--------------------------------Presenter层----------------------------
    public interface IInfoIndexHotPresenter {

        //请求数据方法
        void loadData(int page);

        //刷新
        void refreshData();

        //加载更多
        void loadMoreData();

        //绑定View
        void attachView(IInfoIndexHotView view);

        //解绑View
        void detachView();
    }

}
