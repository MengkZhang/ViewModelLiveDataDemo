package com.yb.ballworld.information.ui.personal.presenter;

import android.content.Intent;
import android.util.Log;

import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.MutableLiveData;

import com.google.gson.Gson;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.livedata.LiveDataResult;
import com.yb.ballworld.information.http.InforMationHttpApi;
import com.yb.ballworld.information.http.PersonalHttpApi;
import com.yb.ballworld.information.ui.personal.bean.Follow;
import com.yb.ballworld.information.ui.personal.bean.PageBean;
import com.yb.ballworld.information.ui.personal.view.FollowFragment;

import java.util.List;


public class FollowPresenter extends BasePresenter<LifecycleOwner, VoidModel> {
    private PersonalHttpApi api = new PersonalHttpApi();
    private InforMationHttpApi inforMationHttpApi = new InforMationHttpApi();
    private String focusUserId = "";
    // 分页
    private int pageNum = 1;
    // 每页数量
    private int pageSize = 15;
    // 总分页数
    private int totalPage = Integer.MIN_VALUE;
    private int type=0;
    public MutableLiveData<LiveDataResult<List<Follow>>> followData = new MutableLiveData<>();


    public void getList() {
        if(!hasMore()) return;
        request(new LifecycleCallback<String>(mView) {
            @Override
            public void onSuccess(String data) {
                Gson gson = new Gson();
                PageBean pageBean=null;
                try {
                    pageBean = gson.fromJson(data, PageBean.class);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                LiveDataResult<List<Follow>> result = new LiveDataResult<>();
                if (pageBean != null && !pageBean.getList().isEmpty()) {
                    result.setData(pageBean.getList());
                    totalPage=pageBean.getTotalPage();
                    pageNum++;
                    LogUtils.INSTANCE.i("arway","totalPage="+totalPage+"/pageNum="+pageNum);
                } else {
                    result.setError(Integer.MIN_VALUE, "暂无数据");
                }
                followData.setValue(result);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                LiveDataResult<List<Follow>> result = new LiveDataResult<>();
                result.setError(errCode, errMsg == null ? "网络异常" : errMsg);
                followData.setValue(result);

            }
        });
    }


    private void request(LifecycleCallback<String> callback){
        if(type== FollowFragment.TYPE_FOLLOW){
            api.getFollowList(focusUserId,pageNum,pageSize,callback);
        }else if(type==FollowFragment.TYPE_FANS){
            api.getFansList(focusUserId,pageNum,pageSize,callback);
        }
    }



    /**
     * 关注与取消关注
     *
     * @param focusUserId
     * @param action
     * @param callback
     */
    public void attentionAction(int focusUserId, boolean action, LifecycleCallback callback) {
        if (action) {
            inforMationHttpApi.attentionAuthor(focusUserId, callback);
        } else {
            inforMationHttpApi.attentionAuthorCancel(focusUserId, callback);
        }
    }


    public void setFocusUserId(String focusUserId) {
        this.focusUserId = focusUserId;
    }

    /**
     * 判断是否可以加载更多
     *
     * @return
     */
    public boolean hasMore() {
        LogUtils.INSTANCE.i("arwayHasMOre","totalPage="+totalPage+"/pageNum="+pageNum);
        return totalPage == Integer.MIN_VALUE || totalPage+1 > pageNum;
    }

    public void setType(int type) {
        this.type = type;
    }


    public void resetPage(){
        totalPage= Integer.MIN_VALUE;
        pageNum=1;
    }
}
