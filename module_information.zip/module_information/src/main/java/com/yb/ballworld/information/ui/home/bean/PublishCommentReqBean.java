package com.yb.ballworld.information.ui.home.bean;

/**
 * Desc 发表评论请求参数
 * Date 2019/10/22
 * author mengk
 */
public class PublishCommentReqBean {
    //唯一主键
    private String id;
    //0.评论 1.回复
    private String commentType;
    //创建人
    private String createdBy;
    //创建时间
    private String createdDate;
    //图片1
    private String imgUrl1;
    //图片2
    private String imgUrl2;
    //图片3
    private String imgUrl3;
    //最近操作人
    private String lastModifiedBy;
    //更新时间
    private String lastModifiedDate;
    //点赞数
    private String likeCount;
    //主评论ID
    private String mainCommentId;
    //评论的资讯ID
    private String newsId;
    //评论内容
    private String content;
    //用户昵称
    private String nickName;
    //回复ID
    private String replyId;
    //评论用户ID
    private String userId;
    //视频链接
    private String videoUrl;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCommentType() {
        return commentType;
    }

    public void setCommentType(String commentType) {
        this.commentType = commentType;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getImgUrl1() {
        return imgUrl1;
    }

    public void setImgUrl1(String imgUrl1) {
        this.imgUrl1 = imgUrl1;
    }

    public String getImgUrl2() {
        return imgUrl2;
    }

    public void setImgUrl2(String imgUrl2) {
        this.imgUrl2 = imgUrl2;
    }

    public String getImgUrl3() {
        return imgUrl3;
    }

    public void setImgUrl3(String imgUrl3) {
        this.imgUrl3 = imgUrl3;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public String getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(String likeCount) {
        this.likeCount = likeCount;
    }

    public String getMainCommentId() {
        return mainCommentId;
    }

    public void setMainCommentId(String mainCommentId) {
        this.mainCommentId = mainCommentId;
    }

    public String getNewsId() {
        return newsId;
    }

    public void setNewsId(String newsId) {
        this.newsId = newsId;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getReplyId() {
        return replyId;
    }

    public void setReplyId(String replyId) {
        this.replyId = replyId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }
}
