package com.yb.ballworld.information.ui.personal.constant;

import rxhttp.wrapper.entity.Response;

/**
 * Desc:
 * Author: JS-Kylo
 * Created On: 2019/10/11 18:13
 */
public interface PraiseCallbackListener {
    void onPraiseSuccess(Response response);
    void onPraiseFail(String msg);
}
