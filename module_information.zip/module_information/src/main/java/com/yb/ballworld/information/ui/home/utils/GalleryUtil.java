package com.yb.ballworld.information.ui.home.utils;

import android.content.Context;

import androidx.appcompat.app.AppCompatActivity;

import com.yb.ballworld.baselib.constant.Constant;
import com.yb.ballworld.baselib.utils.Glide4Engine;
import com.yb.ballworld.information.R;
import com.zhihu.matisse.Matisse;
import com.zhihu.matisse.MimeType;

/**
 * Desc
 * Date 2019/11/5
 * author mengk
 */
public class GalleryUtil {
    /**
     * 打开相册
     */
    public static void openGallery(AppCompatActivity context) {
        Matisse.from(context)
                .choose(MimeType.of(MimeType.JPEG, MimeType.PNG, MimeType.GIF), false)
                .theme(R.style.Matisse_Zhihu)
                .countable(false)
                .showSingleMediaType(true)
                .maxSelectable(3)
                .thumbnailScale(0.8f)
                .originalEnable(false)
                .maxOriginalSize(10)
                .imageEngine(new Glide4Engine())
                .forResult(Constant.REQUEST_CODE_CHOOSE);
    }
}
