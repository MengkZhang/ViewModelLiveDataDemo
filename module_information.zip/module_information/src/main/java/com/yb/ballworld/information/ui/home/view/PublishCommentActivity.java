package com.yb.ballworld.information.ui.home.view;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.text.Editable;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bfw.util.ToastUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.google.android.material.snackbar.Snackbar;
import com.gyf.immersionbar.ImmersionBar;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.constant.Constant;
import com.yb.ballworld.baselib.utils.Glide4Engine;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.widget.chat.EmojiLayout;
import com.yb.ballworld.common.base.SystemBarActivity;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.community.bean.Topic;
import com.yb.ballworld.information.ui.home.adapter.ChoiceImgAdapter;
import com.yb.ballworld.information.ui.home.bean.InfoPublishImgBean;
import com.yb.ballworld.information.ui.home.bean.PublishCommentReqBean;
import com.yb.ballworld.information.ui.home.bean.PublishCommentResBean;
import com.yb.ballworld.information.ui.home.constant.FailStateConstant;
import com.yb.ballworld.information.ui.home.constant.PublishIntentParam;
import com.yb.ballworld.information.ui.home.constant.PublishReqCode;
import com.yb.ballworld.information.ui.home.presenter.PublishCommentContract;
import com.yb.ballworld.information.ui.home.presenter.PublishCommentPresenter;
import com.yb.ballworld.information.ui.home.presenter.TopicPublishCommentPresenter;
import com.yb.ballworld.information.ui.home.utils.GlideLoadImgUtil;
import com.yb.ballworld.information.ui.home.utils.MediaUtils;
import com.yb.ballworld.information.ui.home.utils.softkey.KPSwitchFSPanelLinearLayout;
import com.yb.ballworld.information.ui.home.utils.softkey.KeyboardUtil;
import com.yb.ballworld.information.ui.home.widget.DeleteImgDialog;
import com.zhihu.matisse.Matisse;
import com.zhihu.matisse.MimeType;
import com.zhihu.matisse.internal.entity.Item;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Desc 发布评论activity
 * Date 2019/10/19
 * author mengk
 */
public class PublishCommentActivity extends SystemBarActivity implements PublishCommentContract.IInfoPublishCommentView {

    private KPSwitchFSPanelLinearLayout emojiRootView;
    private EditText edInputContent;
    private Button btnPublish;
    private RecyclerView rvChoiceImg;
    private ImageView ivChoiceVideo;
    private RelativeLayout rlChoiceVideo;
    private RelativeLayout rlDeleteVideo;
    //选中相册按钮
    private RelativeLayout publishImg;
    //选视频
    private ImageView publishVideo;
    //点击弹出emoji的按钮
    private RelativeLayout rlEmoji;
    //emoji表情布局
    private EmojiLayout mEmojiLayout;
    //权限请求码
    private static final int PERMISSION_REQUEST = 222;
    private static final int PERMISSION_VIDEO_REQUEST = 299;
    private static final int REQUEST_CODE_VIDEO = 333;
    //声明一个数组permissions，将需要的权限都放在里面
    private String[] permissions = new String[]{Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE};
    //创建一个mPermissionList，逐个判断哪些权限未授予，未授予的权限存储到mPermissionList中
    private List<String> mPermissionList = new ArrayList<>();
    //知乎选相册的数组
    private List<Item> s = new ArrayList();
    private List<Item> sVideo = new ArrayList();
    //相册图片数组
    private List<InfoPublishImgBean> mListPhotoData = new ArrayList<>();
    //视频数组
    private List<File> videoList = new ArrayList<>();
    private List<String> imagePaths = new ArrayList<>();
    private ChoiceImgAdapter adapter;
    private PublishCommentPresenter presenter;
    //是否显示了软键盘
    private boolean mIsShowSoftKeyBoard = false;

    private String newsId;
    private String replyId;
    private String id;
    private String commentType;
    private String createdBy;
    private String createdDate;
    private String lastModifiedBy;
    private String lastModifiedDate;
    private String likeCount;
    private String mainCommentId;
    private String nickName;
    private String userId;
    private PublishCommentReqBean bean;
    private View decorRootView;
    private KeyboardOnGlobalChangeListener keyboardOnGlobalChangeListener;
    private int type;


    /**
     * 初始化沉浸式
     */
    protected void initImmersionBar() {
        // 设置共同沉浸式样式
        ImmersionBar.with(this)
                .statusBarDarkFont(true, 0.2f)
                .statusBarColor(getStatusBarColor())
                .navigationBarColor(R.color.white)
                .init();
    }


    @Override
    public int getLayoutId() {
        return R.layout.activity_save_comment;
    }

    @Override
    protected void initView() {
        F(R.id.title_bar_back).setOnClickListener(v -> finish());
        //F(R.id.statusbar_new).setVisibility(View.VISIBLE);
        View statusView = F(R.id.statusbar_new);
        int statusHeight = getStatusHeight();
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) statusView.getLayoutParams();
        layoutParams.height = statusHeight;
        statusView.setLayoutParams(layoutParams);
        edInputContent = F(R.id.et_input_content_info);
        btnPublish = F(R.id.title_bar_sure);
        emojiRootView = F(R.id.emoji_root_view);
        rlEmoji = F(R.id.rl_emoji_info);
        mEmojiLayout = F(R.id.emoji_info_publish);
        publishImg = F(R.id.rl_publish_img_info);
        publishVideo = F(R.id.iv_publish_video_info);
        rvChoiceImg = F(R.id.rv_img_publish);
        rlChoiceVideo = F(R.id.rl_video_publish);
        ivChoiceVideo = F(R.id.iv_video_multi_publish);
        rlDeleteVideo = F(R.id.rl_info_video_publish_del);
        rvChoiceImg.setLayoutManager(new GridLayoutManager(this, 3));
        adapter = new ChoiceImgAdapter(mListPhotoData);
        rvChoiceImg.setAdapter(adapter);
        type = getIntent().getIntExtra("type",0);
        if(type ==Integer.MIN_VALUE){
            presenter=new TopicPublishCommentPresenter();
        }else{
            presenter = new PublishCommentPresenter();
        }
        presenter.attachView(this);
        //监听视图树的布局改变(弹出/隐藏软键盘会触发)
        decorRootView = getWindow().getDecorView().findViewById(android.R.id.content);
        keyboardOnGlobalChangeListener = new KeyboardOnGlobalChangeListener();
        addOnGlobalLayoutListener();
        bean = new PublishCommentReqBean();
        edInputContent.setFocusable(true);
        edInputContent.requestFocus();
        autoShowSoftKey();
    }

    /**
     * 自动弹出软键盘
     * 时候由于刚进入界面未初始化完毕导致未显示出来 那么定时器 200毫秒后去执行它既可
     */
    private void autoShowSoftKey() {
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                InputMethodManager manager = (InputMethodManager) PublishCommentActivity.this.getSystemService(Context.INPUT_METHOD_SERVICE);
                manager.showSoftInput(edInputContent,0);
            }
        },200);
    }

    /**
     * 添加软键盘监听
     */
    private void addOnGlobalLayoutListener() {
        decorRootView.getViewTreeObserver().addOnGlobalLayoutListener(keyboardOnGlobalChangeListener);
    }

    @Override
    protected void onPause() {
        super.onPause();
        removeOnGlobalLayoutListener();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        removeOnGlobalLayoutListener();
    }

    private void removeOnGlobalLayoutListener() {
        if (keyboardOnGlobalChangeListener != null) {
            decorRootView.getViewTreeObserver().removeOnGlobalLayoutListener(keyboardOnGlobalChangeListener);
        }

        //如果显示了软键盘 则隐藏
        if (mIsShowSoftKeyBoard) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(edInputContent.getWindowToken(), 0);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        addOnGlobalLayoutListener();
    }

    @Override
    protected void getIntentData() {
        super.getIntentData();
        Intent intent = getIntent();
        if (intent == null) return;
        newsId = intent.getStringExtra(PublishIntentParam.NEWS_ID);
        replyId = intent.getStringExtra(PublishIntentParam.REPLY_ID);
        id = intent.getStringExtra(PublishIntentParam.ID);
        commentType = intent.getStringExtra(PublishIntentParam.COMMENT_TYPE);
        createdBy = intent.getStringExtra(PublishIntentParam.CREATED_BY);
        createdDate = intent.getStringExtra(PublishIntentParam.CREATED_DATE);
        lastModifiedBy = intent.getStringExtra(PublishIntentParam.LAST_MODIFIED_BY);
        lastModifiedDate = intent.getStringExtra(PublishIntentParam.LAST_MODIFIED_DATE);
        likeCount = intent.getStringExtra(PublishIntentParam.LIKE_COUNT);
        mainCommentId = intent.getStringExtra(PublishIntentParam.MAIN_COMMENT_ID);
        nickName = intent.getStringExtra(PublishIntentParam.NICK_NAME);
        userId = intent.getStringExtra(PublishIntentParam.USER_ID);
    }

    /**
     * 重写触摸不隐藏软键盘
     *
     * @return
     */
    @Override
    protected boolean isTouchHideSoftInput() {
        return false;
    }

    private boolean isSheQu() {
        return type == Integer.MIN_VALUE;
    }

    @Override
    protected void bindEvent() {
        //点击选视频
        publishVideo.setOnClickListener(v -> {
//            if (isSheQu()) { //社区 放开视频入口
//                if (Build.VERSION.SDK_INT >= 23) {
//                    requestVideoPermissions();
//                } else {
//                    openVideo();
//                }
//
//            } else {         //资讯 屏蔽视频入口
//                //2019/10/23 V1.1.0版本不上
//                ToastUtils.INSTANCE.showToast(R.string.prompt_coding);
//            }
            //V1.2.0版本的资讯打开了发布视频评论的入口
            if (Build.VERSION.SDK_INT >= 23) {
                requestVideoPermissions();
            } else {
                openVideo();
            }
        });

        //点击发布
        btnPublish.setOnClickListener(v -> publishComment());

        //点击删除图片
        adapter.setOnItemChildClickListener((adapter, view, position) -> {
            if (view.getId() == R.id.rl_info_publish_del) {
                DeleteImgDialog dialog = new DeleteImgDialog(PublishCommentActivity.this,
                        getResources().getString(R.string.prompt_comment_del_img_sure));
                dialog.show();
                dialog.setSureOrCancelListener(new DeleteImgDialog.SureOrCancelListener() {
                    @Override
                    public void cancel() {
                        dialog.dismiss();
                    }

                    @Override
                    public void sure() {
                        dialog.dismiss();
                        delImgLogic(adapter, position);
                    }
                });
            }
        });

        //点击删除视频
        rlDeleteVideo.setOnClickListener(v -> {
            DeleteImgDialog dialog = new DeleteImgDialog(PublishCommentActivity.this,
                    getResources().getString(R.string.prompt_comment_del_video_sure));
            dialog.show();
            dialog.setSureOrCancelListener(new DeleteImgDialog.SureOrCancelListener() {
                @Override
                public void cancel() {
                    dialog.dismiss();
                }

                @Override
                public void sure() {
                    dialog.dismiss();
                    PublishCommentActivity.this.delVideoLogic();
                }
            });

        });

        //点击打开相册
        publishImg.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 23) {
                requestPermissions();
            } else {
                openGallery();
            }
        });

        //点击是否打开Emoji布局
        rlEmoji.setOnClickListener(v -> ifNeedShowEmoji());

        //点击emoji item
        mEmojiLayout.setOnEmojiClickListener(s -> {
            int selectionStart = edInputContent.getSelectionStart();
            Editable editableText = edInputContent.getEditableText();
            if (editableText != null) {
//                editableText.append(s);
                editableText.insert(selectionStart, s);
            }
            return null;
        });
    }

    /**
     * 删除视频
     */
    private void delVideoLogic() {
        if (videoList.size() != 0) {
            try {
                videoList.clear();
                sVideo.clear();
                rlChoiceVideo.setVisibility(View.GONE);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 打开视频页面
     */
    private void openVideo() {
        //判断是否有图片选择
        if (mListPhotoData.size() != 0) {
            ToastUtils.showToast(getResources().getString(R.string.info_detail_choice_judge));
            return;
        }
        Matisse.from(this)
                .choose(MimeType.of(MimeType.MPEG, MimeType.MP4, MimeType.QUICKTIME, MimeType.THREEGPP,
                        MimeType.THREEGPP2, MimeType.MKV, MimeType.WEBM, MimeType.TS, MimeType.AVI), true)
                .theme(R.style.Matisse_Zhihu)
                .countable(true)
                .showSingleMediaType(true)
                .maxSelectable(1)
                .setSelectionItems(sVideo)
                .originalEnable(false)
                .maxOriginalSize(10)
                .imageEngine(new Glide4Engine())
                .forResult(REQUEST_CODE_VIDEO);
    }

    /**
     * 删除照片
     *
     * @param adapter
     * @param position
     */
    private void delImgLogic(BaseQuickAdapter adapter, int position) {
        if (mListPhotoData.size() != 0) {
            try {
                mListPhotoData.remove(position);
                s.remove(position);
                adapter.replaceData(mListPhotoData);
                //当数组为空的时候 隐藏图片列表
                if (mListPhotoData.size() == 0) {
                    rvChoiceImg.setVisibility(View.GONE);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 发布评论
     */
    private boolean isPosting = false;
    private void publishComment() {
        if (isPosting) {
            return;
        }
        String content = edInputContent.getText().toString().trim();
        int imgSize = mListPhotoData.size();
        //判断是否有内容
        if (!TextUtils.isEmpty(content)) {//有文本内容
            //判断内容是否超过5000字
            if (edInputContent.getText().length() > 5000) {//文本超过了5000字
                ToastUtils.showToast("内容不能超过5000字");
            } else {
                isPosting = true;                       //正常发布
                publishLogic(content);
            }
        } else {                          //没有文本内容 判断是否有图片内容
            if (imgSize > 0 || videoList.size() > 0) {//有图片视频内容
                isPosting = true;
                publishLogic("");
            } else {          //没有图片&&没有文本
                ToastUtils.showToast("内容不能为空");
            }
        }
    }

    /**
     * 请求逻辑
     *
     * @param content
     */
    private void publishLogic(String content) {
        //判断是否需要传图片
        bean.setId(id);
        bean.setCommentType(commentType);
        bean.setContent(content);
        bean.setCreatedBy(createdBy);
        bean.setCreatedDate(createdDate);
        bean.setLastModifiedBy(lastModifiedBy);
        bean.setLastModifiedDate(lastModifiedDate);
        bean.setLikeCount(likeCount);
        bean.setMainCommentId(mainCommentId);
        bean.setNickName(nickName);
        bean.setUserId(userId);
        bean.setNewsId(newsId);
        bean.setReplyId(replyId);
        presenter.setParamsBean(bean);
        if (videoList != null && videoList.size() > 1) {//有视频 上传视频
            presenter.uploadVideoFile(videoList.get(0),videoList.get(1), "image");
        } else {                                         //没有视频 判断是否有图片
            if (mListPhotoData.size() > 0) {//需要上传图片
                List<File> files = new ArrayList<>();
                for (InfoPublishImgBean mListPhotoDatum : mListPhotoData) {
                    String path = mListPhotoDatum.getPath();
                    if (!TextUtils.isEmpty(path)) {
                        files.add(new File(path));
                    }
                }
                if (files.size() == 0) return;
                presenter.uploadFile(files, "image");
            } else {                       //没有图片直接访问发表接口
                presenter.publishComment(bean, null);
            }
        }
        if (mListPhotoData != null && mListPhotoData.size() != 0) {
            for (InfoPublishImgBean bean : mListPhotoData) {
                LogUtils.INSTANCE.e("===z","mListPhotoData path = " + bean.getPath());
            }
        }

    }


    @Override
    protected void initData() {

    }


    @Override
    protected void processClick(View view) {

    }

    /**
     * 是否展示emoji
     */
    private void ifNeedShowEmoji() {
        LogUtils.INSTANCE.e("===z", "ifNeedShowEmoji软键盘 = " + mIsShowSoftKeyBoard);
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (mIsShowSoftKeyBoard) {//显示了软键盘 需要隐藏
            imm.hideSoftInputFromWindow(edInputContent.getWindowToken(), 0);
        } else {//没显示软键盘 需要打开
            imm.showSoftInput(edInputContent, InputMethodManager.RESULT_SHOWN);
            imm.toggleSoftInput(InputMethodManager.SHOW_FORCED,
                    InputMethodManager.HIDE_IMPLICIT_ONLY);

        }

    }

    /**
     * 请求多权限
     */
    private void requestPermissions() {
        //清空没有通过的权限
        mPermissionList.clear();

        //逐个判断你要的权限是否已经通过
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                //添加还未授予的权限
                mPermissionList.add(permission);
            }
        }

        //申请权限
        if (mPermissionList.size() > 0) {//有权限没有通过，需要申请
            ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST);
        } else {                         //说明权限都已经通过
            openGallery();
        }
    }

    private void requestVideoPermissions() {
        //清空没有通过的权限
        mPermissionList.clear();

        //逐个判断你要的权限是否已经通过
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                //添加还未授予的权限
                mPermissionList.add(permission);
            }
        }

        //申请权限
        if (mPermissionList.size() > 0) {//有权限没有通过，需要申请
            ActivityCompat.requestPermissions(this, permissions, PERMISSION_VIDEO_REQUEST);
        } else {                         //说明权限都已经通过
            openVideo();
        }
    }


    /**
     * 打开相册
     */
    private void openGallery() {
        //判断是否选择了视频
        if (videoList.size() != 0) {
            ToastUtils.showToast(getResources().getString(R.string.info_detail_choice_judge));
            return;
        }
        Matisse.from(this)
                .choose(MimeType.of(MimeType.JPEG, MimeType.PNG, MimeType.GIF), false)
                .theme(R.style.Matisse_Zhihu)
                .countable(true)
                .showSingleMediaType(true)
                .maxSelectable(3)
                .thumbnailScale(0.8f)
                .setSelectionItems(s)
                .originalEnable(false)
                .maxOriginalSize(10)
                .imageEngine(new Glide4Engine())
                .forResult(Constant.REQUEST_CODE_CHOOSE);
    }

    /**
     * activity的回调
     *
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //打开相册后的回调
        switch (requestCode) {
            case Constant.REQUEST_CODE_CHOOSE://打开相册回调
                openGalleryCallBack(resultCode, data);
                break;

            case REQUEST_CODE_VIDEO:          //打开视频回调
                openVideoCallBack(resultCode, data);
                break;
        }


    }

    /**
     * 打开视频回调
     * @param resultCode
     * @param data
     */
    private void openVideoCallBack(int resultCode, @Nullable Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            if (data == null) return;
            rvChoiceImg.setVisibility(View.GONE);
            mListPhotoData.clear();
            videoList.clear();
            rlChoiceVideo.setVisibility(View.VISIBLE);

            if (s != null) {
                s.clear();
            }

            sVideo = Matisse.obtainItem(data);
            List<Uri> uris = Matisse.obtainResult(data);
            List<String> paths = Matisse.obtainPathResult(data);
            if (uris == null || uris.size() == 0 || paths == null || paths.size() == 0) return;
            LogUtils.INSTANCE.e("===z", "uris = " + uris.get(0));
            LogUtils.INSTANCE.e("===z", "paths = " + paths.get(0));
            MediaUtils.getImageForVideo(paths.get(0), file -> {
                LogUtils.INSTANCE.e("===z", "file = " + file);
                if (file != null) {
                    videoList.add(file);
                    videoList.add(new File(paths.get(0)));
                }
            });
            GlideLoadImgUtil.loadImg(this, uris.get(0).toString(), ivChoiceVideo);
        } else {
            LogUtils.INSTANCE.e("===z", "没有选av");
        }
    }

    /**
     * 打开相册回调
     * @param resultCode
     * @param data
     */
    private void openGalleryCallBack(int resultCode, @Nullable Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            //清空数组
            if (sVideo != null) {
                sVideo.clear();
            }
            videoList.clear();
            mListPhotoData.clear();
            if (data == null) return;

            rvChoiceImg.setVisibility(View.VISIBLE);
            rlChoiceVideo.setVisibility(View.GONE);

            s = Matisse.obtainItem(data);
            List<Uri> uris = Matisse.obtainResult(data);
            List<String> paths = Matisse.obtainPathResult(data);

            if (uris == null || uris.size() == 0 || paths == null || paths.size() == 0) return;

            for (int i = 0; i < uris.size(); i++) {
                mListPhotoData.add(new InfoPublishImgBean(paths.get(i), uris.get(i)));
            }
            adapter.replaceData(mListPhotoData);

        }
    }


    /**
     * 动态权限请求回调
     *
     * @param requestCode
     * @param permissions
     * @param grantResults
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean hasPermissionDismiss = false;//有权限没有通过
        if (requestCode == PERMISSION_REQUEST) {// Request for camera permission.

            for (int grantResult : grantResults) {
                if (grantResult == -1) {
                    hasPermissionDismiss = true;
                }
            }

            if (hasPermissionDismiss) {   //如果有权限没有被允许
                //跳转到系统设置权限页面，或者直接关闭页面，不让他继续访问
                Snackbar.make(mEmojiLayout, "需要打开权限",
                        Snackbar.LENGTH_LONG).setAction("打开", view -> {
                    // Request the permission
                    requestPermissions();
                }).show();
            } else {                      //全部权限通过
                openGallery();
            }

        } else if (requestCode == PERMISSION_VIDEO_REQUEST) {//视频

            for (int grantResult : grantResults) {
                if (grantResult == -1) {
                    hasPermissionDismiss = true;
                }
            }

            if (hasPermissionDismiss) {   //如果有权限没有被允许
                //跳转到系统设置权限页面，或者直接关闭页面，不让他继续访问
                Snackbar.make(mEmojiLayout, "需要打开权限",
                        Snackbar.LENGTH_LONG).setAction("打开", view -> {
                    // Request the permission
                    requestVideoPermissions();
                }).show();
            } else {                      //全部权限通过
                openVideo();
            }
        }
    }

    /**
     * 监听软键盘
     */
    private class KeyboardOnGlobalChangeListener implements ViewTreeObserver.OnGlobalLayoutListener {

        @Override
        public void onGlobalLayout() {
            //判断是否显示了软键盘
            boolean keyboardShown = isKeyboardShown(decorRootView);
            if (keyboardShown) {
                if (mEmojiLayout.getVisibility() == View.VISIBLE) {
                    mEmojiLayout.setVisibility(View.GONE);
                }
                mIsShowSoftKeyBoard = true;
            } else {
                mIsShowSoftKeyBoard = false;
            }

            //测量键盘高度
            KeyboardUtil.attach(PublishCommentActivity.this, emojiRootView);
            int mKeyboardHeight = KeyboardUtil.getKeyboardHeight(PublishCommentActivity.this);
//            LogUtils.INSTANCE.e("===z","键盘高度 = " + mKeyboardHeight);

            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) mEmojiLayout.getLayoutParams();
            layoutParams.height = mKeyboardHeight;
            mEmojiLayout.setVisibility(View.VISIBLE);


        }
    }

    private boolean isKeyboardShown(View rootView) {
        final int softKeyboardHeight = 100;
        Rect r = new Rect();
        rootView.getWindowVisibleDisplayFrame(r);
        DisplayMetrics dm = rootView.getResources().getDisplayMetrics();
        int heightDiff = rootView.getBottom() - r.bottom;
        return heightDiff > softKeyboardHeight * dm.density;
    }


    @Override
    public AppCompatActivity getActivity() {
        return this;
    }

    @Override
    public void requestLoading() {
        showDialogLoading();
    }

    @Override
    public void resultUploadFileFail(int type) {
        hideDialogLoading();
        switch (type) {
            case FailStateConstant.TYPE_ERROR:
                ToastUtils.showToast("请求服务器失败");
                break;
            case FailStateConstant.TYPE_EMPTY:
                ToastUtils.showToast("请求服务器数据为空");
                break;
            default:
                break;
        }
        isPosting = false;
    }

    @Override
    public void resultUploadFileSuccess(PublishCommentResBean data) {
        LiveEventBus.get().with(LiveEventBusKey.KEY_NEWS_COLLECTION, String.class).post(newsId);
        hideDialogLoading();
        removeOnGlobalLayoutListener();
        ToastUtils.showToast("发表成功");
        //返回数据给详情页 改data实体实现了Parcelable接口 可以直接传递及接收 请在onActivityResult()根据请求码PublishReqCode.REQ_CODE来接收数据

        Intent intent = new Intent();
        intent.putExtra(PublishIntentParam.RETURN_DATA, data);
        setResult(PublishReqCode.REQ_CODE, intent);
        finish();
    }

    /**
     * 社区发布成功
     * @param topic
     */
    @Override
    public void resultUploadFileSuccess(Topic topic) {
        hideDialogLoading();
        removeOnGlobalLayoutListener();
        ToastUtils.showToast("发表成功");
        //返回数据给详情页 改data实体实现了Parcelable接口 可以直接传递及接收 请在onActivityResult()根据请求码PublishReqCode.REQ_CODE来接收数据

        Intent intent = new Intent();
        intent.putExtra(PublishIntentParam.RETURN_DATA, topic);
        setResult(PublishReqCode.REQ_CODE, intent);
        finish();
    }

}
