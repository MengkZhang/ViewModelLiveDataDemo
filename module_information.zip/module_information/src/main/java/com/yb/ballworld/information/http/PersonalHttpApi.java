package com.yb.ballworld.information.http;

import android.annotation.SuppressLint;
import android.text.TextUtils;

import com.rxjava.rxlife.RxLife;
import com.yb.ballworld.baselib.data.UserInfo;
import com.yb.ballworld.baselib.utils.AppUtils;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.common.api.BaseHttpApi;
import com.yb.ballworld.common.api.OnError;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.callback.OnUICallback;
import com.yb.ballworld.information.ui.community.bean.PostCollectionEntity;
import com.yb.ballworld.information.ui.personal.bean.CollectionEntity;
import com.yb.ballworld.information.ui.personal.bean.CommentBeanEntity;
import com.yb.ballworld.information.ui.personal.bean.PersonalInfo;
import com.yb.ballworld.information.ui.personal.bean.PostEntity;
import com.yb.ballworld.information.ui.personal.bean.community.PostHistoryEntity;
import com.yb.ballworld.information.ui.personal.bean.community.PostReleaseEntity;
import com.yb.ballworld.information.ui.personal.bean.community.ReportAuthorReason;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.reactivex.disposables.Disposable;
import rxhttp.RxHttp;
import rxhttp.wrapper.entity.Response;

/**
 * Desc:
 * Author: JS-Kylo
 * Created On: 2019/10/11 15:32
 */
public class PersonalHttpApi extends BaseHttpApi {
    //收藏列表
    private static final String INFO_COLLECTION_LIST = "/qiutx-news/app/personal/favorites";
    //足迹列表
    private static final String INFO_FOOTPRINT_LIST = "/qiutx-news/app/personal/footprint";
    //评论列表
    private static final String INFO_COMMENT_LIST = "/qiutx-news/app/homepage/comments";
    //评论点赞
    private static final String INFO_COMMENT_PRAISE = "/qiutx-news/app/news/commentlike/%s";
    //资讯点赞
    private static final String INFO_COLLECTION_PRAISE = "/qiutx-news/app/news/like/%s";
    //发表列表
    private static final String INFO_PUBLISH_LIST = "/qiutx-news/app/homepage/news";
    //个人页面 个人信息；发表数，评论数，关注数，粉丝数
    private static final String INFO_USER_RELATED_COUNT = "/qiutx-news/app/homepage/userdetail/";
    //收藏
    private static final String INFO_COLLECT_INFO = "/qiutx-news/app/news/favorites/%s";
    //取消收藏
    // private static final String INFO_CANCLE_COLLECT_INFO = "/qiutx-news/app/news/favorites/removeConcerns";
    private static final String INFO_CANCLE_COLLECT_INFO = "/qiutx-news/app/news/favorites/removeConcerns/%s";

    private static final String SPACE_POST_FAVORITES = "/qiutx-news/app/post/space/favorites";
    private static final String SPACE_POST_RELEASE_LIST = "/qiutx-news/app/post/space/list";
    private static final String SPACE_POST_REPLY_LIST = "/qiutx-news/app/post/space/reply";
    private static final String SPACE_POST_HISTORY_LIST = "/qiutx-news/app/post/space/record";
    private static final String POST_LIKE = "/qiutx-news/app/post/like/%s";
    private static final String PERSONAL_COMMUNITY_SPACE = "/qiutx-news/app/post/author/space/";
    private static final String REPORT_AUTHOR_REASON = "/qiutx-news/app/post/report/author";
    private static final String REPORT_TOPIC_REASON = "/qiutx-news/app/post/report/post";
    private static final String REPORT_AUTHOR_OR_POST = "/qiutx-news/app/post/report";

    public static final String URL_Follow_LIST = "/qiutx-news/app/post/space/focus";
    public static final String URL_FANS_LIST = "/qiutx-news/app/post/space/focus/fans";
    public static final String URL_DYNAMIC_LIST = "/qiutx-news/app/news/dynamic";

    public PersonalHttpApi() {
        RxHttp.setDebug(true);
    }

    /***
     * 请求收藏列表数据
     * @param callback 回调
     * @return
     */
    public Disposable getCollectionList(OnUICallback<CollectionEntity> callback) {
        return getInfoApi((RxHttp.get(INFO_COLLECTION_LIST)))
                .asResponse(CollectionEntity.class)
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    public Disposable getCollectionList(int pageNum, LifecycleCallback<CollectionEntity> callback) {
        return getInfoApi((RxHttp.get(INFO_COLLECTION_LIST)))
                .add("pageNum", pageNum)
                .add("pageSize", 20)
                .asResponse(CollectionEntity.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    public Disposable getFootprintList(int pageNum, LifecycleCallback<CollectionEntity> callback) {
        return getInfoApi((RxHttp.get(INFO_FOOTPRINT_LIST)))
                .add("pageNum", pageNum)
                .add("pageSize", 20)
                .asResponse(CollectionEntity.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /***
     *  获取评论列表  暂无接口
     * @param userId  用户ID
     * @param pageNum  当前页码，从0开始
     * @param pageSize 每页记录数
     * @param callback  回调
     * @return
     */
    public Disposable getCommentList(String userId, int pageNum, int pageSize, OnUICallback<CommentBeanEntity> callback) {
        return getInfoApi(RxHttp.get(INFO_COMMENT_LIST))
                //.add("currentUserId", loadUserId())
                .add("userId", userId)
                .add("pageNum", pageNum)
                .add("pageSize", pageSize)
                .asResponse(CommentBeanEntity.class)
                .subscribe(data -> callback.onSuccess(data), (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 评论点赞
     *
     * @param commentId 评论的id
     * @param callback  回调
     */
    @SuppressLint("CheckResult")
    public void praiseComment(int commentId, OnUICallback<Response> callback) {
        getInfoApi(RxHttp.postForm(String.format(INFO_COMMENT_PRAISE, commentId)))
                .asObject(Response.class)
                .subscribe(data -> callback.onSuccess(data), (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));

        // 可以回调成功，实际上失效
        //getInfoApi(RxHttp.get(INFO_COMMENT_PRAISE))
        //        .add("commentId", commentId)
        //        .asObject(Response.class)
        //        .subscribe(data -> callback.onSuccess(data), (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 资讯点赞
     *
     * @param newsId   id
     * @param callback 回调
     */
   /* @SuppressLint("CheckResult")
    public void praiseInfo(String newsId, OnUICallback<Response> callback) {
        JSONObject json = new JSONObject();
        try {
            json.put("newsId", newsId);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        getInfoApi(RxHttp.postJson(INFO_COLLECTION_PRAISE))
                .setJsonParams(json.toString())
                .asObject(Response.class)
                .subscribe(data -> callback.onSuccess(data), (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));

    }*/

    /**
     * 请求点赞
     *
     * @param newsId
     * @param callback
     */
    @SuppressLint("CheckResult")
    public void praiseInfo(String newsId, OnUICallback<Response> callback) {
        getInfoApi(RxHttp.postForm(String.format(INFO_COLLECTION_PRAISE, newsId)))
                .asObject(Response.class)
                .subscribe(data -> callback.onSuccess(data), (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));

    }
    /**
     * 我的发表
     *
     * @param userId
     * @param pageNum
     * @param pageSize
     * @param mediaType
     * @param callback
     * @return
     */
    public Disposable getPublishList(String userId, int pageNum, int pageSize, int mediaType, int reviewStatus, OnUICallback<PostEntity> callback) {
        RxHttp rxHttp=getInfoApi((RxHttp.get(INFO_PUBLISH_LIST)));

        rxHttp.add("currentUserId", loadUserId());
        rxHttp.add("userId", userId);
        rxHttp.add("pageNum", pageNum);
        rxHttp.add("pageSize", pageSize);
        if(mediaType>=0){
            rxHttp.add("mediaType", mediaType);
        }
        if(reviewStatus>=0){
            rxHttp.add("reviewStatus", reviewStatus);
        }
       return rxHttp.asResponse(PostEntity.class)
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }


    public Disposable getDynamic(String userId, int pageNum, int pageSize, OnUICallback<PostEntity> callback) {
        RxHttp rxHttp=getInfoApi((RxHttp.get(URL_DYNAMIC_LIST)));

        rxHttp.add("key", userId);
        rxHttp.add("pageNum", pageNum);
        rxHttp.add("pageSize", pageSize);
        return rxHttp.asResponse(PostEntity.class)
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }


    public Disposable getAuditPublish(String userId, int pageNum, int pageSize, OnUICallback<CollectionEntity> callback) {
        RxHttp rxHttp=getInfoApi((RxHttp.get(INFO_PUBLISH_LIST)));

        rxHttp.add("currentUserId", loadUserId());
        rxHttp.add("userId", userId);
        rxHttp.add("pageNum", pageNum);
        rxHttp.add("pageSize", pageSize);
        /*if(mediaType>=0){
            rxHttp.add("mediaType", mediaType);
        }*/
        rxHttp.add("reviewStatus", 0); // 审核状态
        return rxHttp.asResponse(CollectionEntity.class)
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 个人页面用户信息；发表数，评论数，关注数，粉丝数
     *
     * @param callback
     * @return
     */
    public Disposable getPersonalInfo(String userId, OnUICallback<PersonalInfo> callback) {
        return getInfoApi(RxHttp.get(INFO_USER_RELATED_COUNT + userId))
                //.add("userId",userId)
                .asResponse(PersonalInfo.class)
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 资讯收藏 （这里没用到）
     *
     * @param newsId   id
     * @param callback 回调
     * @return
     */
    public Disposable collectInfo(String newsId, OnUICallback<Response> callback) {
        return getInfoApi(RxHttp.postJson(String.format(INFO_COLLECT_INFO, newsId)))
                .asObject(Response.class)
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 取消收藏
     *
     * @param newsId   id
     * @param callback 回调
     * @return
     */
    public Disposable removeCollectInfo(String newsId, OnUICallback<Response> callback) {
        JSONObject json = new JSONObject();
        try {
            json.put("newsId", newsId);
        } catch (JSONException e) {
            e.printStackTrace();
        }
//        return  getInfoApi(RxHttp.get(INFO_CANCLE_COLLECT_INFO))
//                .add("newsId", newsId)
//                .asObject(Response.class)
//                .subscribe(data -> callback.onSuccess(data), (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));

//        return getInfoApi(RxHttp.postJson(INFO_CANCLE_COLLECT_INFO))
//                .setJsonParams(json.toString())
//                .asObject(Response.class)
//                .subscribe(data -> callback.onSuccess(data), (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
//        return getInfoApi(RxHttp.postJson(INFO_CANCLE_COLLECT_INFO))
//                .add("newsId", newsId)
//                .asObject(Response.class)
//                .subscribe(data -> callback.onSuccess(data), (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
        return getInfoApi(RxHttp.postForm(String.format(INFO_CANCLE_COLLECT_INFO, newsId)))
                .asObject(Response.class)
                .subscribe(data -> callback.onSuccess(data), (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));

    }

    /**
     *  帖子点赞
     */
    public Disposable postLike(int postId,LifecycleCallback<String> callback){
        return getInfoApi(RxHttp.postForm(String.format(POST_LIKE, postId)))
                .asResponse(String.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /***
     * 个人空间-社区-收藏
     * @return
     */
    public Disposable getPersonalCollectionList(int userId,int pageNum, int pageSize, LifecycleCallback<PostCollectionEntity> callback) {
        return getInfoApi((RxHttp.get(SPACE_POST_FAVORITES)))
                //.add("authorId", 240)
                .add("authorId", userId)
                .add("pageNum", pageNum)
                .add("pageSize", pageSize)
                .asResponse(PostCollectionEntity.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /***
     * 个人空间-社区-发帖列表
     * @return
     */
    public Disposable getPostReleaseList(int userId,int pageNum, int pageSize, LifecycleCallback<PostReleaseEntity> callback) {
        return getInfoApi((RxHttp.get(SPACE_POST_RELEASE_LIST)))
                .add("authorId", userId)
                .add("pageNum", pageNum)
                .add("pageSize", pageSize)
                .asResponse(PostReleaseEntity.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /***
     * 个人空间-社区-回帖列表
     * @return
     */
    public Disposable getPostReplyList(int userId,int pageNum, int pageSize, LifecycleCallback<PostReleaseEntity> callback) {
        return getInfoApi((RxHttp.get(SPACE_POST_REPLY_LIST)))
                .add("authorId", userId)
                .add("pageNum", pageNum)
                .add("pageSize", pageSize)
                .asResponse(PostReleaseEntity.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /***
     * 个人空间-社区-足迹列表
     * @return
     */
    public Disposable getPostHistoryList(int userId,int pageNum, int pageSize, LifecycleCallback<PostHistoryEntity> callback) {
        return getInfoApi((RxHttp.get(SPACE_POST_HISTORY_LIST)))
                .add("authorId", userId)
                .add("pageNum", pageNum)
                .add("pageSize", pageSize)
                .asResponse(PostHistoryEntity.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /***
     * 个人空间-关注
     * @return
     */
    public Disposable getFollowList(String userId,int pageNum, int pageSize, LifecycleCallback<String> callback) {
        return getInfoApi((RxHttp.get(URL_Follow_LIST)))
                .add("focusUserId", userId)
                .add("pageNum", pageNum)
                .add("pageSize", pageSize)
                .asResponse(String.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /***
     * 个人空间-关注
     * @return
     */
    public Disposable getFansList(String userId,int pageNum, int pageSize, LifecycleCallback<String> callback) {
        return getInfoApi((RxHttp.get(URL_FANS_LIST)))
                .add("userId", userId)
                .add("pageNum", pageNum)
                .add("pageSize", pageSize)
                .asResponse(String.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }



    /**
     * 社区个人页面用户信息；发表数，评论数，关注数，粉丝数
     *
     * @param callback
     * @return
     */
    public Disposable getPersonalCommunityInfo(String userId, LifecycleCallback<PersonalInfo> callback) {
        return getInfoApi(RxHttp.get(PERSONAL_COMMUNITY_SPACE + userId))
                //.add("userId",userId)
                .asResponse(PersonalInfo.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 获取作者举报原因
     * @param callback
     * @return
     */
    public Disposable getReportReasonOfAuthor(LifecycleCallback<List<ReportAuthorReason>> callback) {
        return getInfoApi(RxHttp.get(REPORT_AUTHOR_REASON))
                //.add("userId",userId)
                .asResponseList(ReportAuthorReason.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 获取帖子举报原因
     * @param callback
     * @return
     */
    public Disposable getReportReasonOfTopic(LifecycleCallback<List<ReportAuthorReason>> callback) {
        return getInfoApi(RxHttp.get(REPORT_TOPIC_REASON))
                //.add("userId",userId)
                .asResponseList(ReportAuthorReason.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(callback::onSuccess, (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

     /**
      * 举报
      * @param reportBy 帖子ID或作者ID
      * @param idType 举报类型 0.作者 1.帖子
      */
    public Disposable reportAuthorOrPost(String reason, int reportBy, int reasonId, int idType, LifecycleCallback<Response> callback) {
        JSONObject json = new JSONObject();
        try {
            json.put("reason", reason);
            json.put("reasonId", reasonId);
            json.put("reportBy", reportBy);
            json.put("idType", idType);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return getInfoApi(RxHttp.postJson(REPORT_AUTHOR_OR_POST))
                .setJsonParams(json.toString())
                .asObject(Response.class)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(data -> callback.onSuccess(data), (OnError) error -> callback.onFailed(error.getErrorCode(), error.getErrorMsg()));
    }

    /**
     * 获取举报作者原因
     */

    /**
     * api
     * @param rxHttp
     * @return
     */
    private RxHttp getInfoApi(RxHttp rxHttp) {
        String token = LoginOrdinaryUtils.INSTANCE.getToken();
        long uid = LoginOrdinaryUtils.INSTANCE.getUid();
        String uidOrDeviceId = "";
        JSONObject json = new JSONObject();
        if (uid > 0) {//用户id
            try {
                json.put("uid", uid);
                uidOrDeviceId = json.toString();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        if (TextUtils.isEmpty(token)) {
            UserInfo userInfo = LoginOrdinaryUtils.INSTANCE.getUserInfo();
            if (userInfo != null) {
                token = userInfo.getToken();
            }
        }
        if (token != null && !token.isEmpty()) {
            rxHttp.addHeader("Authorization", "Bearer " + token);
        } else {
            rxHttp.addHeader("Authorization", "Basic YXBwOmFwcA==");
        }
        rxHttp.addHeader("channel", getAppChannelValue());
        rxHttp.addHeader("version", AppUtils.INSTANCE.getVersionName());
        rxHttp.addHeader("client-type", "android"); // h5, web, android,ios
        rxHttp.addHeader("deviceId", getDeviceId()); //资讯带设备id
        rxHttp.addHeader("x-user-header", uidOrDeviceId); //资讯带uid
        return rxHttp;
    }

    /**
     * 获取设备id
     *
     * @return
     */
    public static String getDeviceId() {
        String deviceId = AppUtils.INSTANCE.getDeviceId();
        return deviceId;
    }


    public <T> Disposable getRequest(String url, Map<String,String> map, Class<T> tClass, LifecycleCallback<T> callback) {
        if(map==null)map=new HashMap<>();
        return getApi(RxHttp.get(url))
                .add(map)
                .asResponse(tClass)
                .as(RxLife.asOnMain(callback.getOwner()))
                .subscribe(T -> {
                    callback.onSuccess(T);
                }, (OnError) error -> {
                    callback.onFailed(error.getErrorCode(), error.getErrorMsg());
                });
    }
}
