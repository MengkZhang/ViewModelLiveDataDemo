package com.yb.ballworld.information.ui.home.constant;

import androidx.annotation.IntDef;
import androidx.annotation.StringDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Desc 发表页参数类型
 * Date 2019/10/16
 * author mengk
 */
@IntDef({
        PublishReqCode.REQ_CODE
})

@Retention(RetentionPolicy.SOURCE)

public @interface PublishReqCode {
    int REQ_CODE = 1001;
}
