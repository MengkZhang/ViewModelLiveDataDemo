package com.yb.ballworld.information.ui.home.utils;

import android.text.TextUtils;

/**
 * Desc
 * Date 2019/11/8
 * author mengk
 */
public class InfoStringUtil {
    public static String isNotNull(String string) {
        return !TextUtils.isEmpty(string) ? string : "";
    }
}
