package com.yb.ballworld.information.ui.home.bean;

import java.util.Map;

/**
 * Desc
 * Date 2019/11/5
 * author mengk
 */
public class PublishArticleUploadFilePostBean {
    private boolean uploadSuccess;
    private Map<String,String> imgUrlMap;

    public PublishArticleUploadFilePostBean() {}

    public PublishArticleUploadFilePostBean(boolean uploadSuccess,Map<String,String> imgUrlMap) {
        this.uploadSuccess = uploadSuccess;
        this.imgUrlMap = imgUrlMap;
    }

    public boolean isUploadSuccess() {
        return uploadSuccess;
    }

    public void setUploadSuccess(boolean uploadSuccess) {
        this.uploadSuccess = uploadSuccess;
    }

    public Map<String, String> getImgUrlMap() {
        return imgUrlMap;
    }

    public void setImgUrlMap(Map<String, String> imgUrlMap) {
        this.imgUrlMap = imgUrlMap;
    }
}
