package com.yb.ballworld.information.ui.auth;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.text.Editable;
import android.text.InputFilter;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bfw.image.core.utils.ImageUtils;
import com.bfw.util.ToastUtils;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshHeader;
import com.scwang.smartrefresh.layout.util.DensityUtil;
import com.yb.ballworld.baselib.constant.Constant;
import com.yb.ballworld.baselib.data.UserAreaNo;
import com.yb.ballworld.baselib.data.UserInfo;
import com.yb.ballworld.baselib.utils.Glide4Engine;
import com.yb.ballworld.baselib.utils.ImageManager;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.baselib.utils.NetWorkUtils;
import com.yb.ballworld.baselib.utils.PreferencesHelper;
import com.yb.ballworld.baselib.widget.CommonEditText;
import com.yb.ballworld.baselib.widget.countryCodePicker.CountryCodePickerPopWin;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.common.base.mvp.BaseMvpActivity;
import com.yb.ballworld.common.livedata.LiveDataObserver;
import com.yb.ballworld.common.widget.CommonTitleBar;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.auth.adapter.AuthImgAdapter;
import com.yb.ballworld.information.ui.auth.data.AuthImgBean;
import com.yb.ballworld.information.ui.auth.data.PhoneCodeGetEvent;
import com.yb.ballworld.information.ui.auth.data.SpecialAuthSubmitBean;
import com.yb.ballworld.information.ui.auth.data.SpecialReviewBean;
import com.yb.ballworld.information.ui.auth.utils.DigitUtil;
import com.yb.ballworld.information.ui.auth.utils.SpecialAuthUtils;
import com.yb.ballworld.information.ui.auth.widget.SpecialAuthTipDialog;
import com.yb.ballworld.information.ui.auth.widget.SpecialSamplePhotoDialog;
import com.yb.ballworld.information.ui.home.utils.MyGlideEngine;
import com.yb.ballworld.information.widget.GridSpacingItemDecoration;
import com.zhihu.matisse.Matisse;
import com.zhihu.matisse.MimeType;
import com.zhihu.matisse.internal.entity.CaptureStrategy;
import com.zhihu.matisse.internal.entity.Item;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import cn.jmessage.support.qiniu.android.utils.StringUtils;

import static com.yb.ballworld.common.widget.CommonTitleBar.ACTION_LEFT_BUTTON;

/**
 * 特约认证
 * @author Gethin
 * @time 2019/11/7 20:22
 */

public class SpecialAuthActivity extends BaseMvpActivity<SpecialPresenter> {

    private static final int REQUEST_CODE_CAPTURE = 1000;
    private static final int PERMISSION_REQUEST_CODE_OPEN_GALLERY = 1001;
    private static final int PERMISSION_REQUEST_CODE_CAPTURE = 1002;
    private String[] permissions = new String[]{Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE};

    private SmartRefreshLayout smartRefreshLayout;
    private PlaceholderView placeholder;

    // 知乎选相册的数组
    private List<Item> s = new ArrayList<>();
    // 其他身份证明图片
    private RecyclerView rvAuthImg;
    private AuthImgAdapter authImgAdapter = new AuthImgAdapter();
//    private List<AuthImgBean> authImgData =  new ArrayList<>();
    private List<AuthImgBean> authImgBeans = new ArrayList<>();
    private AuthImgBean authIDPhoto = new AuthImgBean("", null);
    private ImageView ivAuthPhoto;

    private CommonEditText cetInputName;
    private CommonEditText cetInputID;
    private CommonEditText cetIDPhoto;
    private TextView tvAreaCode;
    private TextView tvCountry;
    private CountryCodePickerPopWin codePopupWindow = null;
    private CommonEditText cetInputPhone;
    private CommonEditText cetAuthCode;
    private TextView tvGetCode;
    private TextView tvPostImg;
    private Button btnSubmit;

    private SpecialAuthUtils specialAuthUtils = SpecialAuthUtils.Companion.newInstance();
    private TextView tvNameTip;
    private TextView tvPhotoTip;
    private TextView tvPhoneTip;
    private TextView tvShowSamplePhoto;

    private List<File> postFiles = new ArrayList<>();
    private List<File> otherFiles = new ArrayList<>();
    private ImageView ivAuthPhotoCapture;

    // 认证数据提交类型，默认为初次提交
    private String submitType = SpecialReviewBean.TYPE_SAVE;
    private String mobile;
    private RelativeLayout rlAuthSate;
    private ImageView ivState;
    private TextView tvState;
    private Button btnState;
    private TextView tvAuthing;
    private TextView centerTextView;

    public static void launch(Context context) {
        context.startActivity(new Intent(context, SpecialAuthActivity.class));
    }

    @Override
    protected RefreshHeader getRefreshHeader() {
        return super.getRefreshHeader();
    }

    @Override
    public void initPresenter() {
        mPresenter.setVM(this);
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_special_auth;
    }

    @Override
    protected void initView() {
        cetInputName = findViewById(R.id.cetInputName);
        cetInputID = findViewById(R.id.cetInputID);
        cetIDPhoto = findViewById(R.id.cetIDPhoto);
        ivAuthPhoto = findViewById(R.id.ivAuthPhoto);
        rvAuthImg = findViewById(R.id.rvImg);
        tvCountry = findViewById(R.id.tvCountry);
        tvAreaCode = findViewById(R.id.tvAreaCode);
        cetInputPhone = findViewById(R.id.cetInputPhone);
        tvGetCode = findViewById(R.id.tvGetCode);
        cetAuthCode = findViewById(R.id.cetAuthCode);
        ivAuthPhotoCapture = findViewById(R.id.ivAuthPhotoCapture);
        tvPostImg = findViewById(R.id.tvPostImg);
        btnSubmit = findViewById(R.id.btnSubmit);
        tvNameTip = findViewById(R.id.tvNameTip);
        tvPhotoTip = findViewById(R.id.tvPhotoTip);
        tvPhoneTip = findViewById(R.id.tvPhoneTip);
        tvShowSamplePhoto = findViewById(R.id.tvShowSamplePhoto);

        rlAuthSate = findViewById(R.id.rlAuthSate);
        ivState = findViewById(R.id.ivState);
        tvState = findViewById(R.id.tvState);
        tvAuthing = findViewById(R.id.tvAuthing);
        btnState = findViewById(R.id.btnState);

        smartRefreshLayout = findViewById(R.id.smart_refresh_layout);
        smartRefreshLayout.setRefreshFooter(getRefreshFooter());
        smartRefreshLayout.setRefreshHeader(getRefreshHeader());
        initRefreshView();
        enableRefresh(true);
        enableLoadMore(false);
        placeholder = findViewById(R.id.placeholder);

        initPopWindow();
    }

    @Override
    public SmartRefreshLayout getSmartRefreshLayout() {
        return smartRefreshLayout;
    }

    @Override
    public PlaceholderView getPlaceholderView() {
        return placeholder;
    }

    @Override
    protected void onRefreshData() {
        loadData();
    }

    @Override
    protected void bindEvent() {
        tvAreaCode.setOnClickListener(this);
        tvCountry.setOnClickListener(this);
        ivAuthPhoto.setOnClickListener(this);
        tvGetCode.setOnClickListener(this);
        tvShowSamplePhoto.setOnClickListener(this);
        btnState.setOnClickListener(this);
        setAuthCodeState(true);
        findViewById(R.id.btnSubmit).setOnClickListener(this);
        CommonTitleBar commonTitleBar = findViewById(R.id.commonTitleBar);
        centerTextView = commonTitleBar.getCenterTextView();
        ((CommonTitleBar)findViewById(R.id.commonTitleBar)).setListener((v, action, extra) -> {
            if (action == ACTION_LEFT_BUTTON) {
                SpecialAuthActivity.this.finish();
            }
        });
        placeholder.setPageErrorRetryListener(view ->  {
            loadData();
        });

        // 查询
        mPresenter.authGet.observe(this, new LiveDataObserver<SpecialReviewBean>() {
            @Override
            public void onSuccess(SpecialReviewBean data) {
                hideLoading();
                showPageContent();
                if (data != null) { // 查询到有提交过数据就显示数据和状态
                    lastSubmitData = data;
                    showAuthStatePage(data.getReviewStatus());
                } else { // 自动填充用户的手机号
                    showUserPhone();
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                hideLoading();
                showPageContent();
                ToastUtils.showToast(errMsg);
            }
        });

        // 提交或修改
        mPresenter.autSubmit.observe(this, new LiveDataObserver<SpecialAuthSubmitBean>() {
            @Override
            public void onSuccess(SpecialAuthSubmitBean data) {
                hideLoading();
                showAuthStatePage(SpecialReviewBean.AUTH_ING);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                hideLoading();
                ToastUtils.showToast(errMsg);
            }
        });

        cetInputName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (TextUtils.isEmpty(s)) {
                    tvNameTip.setVisibility(View.GONE);
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        cetInputID.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (TextUtils.isEmpty(s)) {
                    tvNameTip.setVisibility(View.GONE);
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        cetInputPhone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (TextUtils.isEmpty(s)) {
                    tvPhoneTip.setVisibility(View.GONE);
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        cetAuthCode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (TextUtils.isEmpty(s)) {
                    tvPhoneTip.setVisibility(View.GONE);
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        // 验证码监听
        mPresenter.phoneCode.observe(this, new LiveDataObserver<PhoneCodeGetEvent>() {
            @Override
            public void onSuccess(PhoneCodeGetEvent data) {
                if (data != null) {
                    int state = data.getState();
                    if (PhoneCodeGetEvent.SUCCESS == state) {
                        ToastUtils.showToast("验证码发送成功！");
                    } else if (PhoneCodeGetEvent.FAILURE == state){
                       onGetCodeFail(data.getErrMsg());
                    }
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                onGetCodeFail(errMsg);
            }
        });
    }

    private SpecialReviewBean lastSubmitData;
    private void showAuthStatePage(int state) {
        centerTextView.setText("认证结果");
        rlAuthSate.setVisibility(View.VISIBLE);
        smartRefreshLayout.setVisibility(View.GONE);
        switch (state) {
            case SpecialReviewBean.AUTH_ING:      // 待审核
                ivState.setImageResource(R.drawable.conduct);
                tvState.setText("审核中");
                tvAuthing.setVisibility(View.VISIBLE);
                btnState.setVisibility(View.GONE);
                break;
            case SpecialReviewBean.AUTH_SUCCESS:  //审核通过
                submitType = SpecialReviewBean.TYPE_UPDATE;
                ivState.setImageResource(R.drawable.success);
                tvState.setText("审核通过");
                tvAuthing.setVisibility(View.GONE);
                btnState.setVisibility(View.VISIBLE);
                btnState.setText("修改资料");
                break;
            case SpecialReviewBean.AUTH_FAILURE:  //审核未通过
                submitType = SpecialReviewBean.TYPE_UPDATE;
                ivState.setImageResource(R.drawable.failed);
                tvState.setText("审核失败");
                tvAuthing.setVisibility(View.GONE);
                btnState.setVisibility(View.VISIBLE);
                btnState.setText("重新申请");
                break;
        }
    }

    // 显示上次提交的数据
    private void showLastSubmitData() {
        centerTextView.setText("认证信息");
        cetInputName.setText(lastSubmitData.getName());
        cetInputID.setText(lastSubmitData.getIdCard());
        ImageManager.INSTANCE.loadReportRoundIcon(lastSubmitData.getIdUrl(), (int) mContext.getResources().getDimension(R.dimen.dp_5), ivAuthPhoto);
        authIDPhoto.setUri(Uri.parse(lastSubmitData.getIdUrl()));
        ivAuthPhotoCapture.setVisibility(View.GONE);
        String imgUrl = lastSubmitData.getImgUrl();
        if (!TextUtils.isEmpty(imgUrl) && imgUrl.contains(",")) {
            String[] urls = imgUrl.split(",");
            int length = urls.length;
            int l = length > 9 ? 9 : length;
            if (l > 0) {
                authImgBeans.clear();
                for (int i = 0; i < l; i++) {
                    String url = urls[i];
                    AuthImgBean authImgBean = new AuthImgBean("", Uri.parse(url));
                    authImgBeans.add(authImgBean);
                }
                if (authImgBeans.size() < 9) {
                    authImgBeans.add(new AuthImgBean("", null));
                }
                authImgAdapter.setNewData(authImgBeans);
                //SpannableString uploadSize = new SpannableString("已传" + l + "张");
                //uploadSize.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.color_ff6b00)), 2, 3, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                //tvPostImg.setText(uploadSize);
            }
        }
        UserInfo userInfo = LoginOrdinaryUtils.INSTANCE.getUserInfo();
        if (userInfo != null) {
            areaNo = PreferencesHelper.INSTANCE.getPref("areaNo", "86");
            List<UserAreaNo> codeList = codePopupWindow.getCodeList();
            int codePos = -1;
            for (int i = 0; i < codeList.size(); i++) {
                UserAreaNo userAreaNo = codeList.get(i);
                if (areaNo.equals(String.valueOf(userAreaNo.getStateCode()))) {
                    codePos = i;
                    break;
                }
            }
            if (codePos > -1) {
                UserAreaNo userAreaNo = codeList.get(codePos);
                String zhName = userAreaNo.getZhName();
                int stateCode = userAreaNo.getStateCode();
                tvCountry.setText(zhName);
                tvAreaCode.setText("+" + stateCode);
                constraintPhoneLength(""+stateCode);
            }
        }
        cetInputPhone.setText(lastSubmitData.getPhoneNum());
    }

    @Override
    protected void initData() {
        setAuthImg();
        loadData();
    }

    //初始化国家代码选择弹框
    private void initPopWindow() {
        codePopupWindow = new CountryCodePickerPopWin.Builder(this, new CountryCodePickerPopWin.OnCodePickedListener() {
            @Override
            public void OnCodePickedListener(UserAreaNo countryCode) {
                areaNo = countryCode.getStateCode() + "";
                constraintPhoneLength(areaNo);
                tvCountry.setText(countryCode.getZhName());
                tvAreaCode.setText("+" + areaNo);
                cetInputPhone.setText("");
                cetAuthCode.setText("");

            }
        }).colorCancel(ContextCompat.getColor(this, R.color.grey_99)) //color of cancel button
                .colorConfirm(ContextCompat.getColor(this, R.color.color_ff3683FF))//color of confirm button
                .textConfirm(getString(R.string.dialog_submit)) //text of confirm button
                .textCancel(getString(R.string.dialog_cancel)) //text of cancel button
                //.popDataList(codeList)
                .isShowDay(false)
                .build();
    }

    private final String CODE_DEFAULT = "86";
    private final String CODE_PH = "63";
    private final String CODE_Cam = "855";
    private final String CODE_MALA = "60";
    private final String CODE_HK = "852";

    //根据区号限制手机输入框输入的最大长度
    private void constraintPhoneLength(String code) {
        switch (code) {
            case CODE_DEFAULT:
                cetInputPhone.setFilters(new InputFilter[]{new InputFilter.LengthFilter(11)});
                break;
            case CODE_PH:
                cetInputPhone.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
                break;
            case CODE_Cam:
            case CODE_HK:
                cetInputPhone.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
                break;
            case CODE_MALA:
                cetInputPhone.setFilters(new InputFilter[]{new InputFilter.LengthFilter(12)});
                break;
            default:
                cetInputPhone.setFilters(new InputFilter[]{new InputFilter.LengthFilter(22)});
                break;
        }
    }

    private void hideLoading() {
        hideDialogLoading();
        hidePageLoading();
        stopRefresh();
    }

    private void setAuthImg() {
        rvAuthImg.setLayoutManager(new GridLayoutManager(mContext, 3));
        rvAuthImg.addItemDecoration(new GridSpacingItemDecoration(3, DensityUtil.dp2px(2), false));
        rvAuthImg.setAdapter(authImgAdapter);
        authImgBeans.add(new AuthImgBean("", null));
        authImgAdapter.setNewData(authImgBeans);
        authImgAdapter.setOnItemClickListener((adapter, view, position) -> {
            if (position == authImgBeans.size() - 1 && authImgBeans.get(position).getUri() == null) {
                tryOpenGallery();
            }
        });
        authImgAdapter.setOnDataChangedListener((data, pos) -> {
            Uri uri = data.get(pos).getUri();
            int temp = -1;
            for (int i = 0; i < s.size(); i++) {
                if (s.get(i).getContentUri().equals(uri)) {
                    temp = i;
                    break;
                }
            }
            if (temp > -1) {
                s.remove(temp);
            }
            AuthImgBean authImgBean = data.get(pos);
            authImgBeans.remove(authImgBean);
            if (authImgBeans.size() == 8 && authImgBeans.get(7).getUri() != null) {
                authImgBeans.add((new AuthImgBean("", null)));
            }
            authImgAdapter.setNewData(authImgBeans);
        });
    }

    /**
     * 动态权限请求回调
     *
     * @param requestCode
     * @param permissions
     * @param grantResults
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean hasPermissionDenied = false;
        if (requestCode == PERMISSION_REQUEST_CODE_OPEN_GALLERY) {
            for (int grantResult : grantResults) {
                if (grantResult == PackageManager.PERMISSION_DENIED) {
                    hasPermissionDenied = true;
                }
            }
            if (hasPermissionDenied) {
                showToastMsgShort("请检测权限");
            } else {
                openGallery();
            }
        } else if(requestCode == PERMISSION_REQUEST_CODE_CAPTURE) {
            for (int grantResult : grantResults) {
                if (grantResult == PackageManager.PERMISSION_DENIED) {
                    hasPermissionDenied = true;
                }
            }
            if (hasPermissionDenied) {
                showToastMsgShort("请检测权限");
            } else {
                openCapture();
            }
        }
    }

    /**
     * activity的回调
     *
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case Constant.REQUEST_CODE_CHOOSE:
                openGalleryCallBack(resultCode, data);
                break;
            case REQUEST_CODE_CAPTURE:
                openCaptureCallback(resultCode, data);
           default:
               break;
        }
    }


    List<String> capturePermissions = new ArrayList<>();
    private void tryOpenCapture() {
        capturePermissions.clear();
        // 判断权限
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                capturePermissions.add(permission);
            }
        }

        // 申请权限
        if (capturePermissions.size() > 0) {
            ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE_CAPTURE);
        } else {
            openCapture();
        }
    }

    /**
     * 打开相机
     */
    private void openCapture() {
        Matisse.from(this)
                .choose(MimeType.of(MimeType.JPEG, MimeType.PNG))//图片类型
                .countable(true)//true:选中后显示数字;false:选中后显示对号
                .maxSelectable(1)//可选的最大数
                .capture(true)//选择照片时，是否显示拍照
                .setSelectionItems(new ArrayList<>())
                .gridExpectedSize(getResources().getDimensionPixelSize(R.dimen.dp_120))
                .restrictOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED)
                .thumbnailScale(0.85f)
                .theme(R.style.Matisse_Zhihu)
                //参数1 true表示拍照存储在共有目录，false表示存储在私有目录；参数2与 AndroidManifest中authorities值相同，用于适配7.0系统 必须设置
                .captureStrategy(new CaptureStrategy(true, getPackageName()+".fileProvider"))
                .imageEngine(new MyGlideEngine())//图片加载引擎
                .forResult(REQUEST_CODE_CAPTURE);//
    }

    /**
     * 打开相机回调
     * @param resultCode
     * @param data
     */
    private void openCaptureCallback(int resultCode, @Nullable Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            if (data == null) return;
            List<String> paths = Matisse.obtainPathResult(data);

            if (paths == null || paths.size() == 0) return;

            String path = paths.get(0);
            File file = new File(path);
            if (file.exists()) {
                authIDPhoto.setPath(path);
                tvPhotoTip.setVisibility(View.GONE);
                ivAuthPhotoCapture.setVisibility(View.GONE);
                ImageManager.INSTANCE.loadReportRoundIcon(path, (int) mContext.getResources().getDimension(R.dimen.dp_5), ivAuthPhoto);
            }
        }
    }

    private void tryOpenGallery() {
        boolean hasPermission = ImageUtils.INSTANCE.checkPermission(SpecialAuthActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (!hasPermission) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE_OPEN_GALLERY);
        } else {
            openGallery();
        }
    }

    /**
     * 打开相册
     */
    private void openGallery() {
        int count = 9;
        if (authImgBeans!=null) {
            boolean flag = false;
            for (AuthImgBean authImgBean : authImgBeans) {
                if (TextUtils.isEmpty(authImgBean.getPath()) && authImgBean.getUri() == null){
                    flag = true;
                    break;
                }
            }
            if (flag){
                count = 9+1 - authImgBeans.size();
            }else{
                count = 0;
            }
        }

        Matisse.from(this)
                .choose(MimeType.of(MimeType.JPEG, MimeType.PNG), false)
                .theme(R.style.Matisse_Zhihu)
                .countable(true)
                .showSingleMediaType(true)
                .maxSelectable(9)
                .thumbnailScale(0.8f)
                .setSelectionItems(s)
                .originalEnable(false)
                .maxOriginalSize(10)
                .imageEngine(new Glide4Engine())
                .forResult(Constant.REQUEST_CODE_CHOOSE);
    }


    /**
     * 打开相册回调
     * @param resultCode
     * @param data
     */
    private void openGalleryCallBack(int resultCode, @Nullable Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            if (data == null) return;
            s = Matisse.obtainItem(data);
            List<Uri> uris = Matisse.obtainResult(data);
            List<String> paths = Matisse.obtainPathResult(data);

            if (uris == null || uris.size() == 0 || paths == null || paths.size() == 0) return;

            AuthImgBean temp = null;
            if (authImgBeans!=null) {
                for (AuthImgBean authImgBean : authImgBeans) {
                    if (TextUtils.isEmpty(authImgBean.getPath()) && authImgBean.getUri() == null) {
                        temp = authImgBean;
                        break;
                    }
                }
            }

            // authImgData.clear();
            if (temp != null && authImgBeans!=null){
                authImgBeans.remove(temp);
            }
            List<AuthImgBean> tempList = new ArrayList<>();
            if (!authImgBeans.isEmpty()) {
                for (int i = 0; i < authImgBeans.size(); i++) {
                    AuthImgBean authImgBean = authImgBeans.get(i);
                    Uri uri = authImgBean.getUri();
                    if (uri != null) {
                        String s = uri.toString();
                        if (s.startsWith("http")) {
                            tempList.add(authImgBean);
                        }
                    }
                }
            }
            authImgBeans = tempList;
            for (int i = 0; i < uris.size(); i++) {
                if (authImgBeans.size()<9) {
                    authImgBeans.add(new AuthImgBean(paths.get(i), uris.get(i)));
//                    Uri u1 = uris.get(i);
//                    if (u1 != null) {
//                        boolean has = false;
//                        for (int j = 0; j < authImgBeans.size(); j++) {
//                            Uri u2 = authImgBeans.get(j).getUri();
//                            if (u1.equals(u2)) {
//                                has = true;
//                                break;
//                            }
//                        }
//                        if (!has) {
//                            authImgBeans.add(new AuthImgBean(paths.get(i), uris.get(i)));
//                        }
//                    }
                }
            }
//            for (int i = 0; i < paths.size(); i++) {
//                String path = paths.get(i);
//                File file = new File(path);
//                if (file.exists()) {
//                    otherFiles.add(file);
//                }
//            }
            if (authImgBeans.size() < 9) {
                authImgBeans.add(new AuthImgBean("", null));
            }
            authImgAdapter.setNewData(authImgBeans);
        }
    }

    @Override
    protected void processClick(View view) {
        int id = view.getId();
        if (R.id.btnSubmit == id) {
            postSubmit();
        } else if (R.id.ivAuthPhoto == id) {
            tryOpenCapture();
        } else if (id == R.id.tvAreaCode || id == R.id.tvCountry) {
            if (codePopupWindow.isShowing()) {
                codePopupWindow.dismiss();
            } else {
                codePopupWindow.showPopWin(this);
            }
        } else if (id == R.id.tvGetCode) {
            sendAuthCode();
        } else if (id == R.id.tvShowSamplePhoto) {
            showPhotoSample();
        } else if (id == R.id.btnState) {
            rlAuthSate.setVisibility(View.GONE);
            smartRefreshLayout.setVisibility(View.VISIBLE);
            showLastSubmitData();
        }
    }

    // 展示拍照示例
    private void showPhotoSample() {
        SpecialSamplePhotoDialog dialog = new SpecialSamplePhotoDialog(this);
        dialog.show();
    }

    private String areaNo = CODE_DEFAULT; //手机所在国家编号
    // 获取验证码
    private void sendAuthCode() {
        if (!NetWorkUtils.INSTANCE.isNetworkConnected()){
            showToastMsgLong("暂无网络");
            return;
        }
        tvPhoneTip.setText("");
        String phoneStr = cetInputPhone.getText().toString().replace(" ", "");
        if (!TextUtils.isEmpty(phoneStr) && phoneStr.contains("*")) {
            phoneStr = mobile;
        }
        if (LoginOrdinaryUtils.INSTANCE.checkMobilNumber(areaNo, phoneStr)) { // 验证手机号
            specialAuthUtils.start(tvGetCode, cetInputPhone, getResources()); // 60秒倒计时
            mPresenter.sendAuthCode(phoneStr, areaNo); // 获取验证码
        } else {
            tvPhoneTip.setText("手机号错误");
            tvPhoneTip.setVisibility(View.VISIBLE);
        }
    }

    //设置获取验证码状态
    private void setAuthCodeState(boolean enable) {
        if (enable) {
            tvGetCode.setEnabled(true);
            tvGetCode.setTextColor(ContextCompat.getColor(this, R.color.login_server_info_color));
            tvGetCode.setBackgroundResource(R.drawable.shape_special_auth_verifycode_bg);
        } else {
            tvGetCode.setEnabled(false);
            tvGetCode.setTextColor(ContextCompat.getColor(this, R.color.grey_66));
            tvGetCode.setBackgroundResource(R.drawable.shape_special_auth_verifycode_bg2);
        }
    }

    //获取验证码失败
    public void onGetCodeFail(String errMsg) {
        String errorMsg = TextUtils.isEmpty(errMsg) ? "短信接口调用失败" : errMsg;
        ToastUtils.showToast(errorMsg);
        cetAuthCode.setText("");
        if (!StringUtils.isNullOrEmpty(cetInputPhone.getText().toString().trim())) {
            setAuthCodeState(true);
        }
        tvGetCode.setText("获取验证码");
        specialAuthUtils.removeRunable();
    }

    /**
     * 提交认证信息
     */
    private void postSubmit() {

        if (TextUtils.isEmpty(cetInputName.getText().toString().trim())) {
            tvNameTip.setText("请输入您的姓名");
            tvNameTip.setVisibility(View.VISIBLE);
            return;
        }

        if (TextUtils.isEmpty(cetInputID.getText().toString().trim())) {
            tvNameTip.setText("请输入您的身份证号码");
            tvNameTip.setVisibility(View.VISIBLE);
            return;
        }

        if (TextUtils.isEmpty(authIDPhoto.getPath()) && (authIDPhoto.getUri() == null)){
            tvPhotoTip.setText("请上传正面手持身份证照片");
            tvPhotoTip.setVisibility(View.VISIBLE);
            return;
        }

        postFiles.clear();

        String idPhotoPath = authIDPhoto.getPath();
        if (!TextUtils.isEmpty(idPhotoPath)) {
            postFiles.add(new File(idPhotoPath));
        }

        StringBuilder lastPostFiles = new StringBuilder();
        if (!authImgBeans.isEmpty()) {
            for (AuthImgBean authImgBean:authImgBeans) {
                if (!TextUtils.isEmpty(authImgBean.getPath())) {
                    postFiles.add(new File(authImgBean.getPath()));
                }
                Uri uri = authImgBean.getUri();
                if ((uri != null) && (uri.toString().startsWith("http"))) {
                    lastPostFiles.append(uri.toString()).append(",");
                }
            }
        }

        if (TextUtils.isEmpty(cetInputPhone.getText().toString().trim())){
            tvPhoneTip.setText("请输入手机号");
            tvPhoneTip.setVisibility(View.VISIBLE);
            return;
        }

        String authCodeStr = cetAuthCode.getText().toString().trim();
        if (TextUtils.isEmpty(authCodeStr)){
            tvPhoneTip.setText("请输入验证码");
            tvPhoneTip.setVisibility(View.VISIBLE);
            return;
        }
        if (!LoginOrdinaryUtils.INSTANCE.isAuthCodeFormat(authCodeStr)) {
            tvPhoneTip.setText("验证码错误");
            tvPhoneTip.setVisibility(View.VISIBLE);
            cetAuthCode.setText("");
            return;
        }

        SpecialReviewBean postData = new SpecialReviewBean();
        if (TextUtils.isEmpty(idPhotoPath)) {
            postData.setIdUrl(authIDPhoto.getUri().toString());
        }
        postData.setImgUrl(lastPostFiles.toString());
        if (SpecialReviewBean.TYPE_UPDATE.equals(submitType) && lastSubmitData != null) {
            postData.setId(lastSubmitData.getId());
        }
        postData.setSubmitType(submitType);
        postData.setName(cetInputName.getText().toString());
        postData.setIdCard(cetInputID.getText().toString());
        String phoneStr = cetInputPhone.getText().toString().trim().replace(" ", "");
        if (!TextUtils.isEmpty(phoneStr) && phoneStr.contains("*")) {
            phoneStr = mobile;
        }
        postData.setPhoneNum(phoneStr);
        postData.setCode(cetAuthCode.getText().toString());
        showDialogLoading();
        mPresenter.submitAuthFormData(postFiles, postData);
    }


    /**
     * 修改数据
     */
    private void upDateSubmit() {


    }

    private void loadData() {
        showPageLoading();
        mPresenter.getSpecialReview();
    }

    private void showUserPhone() {
        // 预先填充用户登陆的手机号
        smartRefreshLayout.setVisibility(View.VISIBLE);
        rlAuthSate.setVisibility(View.GONE);
        UserInfo userInfo = LoginOrdinaryUtils.INSTANCE.getUserInfo();
        if (userInfo != null) {
            areaNo = PreferencesHelper.INSTANCE.getPref("areaNo", "86");
            List<UserAreaNo> codeList = codePopupWindow.getCodeList();
            int codePos = -1;
            for (int i = 0; i < codeList.size(); i++) {
                UserAreaNo userAreaNo = codeList.get(i);
                if (areaNo.equals(String.valueOf(userAreaNo.getStateCode()))) {
                    codePos = i;
                    break;
                }
            }
            if (codePos > -1) {
                UserAreaNo userAreaNo = codeList.get(codePos);
                String zhName = userAreaNo.getZhName();
                int stateCode = userAreaNo.getStateCode();
                mobile = userInfo.getMobile();
                cetInputPhone.setText(DigitUtil.hidePhone(mobile));
                tvCountry.setText(zhName);
                tvAreaCode.setText("+" + stateCode);
                constraintPhoneLength(""+stateCode);
            }
        }
    }
}
