package com.yb.ballworld.information.ui.community.bean;

public class TopicConstant {
    public final static int TYPE_TOPIC_TEXT = 0; // 文本
    public final static int TYPE_TOPIC_IMAGE = 1;// 图片
    public final static int TYPE_TOPIC_VIDEO = 2;// 视频

}
