package com.yb.ballworld.information.ui.profile.view.fragments;

import android.graphics.Color;
import android.view.View;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.yb.ballworld.common.livedata.LiveDataObserver;
import com.yb.ballworld.common.utils.TUtil;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.profile.adapter.DataSubTotalAdapter;
import com.yb.ballworld.information.ui.profile.data.DataSubTotalBean;
import com.yb.ballworld.information.ui.profile.presenter.DataSubTotalPresenter;

import java.util.ArrayList;
import java.util.List;

/**
 * 资料库-数据-总计
 * @author Gethin
 * @time 2019/11/9 10:25
 */

public class DataSubTotalFragment extends RvBaseFragment<DataSubTotalPresenter>{
    private String playerId;
    private Class cls;

    private DataSubTotalAdapter adapter = new DataSubTotalAdapter(R.layout.rv_item_data_sub_total_section);

    public  static <T extends DataSubTotalPresenter>  DataSubTotalFragment newInstance(Class<T> cls,String playerId){
        DataSubTotalFragment fragment=new DataSubTotalFragment();
        fragment.playerId=playerId;
        fragment.cls=cls;
        return fragment;
    }

    @Override
    protected void initView() {
        super.initView();
        rlRoot.setBackgroundColor(Color.parseColor("#ffffff"));
    }

    @Override
    protected void loadData() {
        mPresenter.loadDataSubTotal();
      //  testUI();
    }

    @Override
    protected BaseQuickAdapter getAdapter() {
        return adapter;
    }

    @Override
    public void initPresenter() {
        try{
            mPresenter = (DataSubTotalPresenter) cls.newInstance();
            // mModel= TUtil.getT(this,1);
            if (mPresenter != null) {
                mPresenter.mContext = this.getActivity();
                mPresenter.setVM(this);
                mPresenter.setPlayerId(playerId);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    protected void bindEvent() {
        mPresenter.dataSubTotalData.observe(this, new LiveDataObserver<List<DataSubTotalBean>>() {
            @Override
            public void onSuccess(List<DataSubTotalBean> data) {
                smartRefreshLayout.finishRefresh();
                if (data != null && data.size() > 0) {
                    showPageContent();
                    adapter.setNewData(data);
                } else {
                    showPageEmpty("");
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                smartRefreshLayout.finishRefresh();
                showPageError(errMsg);
            }
        });
    }

    @Override
    protected void processClick(View view) {

    }

    private void testUI(){
        DataSubTotalBean subTotalSection = new DataSubTotalBean(DataSubTotalBean.SECTION);
        DataSubTotalBean subTotalContent = new DataSubTotalBean(DataSubTotalBean.CONTENT);
        List<DataSubTotalBean> subTotalBeans = new ArrayList<>();
        subTotalBeans.add(subTotalSection);
        subTotalBeans.add(subTotalContent);
        adapter.setNewData(subTotalBeans);
    }
}
