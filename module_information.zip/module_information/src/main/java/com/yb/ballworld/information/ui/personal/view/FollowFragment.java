package com.yb.ballworld.information.ui.personal.view;

import android.app.Dialog;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import androidx.lifecycle.Observer;

import com.bfw.util.ToastUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.livedata.LiveDataResult;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.community.bean.Topic;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.personal.adapter.FollowAdapter;
import com.yb.ballworld.information.ui.personal.bean.Follow;
import com.yb.ballworld.information.ui.personal.presenter.FollowPresenter;
import com.yb.ballworld.information.ui.profile.view.fragments.RvBaseFragment;
import com.yb.ballworld.information.utils.ShareTextUitl;
import com.yb.ballworld.information.widget.ConfirmDialog;

import java.util.List;

public class FollowFragment extends RvBaseFragment<FollowPresenter> {
    public final static int TYPE_FOLLOW=Integer.MAX_VALUE;
    public final static int TYPE_FANS=Integer.MIN_VALUE;
    private boolean isReset;

    private String userId;
    private int type;
    private int from;
    public static FollowFragment newInstance(String userId,int type,int from) {
        FollowFragment fragment = new FollowFragment();
        fragment.userId=userId;
        fragment.type=type;
        fragment.from=from;
        return fragment;
    }

    @Override
    protected void loadData() {

    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_follow_recycler_view;
    }

    @Override
    protected void initView() {
        super.initView();
        smartRefreshLayout.setRefreshFooter(getRefreshFooter());
        smartRefreshLayout.setEnableAutoLoadMore(true);
        initRefreshView();
        enableRefresh(true);
        enableLoadMore(false);
        placeholderView.setPageErrorRetryListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPageLoading();
                mPresenter.getList();
            }
        });
    }

    @Override
    protected void initData() {
        super.initData();
        showPageLoading();
        mPresenter.getList();
    }

    @Override
    protected BaseQuickAdapter getAdapter() {
        return new FollowAdapter(R.layout.item_follow);
    }

    @Override
    public void initPresenter() {
        mPresenter.setVM(this);
        mPresenter.setFocusUserId(userId);
        mPresenter.setType(type);
    }

    @Override
    protected void bindEvent() {
        adapter.setOnItemChildClickListener(new BaseQuickAdapter.OnItemChildClickListener() {
            @Override
            public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
                Follow follow= (Follow) adapter.getData().get(position);
                if(follow==null) return;
                // TODO 关注与取消关注
                if (view.getId() == R.id.tv_follow) {
                    if(LoginOrdinaryUtils.INSTANCE.isLogin()){
                        onAttentionClick(follow,view,position);
                    }else{
                        NavigateToDetailUtil.toLogin(getActivity());
                    }
                } else if (view.getId() == R.id.iv_head_image || view.getId() == R.id.tv_nick_name) {
                    InformationPersonalActivityNew.startActivity(getActivity(),""+follow.getUserId(),from);
                }
            }
        });

        mPresenter.followData.observe(this, new Observer<LiveDataResult<List<Follow>>>() {
            @Override
            public void onChanged(LiveDataResult<List<Follow>> result) {
                hidePageLoading();
                smartRefreshLayout.finishRefresh();
                smartRefreshLayout.finishLoadMore();
                // 如果是下拉刷新，则清空数据
                if(isReset){
                    isReset=false;
                    List list=adapter.getData();
                    if(list!=null){
                        list.clear();
                        adapter.notifyDataSetChanged();
                    }
                }
                if(result.isSuccessed()){
                    List<Follow> datas=adapter.getData();
                    if(datas==null){
                        adapter.setNewData(result.getData());
                    }else{
                        int startInde=datas.size();
                        datas.addAll(result.getData());
                        adapter.notifyItemRangeChanged(startInde,datas.size());
                    }

                    enableLoadMore(mPresenter.hasMore());
                }else{
                    if(result.getErrorCode()==Integer.MIN_VALUE){
                        showPageEmpty(result.getErrorMsg());
                    }else{
                        showPageError(result.getErrorMsg());
                    }
                }
            }
        });
        // 个人空间关注, 粉丝更新数据
        if(type==TYPE_FANS){
            LiveEventBus.get().with(LiveEventBusKey.KEY_TOPIC_ATTENTION_USER_SPACE, Topic.class).observe(this, new Observer<Topic>() {
                @Override
                public void onChanged(Topic topic) {
                    if(topic!=null){
                        resetPage();
                        showPageLoading();
                        mPresenter.getList();
                    }
                }
            });
        }


    }

    @Override
    protected void processClick(View view) {

    }


    @Override
    protected void onLoadMoreData() {
        super.onLoadMoreData();
        mPresenter.getList();
    }

    @Override
    protected void onRefreshData() {
        super.onRefreshData();
        resetPage();
        mPresenter.getList();
    }

    /**
     * 判断是否用户本人
     * @param userId
     * @return
     */
    private boolean isSelf(String userId){
        if(TextUtils.isEmpty(userId)){
            return false;
        }
        long uid= LoginOrdinaryUtils.INSTANCE.getUid();
        if(uid==0){
            return false;
        }
        return String.valueOf(uid).equals(userId);
    }




    private void onAttentionClick(Follow follow , View view,int postion) {
        boolean isAttention = view.isSelected();
        if (isAttention) {
            new ConfirmDialog(getActivity(), ShareTextUitl.getMarksText(follow.getNickname()), "是否取消对ta的关注？", new ConfirmDialog.OnCloseListener() {
                @Override
                public void onClick(Dialog dialog, boolean confirm) {
                    if (confirm) {
                        //取消关注
                        attentionAction(view, follow,postion);
                    }
                }
            }).show();
        } else {
            attentionAction(view, follow,postion);
        }
    }


    private void attentionAction(View view, Follow follow ,int postion) {
        mPresenter.attentionAction(follow.getUserId(), !view.isSelected(), new LifecycleCallback(FollowFragment.this) {
            @Override
            public void onSuccess(Object data) {
                view.setSelected(!view.isSelected());
                if(!view.isSelected()){
                    ToastUtils.showToast("已取消");
                    // 是自己，移除改item
                    if(isSelf(userId)){
                        if(type==TYPE_FOLLOW){
                            adapter.getData().remove(postion);
                            adapter.notifyDataSetChanged();
                        }
                    }
                    int fans=follow.getFansCount()-1;
                    if(fans<0){
                        fans=0;
                    }
                    follow.setFansCount(fans);
                }else{
                    ToastUtils.showToast("已关注");
                    follow.setFansCount(follow.getFansCount()+1);
                }
                follow.setIsAttention(view.isSelected());
                Object object=view.getTag();
                if(object!=null && object instanceof TextView){
                    ((TextView)object).setText("粉丝" + follow.getFansCount() + " |  帖子" + follow.getPostCount());
                }

            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                ToastUtils.showToast("网络异常，请稍后再试");
            }
        });
    }

    /**
     * 更新一面状态
     */
    private void resetPage(){
        mPresenter.resetPage();
        isReset=true;
    }
}
