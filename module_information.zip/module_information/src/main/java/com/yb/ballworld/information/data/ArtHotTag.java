package com.yb.ballworld.information.data;

/**
* Desc: 关键热词标签
* @author ink
* created at 2019/10/9 20:51
*/
public class ArtHotTag {
    //标签Id
    private long tagId;
    //标签名称
    private String tagName;
    //热门值
    private String heat;
    //图标
    private String tagIcon;
    //行为类型
    private int action;

    public long getTagId() {
        return tagId;
    }

    public void setTagId(long tagId) {
        this.tagId = tagId;
    }

    public String getTagName() {
        return tagName;
    }

    public void setTagName(String tagName) {
        this.tagName = tagName;
    }

    public String getHeat() {
        return heat;
    }

    public void setHeat(String heat) {
        this.heat = heat;
    }

    public String getTagIcon() {
        return tagIcon;
    }

    public void setTagIcon(String tagIcon) {
        this.tagIcon = tagIcon;
    }

    public int getAction() {
        return action;
    }

    public void setAction(int action) {
        this.action = action;
    }
}
