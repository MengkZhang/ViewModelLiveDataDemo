package com.yb.ballworld.information.ui.detail;

import com.yb.ballworld.common.base.mvp.BaseModel;
import com.yb.ballworld.information.data.ArticleDetailBean;
import com.yb.ballworld.information.data.CommitBeanList;

/**
 * 详情页数据模型
 */
public class InforDetailModel implements BaseModel {

    private ArticleDetailBean articleDetail;
    private CommitBeanList commitBeanList;

    public ArticleDetailBean getArticleDetail() {
        return articleDetail;
    }

    public void setArticleDetail(ArticleDetailBean articleDetail) {
        this.articleDetail = articleDetail;
    }

    public CommitBeanList getCommitBeanList() {
        return commitBeanList;
    }

    public void setCommitBeanList(CommitBeanList commitBeanList) {
        this.commitBeanList = commitBeanList;
    }
}
