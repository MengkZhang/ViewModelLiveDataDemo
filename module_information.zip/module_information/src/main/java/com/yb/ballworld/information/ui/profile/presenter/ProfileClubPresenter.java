package com.yb.ballworld.information.ui.profile.presenter;

import android.util.Log;

import androidx.lifecycle.LifecycleOwner;

import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.livedata.LiveDataWrap;
import com.yb.ballworld.information.ui.profile.data.ClubBasicsInfoBean;
import com.yb.ballworld.information.ui.profile.data.ClubTeamSeasonIdBean;
import com.yb.ballworld.information.ui.profile.http.ProfileHttp;


/**
 * @author Gethin
 * @time 2019/11/20 12:53
 */

public class ProfileClubPresenter extends BasePresenter<LifecycleOwner, VoidModel> {

    private ProfileHttp http = new ProfileHttp();

    public LiveDataWrap<ClubTeamSeasonIdBean> clubTeamSeasonId = new LiveDataWrap<>();
    public LiveDataWrap<ClubBasicsInfoBean> clubBasicsInfoBean = new LiveDataWrap<>();

    public void loadClubTeamSeasonId(String teamId) {
        add(http.getClubTeamSeasonId(teamId, new LifecycleCallback<ClubTeamSeasonIdBean>(mView) {
            @Override
            public void onSuccess(ClubTeamSeasonIdBean data) {
                LogUtils.INSTANCE.i("wxz", "onSuccess: " + data.toString());
                loadClubBaseInfo(teamId, data.getSeasonId());
                clubTeamSeasonId.setData(data);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                clubTeamSeasonId.setError(errCode, errMsg);
                LogUtils.INSTANCE.i("wxz", "onSuccess: " + errCode + "," + errMsg);
            }
        }));
    }

    private void loadClubBaseInfo(String teamId, String seasonId) {
        add(http.getClubBasicsInfo(teamId, seasonId, new LifecycleCallback<ClubBasicsInfoBean>(mView) {
            @Override
            public void onSuccess(ClubBasicsInfoBean data) {
                clubBasicsInfoBean.setData(data);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                clubBasicsInfoBean.setError(errCode, errMsg);
            }
        }));
    }


}
