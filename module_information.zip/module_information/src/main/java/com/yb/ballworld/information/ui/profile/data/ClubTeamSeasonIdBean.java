package com.yb.ballworld.information.ui.profile.data;

/**
 * @author Gethin
 * @time 2019/11/21 18:02
 */

public class ClubTeamSeasonIdBean {

    /**
     * seasonId : 11100
     * teamId : 44
     * type : 1
     */

    private String seasonId;
    private String teamId;
    private String type;

    public String getSeasonId() {
        return seasonId;
    }

    public void setSeasonId(String seasonId) {
        this.seasonId = seasonId;
    }

    public String getTeamId() {
        return teamId;
    }

    public void setTeamId(String teamId) {
        this.teamId = teamId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "ClubTeamSeasonIdBean{" +
                "seasonId='" + seasonId + '\'' +
                ", teamId='" + teamId + '\'' +
                ", type='" + type + '\'' +
                '}';
    }
}
