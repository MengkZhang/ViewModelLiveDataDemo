package com.yb.ballworld.information.ui.auth.widget;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.yb.ballworld.information.R;

/**
 * 特约认证提示对话框
 * Date 2019/10/20
 * author mengk
 */
public class SpecialAuthTipDialog extends Dialog {
    private Context context;
    private TextView tvTitle;
    private TextView tvSubTitle;
    private TextView tvCancel;
    private TextView tvOK;
    private String title;
    private View vdivider;

    public SpecialAuthTipDialog(@NonNull Context context, String title) {
        super(context, R.style.common_dialog);
        this.context = context;
        this.title = title;
        setContentView(R.layout.dialog_special_auth);
        initView();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setCanceledOnTouchOutside(false);
            Window window = getWindow();
            WindowManager.LayoutParams attributes = window.getAttributes();
            attributes.gravity = Gravity.CENTER;
            attributes.width = WindowManager.LayoutParams.MATCH_PARENT;
            window.setAttributes(attributes);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initView() {
        tvTitle = findViewById(R.id.tv_title);
        tvSubTitle = findViewById(R.id.tv_sub_title);
        tvCancel = findViewById(R.id.tv_cancel);
        tvOK = findViewById(R.id.tv_ok);
        vdivider = findViewById(R.id.v_divider);
        tvTitle.setText(title);
        tvOK.setOnClickListener(v -> {
            if (mSureOrCancelListener != null) {
                mSureOrCancelListener.ok();
            }
        });
        tvCancel.setOnClickListener(v -> {
            if (mSureOrCancelListener != null) {
                mSureOrCancelListener.cancel();
            }
        });
    }

    public void setTitle(String text){
        tvTitle.setVisibility(View.VISIBLE);
        tvTitle.setText(text);
    }

    public void setSubTitle(String text) {
        tvSubTitle.setVisibility(View.VISIBLE);
        tvSubTitle.setText(text);
    }

    public void showOneBtn() {
        tvCancel.setVisibility(View.GONE);
        vdivider.setVisibility(View.GONE);
        tvOK.setVisibility(View.VISIBLE);
    }

    public interface SureOrCancelListener {
        void cancel();
        void ok();
    }

    private SureOrCancelListener mSureOrCancelListener;

    public void setSureOrCancelListener(SureOrCancelListener mSureOrCancelListener) {
        this.mSureOrCancelListener = mSureOrCancelListener;
    }
}
