package com.yb.ballworld.information.ui.home.presenter;

import android.content.Intent;
import android.text.TextUtils;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.MutableLiveData;

import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.livedata.LiveDataWrap;
import com.yb.ballworld.information.ui.home.bean.IndexLableLetterBean;
import com.yb.ballworld.information.ui.home.bean.OutSideIndexListLableLetterBean;
import com.yb.ballworld.information.ui.home.bean.OutSideLableGroupBean;
import com.yb.ballworld.information.ui.home.constant.PublishTagType;
import com.yb.ballworld.information.ui.home.constant.TagParams;
import com.yb.ballworld.information.ui.home.constant.TagReqCode;
import com.yb.ballworld.information.ui.home.service.InfoHttpApi;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.home.view.TagSortActivity;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc
 * Date 2019/11/6
 * author mengk
 */
public class TagSortGroupPresenter extends BasePresenter<LifecycleOwner, VoidModel> {
    private InfoHttpApi httpApi = new InfoHttpApi();

    private LiveDataWrap<OutSideLableGroupBean> mOutSideLableGroupBean = new LiveDataWrap<>();
    private MutableLiveData<Boolean> reqLoading = new MutableLiveData<>();

    public MutableLiveData<Boolean> getReqLoading() {
        return reqLoading;
    }

    public LiveDataWrap<OutSideLableGroupBean> getmOutSideLableGroupBean() {
        return mOutSideLableGroupBean;
    }

    /**
     * 获取按照字母排序的tag列表
     * @param type
     * @param searchKey
     */
    public void getLableGroupData(String type,String searchKey) {
        //搜索的时候不显示loading
        if (TextUtils.isEmpty(searchKey)) {
            reqLoading.setValue(true);
        } else {
            reqLoading.setValue(false);
        }

        add(httpApi.getLableListGroup(type, searchKey, new LifecycleCallback<OutSideLableGroupBean>(mView) {
            @Override
            public void onSuccess(OutSideLableGroupBean data) {
                if (data != null) {
                    mOutSideLableGroupBean.setData(data);
                } else {
                    mOutSideLableGroupBean.setError(0,"data数据为空");
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                mOutSideLableGroupBean.setError(errCode,!TextUtils.isEmpty(errMsg) ? errMsg : "请求服务器失败");
            }
        }));
    }

    /**
     * 点击到更多标签页面
     * @param activity
     * @param position
     * @param lebelGroupData
     */
    public void clickToMoreTags(AppCompatActivity activity,int position,List<OutSideIndexListLableLetterBean> lebelGroupData) {
        List<IndexLableLetterBean> resultList = new ArrayList<>();
        ArrayList<String> ids = new ArrayList<>();

        OutSideIndexListLableLetterBean lableLetterBean = lebelGroupData.get(position);
        if (lableLetterBean != null) {
            List<IndexLableLetterBean> list = lableLetterBean.getList();
            for (IndexLableLetterBean indexLableLetterBean : list) {
                if (indexLableLetterBean.isCheck()) {
                    resultList.add(indexLableLetterBean);
                }
            }

            for (IndexLableLetterBean indexLableLetterBean : resultList) {
                ids.add(String.valueOf(indexLableLetterBean.getId()));
            }

            //数组组装按照 1球员，2俱乐部球队，3赛事 4国家队的顺序
            int type;
            switch (position) {
                case 0:
                    type = PublishTagType.TYPE_PERSON;
                    break;
                case 1:
                    type = PublishTagType.TYPE_TEAM;
                    break;
                case 2:
                    type = PublishTagType.TYPE_MATCH;
                    break;
                case 3:
                    type = PublishTagType.TYPE_COUNTRY_TEAM;
                    break;
                default:
                    type = PublishTagType.TYPE_PERSON;
                    break;
            }

            //跳转
            NavigateToDetailUtil.navigateToTagSortByIndex(activity, ids,type,position);

        }
    }

    /**
     * 点击确认以及数据回调处理
     * @param activity
     * @param lebelGroupData
     */
    public void sureClickResultHandleData(TagSortActivity activity,List<OutSideIndexListLableLetterBean> lebelGroupData) {
        ArrayList<IndexLableLetterBean> returnList = new ArrayList<>();
        if (lebelGroupData != null && lebelGroupData.size() != 0) {

            for (OutSideIndexListLableLetterBean lebelGroupDatum : lebelGroupData) {
                List<IndexLableLetterBean> list = lebelGroupDatum.getList();
                for (IndexLableLetterBean indexLableLetterBean : list) {
                    if (indexLableLetterBean.isCheck()) {
                        returnList.add(indexLableLetterBean);
                    }
                }
            }

            Intent intent = new Intent();
            intent.putExtra(TagParams.INTENT_PARAM_DATA, returnList);
            activity.setResult(TagReqCode.REQ_CODE_PUBLISH_TO_TAG, intent);
            activity.finish();

        }
    }

    /**
     * 处理回调事件
     */
    public void onActivityResultHandleData(Intent data,List<OutSideIndexListLableLetterBean> lebelGroupData) {
        ArrayList<String> ids = data.getStringArrayListExtra(TagParams.INTENT_PARAM);
        int position = data.getIntExtra(TagParams.INTENT_PARAM_POSITION, 0);
        OutSideIndexListLableLetterBean bean = lebelGroupData.get(position);

        //判断传过来的数组是否包含当前id
        if (ids != null && ids.size() != 0) {

            List<IndexLableLetterBean> list = bean.getList();
            for (IndexLableLetterBean indexLableLetterBean : list) {
                int id = indexLableLetterBean.getId();
                if (ids.contains(String.valueOf(id))) {
                    indexLableLetterBean.setCheck(true);
                } else {
                    indexLableLetterBean.setCheck(false);
                }
            }

        } else {                               //没有选中 全部清空

            List<IndexLableLetterBean> list = bean.getList();
            for (IndexLableLetterBean indexLableLetterBean : list) {
                indexLableLetterBean.setCheck(false);
            }

        }


    }

    /**
     * 判断上个页面带过来的数据id是否选中
     * @param lebelGroupData
     * @param outSideListLabelGroupData
     * @param ids
     */
    public void handleIfContainsChoiceData(List<OutSideIndexListLableLetterBean> lebelGroupData, List<OutSideIndexListLableLetterBean> outSideListLabelGroupData, ArrayList<String> ids) {
        //重置数据
        if (lebelGroupData.size() != 0) {
            lebelGroupData.clear();
        }

        //判断上个页面带过来的数据id是否选中
        for (OutSideIndexListLableLetterBean lebelGroupDatum : outSideListLabelGroupData) {
            List<IndexLableLetterBean> list = lebelGroupDatum.getList();
            for (IndexLableLetterBean indexLableLetterBean : list) {
                int id = indexLableLetterBean.getId();
                if (ids != null && ids.size() != 0) {
                    if (ids.contains(String.valueOf(id))) {
                        indexLableLetterBean.setCheck(true);
                    }
                }
            }
        }
    }


    /**
     * 获取上一个页面传递的参数ids
     * @param intent
     * @return
     */
    public ArrayList<String> getIds(Intent intent) {
        return intent.getStringArrayListExtra(TagParams.INTENT_PARAM);
    }
}
