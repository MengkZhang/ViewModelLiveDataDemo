package com.yb.ballworld.information.ui.personal.constant;

import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Desc 资讯列表的item的类型itemType区分
 * //没有头像 （单图类型 图片居右） 1\n 有头像 单图 2\n 双图 3\n 三图 4\n 视频 没有头像 5\n 有头像 6
 * Date 2019/10/7
 * author JS-Kylo
 */
@IntDef({
        AdapterConstant.TYPE_ONLY_TITLE,
        AdapterConstant.TYPE_IMG_WITHOUT_HEAD,
        AdapterConstant.TYPE_IMGS_WITHOUT_HEAD,
        AdapterConstant.TYPE_IMGS3_WITHOUT_HEAD,
        AdapterConstant.TYPE_IMGS_WITH_HEAD,
        AdapterConstant.TYPE_VIDEO_WITHOUT_HEAD,
        AdapterConstant.TYPE_IMG_WITH_HEAD,
        AdapterConstant.TYPE_VIDEO_WITH_HEAD,
        AdapterConstant.TYPE_IMGS3_WITH_HEAD
})

@Retention(RetentionPolicy.SOURCE)

public @interface AdapterConstant {
    //标题
    int TYPE_ONLY_TITLE = 0;
    //单图 普通没有头像类型
    int TYPE_IMG_WITHOUT_HEAD = 1;
    int TYPE_IMGS_WITHOUT_HEAD = 11;
    int TYPE_IMGS3_WITHOUT_HEAD = 12;

    //单图 有头像
    int TYPE_IMG_WITH_HEAD = 2;
    //双图 有头像
    int TYPE_IMGS_WITH_HEAD = 3;
    //三图 有头像
    int TYPE_IMGS3_WITH_HEAD = 4;

    //视频 没有头像
    int TYPE_VIDEO_WITHOUT_HEAD = 5;
    //视频 有头像
    int TYPE_VIDEO_WITH_HEAD = 6;

}


