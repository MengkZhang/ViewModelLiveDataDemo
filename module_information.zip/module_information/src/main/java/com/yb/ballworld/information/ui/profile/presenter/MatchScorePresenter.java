package com.yb.ballworld.information.ui.profile.presenter;

import androidx.lifecycle.LifecycleOwner;

import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.livedata.LiveDataWrap;
import com.yb.ballworld.information.ui.profile.data.PointData;
import com.yb.ballworld.information.ui.profile.http.ProfileHttp;

import java.util.List;

/**
 * Desc: <球队信息积分榜>
 * Author: JS-Barder
 * Created On: 2019/11/21 17:26
 */
public class MatchScorePresenter extends BasePresenter<LifecycleOwner, VoidModel> {
    private ProfileHttp http = new ProfileHttp();
    private LiveDataWrap<List<PointData>> dataWrap = new LiveDataWrap<>();

    public LiveDataWrap<List<PointData>> getDataWrap() {
        return dataWrap;
    }

    private String seasonId;
    private String groupId;

    public void setSeasonId(String seasonId) {
        this.seasonId = seasonId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
        loadData();
    }

    private void loadData() {
        add(http.getMatchTeamRank(seasonId, groupId, new LifecycleCallback<List<PointData>>(mView) {
            @Override
            public void onSuccess(List<PointData> data) {
                dataWrap.setData(data);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                dataWrap.setError(errCode, errMsg);
            }
        }));
    }
}
