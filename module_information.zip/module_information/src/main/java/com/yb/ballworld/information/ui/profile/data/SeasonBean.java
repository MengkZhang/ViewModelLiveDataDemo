package com.yb.ballworld.information.ui.profile.data;

/**
 * Desc: <>
 * Author: JS-Barder
 * Created On: 2019/11/21 21:52
 */
public class SeasonBean {
    public String seasonId;
    public String seasonName;
}
