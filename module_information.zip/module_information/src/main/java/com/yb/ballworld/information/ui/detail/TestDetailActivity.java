package com.yb.ballworld.information.ui.detail;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AbsListView;
import android.widget.SimpleAdapter;

import com.yb.ballworld.common.base.mvp.BaseMvpActivity;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.data.ArticleBean;
import com.yb.ballworld.information.data.ArticleDetailBean;
import com.yb.ballworld.information.widget.DetailListView;
import com.yb.ballworld.information.widget.DetailScrollView;
import com.yb.ballworld.information.widget.DetailWebView;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Desc: <功能简述>
 * Author: JS-Dugu
 * Created On: 2019/10/15 17:56
 */
public class TestDetailActivity extends BaseMvpActivity<TestDetailPresenter> {

    private DetailScrollView mScrollView;
    private DetailWebView mWebView;
    private DetailListView mListView;

    private int mListScrollState = AbsListView.OnScrollListener.SCROLL_STATE_IDLE;
    private int mFirstVisibleItem;
    private int mWebViewHeight;
    private int mScreenHeight;
    private int mLastY;


    @Override
    public void initPresenter() {
        if (mPresenter != null) {
            mPresenter.setVM(this);
        }
        //  = intent.getStringExtra("NEWS_ID")
        // 301eb08573ab40d7a6d4784e873324f1
        String newsId = "168977dc0d514b8a98261046d9c6941f";
        Intent intent = getIntent();
        if (intent != null) {
            mPresenter.init(newsId);
        }
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_test_detail;
    }

    @Override
    protected void initView() {
        mScrollView = (DetailScrollView) findViewById(R.id.scrollView);
        mWebView = findViewById(R.id.webview);
        mListView = (DetailListView) findViewById(R.id.list_view);
        initWebView();
        initListView();
    }

    @Override
    protected void bindEvent() {
    }

    @Override
    protected void initData() {
        showDialogLoading();
        mPresenter.loadInfor();
        //  mPresenter.loadMore();
    }

    @Override
    protected void processClick(View view) {
    }


    /**
     * 显示文章详情
     *
     * @param detail
     */
    public void showInfor(ArticleDetailBean detail) {
        hideDialogLoading();
        ArticleBean article = detail.getNews();
        if (article != null) {
//            ViewGroup viewGroup = F(R.id.infor_navLayout);
//            ViewUtils.INSTANCE.getTextView(R.id.inforDetail_publisher, viewGroup).setText(article.getNickName());
//            ViewUtils.INSTANCE.getTextView(R.id.inforDetail_publishTime, viewGroup).setText(article.getCreatedDate());
//            ViewUtils.INSTANCE.getTextView(R.id.inforDetail_title, viewGroup).setText(article.getTitle());
//            ViewUtils.INSTANCE.getTextView(R.id.inforDetail_likeCount, viewGroup).setText(String.valueOf(article.getLikeCount()));
//            ImageView likeView = ViewUtils.INSTANCE.getImageView(R.id.inforDetail_like, viewGroup);
//            likeView.setImageResource(article.isLike() ? R.drawable.icon_priase_info : R.drawable.icon_priase_info_normal);
//            likeView.setClickable(!article.isLike());
//            likeView.setTag(article.isLike());

//            new Thread(new Runnable() {
//                @Override
//                public void run() {
//                   final  String stringDoc =mWebView.parseHtmlText(article.getContent());
//                   runOnUiThread(new Runnable() {
//                       @Override
//                       public void run() {
//                           mWebView.setHtml(stringDoc);
//                       }
//                   });
//                }
//            }).start();

//            //显示热门标签
//            FlowTagLayout flowTagLayout = F(R.id.inforDetail_flowTagLayout);
//            List<String> tags = CommondUtil.arrayToList(CommondUtil.splitBySign(article.getKeywords(), ","));
//            boolean needShow = tags != null;
//            flowTagLayout.setVisibility(needShow ? View.VISIBLE : View.GONE);
//            if (needShow) {
//                mTagAdapter.clearAndAddAll(tags);
//            }
        }

//        List<ArticleBean> newsList = detail.getCurrentNews();
//        if (!CommondUtil.isEmpty(newsList)) {
//            F(R.id.recyclerView).setVisibility(View.VISIBLE);
//            mNewsAdapter.addData(newsList);
//            mNewsAdapter.notifyDataSetChanged();
//        }

    }

    private void initWebView() {
        //webview 高度自动撑开
        WebSettings settings = mWebView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        String url = "http://test-news-node.seeyouyima.com/article?news_id=681558";
        //url = "http://test-news-node.seeyouyima.com/article?news_id=681523";        //网页很短测试
        // mWebView.loadUrl(url);
        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(final WebView view, String url) {
                super.onPageFinished(view, url);
                int w = View.MeasureSpec.makeMeasureSpec(0,
                        View.MeasureSpec.UNSPECIFIED);
                int h = View.MeasureSpec.makeMeasureSpec(0,
                        View.MeasureSpec.UNSPECIFIED);
                // 重新测量
                view.measure(w, h);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        mWebViewHeight = view.getHeight();
                    }
                }, 100);
            }
        });
    }

    private ArrayList<HashMap<String, String>> list;
    private SimpleAdapter mAdapter;
    // 这里是ListView显示内容每一列的列名
    String[] from = {"name", "id"};
    // 这里是ListView显示每一列对应的list_item中控件的id
    int[] to = {R.id.user_name, R.id.user_id};


    private void initListView() {
        // 创建ArrayList对象；
        list = new ArrayList<HashMap<String, String>>();
        for (int i = 0; i < 20; i++) {
            // 为避免产生空指针异常，有几列就创建几个map对象
            HashMap<String, String> map = new HashMap<String, String>();
            map.put("id", "userId:  " + i);
            map.put("name", "userName：" + i);
            list.add(map);
        }
        mAdapter = new SimpleAdapter(this, list, R.layout.test_list_item, from, to);
        mListView.setAdapter(mAdapter);
    }


    private int getStatusBarHeight() {
        return dip2px(getApplicationContext(), 50 + 25);//标题栏+状态栏
    }

    public static int dip2px(Context context, float dipValue) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dipValue * scale + 0.5f);
    }

    private int getListViewPositionAtScreen() {
        try {
            int[] location = new int[2];
            mListView.getLocationInWindow(location);
            int y = location[1];
            return y;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return -1;
    }

}
