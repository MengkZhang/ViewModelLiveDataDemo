package com.yb.ballworld.information.ui.home.bean;

import android.net.Uri;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Desc
 * Date 2019/11/11
 * author mengk
 */
public class PublishVideoDataBean implements Serializable {
    private String title;
    private String content;
    private String uriStr;
    private String path;
    private InfoPublishCategoryBean categoryBean;
    private ArrayList<IndexLableLetterBean> tagList;


    public PublishVideoDataBean() {
    }

    public InfoPublishCategoryBean getCategoryBean() {
        return categoryBean;
    }

    public void setCategoryBean(InfoPublishCategoryBean categoryBean) {
        this.categoryBean = categoryBean;
    }

    public ArrayList<IndexLableLetterBean> getTagList() {
        return tagList;
    }

    public void setTagList(ArrayList<IndexLableLetterBean> tagList) {
        this.tagList = tagList;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getUri() {
        return uriStr;
    }

    public void setUri(String uri) {
        this.uriStr = uri;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

}
