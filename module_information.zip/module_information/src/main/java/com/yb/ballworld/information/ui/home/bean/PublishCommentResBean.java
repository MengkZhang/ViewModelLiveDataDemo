package com.yb.ballworld.information.ui.home.bean;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Desc
 * Date 2019/10/20
 * author mengk
 */
public class PublishCommentResBean implements Parcelable {

    /**
     * commentType : 0
     * content :
     * createdBy :
     * createdDate :
     * id : 0
     * imgUrl1 :
     * imgUrl2 :
     * imgUrl3 :
     * lastModifiedBy :
     * lastModifiedDate :
     * likeCount : 0
     * mainCommentId : 0
     * newsId :
     * nickName :
     * replyId : 0
     * userId : 0
     * videoUrl :
     */

    private int commentType;
    private String content;
    private String createdBy;
    private String createdDate;
    private int id;
    private String imgUrl1;
    private String imgUrl2;
    private String imgUrl3;
    private String lastModifiedBy;
    private String lastModifiedDate;
    private int likeCount;
    private int mainCommentId;
    private String newsId;
    private String nickName;
    private int replyId;
    private int userId;
    private String videoUrl;
    private String videoCoverUrl;

    public PublishCommentResBean() {}

    protected PublishCommentResBean(Parcel in) {
        commentType = in.readInt();
        content = in.readString();
        createdBy = in.readString();
        createdDate = in.readString();
        id = in.readInt();
        imgUrl1 = in.readString();
        imgUrl2 = in.readString();
        imgUrl3 = in.readString();
        lastModifiedBy = in.readString();
        lastModifiedDate = in.readString();
        likeCount = in.readInt();
        mainCommentId = in.readInt();
        newsId = in.readString();
        nickName = in.readString();
        replyId = in.readInt();
        userId = in.readInt();
        videoUrl = in.readString();
        videoCoverUrl = in.readString();
    }

    public static final Creator<PublishCommentResBean> CREATOR = new Creator<PublishCommentResBean>() {
        @Override
        public PublishCommentResBean createFromParcel(Parcel in) {
            return new PublishCommentResBean(in);
        }

        @Override
        public PublishCommentResBean[] newArray(int size) {
            return new PublishCommentResBean[size];
        }
    };

    public String getVideoCoverUrl() {
        return videoCoverUrl;
    }

    public void setVideoCoverUrl(String videoCoverUrl) {
        this.videoCoverUrl = videoCoverUrl;
    }

    public int getCommentType() {
        return commentType;
    }

    public void setCommentType(int commentType) {
        this.commentType = commentType;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getImgUrl1() {
        return imgUrl1;
    }

    public void setImgUrl1(String imgUrl1) {
        this.imgUrl1 = imgUrl1;
    }

    public String getImgUrl2() {
        return imgUrl2;
    }

    public void setImgUrl2(String imgUrl2) {
        this.imgUrl2 = imgUrl2;
    }

    public String getImgUrl3() {
        return imgUrl3;
    }

    public void setImgUrl3(String imgUrl3) {
        this.imgUrl3 = imgUrl3;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public String getLastModifiedDate() {
        return lastModifiedDate;
    }

    public void setLastModifiedDate(String lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }

    public int getLikeCount() {
        return likeCount;
    }

    public void setLikeCount(int likeCount) {
        this.likeCount = likeCount;
    }

    public int getMainCommentId() {
        return mainCommentId;
    }

    public void setMainCommentId(int mainCommentId) {
        this.mainCommentId = mainCommentId;
    }

    public String getNewsId() {
        return newsId;
    }

    public void setNewsId(String newsId) {
        this.newsId = newsId;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public int getReplyId() {
        return replyId;
    }

    public void setReplyId(int replyId) {
        this.replyId = replyId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(commentType);
        dest.writeString(content);
        dest.writeString(createdBy);
        dest.writeString(createdDate);
        dest.writeInt(id);
        dest.writeString(imgUrl1);
        dest.writeString(imgUrl2);
        dest.writeString(imgUrl3);
        dest.writeString(lastModifiedBy);
        dest.writeString(lastModifiedDate);
        dest.writeInt(likeCount);
        dest.writeInt(mainCommentId);
        dest.writeString(newsId);
        dest.writeString(nickName);
        dest.writeInt(replyId);
        dest.writeInt(userId);
        dest.writeString(videoUrl);
        dest.writeString(videoCoverUrl);
    }
}
