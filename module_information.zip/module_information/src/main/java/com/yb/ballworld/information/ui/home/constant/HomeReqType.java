package com.yb.ballworld.information.ui.home.constant;

import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Desc 区分首页请求类型
 * Date 2019/10/16
 * author mengk
 */
@IntDef({
        HomeReqType.TYPE_HOME_HOT,
        HomeReqType.TYPE_HOME_VIDEO_OTHER
})

@Retention(RetentionPolicy.SOURCE)

public @interface HomeReqType {
    //0 首页热门
    int TYPE_HOME_HOT = 0;
    //1 视频或者其他资讯
    int TYPE_HOME_VIDEO_OTHER = 1;
}
