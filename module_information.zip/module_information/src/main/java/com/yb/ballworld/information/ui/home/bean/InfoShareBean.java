package com.yb.ballworld.information.ui.home.bean;

/**
 * Desc
 * Date 2019/10/19
 * author mengk
 */
public class InfoShareBean {
    private int id;
    private String name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
