//package com.yb.ballworld.information.ui.home.view.newdetail;
//
//import android.content.Intent;
//import android.os.SystemClock;
//import android.text.TextUtils;
//import android.view.View;
//import android.widget.Toast;
//
//import androidx.recyclerview.widget.LinearLayoutManager;
//import androidx.recyclerview.widget.RecyclerView;
//
//import com.yb.ballworld.baselib.utils.ToastUtils;
//import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
//import com.yb.ballworld.common.base.mvp.BaseMvpActivity;
//import com.yb.ballworld.information.R;
//import com.yb.ballworld.information.data.ArticleBean;
//import com.yb.ballworld.information.data.ArticleDetailBean;
//import com.yb.ballworld.information.ui.detail.NewsQuickAdapter;
//import com.yb.ballworld.information.ui.home.widget.PlaceholderViewInfoDetail;
//import com.yb.ballworld.information.utils.CommondUtil;
//
//import java.util.List;
//
///**
// * Desc 资讯详情页new 解决WebView加载H5页面闪动幅度过大的问题
// * Date 2019/10/18
// * author mengk
// */
//public class InfoNewsDetailActivity extends BaseMvpActivity<InfoDetailPresenter> {
//
//    //评论列表
//    private RecyclerView rvComment;
//    private PlaceholderViewInfoDetail placeHodler;
//    private LinearLayoutManager layoutManager;
//    private NewsQuickAdapter mNewsAdapter;
//    private NewsDetailHeaderView mHeaderView;
//
//    @Override
//    public void initPresenter() {
//        if (mPresenter != null) {
//            mPresenter.setVM(this);
//        }
//        String newsId =null;
//        Intent intent = getIntent();
//        if (intent != null) {
//            newsId = intent.getStringExtra("NEWS_ID");
//            mPresenter.init(newsId);
////            isVideo = intent.getBooleanExtra("NEWS_TYPE", false);
//        }
//        if (TextUtils.isEmpty(newsId)) {
//            ToastUtils.INSTANCE.showToast(R.string.prompt_articleBeDeleted);
//            finish();
//        }
//    }
//
//    @Override
//    protected void initData() {
//        showDialogLoading();
//        showPageLoading();
//        mPresenter.loadInfor();
//    }
//
//
//    @Override
//    public int getLayoutId() {
//        return R.layout.activity_info_news_detail;
//    }
//
//    @Override
//    protected void initView() {
//        F(R.id.statusbar_new).setVisibility(View.GONE);
//        rvComment = F(R.id.rv_comment_info_detail);
//        placeHodler = F(R.id.place_holder_detail);
//        layoutManager = new LinearLayoutManager(this);
//        rvComment.setLayoutManager(layoutManager);
//        mNewsAdapter = new NewsQuickAdapter(null);
//        rvComment.setAdapter(mNewsAdapter);
//    }
//
//    @Override
//    protected void bindEvent() {
//
//    }
//
//    @Override
//    protected void processClick(View view) {
//
//    }
//
//    @Override
//    public PlaceholderView getPlaceholderView() {
//        return placeHodler;
//    }
//
//    public void showInfo(ArticleDetailBean detail) {
//        ArticleBean news = detail.getNews();
//        String content = news.getContent();
//        List<ArticleBean> newsList = detail.getCurrentNews();
//        if (!CommondUtil.isEmpty(newsList)) {//相关新闻有数据
//            mNewsAdapter.addData(newsList);
//            addHeaderView(content);
//        } else {//只有头部
//            addHeaderView(content);
//        }
//    }
//
//    private void addHeaderView(String content) {
//        mHeaderView = new NewsDetailHeaderView(this);
//        mNewsAdapter.addHeaderView(mHeaderView);
//        mHeaderView.setDetail(content, () -> {
//            //加载完成 显示内容布局
//            hideDialogLoading();
//            showPageContent();
//            mNewsAdapter.notifyDataSetChanged();
//        });
//    }
//}
