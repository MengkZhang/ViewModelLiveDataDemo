package com.yb.ballworld.information.widget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.widget.ImageView

/**
* Desc: 自定义ImageView，可以存放Bitmap和Path等信息
* @author ink
* created at 2019/10/7 23:05
*/
class DataImageView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null, defStyle: Int = 0) : ImageView(context, attrs, defStyle) {

    private val showBorder = false //是否显示边框
    var borderColor = Color.GRAY//边框颜色
    var borderWidth = 5//边框大小

    var absolutePath: String? = null
    var bitmap: Bitmap? = null

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        if (showBorder) {
            //画边框
            val rec = canvas.clipBounds
            // 这两句可以使底部和右侧边框更大
            //rec.bottom -= 2;
            //rec.right -= 2;
            //画笔
            val paint = Paint()
            paint.color = borderColor//设置颜色
            paint.strokeWidth = borderWidth.toFloat()//设置画笔的宽度
            paint.style = Paint.Style.STROKE//设置画笔的风格-不能设成填充FILL否则看不到图片了
            canvas.drawRect(rec, paint)
        }
    }
}
