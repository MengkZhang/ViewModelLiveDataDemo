package com.yb.ballworld.information.widget

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.net.http.SslError
import android.os.Build
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.SslErrorHandler
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.annotation.RequiresApi
import com.yb.ballworld.information.widget.listener.OnElementClickListener
import org.jsoup.Jsoup
import org.jsoup.nodes.Document


/**
 * RichWebView
 * TAG1: 增加富文本中图片 链接等点击处理
 *
 * TAG2: 修复嵌套在滚动布局中WebView高度显示不对问题 尝试了很多办法仅这种有效
 *       注意富文本必须有h5头，才能使用标准模式获取到高度，否则怪异模式
 *       WebViewClient做了一定延迟调用JS 等待网页加载完成
 *       这部分会引起网页滚动失效，所以根据需要加滚动布局 或去掉这部分处理
 *
 * @author ink
 * created at 2019/10/10 17:42
 */
class RichWebView : WebView {
    val TYPE_OTHER = 0
    val TYPE_LINK = 1
    val TYPE_IMG = 2
    private var imgUrls = ArrayList<String>()
    private var aUrls = ArrayList<String>()
    private var startClickTime: Long = 0
    private var onClickListener: ((View) -> Boolean)? = null
    private var onElementClick: OnElementClickListener? = null
    private var cacheText: String? = ""

    constructor(context: Context) : super(context)

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs)

    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr)

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int, defStyleRes: Int) : super(context, attrs, defStyleAttr, defStyleRes)

    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int, privateBrowsing: Boolean) : super(context, attrs, defStyleAttr, privateBrowsing)

    init {
        scrollBarStyle = View.SCROLLBARS_OUTSIDE_OVERLAY//取消滚动条
        //isDrawingCacheEnabled = false
        //settings.loadWithOverviewMode = true
//        settings.setBlockNetworkImage(true)

        settings.setSupportZoom(false)//不支持缩放功能
        @SuppressLint("SetJavaScriptEnabled")
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        //TAG1 TAG2
        addJavascriptInterface(RichTextJs(), "RichTextJs")
        setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startClickTime = System.currentTimeMillis()
                }
                MotionEvent.ACTION_UP -> {
                    if (onClickListener == null) return@setOnTouchListener false
                    val clickDuration = System.currentTimeMillis() - startClickTime
                    if (clickDuration < 200) {
                        return@setOnTouchListener onClickListener!!.invoke(this@RichWebView)
                    }
                }
            }
            false
        }
        //TAG2
        webViewClient = object : WebViewClient() {
            override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                super.onReceivedSslError(view, handler, error)
                handler.proceed()
            }

            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                this@RichWebView.loadUrl(url)
                return true
            }

            override fun onPageFinished(view: WebView?, url: String?) {

//                settings.setBlockNetworkImage(false)
//                // 判断webview是否加载了，图片资源
//                if (!settings.getLoadsImagesAutomatically()) {
//                    // 设置wenView加载图片资源
//                    settings.setLoadsImagesAutomatically(true)
//                }

                super.onPageFinished(view, url)
                // evaluateJavascript("document.body.removeAttribute('style')",null)
                view?.postDelayed({
                    loadUrl("""javascript:RichTextJs.resize(document.body.scrollHeight)""")
                }, 500)
            }
        }
    }

    /**
     * RichTextView 点击事件监听
     * @param listener 监听 返回true拦截事件
     **/
    fun setOnClickListener(listener: (View) -> Boolean) {
        onClickListener = listener
    }

    fun setHtml(text: String?) {
        if (text == null) return
        cacheText = text
        val doc = Jsoup.parse(text)
        fixImg(doc)
        fixA(doc)
        fixEmbed(doc)

        // <script src="file:///android_asset/js/flexible.js"></script>
        //TAG2
        val docHtml = """
            <!DOCTYPE html><head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"> 
            <link rel="stylesheet" href="file:///android_asset/css/news.css" type="text/css" />
            <body>${doc.html().replace("<p style=\"text-align: center;\">", "<p style=\"display: flex; align-items: center; justify-content: center;\">")}
            </body></html>
        """
        loadDataWithBaseURL(null, docHtml, "text/html", "UTF-8", null)
    }

    fun setDocHtml(docHtml: String?) {
        if (docHtml == null) return
        cacheText = docHtml
        loadDataWithBaseURL(null, docHtml, "text/html", "UTF-8", null)
    }

    fun getHtml(): String {
        return cacheText ?: ""
    }

    /** 修复 img 标签 **/
    private fun fixImg(doc: Document) {
        //使用 jsoup 修改 img 的属性:
        val images = doc.getElementsByTag("img")
        for (i in 0 until images.size) {
            //宽度最大100%，高度自适应
            images[i].attr("style", "max-width: 100%; height: auto;")
                    //.attr("onclick", """RichTextJs.onTagClick(this.src, this.getAttribute('data-filename'))""")
                    .attr("onclick", """RichTextJs.onTagClick(this.src,$TYPE_IMG,$i)""")
            imgUrls.add(images[i].attr("src"))
        }
    }

    /** 修复 a 标签 **/
    private fun fixA(doc: Document) {
        //使用 jsoup 修改 img 的属性:
        val `as` = doc.getElementsByTag("a")
        for (i in 0 until `as`.size) {
            val tempA = `as`[i]
            aUrls.add(tempA.attr("href"))
            tempA.attr("onclick", """RichTextJs.onTagClick('${tempA.attr("href")}',$TYPE_LINK,$i)""")
                    .attr("href", "javascript:void(0)")
                    .attr("style", "word-break: break-word")
        }
    }

    /** 修复 embed 标签 **/
    private fun fixEmbed(doc: Document) {
        //使用 jsoup 修改 embed 的属性:
        val embeds = doc.getElementsByTag("embed")
        for (element in embeds) {
            //宽度最大100%，高度自适应
            element.attr("style", "max-width: 100%; height: auto;")
                    .attr("controls", "controls")
        }
        //webview 无法正确识别 embed 为视频时，需要这个标签改成 video 手机就可以识别了
        doc.select("embed").tagName("video")
    }

    private inner class RichTextJs {

        //TAG1 js调用 标签点击
        //@JavascriptInterface注解方法，js端调用，4.2以后安全
        //4.2以前，当JS拿到Android这个对象后，就可以调用这个Android对象中所有的方法，包括系统类（java.lang.Runtime 类），从而进行任意代码执行。
        @JavascriptInterface
        fun onTagClick(url: String, type: Int, position: Int) {
            //const val TYPE_OTHER = 3
            //const val TYPE_LINK = 1
            // const val TYPE_IMG = 2
            onElementClick?.onElementClick(url, type, position, if (type == TYPE_IMG) {
                imgUrls
            } else if (type == TYPE_LINK) {
                aUrls
            } else {
                null
            })
            //TODO 这里可以做你需要的操作 如用PhotoView查看大图等
            // println(url)
        }

        //TAG2 js调用 重设WebView高度
        @JavascriptInterface
        fun resize(height: Int) {
            if (context is Activity) {
                (context as Activity).runOnUiThread {
                    //重设高度
                    layoutParams = layoutParams.also {
                        it.height = (height * resources.displayMetrics.density + 0.5f).toInt()
                    }
                }
            }
        }
    }

    fun setOnElementClick(onElementClick: OnElementClickListener) {
        this.onElementClick = onElementClick
    }

}