package com.yb.ballworld.information.ui.profile.data;

import com.chad.library.adapter.base.entity.MultiItemEntity;

/**
 * @author Gethin
 * @time 2019/11/9 15:20
 */

public class DataSubTotalBean implements MultiItemEntity {

    public static final int SECTION = 1;
    public static final int CONTENT = 2;

    private int itemType = CONTENT;

    private String id;
    private String leaugeId;
    private String leaugeName;
    private String leaugeType;
    private String seasonId;
    private String year;
    private String presence;
    private String startingNum;
    private String playTime;
    private String goals;
    private String assist;
    private String red;
    private String yellow;

    public static int getSECTION() {
        return SECTION;
    }

    public static int getCONTENT() {
        return CONTENT;
    }

    public void setItemType(int itemType) {
        this.itemType = itemType;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLeaugeId() {
        return defaulValue(leaugeId);
    }

    public void setLeaugeId(String leaugeId) {
        this.leaugeId = leaugeId;
    }

    public String getLeaugeName() {
        return defaulValue(leaugeName);
    }

    public void setLeaugeName(String leaugeName) {
        this.leaugeName = leaugeName;
    }

    public String getLeaugeType() {
        return defaulValue(leaugeType);
    }

    public void setLeaugeType(String leaugeType) {
        this.leaugeType = leaugeType;
    }

    public String getSeasonId() {
        return defaulValue(seasonId);
    }

    public void setSeasonId(String seasonId) {
        this.seasonId = seasonId;
    }

    public String getYear() {
        return defaulValue(year);
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getPresence() {
        return defaulValue(presence);
    }

    public void setPresence(String presence) {
        this.presence = presence;
    }

    public String getStartingNum() {
        return defaulValue(startingNum);
    }

    public void setStartingNum(String startingNum) {
        this.startingNum = startingNum;
    }

    public String getPlayTime() {
        return defaulValue(playTime);
    }

    public void setPlayTime(String playTime) {
        this.playTime = playTime;
    }

    public String getGoals() {
        return defaulValue(goals);
    }

    public void setGoals(String goals) {
        this.goals = goals;
    }

    public String getAssist() {
        return defaulValue(assist);
    }

    public void setAssist(String assist) {
        this.assist = assist;
    }

    public String getRed() {
        return defaulValue(red);
    }

    public void setRed(String red) {
        this.red = red;
    }

    public String getYellow() {
        return defaulValue(yellow);
    }

    public void setYellow(String yellow) {
        this.yellow = yellow;
    }


    public DataSubTotalBean(int itemType) {
        this.itemType = itemType;
    }

    @Override
    public int getItemType() {
        return itemType;
    }

    private String defaulValue(String v) {
        return v == null ? "-" : v;
    }
}
