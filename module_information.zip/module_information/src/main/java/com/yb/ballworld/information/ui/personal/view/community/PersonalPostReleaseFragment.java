package com.yb.ballworld.information.ui.personal.view.community;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bfw.util.ToastUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.baselib.utils.NetWorkUtils;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.common.base.mvp.BaseMvpFragment;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.community.bean.Topic;
import com.yb.ballworld.information.ui.community.data.CommunityPost;
import com.yb.ballworld.information.ui.home.constant.FailStateConstant;
import com.yb.ballworld.information.ui.home.constant.LoadMoreType;
import com.yb.ballworld.information.ui.home.utils.JZReleaseUtil;
import com.yb.ballworld.information.ui.personal.adapter.community.PostAdapterType;
import com.yb.ballworld.information.ui.personal.adapter.community.PostReleaseAdapter;
import com.yb.ballworld.information.ui.personal.bean.community.PostReleaseBean;
import com.yb.ballworld.information.ui.personal.presenter.community.PersonalPostReleasePresenter;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;

/**
 * Desc: 个人空间-社区-发帖
 * Author: JS-Kylo
 * Created On: 2019/11/11 16:53
 */
public class PersonalPostReleaseFragment  extends BaseMvpFragment<PersonalPostReleasePresenter> {
    private static final String USER_ID = "USER_ID";
    private SmartRefreshLayout smartRefreshLayout;
    private RecyclerView recyclerView;
    private PlaceholderView placeholder;
    private LinearLayoutManager layoutManager;
    private List<PostReleaseBean> dataList = new ArrayList<>();
    private PostReleaseAdapter releaseAdapter;
    private int userId;

    public static PersonalPostReleaseFragment newInstance(){
        PersonalPostReleaseFragment fragment = new PersonalPostReleaseFragment();
        return fragment;
    }

    public static PersonalPostReleaseFragment newInstance(int userId){
        PersonalPostReleaseFragment fragment = new PersonalPostReleaseFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(USER_ID,userId);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void initPresenter() {
        mPresenter.setVM(this);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_collect_post;
    }

    @Override
    protected void initView() {
        Bundle bundle = getArguments();
        if (bundle != null)
            userId = bundle.getInt(USER_ID);
        smartRefreshLayout = findView(R.id.smartRefreshLayout);
        recyclerView = findView(R.id.recyclerView);
        placeholder = findView(R.id.placeholder);
        smartRefreshLayout.setRefreshHeader(getRefreshHeader());
        smartRefreshLayout.setRefreshFooter(getRefreshFooter());
        layoutManager = new LinearLayoutManager(mContext);
        recyclerView.setLayoutManager(layoutManager);
        releaseAdapter = new PostReleaseAdapter(true,getActivity(),dataList);
        recyclerView.setAdapter(releaseAdapter);
    }

    @Override
    protected void bindEvent() {
        initRefreshLoadMoreEvent();
        initReLoadEvent();
        initPostRefreshData();
        releaseAdapter.setOnItemChildClickListener((adapter, view, position) -> {

            //判断具体点击事件
            if (view.getId() == R.id.rl_praise_root_post_release) {        //点赞事件
                Object item = adapter.getItem(position);
                if (item instanceof PostReleaseBean) {
                    boolean isLike = ((PostReleaseBean) item).isIsLike();
                    int likeCount = ((PostReleaseBean) item).getLikeCount();
                    if (!isLike) {

                        if (NetWorkUtils.INSTANCE.isNetworkNotConnected()) {
                            ToastUtils.showToast(R.string.app_recycler_error);
                            return;
                        }

                        //改变点赞状态 数量加1
                        ((PostReleaseBean) item).setLikeCount((likeCount + 1));
                        ((PostReleaseBean) item).setIsLike(true);
                        releaseAdapter.changeLike(view,((PostReleaseBean) item));

                        //请求点赞数据
                        mPresenter.postLike(view,((PostReleaseBean) item),position);
                    }
                }
            }
        });

        // 评论完
        LiveEventBus.get().with(LiveEventBusKey.KEY_TOPIC_PUBLIC_COMMENT, Topic.class).observe(this, new Observer<Topic>() {
            @Override
            public void onChanged(Topic topic) {
                String postId;
                if (topic.getPostType()==1)
                    postId = String.valueOf(topic.getReplyId());
                else
                    postId = String.valueOf(topic.getId());
                if (dataList.size() != 0) {
                    for (int i = 0; i < dataList.size(); i++) {
                        PostReleaseBean listBean = dataList.get(i);
                        int id= listBean.getId();
                        int commentCount = listBean.getSonNum();
                        if (postId.equals(String.valueOf(id))) {
                            listBean.setSonNum(commentCount + 1);
                            releaseAdapter.notifyItemChanged(i);
                            break;
                        }
                    }
                }
            }
        });

        //帖子点赞后 点赞状态更改
        LiveEventBus.get().with(LiveEventBusKey.KEY_TOPIC_LIKE,String.class).observe(this, newsId -> {
            if (dataList.size() != 0) {
                for (int i = 0; i < dataList.size(); i++) {
                    PostReleaseBean listBean = dataList.get(i);
                    int listBeanId = listBean.getId();
                    if (newsId.equals(String.valueOf(listBeanId))) {
                        listBean.setIsLike(true);
                        listBean.setLikeCount(listBean.getLikeCount() + 1);
                        releaseAdapter.notifyItemChanged(i);
                        break;
                    }
                }
            }
        });

        //接收停止视频
        LiveEventBus.get()
                .with(LiveEventBusKey.KEY_INFO_PAUSE_PLAY, Boolean.class)
                .observe(this, aBoolean -> {
                    if (aBoolean) {
                        JZReleaseUtil.releaseAllVideos();
                    }
                });

        //recyclerView滑动停止播放
        JZReleaseUtil.releaseAllVideos(recyclerView);

    }

    @Override
    public void onPause() {
        super.onPause();
        JZReleaseUtil.releaseAllVideos();
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (!getUserVisibleHint()) {
            JZReleaseUtil.releaseAllVideos();
        }
    }

    /**
     * 本地刷新数据
     */
    private void initPostRefreshData() {
        LiveEventBus.get().with(LiveEventBusKey.KEY_AUTHOR_REPLAY_TIE, CommunityPost.class).observe(this, postBean -> {
            if (postBean != null) {
                //判断是否是自己
                if (isMySelf()) {
                    PostReleaseBean releaseBean = new PostReleaseBean();
                    releaseBean.setHeadImgUrl(postBean.headImgUrl);
                    releaseBean.setNickname(postBean.nickname);
                    releaseBean.setCreatedDate(postBean.postDate);
                    releaseBean.setLikeCount(postBean.likeCount);
                    releaseBean.setIsLike(postBean.isLike);
                    releaseBean.setSonNum(postBean.sonNum);
                    releaseBean.setContent(postBean.content);
                    releaseBean.setId(Integer.valueOf(postBean.id));
                    String videoUrl = postBean.videoUrl;
                    if (!TextUtils.isEmpty(videoUrl)) {
                        releaseBean.setItemViewType(PostAdapterType.TYPE_POST_VIDEOO);
                    } else {
                        releaseBean.setItemViewType(PostAdapterType.TYPE_POST_IMG);
                    }
                    //releaseBean.setIsAttention(postBean.isAttention);
//                    releaseBean.setItemViewType(postBean.getItemType());
                    releaseBean.setPostImgLists(postBean.postImgLists);
                    releaseBean.setSex(postBean.sex);
                    releaseBean.setUserId(Integer.valueOf(postBean.userId));
                    dataList.add(0,releaseBean);
                    releaseAdapter.notifyDataSetChanged();
                    //刷新发帖列表数据
                    //在dataList第0个位置添加这个Javabean

                }
            }
        });
    }

    @Override
    protected void initData() {
        mPresenter.loadDate(userId,1);
//        mPresenter.loadTestDate();
    }

    @Override
    protected void processClick(View view) {

    }

    /**
     * 请求中
     */
    public void requestLoading() {
        placeholder.showLoading();
        smartRefreshLayout.setEnableRefresh(false);
        smartRefreshLayout.setEnableLoadMore(false);
    }

    /**
     * 请求成功回调
     * @param data 列表数据
     */
    public void resultSuccess(List<PostReleaseBean> data,int page) {
        placeholder.hideLoading();
        smartRefreshLayout.setEnableRefresh(true);
        smartRefreshLayout.setEnableLoadMore(true);
        if (page <= 1) {
            dataList.clear();
        }
        dataList.addAll(data);
        releaseAdapter.notifyDataSetChanged();
    }

    /**
     * 请求失败回调
     */
    public void resultFail(int type,String errMsg) {
        switch (type) {
            case FailStateConstant.TYPE_ERROR:   //加载失败
                if (TextUtils.isEmpty(errMsg))
                    placeholder.showError("服务器连接失败~");
                else
                    placeholder.showError(errMsg);
                break;
            case FailStateConstant.TYPE_EMPTY:   //数据为空
                smartRefreshLayout.setEnableRefresh(true);
                placeholder.showEmpty("暂无数据");
                break;

            default:
                break;
        }
    }


    /**
     * 刷新成功
     */
    public void resultRefreshSuccess() {
        smartRefreshLayout.finishRefresh();
        //刷新成功清理存储的数组
        dataList.clear();
    }

    /**
     * 刷新失败
     */
    public void resultRefreshFail(String errorMsg) {
        smartRefreshLayout.finishRefresh();
    }

    /**
     * 加载更多成功
     */
    public void resultLoadMoreSuccess(int type) {
        smartRefreshLayout.finishLoadMore();
        switch (type) {
            case LoadMoreType.TYPE_SUCCESS:      //加载成功
                break;

            case LoadMoreType.TYPE_ALL_DATA:     //已经全部加载
                ToastUtils.showToast("已经全部加载");
                //已经全部加载 就不允许继续上拉加载了
                smartRefreshLayout.setEnableLoadMore(false);
                break;

            default:
                break;
        }
    }

    /**
     * 加载更多失败
     */
    public void resultLoadMoreFail(String errorMsg) {
        smartRefreshLayout.finishLoadMore();
    }

    /**
     * 点赞成功
     */
    public void postLikeFail(String msg){
        //ToastUtils.INSTANCE.showToast("点赞失败");
        ToastUtils.showToast(msg);
    }
    /**
     * 初始化刷新和加载更多
     */
    private void initRefreshLoadMoreEvent() {
        smartRefreshLayout.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                mPresenter.loadMoreData();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                mPresenter.refreshData();
            }
        });
    }

    /**
     * 初始化重新加载数据
     */
    private void initReLoadEvent() {
        placeholder.setPageErrorRetryListener(v -> mPresenter.loadDate(userId,1));
    }


    /**
     * 判断是否是自己
     * @return
     */
    private boolean isMySelf() {
        return String.valueOf(LoginOrdinaryUtils.INSTANCE.getUid()).equals(String.valueOf(userId));
    }
}
