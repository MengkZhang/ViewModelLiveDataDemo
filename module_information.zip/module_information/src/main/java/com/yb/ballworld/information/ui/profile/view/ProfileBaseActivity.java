package com.yb.ballworld.information.ui.profile.view;

import android.view.View;
import android.widget.LinearLayout;

import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.bifen.tablayout.SlidingTabLayout;
import com.bifen.tablayout.listener.OnTabSelectListener;
import com.gyf.immersionbar.ImmersionBar;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.common.base.BaseFragment;
import com.yb.ballworld.common.base.BaseFragmentStateAdapter;
import com.yb.ballworld.common.base.mvp.BaseMvpActivity;
import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.utils.DisplayUtil;
import com.yb.ballworld.common.widget.CommonTitleBar;
import com.yb.ballworld.information.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.yb.ballworld.common.widget.CommonTitleBar.ACTION_LEFT_BUTTON;
/**
 * 资料库-基类Activity
 * @author Gethin
 * @time 2019/11/7 16:24
 */

public abstract class ProfileBaseActivity<P extends BasePresenter> extends BaseMvpActivity<P> {

    private PlaceholderView placeholder;
    private LinearLayout headerLayout;
    private SlidingTabLayout tabLayout;
    private ViewPager viewPager;

    protected View statusView;
    protected BaseFragmentStateAdapter viewPagerAdapter;
    protected List<String> titles = new ArrayList<>();
    protected List<Fragment> fragments = new ArrayList<>();

    @Override
    protected void initImmersionBar() {
        ImmersionBar.with(this)
                .navigationBarColor(getNavigationBarColor())
                .init();
    }

    protected abstract int getHeaderLayoutId();

    protected abstract String[] getTitles();

    protected abstract List<BaseFragment> getFragments();

    protected abstract void loadData();

    @Override
    public int getLayoutId() {
        return R.layout.activity_profile_base;
    }

    @Override
    public PlaceholderView getPlaceholderView() {
        return placeholder;
    }

    @Override
    protected void initView() {
        placeholder = findViewById(R.id.placeholder);
        statusView = findViewById(R.id.statusView);
        headerLayout = findViewById(R.id.headerLayout);
        tabLayout = findViewById(R.id.slidingTabLayout);
        viewPager = findViewById(R.id.viewPager);
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) statusView.getLayoutParams();
        int height;
        if (hasNotchHeight()) {
            height = getNotchHeight();
            params.height = height;
        } else {
            height = getStatusHeight();
            params.height = height;
        }
        statusView.setLayoutParams(params);
        if (getHeaderLayoutId() > 0) {
            View view = getLayouInflater().inflate(getHeaderLayoutId(), null);
            headerLayout.addView(view);
        }
        getPlaceholderView().setPageErrorRetryListener(v -> loadData());
        ((CommonTitleBar)findViewById(R.id.commonTitleBar)).setListener((v, action, extra) -> {
            if (action == ACTION_LEFT_BUTTON) {
                finish();
            }
        });
    }

    protected void loadDataFinish() {
        titles.clear();
        fragments.clear();
        if (getTitles() != null) {
            Collections.addAll(titles, getTitles());
        }
        List<BaseFragment> f = getFragments();
        if (f != null) {
            fragments.addAll(f);
        }
        float tabWidth = DisplayUtil.getScreenWidth(this) * 1.0f / titles.size();
        tabLayout.setTabWidth(tabWidth);

        viewPagerAdapter = new BaseFragmentStateAdapter(getSupportFragmentManager(), fragments, titles);
        viewPager.setAdapter(viewPagerAdapter);
        viewPager.setOffscreenPageLimit(fragments.size());
        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });
        tabLayout.setOnTabSelectListener(new OnTabSelectListener() {
            @Override
            public void onTabSelect(int position) {

            }

            @Override
            public void onTabReselect(int position) {

            }
        });
        tabLayout.setViewPager(viewPager);
        tabLayout.setCurrentTab(0);

        showPageContent();
    }

    @Override
    protected void bindEvent() {
    }

    @Override
    protected void initData() {
        loadData();
    }

    @Override
    protected void processClick(View view) {
    }
}
