package com.yb.ballworld.information.ui.community.view;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.yb.ballworld.baselib.base.activity.BaseActivity;
import com.yb.ballworld.baselib.widget.tab.XTabLayout;
import com.yb.ballworld.common.base.BaseFragmentStateAdapter;
import com.yb.ballworld.common.widget.CommonTitleBar;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.personal.view.InfoCollectionFragment;

import java.util.ArrayList;

/**
 * Desc: 收藏列表(资讯、帖子)
 * Author: JS-Kylo
 * Created On: 2019/11/8 11:04
 */
public class CollectionActivity extends BaseActivity {
    private CommonTitleBar commonTitleBar;
    private ImageView iv_back;
    private XTabLayout xTabLayout;
    private ViewPager viewPager;
    private ArrayList<String> titles = new ArrayList<>();
    private ArrayList<Fragment> fragments = new ArrayList<Fragment>();
    private int currentIndex;

    public static void startActivity(Context activity, int index) {
        Intent intent = new Intent(activity, CollectionActivity.class);
        intent.putExtra("INDEXT",index);
        activity.startActivity(intent);
    }
    @Override
    public int getLayoutResID() {
        return R.layout.activity_info_collection;
    }

    @Override
    protected void initView() {
        super.initView();
        currentIndex = getIntent().getIntExtra("INDEXT",0);
        //commonTitleBar = findViewById(R.id.commonTitleBar);
        iv_back = findViewById(R.id.iv_back);
        xTabLayout = findViewById(R.id.collectTabLayout);
        viewPager = findViewById(R.id.viewPager);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        titles.add("资讯");
        titles.add("帖子");
        fragments.add(InfoCollectionFragment.newInstance());
        fragments.add(PostIndexCollectionFragment.newInstance());
        BaseFragmentStateAdapter adapter = new BaseFragmentStateAdapter(getSupportFragmentManager(), fragments, titles);
        viewPager.setAdapter(adapter);
        xTabLayout.setViewPager(viewPager);
        xTabLayout.setCurrentTabForce(currentIndex);
        viewPager.setCurrentItem(currentIndex);
    }

    @Override
    public void setTextSize(int id, Float size) {

    }

    @Override
    public void setTextSize(TextView textView, Float size) {

    }
}
