package com.yb.ballworld.information.ui.personal.presenter;

import androidx.lifecycle.LifecycleOwner;

import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;

public class InfoVideoPresenter extends BasePresenter<LifecycleOwner, VoidModel> {
}
