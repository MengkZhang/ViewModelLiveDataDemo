package com.yb.ballworld.information.ui.community.view;


import android.content.Intent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.alibaba.android.arouter.launcher.ARouter;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.entity.MultiItemEntity;
import com.hwangjr.rxbus.annotation.Subscribe;
import com.hwangjr.rxbus.thread.EventThread;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshHeader;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.base.fragment.BasePageFragment;
import com.yb.ballworld.baselib.base.recycler.header.PlayBallHeader;
import com.yb.ballworld.baselib.constant.Constant;
import com.yb.ballworld.baselib.core.RouterHub;
import com.yb.ballworld.baselib.data.UserInfo;
import com.yb.ballworld.baselib.data.event.OnActivityResultEvent;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.baselib.utils.ViewUtils;
import com.yb.ballworld.baselib.widget.placeholder.PlaceholderView;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.http.InforMationHttpApi;
import com.yb.ballworld.information.ui.community.CommunityAdapter;
import com.yb.ballworld.information.ui.community.CommunityBestPost;
import com.yb.ballworld.information.ui.community.CommunityHttpApi;
import com.yb.ballworld.information.ui.community.data.CommunityPost;
import com.yb.ballworld.information.ui.community.data.CommunityPostAuthor;
import com.yb.ballworld.information.ui.community.data.CommunityPostBean;
import com.yb.ballworld.information.ui.community.data.CommunityRecommendBean;
import com.yb.ballworld.information.ui.detail.InformationGalleryActivity;
import com.yb.ballworld.information.ui.community.bean.AttentionResult;
import com.yb.ballworld.information.ui.home.utils.JZReleaseUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.personal.view.InformationPersonalActivity;
import com.yb.ballworld.information.ui.personal.view.InformationPersonalActivityNew;
import com.yb.ballworld.information.utils.ShareTextUitl;
import com.yb.ballworld.information.widget.ConfirmDialog;

import java.util.ArrayList;
import java.util.List;

import static android.text.TextUtils.isEmpty;

/**
 * 社区
 */
public class CommunityFragment extends BasePageFragment implements OnRefreshListener, OnLoadMoreListener,
        BaseQuickAdapter.OnItemChildClickListener {

    private SmartRefreshLayout mLayoutRefresh;
    private RecyclerView mListView;
    private ImageView mImgToTop;
    private PlaceholderView placeholderView;
    private boolean hasFreezen;

    private CommunityHttpApi communityHttpApi = new CommunityHttpApi();
    private int mPage = 1;
    private CommunityAdapter mAdapter;
    private List<CommunityPost> mData = new ArrayList<>();

    private int scrollY = 0;

    public static CommunityFragment newInstance() {
        return new CommunityFragment();
    }

    @Override
    public int getLayoutResID() {
        return R.layout.fragment_community;
    }

    @Override
    public void onClick(@NonNull View view) {
        int id = view.getId();
        if (R.id.iv_community_to_top == id) {
            mListView.smoothScrollToPosition(0);
        } else if (R.id.iv_community_new == id) {
            UserInfo userInfo = LoginOrdinaryUtils.INSTANCE.getUserInfo();
            if (userInfo == null) {
                toLogin();
                return;
            }
            if (!hasFreezen) {
                CommunityNewActivity.start(getContext());
            } else {
                showToast("用户已冻结");
            }
        }
        super.onClick(view);
    }

    @Override
    protected void initView() {
        mLayoutRefresh = findView(R.id.refresh_community);
        mListView = findView(R.id.recycle_community);
        mImgToTop = findView(R.id.iv_community_to_top);
        placeholderView = findView(R.id.placeholder);

        mLayoutRefresh.setOnRefreshListener(this);
        mLayoutRefresh.setOnLoadMoreListener(this);
        mLayoutRefresh.setRefreshHeader(getRefreshHeader());

        mImgToTop.setOnClickListener(this);
        findView(R.id.iv_community_new).setOnClickListener(this);

        placeholderView.setPageErrorRetryListener(v -> {
            showLoading(placeholderView);
            loadData();
        });
        mAdapter = new CommunityAdapter();
        mListView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                scrollY += dy;
                ViewUtils.setViewAlphaVisibility(mImgToTop, scrollY - ViewUtils.getScreenHeight() * 2);
            }
        });
        LiveEventBus.get().with(LiveEventBusKey.KEY_AUTHOR_REPLAY_TIE, CommunityPost.class).observe(this,
                post -> {
                    if (post != null && mAdapter != null) {
                        mAdapter.addCommunityPost(post);
                    }
                });

        //接收停止视频
        LiveEventBus.get()
                .with(LiveEventBusKey.KEY_INFO_PAUSE_PLAY, Boolean.class)
                .observe(getPageActivity(), aBoolean -> {
                    if (aBoolean) {
                        JZReleaseUtil.releaseAllVideos();
                    }
                });

    }

    @Override
    public void onResume() {
        super.onResume();
        if (mData != null && !mData.isEmpty()) {
            if (mAdapter != null) {
                mAdapter.notifyDataSetChanged();
            }
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        JZReleaseUtil.releaseAllVideos();
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (!getUserVisibleHint()) {
            JZReleaseUtil.releaseAllVideos();
        }
    }

    @Override
    protected void initData() {
        mListView.setLayoutManager(new LinearLayoutManager(getContext()));
        mAdapter.setOnItemChildClickListener(this);
        mAdapter.setOnItemClickListener((adapter, view, position) -> {
            MultiItemEntity item = mAdapter.getItem(position);
            if (item == null || !(item instanceof CommunityPost)) {
                return;
            }
            CommunityPost post = (CommunityPost) item;
            TopicDetailActivity.start(getActivity(), post.id);
        });
        mAdapter.setAuthorClickListener(v -> {
            CommunityPostAuthor author = (CommunityPostAuthor) v.getTag();
            // 如果不为空则点击的为用户头像，否则为全部
            if (author != null) {
                InformationPersonalActivityNew.startActivity(getContext(), author.userId,InformationPersonalActivityNew.TYPE_COMMUNITY);
            } else {//跳转全部推荐作者列表
                startActivity(new Intent(getContext(), AuthorListActivity.class));
            }
        });
        mListView.setAdapter(mAdapter);
        showLoading(placeholderView);
        loadData();
        //recyclerView滑动停止播放
        JZReleaseUtil.releaseAllVideos(mListView, R.id.player_community);
        JZReleaseUtil.releaseAllVideos(mListView, R.id.player_community_comment);
    }

    @Override
    public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
        int id = view.getId();
        Object item = adapter.getItem(position);
        if (id == R.id.avatar || id == R.id.tv_name) {
            if (item != null && item instanceof CommunityPost) {
                CommunityPost post = (CommunityPost) item;
                if (post.userId != null) {
                    InformationPersonalActivityNew.startActivity(getContext(), post.userId,InformationPersonalActivityNew.TYPE_COMMUNITY);
                }
            }
        } else if (id == R.id.avatar_comment || id == R.id.tv_name_comment) {
            if (item != null && item instanceof CommunityPost) {
                CommunityPost post = (CommunityPost) item;
                if (post.latestPost != null && post.latestPost.userId != null) {
                    InformationPersonalActivityNew.startActivity(getContext(), post.latestPost.userId,InformationPersonalActivityNew.TYPE_COMMUNITY);
                }
            }
        } else if (R.id.tv_attention == id) {
            UserInfo userInfo = LoginOrdinaryUtils.INSTANCE.getUserInfo();
            if (userInfo == null) {
                toLogin();
                return;
            }
            if (item != null && item instanceof CommunityPost) {
//                if (((CommunityPost) item).userId.equals(userInfo.getUid() + "")) {
//                    showToast("不能关注自己");
//                    return;
//                }
                if (((CommunityPost) item).isAttention) {//取消关注
                    ConfirmDialog dialog = new ConfirmDialog(getContext(),   ShareTextUitl.getMarksText(((CommunityPost) item).nickname),
                            "是否取消对ta的关注？",
                            (dialog1, confirm) -> {
                                if (confirm) {
                                    authorCancelLike(position);
                                } else {
                                    dialog1.dismiss();
                                }
                            });
                    dialog.show();
                } else {//关注
                    authorLike(position);
                }
            }
        } else if (R.id.tv_count_likes == id) {
            if (item != null && item instanceof CommunityPost && !((CommunityPost) item).isLike) {
                communityLike(position);
            }
        } else if (R.id.iv_image == id) {
            try {
                int pos = (int) view.getTag();
                ArrayList<String> urls = (ArrayList<String>) adapter.getData();
                NavigateToDetailUtil.navigateToGalleryActivity(getActivity(),
                        urls,
                        position,
                        ShareTextUitl.getShareTitle(((CommunityPost) mAdapter.getItem(pos)).content),
                        ((CommunityPost) mAdapter.getItem(pos)).webShareUrl,
                        ((CommunityPost) mAdapter.getItem(pos)).content,
                        ((CommunityPost) mAdapter.getItem(pos)).webShareUrl);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (R.id.tv_item_community_best_topic == id) {
            UserInfo userInfo = LoginOrdinaryUtils.INSTANCE.getUserInfo();
            if (userInfo == null) {
                toLogin();
                return;
            }
            if (item != null && item instanceof CommunityBestPost) {
                TopicDetailActivity.start(getActivity(), ((CommunityBestPost) item).id + "");
            }
        } else if (R.id.tv_count_reply == id) {
            if (item != null && item instanceof CommunityPost) {
                TopicDetailActivity.start(getActivity(), ((CommunityPost) item).id, true);
            }
        }
    }

    @Override
    public void onRefresh(@NonNull RefreshLayout refreshLayout) {
        mPage = 1;
        loadData();
    }

    @Override
    public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
        mPage++;
        loadPostData(true);
    }

    /**
     * 获取刷新头部
     *
     * @return 头部
     */
    private RefreshHeader getRefreshHeader() {
        return new PlayBallHeader(getPageActivity()).createAnim(PlayBallHeader.FOOTBALL);
    }

    @Override
    public void setTextSize(int id, Float size) {

    }

    @Override
    public void setTextSize(TextView textView, Float size) {

    }

    private void loadData() {
        communityHttpApi.getCommunityRecommend(new LifecycleCallback<CommunityRecommendBean>(this) {
            @Override
            public void onSuccess(CommunityRecommendBean data) {
                mAdapter.setPostAuthorRecommends(data.postAuthorRecommends);
                mAdapter.setPostRecommends(data.postRecommends);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
//                if (!isEmpty(errMsg)) {
//                    showToast(errMsg);
//                }
            }
        });
        loadPostData(false);
        judgeUserState();
    }

    private void loadPostData(boolean isLoadMore) {
        communityHttpApi.getCommunityList(mPage, new LifecycleCallback<CommunityPostBean>(this) {
            @Override
            public void onSuccess(CommunityPostBean data) {
                hidePageLoading(placeholderView);
                showContent(placeholderView);
                mLayoutRefresh.finishRefresh(true);
                mLayoutRefresh.finishLoadMore(true);
                if (!isLoadMore) {
                    mData.clear();
                }
                mData.addAll(data.list);
                mAdapter.setData(mData);
                mLayoutRefresh.setEnableLoadMore(data.pageNum < data.totalPage);
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                if (!isEmpty(errMsg)) {
                    showError(placeholderView, errMsg);
                } else {
                    showError(placeholderView, getString(R.string.app_loading_error));
                }
                mLayoutRefresh.finishRefresh(false);
                mLayoutRefresh.finishLoadMore(false);
                mLayoutRefresh.setEnableLoadMore(false);
            }
        });
    }

    @Override
    protected boolean isRegisterRxBus() {
        return true;
    }

    private void communityLike(int position) {
        UserInfo userInfo = LoginOrdinaryUtils.INSTANCE.getUserInfo();
        if (userInfo == null) {
            toLogin();
            return;
        }
        MultiItemEntity item = mAdapter.getItem(position);
        if (item == null || !(item instanceof CommunityPost)) {
            return;
        }
        CommunityPost post = (CommunityPost) item;
        communityHttpApi.communityLike(post.id,
                new LifecycleCallback<String>(this) {
                    @Override
                    public void onSuccess(String data) {
                        post.isLike = true;
                        post.likeCount++;
                        mAdapter.updateItem(post);
                        showToast("点赞成功");
                    }

                    @Override
                    public void onFailed(int errCode, String errMsg) {
                        if (!isEmpty(errMsg)) {
                            showToast(errMsg);
                        }
                    }
                });
    }

    private void authorLike(int position) {
        MultiItemEntity item = mAdapter.getItem(position);
        if (item == null || !(item instanceof CommunityPost)) {
            return;
        }
        CommunityPost post = (CommunityPost) item;
        int userId = 0;
        try {
            userId = Integer.parseInt(post.userId);
        } catch (NumberFormatException e) {
            e.printStackTrace();
            return;
        }
        new InforMationHttpApi().attentionAuthor(userId, new LifecycleCallback<AttentionResult>(getActivity()) {
            @Override
            public void onSuccess(AttentionResult data) {
                post.isAttention = true;
                mAdapter.updateItem(post);
                showToast("关注成功");
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                if (!isEmpty(errMsg)) {
                    showToast(errMsg);
                }
            }
        });
    }

    private void authorCancelLike(int position) {
        MultiItemEntity item = mAdapter.getItem(position);
        if (item == null || !(item instanceof CommunityPost)) {
            return;
        }
        CommunityPost post = (CommunityPost) item;
        int userId = 0;
        try {
            userId = Integer.parseInt(post.userId);
        } catch (NumberFormatException e) {
            e.printStackTrace();
            return;
        }
        new InforMationHttpApi().attentionAuthorCancel(userId, new LifecycleCallback<AttentionResult>(getActivity()) {
            @Override
            public void onSuccess(AttentionResult data) {
                post.isAttention = false;
                mAdapter.updateItem(post);
                showToast("取消关注成功");
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                if (!isEmpty(errMsg)) {
                    showToast(errMsg);
                }
            }
        });
    }

    private void toLogin() {
        ARouter.getInstance().build(RouterHub.USER_LOGIN_REGISTER_ACTIVITY)
                .navigation(getActivity(), Constant.COMMON_LOGIN_REQUEST);
    }

    @Subscribe(thread = EventThread.MAIN_THREAD)
    public void onActivityResult(OnActivityResultEvent event) {
        LogUtils.INSTANCE.e("tlw: onActivityResult search anchor result " + event);
        if (event.getRequestCode() == Constant.COMMON_LOGIN_REQUEST) {
            loadData();
            mListView.scrollToPosition(0);
            /*if (event.resultCode == 1) {
                PlayerLogUtils.e("tlw: login succeed.")
            } else {
                PlayerLogUtils.e("tlw: login cancel or failed.")
            }*/
        }
    }

    private void judgeUserState() {
        communityHttpApi.judgeUserFreeze(new LifecycleCallback<Boolean>(getActivity()) {
            @Override
            public void onSuccess(Boolean data) {
                hasFreezen = data;
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                if (!isEmpty(errMsg)) {
                    showToast(errMsg);
                }
            }
        });
    }

}
