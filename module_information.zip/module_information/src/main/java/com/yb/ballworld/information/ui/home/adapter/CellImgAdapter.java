package com.yb.ballworld.information.ui.home.adapter;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.util.DensityUtil;
import com.yb.ballworld.base.ScreenUtils;
import com.yb.ballworld.common.baseapp.AppContext;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.bean.JumpBean;
import com.yb.ballworld.information.ui.home.utils.GlideLoadImgUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;

import java.util.List;

/**
 * Desc cell图片适配器
 * Date 2019/10/10
 * author mengk
 */
public class CellImgAdapter extends BaseQuickAdapter<JumpBean, BaseViewHolder> {

    private List<JumpBean> data;

    public CellImgAdapter(@Nullable List<JumpBean> data) {
        super(R.layout.item_img_face, data);
        this.data = data;
    }

    @Override
    public int getItemCount() {
        int size = data.size();
        if (size >=2 && size <= 3) {
            return size;
        } else if (size > 3 && size < 6) {
            return 3;
        } else if (size >= 6) {
            return 6;
        }
        return super.getItemCount();
    }

    @Override
    protected void convert(BaseViewHolder helper, JumpBean item, int pos) {
        int size = data.size();
        ImageView imageView = helper.getView(R.id.iv_img_multi);
        TextView tvTotal = helper.getView(R.id.tv_total_img_info);
        if (size > 6) {
            if (pos == getItemCount() - 1) {
                tvTotal.setVisibility(View.VISIBLE);
                StringBuilder sb = new StringBuilder();
                sb.append("共").append(size).append("张");
                tvTotal.setText(sb.toString());
            } else {
                tvTotal.setVisibility(View.GONE);
            }
        } else {
            tvTotal.setVisibility(View.GONE);
        }
        GlideLoadImgUtil.loadImg(mContext,item.getImgUrl(),imageView);
        helper.addOnClickListener(R.id.iv_img_multi);

        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) (helper.getView(R.id.cv_img_face)).getLayoutParams();
        if (size <= 3) {
            layoutParams.topMargin = 0;
        } else {
            layoutParams.topMargin = DensityUtil.dp2px(6);
        }

    }
}
