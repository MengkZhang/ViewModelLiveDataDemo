package com.yb.ballworld.information.ui.home.bean;

/**
 * Desc
 * Date 2019/10/20
 * author mengk
 */
public class FileDataBean {
    private String imgUrl;
    private String imgPath;

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getImgPath() {
        return imgPath;
    }

    public void setImgPath(String imgPath) {
        this.imgPath = imgPath;
    }
}
