package com.yb.ballworld.information.ui.profile.view.fragments;

import android.os.Bundle;
import android.view.View;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.yb.ballworld.common.livedata.LiveDataObserver;
import com.yb.ballworld.information.ui.profile.adapter.RaceAdapter;
import com.yb.ballworld.information.ui.profile.data.ClubSeasonAgendaBean;
import com.yb.ballworld.information.ui.profile.presenter.RacePresenter;

import java.util.ArrayList;
import java.util.List;

/**
 * 俱乐部资料库-赛程
 * @author Gethin
 * @time 2019/11/7 18:19
 */

public class RaceFragment extends RvBaseFragment<RacePresenter> {

    private RaceAdapter adapter = new RaceAdapter(new ArrayList<>());
    private String teamId;
    private String seasonId;

    public static RaceFragment newInstance(String teamId, String seasonId) {
        RaceFragment raceFragment = new RaceFragment();
        Bundle args = new Bundle();
        args.putString("teamId", teamId);
        args.putString("seasonId", seasonId);
        raceFragment.setArguments(args);
        return raceFragment;
    }

    @Override
    protected void initData() {
        Bundle arguments = getArguments();
        if (arguments != null) {
            teamId = arguments.getString("teamId");
            seasonId = arguments.getString("seasonId");
        }
        super.initData();
    }

    @Override
    protected void loadData() {
        mPresenter.loadRaceData(teamId, seasonId);
    }

    @Override
    protected BaseQuickAdapter getAdapter() {
        return adapter;
    }

    @Override
    public void initPresenter() {
        mPresenter.setVM(this);
    }

    @Override
    protected void bindEvent() {
        mPresenter.seasonAgenda.observe(this, new LiveDataObserver<List<ClubSeasonAgendaBean>>() {
            @Override
            public void onSuccess(List<ClubSeasonAgendaBean> data) {
                stopRefresh();
                if (data != null && data.size() > 0) {
                    showPageContent();
                    adapter.setNewData(data);
                } else {
                    showPageEmpty("");
                }
            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                stopRefresh();
                showPageError("");
            }
        });

    }

    @Override
    protected void processClick(View view) {

    }
}
