package com.yb.ballworld.information.ui.home.bean;

import java.io.Serializable;
import java.util.List;

/**
 * Desc
 * Date 2019/11/15
 * author mengk
 */
public class OutSideLableGroupBean implements Serializable {
    private List<IndexLableLetterBean> cupTeams;
    private List<IndexLableLetterBean> leaguTeams;
    private List<IndexLableLetterBean> leagues;
    private List<IndexLableLetterBean> players;

    public List<IndexLableLetterBean> getCupTeams() {
        return cupTeams;
    }

    public void setCupTeams(List<IndexLableLetterBean> cupTeams) {
        this.cupTeams = cupTeams;
    }

    public List<IndexLableLetterBean> getLeaguTeams() {
        return leaguTeams;
    }

    public void setLeaguTeams(List<IndexLableLetterBean> leaguTeams) {
        this.leaguTeams = leaguTeams;
    }

    public List<IndexLableLetterBean> getLeagues() {
        return leagues;
    }

    public void setLeagues(List<IndexLableLetterBean> leagues) {
        this.leagues = leagues;
    }

    public List<IndexLableLetterBean> getPlayers() {
        return players;
    }

    public void setPlayers(List<IndexLableLetterBean> players) {
        this.players = players;
    }
}
