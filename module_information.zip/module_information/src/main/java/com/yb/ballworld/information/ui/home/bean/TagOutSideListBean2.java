package com.yb.ballworld.information.ui.home.bean;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * Desc
 * Date 2019/11/9
 * author mengk
 */
public class TagOutSideListBean2 implements Parcelable {
    private String title;
    private List<OutSideIndexListBean> list;

    public TagOutSideListBean2() {
    }

    public TagOutSideListBean2(String title, List<OutSideIndexListBean> list) {
        this.title = title;
        this.list = list;
    }

    protected TagOutSideListBean2(Parcel in) {
        title = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<TagOutSideListBean2> CREATOR = new Creator<TagOutSideListBean2>() {
        @Override
        public TagOutSideListBean2 createFromParcel(Parcel in) {
            return new TagOutSideListBean2(in);
        }

        @Override
        public TagOutSideListBean2[] newArray(int size) {
            return new TagOutSideListBean2[size];
        }
    };

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<OutSideIndexListBean> getList() {
        return list;
    }

    public void setList(List<OutSideIndexListBean> list) {
        this.list = list;
    }
}
