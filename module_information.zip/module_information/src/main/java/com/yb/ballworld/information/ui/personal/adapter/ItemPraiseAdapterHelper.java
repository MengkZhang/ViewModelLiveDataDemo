package com.yb.ballworld.information.ui.personal.adapter;

import android.util.Log;
import android.view.View;

import com.bfw.util.ToastUtils;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.utils.NetWorkUtils;
import com.yb.ballworld.baselib.utils.ViewUtils;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.personal.bean.CollectionEntity;
import com.yb.ballworld.information.ui.personal.bean.CommentBean;
import com.yb.ballworld.information.ui.personal.bean.PostEntity;
import com.yb.ballworld.information.ui.personal.constant.CollectInfoCallbackListener;
import com.yb.ballworld.information.ui.personal.constant.PraiseCallbackListener;
import com.yb.ballworld.information.ui.personal.constant.RemoveCollectInfoCallBackListener;
import com.yb.ballworld.information.ui.personal.presenter.ItemPraisePresenter;
import com.yb.ballworld.information.widget.GoodView;

import rxhttp.wrapper.entity.Response;

/**
 * Desc 点赞帮助类
 * Date 2019/10/11
 * author mengk
 */
public class ItemPraiseAdapterHelper {

    /**
     * 评论页面点赞
     *
     * @param adapter         adapter
     * @param praisePresenter presenter
     * @param goodView        点赞动效视图
     */
    public static void initCommentPraise(CommentAdapter adapter, ItemPraisePresenter praisePresenter, GoodView goodView) {
        try {
            adapter.setOnItemChildClickListener(new BaseQuickAdapter.OnItemChildClickListener() {
                @Override
                public void onItemChildClick(BaseQuickAdapter adapter1, View view, int position) {
                    Object item = adapter1.getItem(position);
                    if (item instanceof CommentBean) {
                        int id = ((CommentBean) item).getId();
                        if (id == 0) {
                            ToastUtils.showToast("点赞失败");
                            return;
                        }
                        boolean hasFocus = ((CommentBean) item).isIsLike();
                        int likeCount = ((CommentBean) item).getLikeCount();
                        if (view.getId() == R.id.lyPraise) {
                            if (!hasFocus) { //没有点赞过
                                praisePresenter.loadData("", id, new PraiseCallbackListener() {
                                    @Override
                                    public void onPraiseSuccess(Response response) {
                                        goodView.show(view);
                                        ((CommentBean) item).setLikeCount(likeCount + 1);
                                        ((CommentBean) item).setIsLike(true);
                                        adapter1.notifyItemChanged(position);
                                        //adapter1.notifyDataSetChanged();
                                    }

                                    @Override
                                    public void onPraiseFail(String msg) {
                                        goodView.show(view);
                                        ((CommentBean) item).setLikeCount(likeCount + 1);
                                        ((CommentBean) item).setIsLike(true);
                                        adapter1.notifyItemChanged(position);
                                    }
                                });
                            } else {
                                //ToastUtils.INSTANCE.showToast("点赞成功");
                                //goodView.show(view);
                            }

                        }

                    }
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
            ToastUtils.showToast("点赞失败");
        }

    }

    /**
     * 我的发表页带你走
     *
     * @param adapter         adapter
     * @param praisePresenter presenter
     * @param goodView        点赞动效视图
     */
    public static void initPublishPraise(InfoPublishQuickAdapter adapter, ItemPraisePresenter praisePresenter, GoodView goodView) {
        try {
            adapter.setOnItemChildClickListener(new BaseQuickAdapter.OnItemChildClickListener() {
                @Override
                public void onItemChildClick(BaseQuickAdapter adapter1, View view, int position) {
                    Object item = adapter1.getItem(position);
                    if (item instanceof PostEntity.ListBean) {
                        String id = ((PostEntity.ListBean) item).getId();
                        int commentCount = ((PostEntity.ListBean) item).getLikeCount();
                        boolean hasFocus = ((PostEntity.ListBean) item).isIsLike();
                        if (view.getId() == R.id.iv_praise_icon) {
                            //if (view.getId() == R.id.iv_comment_icon) {
                            if (!hasFocus) { //没有点赞过
                                ((PostEntity.ListBean) item).setLikeCount(commentCount + 1);
                                ((PostEntity.ListBean) item).setIsLike(true);
                                adapter1.notifyItemChanged(position);
                                ToastUtils.showToast("点赞成功");
                                goodView.show(view);
                                praisePresenter.loadData(id, 0, new PraiseCallbackListener() {
                                    @Override
                                    public void onPraiseSuccess(Response response) {
//                                        ((PostEntity.ListBean) item).setLikeCount(commentCount + 1);
//                                        ((PostEntity.ListBean) item).setIsLike(true);
//                                        adapter1.notifyItemChanged(position);
//                                        ToastUtils.INSTANCE.showToast("点赞成功");
//                                        goodView.show(view);
                                    }

                                    @Override
                                    public void onPraiseFail(String msg) {
//                                        ToastUtils.INSTANCE.showToast("点赞失败");
//                                        goodView.show(view);
                                    }
                                });
                            } else {
                                ToastUtils.showToast("点赞成功");
                                goodView.show(view);
                            }

                        }

                    }
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
            ToastUtils.showToast("点赞异常");
        }
    }

    /**
     * 收藏页取消收藏或点赞
     *
     * @param adapter         adapter
     * @param praisePresenter presenter
     * @param goodView        点赞动效视图
     */
    public static void initRemoveCollectOrPraise(InfoCollectionQuickAdapter adapter, ItemPraisePresenter praisePresenter, GoodView goodView) {
        adapter.setOnItemChildClickListener(new BaseQuickAdapter.OnItemChildClickListener() {
            @Override
            public void onItemChildClick(BaseQuickAdapter adapter1, View view, int position) {
                Object item = adapter1.getItem(position);
                if (item instanceof CollectionEntity.ListBean) {
                    CollectionEntity.ListBean bean = (CollectionEntity.ListBean) item;
                    LogUtils.INSTANCE.d("hhhhh", "position: " + position + " content: " + bean.getId());
                    if (view.getId() == R.id.rl_praise_root) {  //点赞
                        praiseInfo(bean, adapter, praisePresenter, position, goodView, view);
                    } else if (view.getId() == R.id.iv_collect_icon) { //收藏
                        if (ViewUtils.INSTANCE.isFastClick())
                            return;
                        if (bean.isFavorite()) {
                            removeCollectInfo(bean, adapter, praisePresenter, view);
                        } else {
                            collectInfo(bean, adapter, praisePresenter, view);
                        }
                    }

                }
            }
        });
    }

    /**
     * 点赞(收藏)
     *
     * @param item            item子集
     * @param adapter         adapter
     * @param praisePresenter presenter
     * @param position        position
     * @param goodView        动画view
     * @param view            view
     */
    public static void praiseInfo(CollectionEntity.ListBean item, InfoCollectionQuickAdapter adapter, ItemPraisePresenter praisePresenter, int position, GoodView goodView, View view) {
        String id = item.getId();
        boolean hasFocus = item.isIsLike();
        int likeCount = item.getLikeCount();
        if (!hasFocus) { //没有点赞过
            if (NetWorkUtils.INSTANCE.isNetworkNotConnected()) {
                ToastUtils.showToast(R.string.app_recycler_error);
                return;
            }
            item.setLikeCount(likeCount + 1);
            item.setIsLike(true);
            adapter.changeLike(view, item);
            ToastUtils.showToast("点赞成功");

            praisePresenter.loadData(id, 0, new PraiseCallbackListener() {
                @Override
                public void onPraiseSuccess(Response response) {
                    // goodView.show(view);
                    //item.setLikeCount(commentCount + 1);
                    //item.setIsLike(true);
                    //adapter.notifyItemChanged(position);
                    //ToastUtils.INSTANCE.showToast("点赞成功");
                }

                @Override
                public void onPraiseFail(String msg) {
                    // ToastUtils.INSTANCE.showToast("点赞失败");
                    //goodView.show(view);
                }
            });
        }
    }

    /**
     * 收藏
     *
     * @param item            item子集
     * @param adapter         adapter
     * @param praisePresenter presenter
     */
    public static void collectInfo(CollectionEntity.ListBean item, InfoCollectionQuickAdapter adapter, ItemPraisePresenter praisePresenter, View view) {
        String id = item.getId();
        boolean hasFocus = item.isFavorite();
        if (!hasFocus) { //没有点赞过
            praisePresenter.collectInfo(id, new CollectInfoCallbackListener() {
                @Override
                public void onCollectSuccess(Response response) {
                    item.setFavorite(true);
                    adapter.changeAttention(view, true);
                    ToastUtils.showToast("收藏成功");
                    LiveEventBus.get().with(LiveEventBusKey.KEY_INFO_COLLECT).post(item.getId());
                }

                @Override
                public void onCollectFail(String msg) {
                    ToastUtils.showToast(msg);
                }
            });
        } else {
            ToastUtils.showToast("已收藏");
            item.setFavorite(true);
            adapter.changeAttention(view, true);
        }
    }

    /**
     * 取消收藏
     *
     * @param item            item子集
     * @param adapter         adapter
     * @param praisePresenter presenter
     */
    public static void removeCollectInfo(CollectionEntity.ListBean item, InfoCollectionQuickAdapter adapter, ItemPraisePresenter praisePresenter, View view) {
        String id = item.getId();
        praisePresenter.removeCollectInfo(id, new RemoveCollectInfoCallBackListener() {
            @Override
            public void onRemoveCollectSuccess(Response response) {
                if (response.getCode() == 200) {
                    item.setFavorite(false);
                    adapter.changeAttention(view, false);
                    LiveEventBus.get().with(LiveEventBusKey.KEY_INFO_REMOVE_COLLECT).post(item.getId());
                } else {
                    ToastUtils.showToast("取消失败");
                }
            }

            @Override
            public void onRemoveCollectFail(String msg) {
                ToastUtils.showToast("取消失败");
            }
        });
    }

    /**
     * 收藏页点赞
     *
     * @param adapter         adapter
     * @param praisePresenter 点赞presenter
     * @param goodView
     */
    @Deprecated
    public static void initCollectPraise(InfoCollectionQuickAdapter adapter, ItemPraisePresenter praisePresenter, GoodView goodView) {
        try {
            adapter.setOnItemChildClickListener(new BaseQuickAdapter.OnItemChildClickListener() {
                @Override
                public void onItemChildClick(BaseQuickAdapter adapter1, View view, int position) {
                    Object item = adapter1.getItem(position);
                    if (item instanceof CollectionEntity.ListBean) {
                        String id = ((CollectionEntity.ListBean) item).getId();
                        boolean hasFocus = ((CollectionEntity.ListBean) item).isIsLike();
                        int commentCount = ((CollectionEntity.ListBean) item).getLikeCount();
                        if (view.getId() == R.id.iv_praise_icon) {
                            if (!hasFocus) { //没有点赞过
                                praisePresenter.loadData(id, 0, new PraiseCallbackListener() {
                                    @Override
                                    public void onPraiseSuccess(Response response) {
                                        goodView.show(view);
                                        ((CollectionEntity.ListBean) item).setLikeCount(commentCount + 1);

                                        //根据id存储了点赞的状态和数量
//                                        PreferencesHelper.INSTANCE.savePref(id, true);
                                        ((CollectionEntity.ListBean) item).setIsLike(true);
                                        adapter1.notifyItemChanged(position);
//                                        //一次点赞和多次点赞都是数量加1 并存储
//                                        Boolean pref = PreferencesHelper.INSTANCE.getPref(id, false);
//                                        if (!pref) {
//                                            PreferencesHelper.INSTANCE.savePref(id, (commentCount + 1));
//                                        }
                                        ToastUtils.showToast("点赞成功");
                                    }

                                    @Override
                                    public void onPraiseFail(String msg) {
                                        ToastUtils.showToast("点赞失败");
                                        goodView.show(view);
                                    }
                                });
                            } else {
                                ToastUtils.showToast("点赞成功");
                                goodView.show(view);
                            }

                        }

                    }
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
            ToastUtils.showToast("点赞失败");
        }

    }

}
