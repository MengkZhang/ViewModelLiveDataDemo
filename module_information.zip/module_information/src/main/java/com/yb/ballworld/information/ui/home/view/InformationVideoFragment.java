package com.yb.ballworld.information.ui.home.view;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bfw.util.ToastUtils;
import com.ethanhua.skeleton.Skeleton;
import com.ethanhua.skeleton.SkeletonScreen;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshFooter;
import com.scwang.smartrefresh.layout.api.RefreshHeader;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshLoadMoreListener;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.base.fragment.BasePageFragment;
import com.yb.ballworld.baselib.base.recycler.header.PlayBallHeader;
import com.yb.ballworld.baselib.base.recycler.header.RecyclerClassicsFooter;
import com.yb.ballworld.baselib.data.UserInfo;
import com.yb.ballworld.baselib.entity.LogoutEvent;
import com.yb.ballworld.baselib.widget.placeholder.HomePlaceholderView;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.adapter.InfoPraiseAdapterHelper;
import com.yb.ballworld.information.ui.home.adapter.InfoVideoAdapter;
import com.yb.ballworld.information.ui.home.bean.HomeInfoListBean;
import com.yb.ballworld.information.ui.home.bean.InfoListEntity;
import com.yb.ballworld.information.ui.home.constant.FailStateConstant;
import com.yb.ballworld.information.ui.home.constant.HotVideoType;
import com.yb.ballworld.information.ui.home.constant.LoadMoreType;
import com.yb.ballworld.information.ui.home.presenter.InfoContract;
import com.yb.ballworld.information.ui.home.presenter.InfoPraiseContract;
import com.yb.ballworld.information.ui.home.presenter.InfoPraisePresenter;
import com.yb.ballworld.information.ui.home.presenter.InfoPresenter;
import com.yb.ballworld.information.ui.home.utils.JZReleaseUtil;
import com.yb.ballworld.information.ui.home.widget.PlaceholderViewInfo;
import com.yb.ballworld.information.widget.GoodView;

import java.util.ArrayList;
import java.util.List;

import static androidx.recyclerview.widget.RecyclerView.SCROLL_STATE_DRAGGING;
import static androidx.recyclerview.widget.RecyclerView.SCROLL_STATE_IDLE;
import static androidx.recyclerview.widget.RecyclerView.SCROLL_STATE_SETTLING;

/**
 * Desc 资讯视频fragment
 * Date 2019/10/7
 * author mengk
 */
public class InformationVideoFragment extends BasePageFragment implements InfoContract.IInfoView {

    //fragment传递参数的key
    private static final String CATEGORYID = "CATEGORYID";
    private static final String MEDIATYPE = "MEDIATYPE";
    private static final String SPORTTYPE = "SPORTTYPE";
    //fragment区分的索引
    private String categoryId;
    private String mediaType;
    private String sportType;

    //数据
    private List<InfoListEntity.ListBean> dataList = new ArrayList<>();
    //adapter
    private InfoVideoAdapter adapter;

    //刷新控件
    private SmartRefreshLayout smartRefreshLayout;
    //列表控件
    private RecyclerView recyclerView;
    //缺省图状态控件
    private PlaceholderViewInfo placeholder;
    //layoutManager
    private LinearLayoutManager layoutManager;
    //presenter
    private InfoPresenter presenter;
    private GoodView goodView;
//    private SkeletonScreen skeletonScreen;

    public static InformationVideoFragment newInstance(String categoryId, String mediaType, String sportType) {
        InformationVideoFragment fragment = new InformationVideoFragment();
        Bundle bundle = new Bundle();
        bundle.putString(InformationVideoFragment.CATEGORYID, categoryId);
        bundle.putString(InformationVideoFragment.MEDIATYPE, mediaType);
        bundle.putString(InformationVideoFragment.SPORTTYPE, sportType);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected void initView() {
        super.initView();
        initArguments();
        initViews();
    }

    @Override
    protected void initData() {
        super.initData();
        //初始化presenter
        presenter = new InfoPresenter(HotVideoType.TYPE_VIDEO,categoryId,mediaType,sportType);
        presenter.attachView(this);
        presenter.loadData(1);
    }

    @Override
    public boolean onBackPressedSupport() {
        return super.onBackPressedSupport();
    }

    @Override
    public void onPause() {
        super.onPause();
        JZReleaseUtil.releaseAllVideos();
    }

    /**
     * 初始化参数
     */
    private void initArguments() {
        Bundle bundle = getArguments();
        if (bundle == null) return;
        categoryId = bundle.getString(InformationVideoFragment.CATEGORYID);
        mediaType = bundle.getString(InformationVideoFragment.MEDIATYPE);
        sportType = bundle.getString(InformationVideoFragment.SPORTTYPE);
    }

    private void initViews() {

        goodView = new GoodView(getPageActivity());
        goodView.setText("+1");
        goodView.setImage(getResources().getDrawable(R.drawable.icon_priase_info));

        placeholder = findView(R.id.placeholder);
        recyclerView = findView(R.id.recyclerView);
        smartRefreshLayout = findView(R.id.smartRefreshLayout);
        smartRefreshLayout.setRefreshHeader(getRefreshHeader());
        smartRefreshLayout.setRefreshFooter(getRefreshFooter());
        layoutManager = new LinearLayoutManager(getPageActivity());
        recyclerView.setLayoutManager(layoutManager);
        adapter = new InfoVideoAdapter(dataList);
        recyclerView.setAdapter(adapter);

    }

    @Override
    protected void initEvent() {
        super.initEvent();
        initRefreshLoadMoreEvent();
        initReLoadEvent();
        initScrollEvent();
        initObserverEvent();
        initAdapterEvent();
    }

    /**
     * 初始化adapter事件
     */
    private void initAdapterEvent() {
        //点赞事件
        InfoPraiseAdapterHelper.initPraise(recyclerView,adapter,new InfoPraisePresenter(getPageActivity()),goodView);
    }

    /**
     * 接受停止正在播放的视频事件
     */
    private void initObserverEvent() {
        LiveEventBus.get()
                .with(LiveEventBusKey.KEY_INFO_PAUSE_PLAY, Boolean.class)
                .observe(getPageActivity(), aBoolean -> {
                    if (aBoolean) {
                        JZReleaseUtil.releaseAllVideos();
                    }
                });

        //接收评论事件
        LiveEventBus.get().with(LiveEventBusKey.KEY_NEWS_COLLECTION,String.class).observe(this, new Observer<String>() {
            @Override
            public void onChanged(String newsId) {
                if (TextUtils.isEmpty(newsId)) return;
                if (dataList.size() == 0) return;
                for (int i = 0; i < dataList.size(); i++) {
                    InfoListEntity.ListBean homeInfoListBean = dataList.get(i);
                    String id = homeInfoListBean.getId();
                    int commentCount = homeInfoListBean.getCommentCount();
                    if (newsId.equals(id)) {
                        homeInfoListBean.setCommentCount(commentCount + 1);
                        adapter.notifyItemChanged(i);
                        break;
                    }
                }
            }
        });


        //接收来自详情页的点赞事件 LiveEventBusKey.KEY_NEWS_LIKE
        LiveEventBus.get().with(LiveEventBusKey.KEY_NEWS_LIKE,String.class).observe(this, new Observer<String>() {
            @Override
            public void onChanged(String newId) {
                if (TextUtils.isEmpty(newId)) return;
                if (dataList.size() == 0) return;
                for (int i = 0; i < dataList.size(); i++) {
                    InfoListEntity.ListBean homeInfoListBean = dataList.get(i);
                    String id = homeInfoListBean.getId();
                    int likeCount = homeInfoListBean.getLikeCount();
                    if (newId.equals(id)) {
                        homeInfoListBean.setLikeCount(likeCount + 1);
                        homeInfoListBean.setIsLike(true);
                        adapter.notifyItemChanged(i);
                        break;
                    }
                }

            }
        });

        //接收登录的广播事件
        LiveEventBus.get().with(LiveEventBusKey.KEY_UserLoginSuccess, UserInfo.class).observe(this, new Observer<UserInfo>() {
            @Override
            public void onChanged(UserInfo userInfo) {
                if (userInfo == null) return;
                if (presenter == null) return;
                presenter.refreshData();
            }
        });
        //接收退出登录的广播事件
        LiveEventBus.get().with(LiveEventBusKey.KEY_LogoutEvent, LogoutEvent.class).observe(this, new Observer<LogoutEvent>() {
            @Override
            public void onChanged(LogoutEvent logoutEvent) {
                if (logoutEvent == null) return;
                if (presenter == null) return;
                presenter.refreshData();
            }
        });
    }

    /**
     * 初始化滑动事件
     */
    private void initScrollEvent() {
        //recyclerView滑动停止播放
        JZReleaseUtil.releaseAllVideos(recyclerView);
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (!getUserVisibleHint()) {
            JZReleaseUtil.releaseAllVideos();
        }
    }

    /**
     * 初始化重新加载数据
     */
    private void initReLoadEvent() {
        placeholder.setPageErrorRetryListener(v -> presenter.loadData(1));
    }

    /**
     * 初始化刷新和加载更多
     */
    private void initRefreshLoadMoreEvent() {
        smartRefreshLayout.setOnRefreshLoadMoreListener(new OnRefreshLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                presenter.loadMoreData();
            }

            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                presenter.refreshData();
            }
        });
    }


    /**
     * 获取刷新头部
     *
     * @return 头部
     */
    private RefreshHeader getRefreshHeader() {
        return new PlayBallHeader(getPageActivity()).createAnim(PlayBallHeader.FOOTBALL);
    }

    /**
     * 获取刷新底部
     *
     * @return 底部
     */
    private RefreshFooter getRefreshFooter() {
        return new RecyclerClassicsFooter(getPageActivity());
    }

    /**
     * 获取布局资源
     *
     * @return 布局资源
     */
    @Override
    public int getLayoutResID() {
        return R.layout.fragment_info;
    }

    @Override
    public void setTextSize(int id, Float size) {

    }

    @Override
    public void setTextSize(TextView textView, Float size) {

    }

    @Override
    public Fragment getFragment() {
        return this;
    }

    @Override
    public void requestLoading() {
//        skeletonScreen = Skeleton.bind(placeholder)
//                .load(R.layout.layout_place_info_loading)
//                .duration(1000)
//                .shimmer(true)//是否开启动画
//                .color(R.color.color_ffffff)
//                .angle(0)
//                .show();
        showLoading(placeholder);
        smartRefreshLayout.setEnableRefresh(false);
        smartRefreshLayout.setEnableLoadMore(false);
    }

    /**
     * 请求成功回调
     *
     * @param data 列表数据
     */
    @Override
    public void resultSuccess(List<InfoListEntity.ListBean> data,int page) {
//        if(skeletonScreen!=null){
//            skeletonScreen.hide();
//        }
        placeholder.hideLoading();
        smartRefreshLayout.setEnableRefresh(true);
        smartRefreshLayout.setEnableLoadMore(true);
        //刷新的时候还要清理这个数字 避免造成多次刷新数据叠加
        if (page <= 1) {
            dataList.clear();
        }
        dataList.addAll(data);
        adapter.notifyDataSetChanged();
    }

    /**
     * 请求失败回调
     *
     * @param type 失败类型
     */
    @Override
    public void resultFail(int type) {
//        if(skeletonScreen!=null){
//            skeletonScreen.hide();
//        }
        switch (type) {
            case FailStateConstant.TYPE_ERROR:   //加载失败
                showError(placeholder, "网络出了小差，连接失败~");
                break;
            case FailStateConstant.TYPE_EMPTY:   //数据为空
                smartRefreshLayout.setEnableRefresh(true);
                showEmpty(placeholder, "暂无数据");
                break;

            default:
                break;
        }
    }

    @Override
    public void resultRefreshSuccess() {
//        Toast.makeText(getPageActivity(), "刷新成功", Toast.LENGTH_SHORT).show();
        smartRefreshLayout.finishRefresh();
        //刷新成功清理存储的数组
        dataList.clear();
    }

    @Override
    public void resultRefreshFail(String errorMsg) {
//        Toast.makeText(getPageActivity(), "刷新失败", Toast.LENGTH_SHORT).show();
        smartRefreshLayout.finishRefresh();
    }

    @Override
    public void resultLoadMoreSuccess(int type) {
        smartRefreshLayout.finishLoadMore();
        switch (type) {
            case LoadMoreType.TYPE_SUCCESS:      //加载成功
//                Toast.makeText(getPageActivity(), "加载更多成功", Toast.LENGTH_SHORT).show();
                break;

            case LoadMoreType.TYPE_ALL_DATA:     //已经全部加载
//                Toast.makeText(getPageActivity(), "已经全部加载", Toast.LENGTH_SHORT).show();
                ToastUtils.showToast("已经全部加载");
                //已经全部加载 就不允许继续上拉加载了
                smartRefreshLayout.setEnableLoadMore(false);
                break;

            default:
                break;
        }
    }

    @Override
    public void resultLoadMoreFail(String errorMsg) {
//        Toast.makeText(getPageActivity(), "加载更多失败", Toast.LENGTH_SHORT).show();
        smartRefreshLayout.finishLoadMore();
    }


}
