package com.yb.ballworld.information.ui.home.adapter;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ViewFlipper;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.widget.round.RoundImageView;
import com.yb.ballworld.common.utils.DisplayUtil;
import com.yb.ballworld.common.widget.banner.MZBannerView;
import com.yb.ballworld.common.widget.banner.holder.MZViewHolder;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.bean.HomeIndexBannerBean;
import com.yb.ballworld.information.ui.home.bean.HomeIndexHotRunBean;
import com.yb.ballworld.information.ui.home.bean.IndexHotEntity;
import com.yb.ballworld.information.ui.home.presenter.InfoPraisePresenter;
import com.yb.ballworld.information.ui.home.utils.GlideLoadImgUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.widget.GoodView;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc 资讯热门列表adapter帮助类
 * Date 2019/10/8
 * author mengk
 */
public class InfoAdapterHelper {

    private static RecyclerView rvTop;

    /**
     * 添加头部banner和ViewFlipper
     * 加载更多防止加载banner区域 不能用多布局 故添加头部
     *
     * @param adapter                  adapter
     * @param context                  context
     * @param mHomeIndexBannerBeanList banner数组
     * @param mHomeIndexHotRunBeanList 子弹推数组
     * @param mHomeIndexTopBeanList    置顶数组
     * @param goodView
     */
    public static void addHeader(InfoHotAdapter adapter, Context context,
                                 List<HomeIndexBannerBean> mHomeIndexBannerBeanList,
                                 List<HomeIndexHotRunBean> mHomeIndexHotRunBeanList,
                                 IndexHotEntity.SpecialBlocksBean mSpecialBlocksBean,
                                 List<IndexHotEntity.NewsTopBlocksBean> mHomeIndexTopBeanList,
                                 GoodView goodView) {
        try {
            View headerView = View.inflate(context, R.layout.item_head_view, null);

            //banner
            adapterBanner(context, mHomeIndexBannerBeanList, headerView);

            //子弹推送View
            adapterHotRun(context, mHomeIndexHotRunBeanList, headerView);

            //专栏
            adapterSpecial(context, mSpecialBlocksBean, headerView);

            //置顶
            adapterTop(context, mHomeIndexTopBeanList, headerView, goodView);

            //没有添加过头部 才添加
            adapter.removeAllHeaderView();
            adapter.addHeaderView(headerView, 0);
            int headerLayoutCount = adapter.getHeaderLayoutCount();
            LogUtils.INSTANCE.e("===z", "header个数 = " + headerLayoutCount);

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("InformationFragment addHeader Exception");
            LogUtils.INSTANCE.e("===z", "addHeader异常");
        }
    }

    public static RecyclerView getRV() {
        if (rvTop != null) {
            return rvTop;
        }
        return null;
    }

    /**
     * 适配置顶数据
     *
     * @param context
     * @param mHomeIndexTopBeanList
     * @param headerView
     * @param goodView
     */
    private static void adapterTop(Context context, List<IndexHotEntity.NewsTopBlocksBean> mHomeIndexTopBeanList, View headerView, GoodView goodView) {
        rvTop = headerView.findViewById(R.id.rv_top);
        LinearLayout viewLineTop = headerView.findViewById(R.id.ll_view_line_top);
        rvTop.removeAllViews();
        try {
            if (mHomeIndexTopBeanList != null && mHomeIndexTopBeanList.size() != 0) { //置顶数据
                rvTop.setVisibility(View.VISIBLE);
                viewLineTop.setVisibility(View.VISIBLE);
                rvTop.setLayoutManager(new LinearLayoutManager(context));
                rvTop.setNestedScrollingEnabled(false);
                IndexTopAdapter indexTopAdapter = new IndexTopAdapter(mHomeIndexTopBeanList);
                rvTop.setAdapter(indexTopAdapter);
                InfoPraiseAdapterHelper.initPraiseTop(indexTopAdapter, new InfoPraisePresenter((Activity) context), goodView);

            } else {                                                                  //置顶为空
                rvTop.setVisibility(View.GONE);
//                viewLineTop.setVisibility(View.GONE);
            }
        } catch (Exception e) {
            e.printStackTrace();
            LogUtils.INSTANCE.e("===z", "置顶异常");
            rvTop.setVisibility(View.GONE);
//            viewLineTop.setVisibility(View.GONE);
        }
    }

    /**
     * 适配专栏数据
     *
     * @param context
     * @param headerView
     */
    private static void adapterSpecial(Context context, IndexHotEntity.SpecialBlocksBean mSpecialBlocksBean, View headerView) {
        //由于后台返回的数组 所以进来的时候要判断到底是图片类型还是
        //专栏图片
        ImageView mImageView = headerView.findViewById(R.id.iv_special);
        //专栏赛事
        RecyclerView rvSpecial = headerView.findViewById(R.id.rv_special);
        rvSpecial.removeAllViews();
        LinearLayout viewLineSpecial = headerView.findViewById(R.id.ll_view_line_special);
        try {
            List<IndexHotEntity.SpecialBlocksBean.SpecialBlockVoBean.MatchDataBean> matchDataList = new ArrayList<>();

            if (mSpecialBlocksBean != null) {
                int specialType = mSpecialBlocksBean.getSpecialType();
                if (specialType == 1) {//赛事
                    mImageView.setVisibility(View.GONE);
                    rvSpecial.setVisibility(View.VISIBLE);
                    viewLineSpecial.setVisibility(View.VISIBLE);

                    List<IndexHotEntity.SpecialBlocksBean.SpecialBlockVoBean> specialBlockVo = mSpecialBlocksBean.getSpecialBlockVo();
                    if (specialBlockVo != null && specialBlockVo.size() != 0) {
                        if (matchDataList.size() != 0) {
                            matchDataList.clear();
                        }

                        for (IndexHotEntity.SpecialBlocksBean.SpecialBlockVoBean specialBlockVoBean : specialBlockVo) {
                            List<IndexHotEntity.SpecialBlocksBean.SpecialBlockVoBean.MatchDataBean> matchData = specialBlockVoBean.getMatchData();
                            if (matchData != null && matchData.size() != 0) {
                                //暂时取第一个元素
                                IndexHotEntity.SpecialBlocksBean.SpecialBlockVoBean.MatchDataBean matchDataBean = matchData.get(0);
//                                matchDataList.addAll(matchData);
                                String matchId = specialBlockVoBean.getMatchId();
                                String sportId = specialBlockVoBean.getSportId();
                                matchDataBean.setMatchId(Integer.parseInt(!TextUtils.isEmpty(matchId) ? matchId : "0"));
                                matchDataBean.setSportId(Integer.parseInt(!TextUtils.isEmpty(sportId) ? sportId : "0"));
                                matchDataList.add(matchDataBean);
                            }
                        }

                        //判断是否只有一条数据

                        LinearLayoutManager layoutManager = new LinearLayoutManager(context);
                        layoutManager.setOrientation(RecyclerView.HORIZONTAL);
                        rvSpecial.setLayoutManager(layoutManager);

                        if (matchDataList.size() == 1) {
                            IndexSpecialJustOneAdapter indexSpecialAdapter = new IndexSpecialJustOneAdapter(matchDataList);
                            LogUtils.INSTANCE.e("===z", "专栏数组size = " + specialBlockVo.size());
                            rvSpecial.setAdapter(indexSpecialAdapter);
                        } else {
                            IndexSpecialAdapter indexSpecialAdapter = new IndexSpecialAdapter(matchDataList);
                            LogUtils.INSTANCE.e("===z", "专栏数组size = " + specialBlockVo.size());
                            rvSpecial.setAdapter(indexSpecialAdapter);
                        }

                    } else {
                        rvSpecial.setVisibility(View.GONE);
                        viewLineSpecial.setVisibility(View.GONE);
                    }
                } else {               //图片
                    mImageView.setVisibility(View.VISIBLE);
                    rvSpecial.setVisibility(View.GONE);
                    //只有一张图片
                    List<IndexHotEntity.SpecialBlocksBean.SpecialBlockVoBean> specialBlockVo = mSpecialBlocksBean.getSpecialBlockVo();
                    if (specialBlockVo != null && specialBlockVo.size() != 0) {
                        IndexHotEntity.SpecialBlocksBean.SpecialBlockVoBean specialBlockVoBean = specialBlockVo.get(0);
                        if (specialBlockVoBean != null) {
                            String imgUrl = specialBlockVoBean.getImgUrl();
                            String jumpId = specialBlockVoBean.getJumpId();
                            int jumpType = specialBlockVoBean.getJumpType();
                            String jumpUrl = specialBlockVoBean.getJumpUrl();
                            GlideLoadImgUtil.loadImg(context, imgUrl, mImageView);
                            String matchId = specialBlockVoBean.getMatchId();//这里是有matchID的
                            String sportType = specialBlockVoBean.getSportId();

                            // TODO: 2019/10/12 点击事件
                            mImageView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    int matchIds = 0;
                                    int sportTypes = 0;
                                    try {
                                        matchIds = Integer.parseInt(matchId);
                                        sportTypes = Integer.parseInt(sportType);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                    NavigateToDetailUtil.jumpType(context,jumpType,jumpId,jumpUrl,matchIds,sportTypes);
                                }
                            });
                        }
                    } else {
                        //走到这里连图片也没有
                        mImageView.setVisibility(View.GONE);
                        viewLineSpecial.setVisibility(View.GONE);
                    }
                }
            } else { //没有专栏
                rvSpecial.setVisibility(View.GONE);
                viewLineSpecial.setVisibility(View.GONE);
                mImageView.setVisibility(View.GONE);
            }
        } catch (Exception e) {
            e.printStackTrace();
            rvSpecial.setVisibility(View.GONE);
            viewLineSpecial.setVisibility(View.GONE);
            mImageView.setVisibility(View.GONE);
            LogUtils.INSTANCE.e("===z","专栏异常");
        }



    }

    /**
     * 适配banner
     *
     * @param context
     * @param mHomeIndexBannerBeanList
     * @param headerView
     */
    private static void adapterBanner(Context context, List<HomeIndexBannerBean> mHomeIndexBannerBeanList, View headerView) {
        try {
            MZBannerView banner = headerView.findViewById(R.id.convenientBanner);
            banner.setIndicatorRes(R.drawable.indicator_square_normal, R.drawable.indicator_square_selected);
            List<String> images = getImgData(mHomeIndexBannerBeanList);
            if (images != null && images.size() != 0) {//有banner
                banner.setVisibility(View.VISIBLE);
                banner.setDelayedTime(5000);//设置Banner 切换时间间隔
                if (images.size() == 1) {
                    banner.setCanLoop(false);
                } else {
                    banner.setCanLoop(true);
                }
                banner.setPages(images, () -> new BannerViewHolder(new MZBannerView.BannerPageClickListener() {
                    @Override
                    public void onPageClick(View view, int position) {
                        if (mHomeIndexBannerBeanList != null && mHomeIndexBannerBeanList.size() != 0) {
                            bannerJumpEvent(context, mHomeIndexBannerBeanList, position);
                        }
                    }
                }));
                banner.setCanLoop(true);
                banner.start();
            } else {//没有banner
                banner.setVisibility(View.GONE);
            }
        } catch (Exception e) {
            e.printStackTrace();
            LogUtils.INSTANCE.e("====z", "banner异常");
        }
    }

    /**
     * banner跳转类型
     *
     * @param context
     * @param mHomeIndexBannerBeanList
     * @param position
     */
    private static void bannerJumpEvent(Context context, List<HomeIndexBannerBean> mHomeIndexBannerBeanList, int position) {
        //点击事件
//        Toast.makeText(context, "click me pos = " + position, Toast.LENGTH_SHORT).show();
        HomeIndexBannerBean bannerBean = mHomeIndexBannerBeanList.get(position);
        int jumpType = bannerBean.getJumpType();
        String jumpId = bannerBean.getJumpId();//就是matchId
        String jumpUrl = bannerBean.getJumpUrl();
        int matchId = bannerBean.getMatchId();
        int sportType = bannerBean.getSportId();
        NavigateToDetailUtil.jumpType(context, jumpType, jumpId, jumpUrl, matchId, sportType);
    }


    /**
     * 适配子弹推数据
     *
     * @param context
     * @param mHomeIndexHotRunBeanList
     * @param headerView
     */
    private static void adapterHotRun(Context context, List<HomeIndexHotRunBean> mHomeIndexHotRunBeanList, View headerView) {
        LinearLayout hotRunView = headerView.findViewById(R.id.ll_hot_run);
        ViewFlipper viewFlipper = headerView.findViewById(R.id.viewflipper);
        viewFlipper.removeAllViews();

        if (mHomeIndexHotRunBeanList != null && mHomeIndexHotRunBeanList.size() != 0) { //有子弹推
            hotRunView.setVisibility(View.VISIBLE);
            try {
                viewFlipper.requestLayout();
                for (HomeIndexHotRunBean homeIndexHotRunBean : mHomeIndexHotRunBeanList) {
                    String title = homeIndexHotRunBean.getTitle();

                    View view = View.inflate(context, R.layout.header_view_flipper_run_item, null);
                    TextView tvKillPush = view.findViewById(R.id.tv_kill_push);
                    ImageView ivBullet = view.findViewById(R.id.iv_bullet);

                    tvKillPush.setText(!TextUtils.isEmpty(title) ? title : "----");
                    viewFlipper.addView(view);

                    String id = homeIndexHotRunBean.getId();
                    String jumpId = homeIndexHotRunBean.getJumpId();
                    int jumpType = homeIndexHotRunBean.getJumpType();
                    String jumpUrl = homeIndexHotRunBean.getJumpUrl();
                    String imgUrl = homeIndexHotRunBean.getImgUrl();
                    int matchId = homeIndexHotRunBean.getMatchId();
                    int sportType = homeIndexHotRunBean.getSportId();
                    Glide.with(context).load(imgUrl).error(R.drawable.icon_new_notify_home_hot)
                            .placeholder(R.drawable.icon_new_notify_home_hot)
                            .override(DisplayUtil.dip2px(40), DisplayUtil.dip2px(16))
                            .into(ivBullet);
                    view.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            NavigateToDetailUtil.jumpType(context, jumpType, jumpId, jumpUrl, matchId, sportType);
                        }
                    });
                }

                if (mHomeIndexHotRunBeanList.size() == 1) {//一张图片 不做滚动
                    viewFlipper.setAutoStart(false);
                } else {                                   //多个数据可以滚动
                    viewFlipper.setAutoStart(true);
                }

            } catch (Exception e) {
                e.printStackTrace();
                LogUtils.INSTANCE.e("===z", "添加header子弹推异常");
            }
        } else {                                                                        //没有子弹推数据
            hotRunView.setVisibility(View.GONE);
        }
    }

    /**
     * 获取banner图片
     *
     * @param mHomeIndexBannerBeanList banner数组
     * @return 图片数组
     */
    private static List<String> getImgData(List<HomeIndexBannerBean> mHomeIndexBannerBeanList) {
        List<String> images = new ArrayList<>();
        if (mHomeIndexBannerBeanList != null && mHomeIndexBannerBeanList.size() != 0) {
            for (HomeIndexBannerBean homeIndexBannerBean : mHomeIndexBannerBeanList) {
                String imgUrl = homeIndexBannerBean.getImgUrl();
                if (!TextUtils.isEmpty(imgUrl)) {
                    images.add(imgUrl);
                }
            }
            return images;
        }
        return null;
    }

    public static class BannerViewHolder implements MZViewHolder<String> {

        private RoundImageView mImageView;
        private Context context;
        private MZBannerView.BannerPageClickListener bannerPageClickListener;

        public BannerViewHolder(MZBannerView.BannerPageClickListener bannerPageClickListener) {
            this.bannerPageClickListener = bannerPageClickListener;
        }

        @Override
        public View createView(Context context) {
            this.context = context;
            // 返回页面布局文件
            View view = LayoutInflater.from(context).inflate(R.layout.home_banner_item, null);
            mImageView = view.findViewById(R.id.banner_image);
            return view;
        }

        @Override
        public void onBind(Context context, int position, String path) {
            // 数据绑定
            int width = DisplayUtil.getScreenWidth(context) - (int) DisplayUtil.dip2px(12) * 2;
            // 设置图片圆角角度
            RoundedCorners roundedCorners = new RoundedCorners(DisplayUtil.dip2px(6));
            // 通过RequestOptions扩展功能,override:采样率,因为ImageView就这么大,可以压缩图片,降低内存消耗
            RequestOptions options = RequestOptions.bitmapTransform(roundedCorners)
                    .placeholder(R.drawable.icon_default_hor)
                    .error(R.drawable.icon_default_hor)
                    .override(width, DisplayUtil.dip2px(147));
            Glide.with(context).load(path)
                    .apply(options)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(mImageView);
            mImageView.setOnClickListener(v -> {
                if (bannerPageClickListener != null) {
                    bannerPageClickListener.onPageClick(mImageView, position);
                }
            });
        }
    }


}
