package com.yb.ballworld.information.widget

import android.animation.LayoutTransition
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.TextUtils
import android.text.style.CharacterStyle
import android.text.style.ForegroundColorSpan
import android.util.AttributeSet
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.View.OnClickListener
import android.view.ViewGroup
import android.widget.*
import com.bfw.image.glide.GlideApp
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition
import com.yb.ballworld.information.R
import java.util.*
import java.util.regex.Pattern

//import com.bumptech.glide.request.animation.GlideAnimation;

/**
 * Created by sendtion on 2016/6/24.
 * 显示富文本
 */
class RichTextView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0) : ScrollView(context, attrs, defStyleAttr) {
    //private static final int EDIT_FIRST_PADDING_TOP = 10; // 第一个EditText的paddingTop值

    private var viewTagIndex = 1 // 新生的view都会打一个tag，对每个view来说，这个tag是唯一的。
    private val allLayout: LinearLayout // 这个是所有子view的容器，scrollView内部的唯一一个ViewGroup
    private val inflater: LayoutInflater
    private val lastFocusText: TextView // 最近被聚焦的TextView
    private var mTransitioner: LayoutTransition? = null // 只在图片View添加或remove时，触发transition动画
    private val editNormalPadding = 0 //
    private val disappearingImageIndex = 0
    //private Bitmap bmp;
    private val btnListener: View.OnClickListener//图片点击事件
    private val imagePaths: ArrayList<String>//图片地址集合
    private var keywords: String? = null//关键词高亮

    private var onRtImageClickListener: OnRtImageClickListener? = null

    /** 自定义属性  */
    //插入的图片显示高度
    var rtImageHeight = 0 //为0显示原始高度
    //两张相邻图片间距
    var rtImageBottom = 10
    //文字相关属性，初始提示信息，文字大小和颜色
    var rtTextInitHint: String? = "没有内容"
    //getResources().getDimensionPixelSize(R.dimen.text_size_16)
    var rtTextSize = 16 //相当于16sp
    var rtTextColor = Color.parseColor("#757575")
    var rtTextLineSpace = 8 //相当于8dp

    /**
     * 获得最后一个子view的位置
     */
    val lastIndex: Int
        get() = allLayout.childCount

    init {

        //获取自定义属性
        val ta = context.obtainStyledAttributes(attrs, R.styleable.RichTextView)
        rtImageHeight = ta.getInteger(R.styleable.RichTextView_rt_view_image_height, 0)
        rtImageBottom = ta.getInteger(R.styleable.RichTextView_rt_view_image_bottom, 10)
        rtTextSize = ta.getDimensionPixelSize(R.styleable.RichTextView_rt_view_text_size, 16)
        //rtTextSize = ta.getInteger(R.styleable.RichTextView_rt_view_text_size, 16);
        rtTextLineSpace = ta.getDimensionPixelSize(R.styleable.RichTextView_rt_view_text_line_space, 8)
        rtTextColor = ta.getColor(R.styleable.RichTextView_rt_view_text_color, Color.parseColor("#757575"))
        rtTextInitHint = ta.getString(R.styleable.RichTextView_rt_view_text_init_hint)

        ta.recycle()

        imagePaths = ArrayList()

        inflater = LayoutInflater.from(context)

        // 1. 初始化allLayout
        allLayout = LinearLayout(context)
        allLayout.orientation = LinearLayout.VERTICAL
        //allLayout.setBackgroundColor(Color.WHITE);//去掉背景
        //setupLayoutTransitions();//禁止载入动画
        val layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT)
        allLayout.setPadding(50, 15, 50, 15)//设置间距，防止生成图片时文字太靠边
        addView(allLayout, layoutParams)

        btnListener = OnClickListener { v ->
            if (v is DataImageView) {
                //int currentItem = imagePaths.indexOf(imageView.getAbsolutePath());
                //Toast.makeText(getContext(),"点击图片："+currentItem+"："+imageView.getAbsolutePath(), Toast.LENGTH_SHORT).show();
                // 开放图片点击接口
                if (onRtImageClickListener != null) {
                    onRtImageClickListener!!.onRtImageClick(v, v.absolutePath)
                }

                //点击图片预览
                //                    PhotoPreview.builder()
                //                            .setPhotos(imagePaths)
                //                            .setCurrentItem(currentItem)
                //                            .setShowDeleteButton(false)
                //                            .start(activity);
            }
        }

        val firstEditParam = LinearLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        //editNormalPadding = dip2px(EDIT_PADDING);
        val firstText = createTextView(rtTextInitHint, dip2px(context, EDIT_PADDING.toFloat()))
        allLayout.addView(firstText, firstEditParam)
        lastFocusText = firstText
    }

    private fun dip2px(context: Context, dipValue: Float): Int {
        val m = context.resources.displayMetrics.density
        return (dipValue * m + 0.5f).toInt()
    }

    interface OnRtImageClickListener {
        fun onRtImageClick(view: View, imagePath: String?)
    }

    fun setOnRtImageClickListener(onRtImageClickListener: OnRtImageClickListener) {
        this.onRtImageClickListener = onRtImageClickListener
    }

    /**
     * 清除所有的view
     */
    fun clearAllLayout() {
        allLayout.removeAllViews()
    }

    /**
     * 生成文本输入框
     */
    fun createTextView(hint: String?, paddingTop: Int): TextView {
        val textView = inflater.inflate(R.layout.layout_rich_textview, null) as TextView
        textView.tag = viewTagIndex++
        textView.setPadding(editNormalPadding, paddingTop, editNormalPadding, paddingTop)
        textView.hint = hint
        //textView.setTextSize(getResources().getDimensionPixelSize(R.dimen.text_size_16));
        textView.setTextSize(TypedValue.COMPLEX_UNIT_PX, rtTextSize.toFloat())
        textView.setLineSpacing(rtTextLineSpace.toFloat(), 1.0f)
        textView.setTextColor(rtTextColor)
        return textView
    }

    /**
     * 生成图片View
     */
    private fun createImageLayout(): RelativeLayout {
        val layout = inflater.inflate(R.layout.layout_richtext_image, null) as RelativeLayout
        layout.tag = viewTagIndex++
        val closeView = layout.findViewById<View>(R.id.image_close)
        closeView.visibility = View.GONE
        val imageView = layout.findViewById<DataImageView>(R.id.edit_imageView)
        //imageView.setTag(layout.getTag());
        imageView.setOnClickListener(btnListener)
        return layout
    }

    fun setKeywords(keywords: String) {
        this.keywords = keywords
    }

    /**
     * 在特定位置插入EditText
     *
     * @param index 位置
     * @param editStr EditText显示的文字
     */
    fun addTextViewAtIndex(index: Int, editStr: CharSequence) {
        try {
            val textView = createTextView("", EDIT_PADDING)
            if (!TextUtils.isEmpty(keywords)) {//搜索关键词高亮
                val textStr = highlight(editStr.toString(), keywords)
                textView.text = textStr
            } else {
                textView.text = editStr
            }

            // 请注意此处，EditText添加、或删除不触动Transition动画
            //allLayout.setLayoutTransition(null);
            allLayout.addView(textView, index)
            //allLayout.setLayoutTransition(mTransitioner); // remove之后恢复transition动画
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    /**
     * 在特定位置添加ImageView
     */
    fun addImageViewAtIndex(index: Int, imagePath: String) {
        if (TextUtils.isEmpty(imagePath)) {
            return
        }
        imagePaths.add(imagePath)
        val imageLayout = createImageLayout() ?: return
        val imageView = imageLayout.findViewById<View>(R.id.edit_imageView) as DataImageView
        imageView.absolutePath = imagePath

        //如果是网络图片
        if (imagePath.startsWith("http")) {
            GlideApp.with(context).asBitmap().load(imagePath).dontAnimate()
                    .into(object : SimpleTarget<Bitmap>() {
                        override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                            try {
                                //调整imageView的高度，根据宽度等比获得高度
                                val imageHeight: Int //解决连续加载多张图片导致后续图片都跟第一张高度相同的问题
                                imageHeight = if (rtImageHeight > 0) {
                                    rtImageHeight
                                } else {
                                    val layoutWidth = allLayout.width - allLayout.paddingLeft - allLayout.paddingRight
                                    layoutWidth * resource.height / resource.width
                                    //imageHeight = allLayout.getWidth() * resource.getHeight() / resource.getWidth();
                                }
                                val lp = RelativeLayout.LayoutParams(
                                        FrameLayout.LayoutParams.MATCH_PARENT, imageHeight)//固定图片高度，记得设置裁剪剧中
                                lp.bottomMargin = rtImageBottom
                                imageView.layoutParams = lp

                                if (rtImageHeight > 0) {
                                    imageView.scaleType = ImageView.ScaleType.CENTER_CROP
                                } else {
                                    imageView.scaleType = ImageView.ScaleType.FIT_XY
                                }
                                imageView.setImageBitmap(resource)
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }

                        }
                    })
        } else { //如果是本地图片
            try {
                // 调整imageView的高度，根据宽度等比获得高度
                val bmp = BitmapFactory.decodeFile(imagePath)
                if (bmp != null) {
                    val imageHeight: Int //解决连续加载多张图片导致后续图片都跟第一张高度相同的问题
                    if (rtImageHeight > 0) {
                        imageHeight = rtImageHeight
                    } else {
                        val layoutWidth = allLayout.width - allLayout.paddingLeft - allLayout.paddingRight
                        imageHeight = layoutWidth * bmp.height / bmp.width
                        //imageHeight = allLayout.getWidth() * bmp.getHeight() / bmp.getWidth();
                    }
                    val lp = RelativeLayout.LayoutParams(
                            FrameLayout.LayoutParams.MATCH_PARENT, imageHeight)//固定图片高度，记得设置裁剪剧中
                    lp.bottomMargin = rtImageBottom
                    imageView.layoutParams = lp

                    if (rtImageHeight > 0) {
                        GlideApp.with(context).load(imagePath).centerCrop()
                                .placeholder(R.color.grey_99).error(R.color.grey_99).into(imageView)
                    } else {
                        GlideApp.with(context).load(imagePath)
                                .placeholder(R.color.grey_99).error(R.color.grey_99).into(imageView)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

        }

        // onActivityResult无法触发动画，此处post处理
        allLayout.addView(imageLayout, index)
    }

    /**
     * 根据view的宽度，动态缩放bitmap尺寸
     *
     * @param width view的宽度
     */
    fun getScaledBitmap(filePath: String, width: Int): Bitmap? {
        if (TextUtils.isEmpty(filePath)) {
            return null
        }
        var options: BitmapFactory.Options? = null
        try {
            options = BitmapFactory.Options()
            options.inJustDecodeBounds = true
            BitmapFactory.decodeFile(filePath, options)
            val sampleSize = if (options.outWidth > width)
                options.outWidth / width + 1
            else
                1
            options.inJustDecodeBounds = false
            options.inSampleSize = sampleSize
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return BitmapFactory.decodeFile(filePath, options)
    }

    /**
     * 初始化transition动画
     */
    private fun setupLayoutTransitions() {
        mTransitioner = LayoutTransition()
        //allLayout.setLayoutTransition(mTransitioner);
        mTransitioner!!.addTransitionListener(object : LayoutTransition.TransitionListener {

            override fun startTransition(transition: LayoutTransition,
                                         container: ViewGroup, view: View, transitionType: Int) {

            }

            override fun endTransition(transition: LayoutTransition,
                                       container: ViewGroup, view: View, transitionType: Int) {
                if (!transition.isRunning && transitionType == LayoutTransition.CHANGE_DISAPPEARING) {
                    // transition动画结束，合并EditText
                    // mergeEditText();
                }
            }
        })
        mTransitioner!!.setDuration(300)
    }

    companion object {
        private val EDIT_PADDING = 10 // edittext常规padding是10dp

        /**
         * 关键字高亮显示
         * @param target  需要高亮的关键字
         * @param text         需要显示的文字
         * @return spannable 处理完后的结果，记得不要toString()，否则没有效果
         * SpannableStringBuilder textString = TextUtilTools.highlight(item.getItemName(), KnowledgeActivity.searchKey);
         * vHolder.tv_itemName_search.setText(textString);
         */
        fun highlight(text: String, target: String?): SpannableStringBuilder {
            val spannable = SpannableStringBuilder(text)
            var span: CharacterStyle
            try {
                val p = Pattern.compile(target)
                val m = p.matcher(text)
                while (m.find()) {
                    span = ForegroundColorSpan(Color.parseColor("#EE5C42"))// 需要重复！
                    spannable.setSpan(span, m.start(), m.end(),
                            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            return spannable
        }
    }
}
