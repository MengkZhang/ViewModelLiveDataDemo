package com.yb.ballworld.information.ui.home.bean;

import java.util.List;

/**
 * Desc index返回的tab banner 子弹推等数组
 * Date 2019/10/8
 * author mengk
 */
public class TabResEntity {

    private List<CustomLablesBean> customLables;
    private List<TopBlocksBean> topBlocks;
    private List<BulletBlocksBean> bulletBlocks;
    private List<SpecialBlocksBean> specialBlocks;
    private List<NewsTopBlocksBean> newsTopBlocks;

    public List<CustomLablesBean> getCustomLables() {
        return customLables;
    }

    public void setCustomLables(List<CustomLablesBean> customLables) {
        this.customLables = customLables;
    }

    public List<TopBlocksBean> getTopBlocks() {
        return topBlocks;
    }

    public void setTopBlocks(List<TopBlocksBean> topBlocks) {
        this.topBlocks = topBlocks;
    }

    public List<BulletBlocksBean> getBulletBlocks() {
        return bulletBlocks;
    }

    public void setBulletBlocks(List<BulletBlocksBean> bulletBlocks) {
        this.bulletBlocks = bulletBlocks;
    }

    public List<SpecialBlocksBean> getSpecialBlocks() {
        return specialBlocks;
    }

    public void setSpecialBlocks(List<SpecialBlocksBean> specialBlocks) {
        this.specialBlocks = specialBlocks;
    }

    public List<NewsTopBlocksBean> getNewsTopBlocks() {
        return newsTopBlocks;
    }

    public void setNewsTopBlocks(List<NewsTopBlocksBean> newsTopBlocks) {
        this.newsTopBlocks = newsTopBlocks;
    }

    public static class CustomLablesBean {
        /**
         * id : 1
         * name : 热门
         * jumpUrl :
         */

        private String id;
        private String name;
        private String jumpUrl;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getJumpUrl() {
            return jumpUrl;
        }

        public void setJumpUrl(String jumpUrl) {
            this.jumpUrl = jumpUrl;
        }
    }

    public static class TopBlocksBean {
        /**
         * id : 5
         * title : test
         * imgUrl : test
         * jumpType : 1
         * jumpId : test
         * jumpUrl : test
         */

        private String id;
        private String title;
        private String imgUrl;
        private int jumpType;
        private String jumpId;
        private String jumpUrl;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getImgUrl() {
            return imgUrl;
        }

        public void setImgUrl(String imgUrl) {
            this.imgUrl = imgUrl;
        }

        public int getJumpType() {
            return jumpType;
        }

        public void setJumpType(int jumpType) {
            this.jumpType = jumpType;
        }

        public String getJumpId() {
            return jumpId;
        }

        public void setJumpId(String jumpId) {
            this.jumpId = jumpId;
        }

        public String getJumpUrl() {
            return jumpUrl;
        }

        public void setJumpUrl(String jumpUrl) {
            this.jumpUrl = jumpUrl;
        }
    }

    public static class BulletBlocksBean {
        /**
         * id : 1
         * title : test
         * imgUrl : test
         * jumpType : 1
         * jumpId : test
         * jumpUrl : test
         */

        private String id;
        private String title;
        private String imgUrl;
        private int jumpType;
        private String jumpId;
        private String jumpUrl;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getImgUrl() {
            return imgUrl;
        }

        public void setImgUrl(String imgUrl) {
            this.imgUrl = imgUrl;
        }

        public int getJumpType() {
            return jumpType;
        }

        public void setJumpType(int jumpType) {
            this.jumpType = jumpType;
        }

        public String getJumpId() {
            return jumpId;
        }

        public void setJumpId(String jumpId) {
            this.jumpId = jumpId;
        }

        public String getJumpUrl() {
            return jumpUrl;
        }

        public void setJumpUrl(String jumpUrl) {
            this.jumpUrl = jumpUrl;
        }
    }

    public static class SpecialBlocksBean {
        /**
         * id : 2
         * specialType : 1
         * title : test
         * imgUrl : test
         * jumpType : 1
         * jumpId : test
         * jumpUrl : test
         * matchId : test
         * sportId : 1
         */

        private String id;
        private int specialType;
        private String title;
        private String imgUrl;
        private int jumpType;
        private String jumpId;
        private String jumpUrl;
        private String matchId;
        private String sportId;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public int getSpecialType() {
            return specialType;
        }

        public void setSpecialType(int specialType) {
            this.specialType = specialType;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getImgUrl() {
            return imgUrl;
        }

        public void setImgUrl(String imgUrl) {
            this.imgUrl = imgUrl;
        }

        public int getJumpType() {
            return jumpType;
        }

        public void setJumpType(int jumpType) {
            this.jumpType = jumpType;
        }

        public String getJumpId() {
            return jumpId;
        }

        public void setJumpId(String jumpId) {
            this.jumpId = jumpId;
        }

        public String getJumpUrl() {
            return jumpUrl;
        }

        public void setJumpUrl(String jumpUrl) {
            this.jumpUrl = jumpUrl;
        }

        public String getMatchId() {
            return matchId;
        }

        public void setMatchId(String matchId) {
            this.matchId = matchId;
        }

        public String getSportId() {
            return sportId;
        }

        public void setSportId(String sportId) {
            this.sportId = sportId;
        }
    }

    public static class NewsTopBlocksBean {
        /**
         * id : 2
         * newsId : 1eb9f30fab2f4275ba98e65c8a0af634
         * title : 德甲彩经：拜仁多特双双告捷 药厂主场难驯红牛
         * imgUrl : http://sta.5yqz2.com/static/bfw/20190923/23/50/0/9af9262a79cea2aafdb9e828b81c100b.jpg
         * preview : 【弗赖堡vs多特蒙德】
         【比赛时间】北京时间10月5日21点30分
         【比赛性质】德甲
         【重要伤停】
         弗赖堡：弗兰茨
         多特蒙德：帕科（疑）、舒尔茨（疑）
         【过往战绩】
         双方近10次交锋，多特蒙德8胜2平
         * commentNumber : null
         */

        private String id;
        private String newsId;
        private String title;
        private String imgUrl;
        private String preview;
        private Object commentNumber;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getNewsId() {
            return newsId;
        }

        public void setNewsId(String newsId) {
            this.newsId = newsId;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getImgUrl() {
            return imgUrl;
        }

        public void setImgUrl(String imgUrl) {
            this.imgUrl = imgUrl;
        }

        public String getPreview() {
            return preview;
        }

        public void setPreview(String preview) {
            this.preview = preview;
        }

        public Object getCommentNumber() {
            return commentNumber;
        }

        public void setCommentNumber(Object commentNumber) {
            this.commentNumber = commentNumber;
        }
    }
}
