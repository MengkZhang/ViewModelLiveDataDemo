package com.yb.ballworld.information.ui.home.utils;

import com.yb.ballworld.information.ui.home.bean.IndexLableLetterBean;
import com.yb.ballworld.information.ui.home.bean.OutSideIndexLableLetterBean;
import com.yb.ballworld.information.ui.home.bean.OutSideIndexListBean;
import com.yb.ballworld.information.ui.home.bean.OutSideIndexListLableLetterBean;
import com.yb.ballworld.information.ui.home.bean.OutSideIndexNewBean;
import com.yb.ballworld.information.ui.home.bean.OutSideLableGroupBean;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc
 * Date 2019/11/7
 * author mengk
 */
public class IndexStringUtil {


    /**
     * 组装数据--一级标签页面组装数据
     * @param sourceBean
     * @return
     */
    public static List<OutSideIndexListLableLetterBean> getOutSideListLabelGroupData(OutSideLableGroupBean sourceBean) {
        List<OutSideIndexListLableLetterBean> list = new ArrayList<>();
        addResData("球员标签",list,sourceBean.getPlayers());
        addResData("球队标签",list,sourceBean.getLeaguTeams());
        addResData("赛事标签",list,sourceBean.getLeagues());
        addResData("国家队标签",list,sourceBean.getCupTeams());

        return list;
    }

    /**
     * 组装数据--二级页面按字母排序的数据组装
     * @param sourceBean
     * @return
     */
    public static List<OutSideIndexListLableLetterBean> getOutSideListLableLetterData(OutSideIndexLableLetterBean sourceBean) {
        List<OutSideIndexListLableLetterBean> list = new ArrayList<>();
        addResData("A",list,sourceBean.getA());
        addResData("B",list,sourceBean.getB());
        addResData("C",list,sourceBean.getC());
        addResData("D",list,sourceBean.getD());
        addResData("E",list,sourceBean.getE());
        addResData("F",list,sourceBean.getF());
        addResData("G",list,sourceBean.getG());
        addResData("H",list,sourceBean.getH());
        addResData("I",list,sourceBean.getI());
        addResData("J",list,sourceBean.getJ());
        addResData("K",list,sourceBean.getK());
        addResData("L",list,sourceBean.getL());
        addResData("M",list,sourceBean.getM());
        addResData("N",list,sourceBean.getN());
        addResData("O",list,sourceBean.getO());
        addResData("P",list,sourceBean.getP());
        addResData("Q",list,sourceBean.getQ());
        addResData("R",list,sourceBean.getR());
        addResData("S",list,sourceBean.getS());
        addResData("T",list,sourceBean.getT());
        addResData("U",list,sourceBean.getU());
        addResData("V",list,sourceBean.getV());
        addResData("W",list,sourceBean.getW());
        addResData("X",list,sourceBean.getX());
        addResData("Y",list,sourceBean.getY());
        addResData("Z",list,sourceBean.getZ());

        return list;
    }


    private static void addResData(String title,List<OutSideIndexListLableLetterBean> list,List<IndexLableLetterBean> resultList) {
        if (isNotNull(resultList)) {
            OutSideIndexListLableLetterBean bean = new OutSideIndexListLableLetterBean();
            bean.setTitle(title);
            bean.setList(resultList);
            list.add(bean);
        }
    }


    private static boolean isNotNull(List list) {
        return list != null && list.size() != 0;
    }
}
