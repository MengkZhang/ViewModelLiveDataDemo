package com.yb.ballworld.information.ui.home.adapter;

import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.scwang.smartrefresh.layout.util.DensityUtil;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.bean.InfoShareBean;

import java.util.List;

/**
 * Desc 分享adapter
 * Date 2019/10/19
 * author mengk
 */
public class InfoShareAdapter extends BaseQuickAdapter<InfoShareBean, BaseViewHolder> {
    public InfoShareAdapter(@Nullable List<InfoShareBean> data) {
        super(R.layout.item_share_item_info, data);
    }

    @Override
    protected void convert(BaseViewHolder helper, InfoShareBean item, int pos) {
        if (item == null) return;
        int id = item.getId();
        ImageView ivIcon = helper.getView(R.id.iv_info_share_icon);
        TextView tvType = helper.getView(R.id.tv_info_share_type);
        helper.addOnClickListener(R.id.ll_share_root_view);
        switch (id) {
            case 1:
                ivIcon.setBackgroundResource(R.drawable.icon_info_share_weixin);
                tvType.setText("微信好友");
                break;
            case 2:
                ivIcon.setBackgroundResource(R.drawable.icon_info_share_friend_circle);
                tvType.setText("朋友圈");
                break;
            case 3:
                ivIcon.setBackgroundResource(R.drawable.icon_info_share_qq);
                tvType.setText("QQ好友");
                break;
            case 4:
                ivIcon.setBackgroundResource(R.drawable.icon_info_share_zone);
                tvType.setText("QQ空间");
                break;
            default:
                ivIcon.setBackgroundResource(R.drawable.icon_info_share_weibo);
                tvType.setText("新浪微博");
                break;
        }

        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) helper.getView(R.id.ll_share_root_view).getLayoutParams();
        if (pos == getItemCount() - 1) {
            layoutParams.bottomMargin = DensityUtil.dp2px(20);
        } else {
            layoutParams.bottomMargin = 0;
        }
    }
}
