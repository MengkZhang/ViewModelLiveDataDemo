package com.yb.ballworld.information.ui.personal.presenter;

import com.yb.ballworld.information.ui.personal.bean.CollectionEntity;

import java.util.List;

/**
 * Desc: 收藏列表
 * Author: JS-Kylo
 * Created On: 2019/10/10 13:40
 */
public interface InfoCollectionContract {
    //--------------------------------View层----------------------------
    public interface CollectionView {
        //请求加载中
        void requestLoading();

        //请求成功
        void resultSuccess(List<CollectionEntity.ListBean> beanList);

        void setEnableLoadMore(boolean enableLoadMore);

        //请求失败
        void resultFail(int type);

        //刷新成功
        void resultRefreshSuccess();

        //刷新失败
        void resultRefreshFail(String errorMsg);
    }

    //--------------------------------Presenter层----------------------------
    public interface CollectionPresenter {

        //请求数据方法
        void loadData();

        //刷新
        void refreshData();

        //加载更多
        void loadMore();

        //绑定View
        void attachView(CollectionView view);

        //解绑View
        void detachView();
    }
}
