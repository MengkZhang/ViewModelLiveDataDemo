package com.yb.ballworld.information.help;

import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.yb.ballworld.information.R;

public class TitleBarHelper {
    private ImageView leftBack;
    private TextView title;
    private TextView rightSure;
    private ViewGroup titleRootView;
    private View statusView;
    private ViewGroup titleLayout;

    /**
     * must be call this method first.
     * @param parentView
     */
    public void bindLayout(ViewGroup parentView) {
        int counter = 6;
        titleRootView = parentView.findViewById(R.id.infor_titlebar);
        counter -= titleRootView != null ? 1 : 0;

        leftBack = parentView.findViewById(R.id.infor_titlebar_back);
        counter -= leftBack != null ? 1 : 0;

        title = parentView.findViewById(R.id.infor_titlebar_title);
        counter -= title != null ? 1 : 0;

        rightSure = parentView.findViewById(R.id.infor_titlebar_sure);
        counter -= rightSure != null ? 1 : 0;

        statusView = parentView.findViewById(R.id.infor_statusbar);
        counter -= statusView != null ? 1 : 0;

        titleLayout = parentView.findViewById(R.id.infor_titleLayout);
        counter -= titleLayout != null ? 1 : 0;
        if (counter != 0) {
            throw new RuntimeException("Can't match the layout #layout_infor_titlebar");
        }
    }

    public ImageView getLeftBack() {
        return leftBack;
    }

    public void setLeftBack(int drawableId) {
        leftBack.setImageResource(drawableId);
    }

    public void setOnClickListener(View view, View.OnClickListener clickListener) {
        view.setOnClickListener(clickListener);
    }

    public TextView getTitle() {
        return title;
    }

    public TextView getRightSure() {
        return rightSure;
    }

    public void setTitle(String text) {
        title.setText(text);
    }

    public void setTitle(int textId) {
        title.setText(textId);
    }

    /**
     *
     * @param textSize sp
     * @param textColor colorValue
     */
    public void setTitle(float textSize,int textColor){
        title.setTextSize(textSize);
        title.setTextColor(textColor);
    }

    public void setBackground(View view, int drawableId) {
        view.setBackgroundResource(drawableId);
    }

    public void setBackgroundColor(View view, int colorId) {
        view.setBackgroundColor(colorId);
    }

    public void setVisiableOrGone(View view, boolean visiable) {
        if (visiable && View.VISIBLE != view.getVisibility()) {
            view.setVisibility(View.VISIBLE);
        } else if (!visiable && View.GONE != view.getVisibility()) {
            view.setVisibility(View.GONE);
        }
    }

    public void setVisiableOrIn(View view, boolean visiable) {
        if (visiable && View.VISIBLE != view.getVisibility()) {
            view.setVisibility(View.VISIBLE);
        } else if (!visiable && View.INVISIBLE != view.getVisibility()) {
            view.setVisibility(View.INVISIBLE);
        }
    }
}
