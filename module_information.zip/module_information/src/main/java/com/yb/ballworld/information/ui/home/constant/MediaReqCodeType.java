package com.yb.ballworld.information.ui.home.constant;

import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Desc
 * Date 2019/10/16
 * author mengk
 */
@IntDef({
        MediaReqCodeType.REQUEST_CODE_VIDEO
})

@Retention(RetentionPolicy.SOURCE)

public @interface MediaReqCodeType {
    //随便写了一个
    int REQUEST_CODE_VIDEO = 5091;

}
