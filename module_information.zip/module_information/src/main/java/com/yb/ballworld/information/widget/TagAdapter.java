package com.yb.ballworld.information.widget;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.home.bean.IndexLableDetailBean;
import com.yb.ballworld.information.ui.home.listener.OnMultiClickListener;
import com.yb.ballworld.information.ui.home.utils.GlideLoadImgUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc: FlowTag演示Adapter
 *
 * @author ink
 * created at 2019/10/7 16:58
 */
public class TagAdapter<T> extends BaseAdapter implements FlowTagLayout.OnInitSelectedPosition {

    private final Context mContext;
    private final List<T> mDataList;

    public TagAdapter(Context context) {
        this.mContext = context;
        mDataList = new ArrayList<>();
    }

    @Override
    public int getCount() {
        return mDataList.size();
    }

    @Override
    public Object getItem(int position) {
        return mDataList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        T t = mDataList.get(position);
        View view;

        if (t instanceof IndexLableDetailBean) { //新版本 label标签

            view = LayoutInflater.from(mContext).inflate(R.layout.item_flowtag_layout_new, null);

            TextView textView = view.findViewById(R.id.tv_title_in_side);
            ImageView imageView = view.findViewById(R.id.iv_icon_in_side);

            textView.setText(((IndexLableDetailBean) t).getLable());
            GlideLoadImgUtil.loadTeamLogo(mContext, ((IndexLableDetailBean) t).getPicUrl(), imageView);

            view.findViewById(R.id.rl_tag_new_root_view).setOnClickListener(new OnMultiClickListener() {
                @Override
                public void onMultiClick(View v) {
                    NavigateToDetailUtil.navigateToTagsBankDetail(((Activity) mContext),((IndexLableDetailBean) t).getType(),((IndexLableDetailBean) t).getReferId(),"");
                }
            });

        } else {                                 //兼容老版本的写法

            view = LayoutInflater.from(mContext).inflate(R.layout.item_flowtag_layout, null);
            if (t instanceof String) {
                TextView textView = view.findViewById(R.id.tv_tag);
                textView.setText((String) t);
            }
        }

        return view;
    }

    public void onlyAddAll(List<T> datas) {
        mDataList.addAll(datas);
        notifyDataSetChanged();
    }

    public void clearAndAddAll(List<T> datas) {
        mDataList.clear();
        onlyAddAll(datas);
    }

    @Override
    public boolean isSelectedPosition(int position) {
        if (position % 2 == 0) {
            return true;
        }
        return false;
    }
}
