package com.yb.ballworld.information.ui.profile.adapter;

import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.yb.ballworld.common.widget.MultTextView;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.profile.data.MatchTeamBean;

/**
 * @author Gethin
 * @time 2019/11/9 10:41
 */

public class TeamRankAdapter extends BaseQuickAdapter<MatchTeamBean, BaseViewHolder> {

    public TeamRankAdapter() {
        super(R.layout.rv_item_team_rank);
    }

    @Override
    protected void convert(BaseViewHolder helper, MatchTeamBean item, int pos) {
        TextView tvPos = helper.getView(R.id.tvPos);
        TextView tvName = helper.getView(R.id.tvName);
        MultTextView mtTeamRankInfo = helper.getView(R.id.mtTeamRankInfo);
        tvPos.setText(String.valueOf(pos + 1));
        tvName.setText(item.cnName);
        mtTeamRankInfo.setTexts(String.valueOf(item.total), item.playerNum);
    }
}
