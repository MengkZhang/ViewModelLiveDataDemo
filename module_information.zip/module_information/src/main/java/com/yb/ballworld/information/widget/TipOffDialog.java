package com.yb.ballworld.information.widget;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.yb.ballworld.baselib.R;
import com.yb.ballworld.common.widget.DialogInterface;
import com.yb.ballworld.information.ui.personal.adapter.TipOffAdapter;
import com.yb.ballworld.information.ui.personal.bean.community.ReportAuthorReason;

import java.util.ArrayList;
import java.util.List;


/**
 * Desc 分享的dialog
 * Date 2019/10/19
 * author mengk
 */
public class TipOffDialog extends Dialog {
    private TextView tvCancel;
    private Context context;
    private TipOffAdapter adapter;
    private List<ReportAuthorReason> list = new ArrayList<>();
    private DialogInterface<ReportAuthorReason> dialogInterface;


    public TipOffDialog(@NonNull Context context, List<ReportAuthorReason> list) {
        super(context, R.style.common_dialog);
        this.context = context;
        this.list = list;
    }

    public TipOffDialog(@NonNull Context context) {
        super(context, R.style.common_dialog);
        this.context = context;
    }

    public void setDate(List<ReportAuthorReason> list){
        this.list = list;
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_tip_off_layout);
        Window window = getWindow();
        WindowManager.LayoutParams attributes = window.getAttributes();
        attributes.gravity = Gravity.BOTTOM;
        attributes.width = WindowManager.LayoutParams.MATCH_PARENT;
        window.setAttributes(attributes);
        window.setBackgroundDrawableResource(R.color.transparent);
        window.setWindowAnimations(R.style.dialog_bottom);
        initView();
    }

    private void initView() {
        RecyclerView rvShareItem = findViewById(R.id.rv_share_item_info);
        tvCancel = findViewById(R.id.tv_cancel_info_share);
        LinearLayoutManager layoutManager = new LinearLayoutManager(context);
        rvShareItem.setLayoutManager(layoutManager);
        adapter = new TipOffAdapter(list);
        rvShareItem.setAdapter(adapter);
        initEvent();
    }


    private void initEvent() {
        adapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
                if (dialogInterface != null) {
                    dialogInterface.onItemClick((ReportAuthorReason) adapter.getItem(position), position);
                }
            }
        });
        tvCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (dialogInterface != null) {
                    dialogInterface.onCancel();
                }
                TipOffDialog.this.dismiss();

            }
        });
    }


    public void setDialogInterface(DialogInterface<ReportAuthorReason> dialogInterface) {
        this.dialogInterface = dialogInterface;
    }

    public List<ReportAuthorReason> getList() {
        return list;
    }
}
