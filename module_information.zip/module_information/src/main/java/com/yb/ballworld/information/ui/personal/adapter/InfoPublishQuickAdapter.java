package com.yb.ballworld.information.ui.personal.adapter;

import android.content.Context;
import android.graphics.Color;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseMultiItemQuickAdapter;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.common.sharesdk.ShareSdkParamBean;
import com.yb.ballworld.common.widget.STCircleImageView;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.community.bean.Topic;
import com.yb.ballworld.information.ui.home.bean.JumpBean;
import com.yb.ballworld.information.ui.home.utils.CommentHotUtil;
import com.yb.ballworld.information.ui.home.utils.GlideLoadImgUtil;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.home.view.InfoPublishPopView;
import com.yb.ballworld.information.ui.personal.bean.CollectionEntity;
import com.yb.ballworld.information.ui.personal.bean.InfoUserBean;
import com.yb.ballworld.information.ui.personal.bean.PostEntity;
import com.yb.ballworld.information.ui.personal.bean.PostImage;
import com.yb.ballworld.information.ui.personal.constant.AdapterConstant;
import com.yb.ballworld.information.ui.personal.view.InfoAuditActivity;
import com.yb.ballworld.information.utils.HtmlParseData;
import com.yb.ballworld.information.widget.listener.OnElementClickListener2;
import com.yb.ballworld.information.ui.home.adapter.CellImgAdapter;

import java.util.ArrayList;
import java.util.List;

import cn.jzvd.Jzvd;
import cn.jzvd.JzvdStd;

/**
 * Desc:
 * Author: JS-Kylo
 * Created On: 2019/10/7 15:59
 */
public class InfoPublishQuickAdapter extends BaseMultiItemQuickAdapter<PostEntity.ListBean, BaseViewHolder> {
    private Context context;
    private boolean isDynamic;

    public Context getContext() {
        return context;
    }


    public InfoPublishQuickAdapter(Context context, List<PostEntity.ListBean> data) {
        super(data);
        this.context = context;
        // 非特约图片类型
        addItemType(AdapterConstant.TYPE_IMG_WITHOUT_HEAD, R.layout.item_info_type_img2);
        // 非特约视频
        addItemType(AdapterConstant.TYPE_VIDEO_WITHOUT_HEAD, R.layout.item_info_type_video2);

        // 特约单图
        addItemType(AdapterConstant.TYPE_IMG_WITH_HEAD, R.layout.item_info_type_imgs_just_one2);
        // 特约双图
        addItemType(AdapterConstant.TYPE_IMGS_WITH_HEAD, R.layout.item_info_type_imgs2);
        // 特约多图
        addItemType(AdapterConstant.TYPE_IMGS3_WITH_HEAD, R.layout.item_info_type_imgs2);
        // 特约视频
        addItemType(AdapterConstant.TYPE_VIDEO_WITH_HEAD, R.layout.item_info_type_video_with_head_or_not2);

    }

    public InfoPublishQuickAdapter(Context context, List<PostEntity.ListBean> data, boolean isDynamic) {
        this(context, data);
        this.isDynamic=isDynamic;
    }

    @Override
    protected void convert(BaseViewHolder helper, PostEntity.ListBean item, int pos) {
        LogUtils.INSTANCE.e("===z","itemtype = " + helper.getItemViewType());

        if(item==null) return;
        setLikeVisibility(helper,item,pos);
        setAuditStatus(helper,item,pos);

        switch (helper.getItemViewType()) {
            case AdapterConstant.TYPE_IMG_WITHOUT_HEAD: // item类型 单图 普通没有头像类型
           // case AdapterConstant.TYPE_IMGS_WITHOUT_HEAD: // item类型 双图 普通没有头像类型
            //case AdapterConstant.TYPE_IMGS3_WITHOUT_HEAD: // item类型 三图 图集 普通没有头像类型
                adapterItem(helper, item, pos);
                break;
            case AdapterConstant.TYPE_IMG_WITH_HEAD:  // item类型 单图有头像类型
                adapterItemMultiImgWithHead(0, helper, item, pos);
                break;

            case AdapterConstant.TYPE_IMGS_WITH_HEAD:               //item类型 双图
                adapterItemMultiImgWithHead(1, helper, item, pos);
                break;

            case AdapterConstant.TYPE_IMGS3_WITH_HEAD:              //item类型 三图
                adapterItemMultiImgWithHead(2, helper, item, pos);
                break;

            case AdapterConstant.TYPE_VIDEO_WITH_HEAD:               //item类型 视频有头像
                adapterItemVideo(0, helper, item, pos);
                break;

            case AdapterConstant.TYPE_VIDEO_WITHOUT_HEAD:            //item类型 视频没有头像
                adapterVideoNoHead(helper, item, pos);
                break;

            default:
                adapterItem(helper, item, pos);
                break;
        }

    }

    /**
     * 设置点赞是否隐藏
     * @param helper
     * @param item
     * @param pos
     */
    private void setLikeVisibility(BaseViewHolder helper, PostEntity.ListBean item, int pos){
        View view =helper.getView(R.id.rl_praise_root);
        if(view!=null){
            if(isSelf(item.getUserId())){
                view.setVisibility(View.INVISIBLE);
            }else{
                view.setVisibility(View.VISIBLE);
            }
        }


    }

    /**
     * 设置审核状态
     * @param helper
     * @param item
     * @param pos
     */
    private void setAuditStatus(BaseViewHolder helper, PostEntity.ListBean item, int pos){
        // 审核状态
        TextView tvAudit=helper.getView(R.id.tv_audit);
        // 自由自己的请况下才能看到审核状态
        if(isSelf(item.getUserId())){
            tvAudit.setVisibility(View.VISIBLE);
            String auditStatus=item.getReviewStatus();
            if("0".equals(auditStatus)){
                // 审核中
                tvAudit.setText("审核中");
                tvAudit.setTextColor(tvAudit.getContext().getResources().getColor(R.color.color_ff6b00));
                int resId=item.isEditor()?R.mipmap.bg_audit_doing_right:R.mipmap.bg_audit_doing_left;
                tvAudit.setBackgroundResource(resId);
            }else if("1".equals(auditStatus)){
                // 审核失败
                tvAudit.setText("审核失败");
                tvAudit.setTextColor(Color.parseColor("#6c6c6c"));
                int resId=item.isEditor()?R.mipmap.bg_audit_fail_right:R.mipmap.bg_audit_fail_left;
                tvAudit.setBackgroundResource(resId);
            }else if("2".equals(auditStatus)){
                // 审核通过
                tvAudit.setText("审核通过");
                tvAudit.setTextColor(Color.parseColor("#33b30b"));
                int resId=item.isEditor()?R.mipmap.bg_audit_done_right:R.mipmap.bg_audit_done_left;
                tvAudit.setBackgroundResource(resId);
            }else {
                tvAudit.setVisibility(View.GONE);
            }

            if("0".equals(auditStatus)){
                tvAudit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(LoginOrdinaryUtils.INSTANCE.isLogin()){
                            InfoAuditActivity.start(context,""+LoginOrdinaryUtils.INSTANCE.getUserId());
                        }

                    }
                });
            }else{
                tvAudit.setOnClickListener(null);
            }

        }else{
            tvAudit.setVisibility(View.GONE);
        }
    }

    /**
     * 最普通的item
     *
     * @param helper
     * @param item
     * @param pos
     */
    private void adapterItem(BaseViewHolder helper, PostEntity.ListBean item, int pos) {
        int mediaType = item.getMediaType();
        if (mediaType == 1) {//显示视频图标
            helper.getView(R.id.iv_info_player_icon).setVisibility(View.VISIBLE);
        } else {//不显示视频播放
            helper.getView(R.id.iv_info_player_icon).setVisibility(View.GONE);
        }
        TextView tvTitle = helper.getView(R.id.tv_title_top);
        TextView tvTopTag = helper.getView(R.id.tv_top_tag);
        TextView tvComment = helper.getView(R.id.tv_comment_count_top);
        ImageView ivFace = helper.getView(R.id.iv_img_top);

        //隐藏置顶
        tvTopTag.setVisibility(View.GONE);
        String imgUrl = item.getImgUrl();
        int commentCount = item.getCommentCount();
        String title = item.getTitle();
        tvTitle.setText(isNotNull(title));
        tvComment.setText(commentCount + "");

        //
        if(TextUtils.isEmpty(imgUrl)){
            List<PostEntity.ListBean.NewsImgsBean> list=item.getNewsImgs();
            if(list!=null && !list.isEmpty() && list.get(0)!=null){
                PostEntity.ListBean.NewsImgsBean bean=list.get(0);
                if(!TextUtils.isEmpty(bean.getImgUrl())){
                    imgUrl=bean.getImgUrl();
                }
            }
        }
        Glide.with(context).load(imgUrl).error(R.drawable.icon_default_info_ball).placeholder(R.drawable.icon_default_info_ball).into(ivFace);
        //点击事件调详情
        helper.getView(R.id.rl_root_view_img).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = item.getId();
                NavigateToDetailUtil.navigateToDetail(mContext, id, item.getMediaType() == 1);
            }
        });
        //模拟点赞
        //helper.addOnClickListener(R.id.iv_comment_icon);
        //设置评论
        CommentHotUtil.setHotComment(mContext, helper.getView(R.id.iv_comment_icon), helper.getView(R.id.tv_comment_count_top), item.getCommentCount());
    }

    /**
     * 有头像类型 单图 双图 三图类型
     *
     * @param type   0 单图 1 双图 2 三图
     * @param helper BaseViewHolder
     * @param item   HomeInfoListBean
     */
    private void adapterItemMultiImgWithHead(int type, BaseViewHolder helper, PostEntity.ListBean item, int position) {
        //首页热门列表这里是Id 不是newsId 不知后台在搞啥
        String id = item.getId();
        if (TextUtils.isEmpty(id)) return;

        //设置评论
        CommentHotUtil.setHotComment(mContext, helper.getView(R.id.iv_comment_icon), helper.getView(R.id.tv_comment_count), item.getCommentCount());

        //点赞按钮
        NavigateToDetailUtil.showShareToast(helper.getView(R.id.rl_share_root_view),mContext,
                new ShareSdkParamBean(item.getTitle(),item.getWebShareUrl(),item.getPreview(),item.getImgUrl(),item.getWebShareUrl()));

        //用户信息
        ImageView imageViewHead = helper.getView(R.id.iv_user_head_info);
        TextView tvNameInfo = helper.getView(R.id.tv_name_info);
        TextView tvDescInfo = helper.getView(R.id.tv_desc_info);
        PostEntity.ListBean.UserBean user = item.getUser();
        tvDescInfo.setText(item.getCreatedDate());
        if (user != null) {
            String headImgUrl = user.getHeadImgUrl();
            loadImg(mContext, headImgUrl, imageViewHead);
            String nickname = user.getNickname();
            String personalDesc = user.getPersonalDesc();
            tvNameInfo.setText(isNotNull(nickname));
        } else {
            loadImg(mContext, "", imageViewHead);
            tvNameInfo.setText("");
            tvDescInfo.setText("");
        }

        //点击头像 不需要点击
        helper.getView(R.id.iv_user_head_info).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        //点击事件
        View rootView = helper.getView(R.id.ll_root_view_multi);
        rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavigateToDetailUtil.navigateToDetail(mContext, id, item.getMediaType() == 1);
            }
        });

        //点赞的状态和数量
        TextView tvPraise = helper.getView(R.id.tv_praise_info);
        int praiseCount = item.getLikeCount();
        String like = praiseCount + "";
        tvPraise.setText(like);
        //点赞状态
        boolean hasFocus = item.isIsLike();
        helper.addOnClickListener(R.id.iv_praise_icon);
        helper.getView(R.id.iv_praise_icon).setSelected(hasFocus);

        //标题
        TextView tvTitle = helper.getView(R.id.tv_title_top);
        String title = item.getTitle();
        tvTitle.setText(isNotNull(title));

        //评论数
        TextView tvComment = helper.getView(R.id.tv_comment_count);
        int commentCount = item.getCommentCount();
        String com = commentCount + "";
        tvComment.setText(com);

        //图片列表
        RecyclerView recyclerViewImg = helper.getView(R.id.rv_imgs_list);
        GridLayoutManager layoutManager;
        switch (type) {
            case 1:
                layoutManager = new GridLayoutManager(mContext, 2);
                break;
            case 2:
                layoutManager = new GridLayoutManager(mContext, 3);
                break;
            default:
                layoutManager = new GridLayoutManager(mContext, 1);
                break;
        }
        recyclerViewImg.setLayoutManager(layoutManager);


        List<JumpBean> list = new ArrayList<>();

        if (type == 0) {//单张
            String imgUrl = item.getImgUrl();
            JumpBean postImage = new JumpBean();
            postImage.setImgUrl(isNotNull(imgUrl));
            postImage.setNewsId(id);
            list.add(postImage);
            CellImgAdapter cellImgAdapter = new CellImgAdapter(list);
            recyclerViewImg.setAdapter(cellImgAdapter);
            cellImgAdapter.setOnItemChildClickListener(new OnImageItemClickListener(item));
        } else {        //多张
            List<PostEntity.ListBean.NewsImgsBean> newsImgs = item.getNewsImgs();
            if (newsImgs != null && newsImgs.size() != 0) {
                for (PostEntity.ListBean.NewsImgsBean homeIndexImgBean : newsImgs) {
                    String imgUrl = homeIndexImgBean.getImgUrl();
                    JumpBean postImage = new JumpBean();
                    postImage.setImgUrl(isNotNull(imgUrl));
                    postImage.setNewsId(id);
                    list.add(postImage);
                }

                CellImgAdapter cellImgAdapter = new CellImgAdapter(list);
                recyclerViewImg.setAdapter(cellImgAdapter);
                cellImgAdapter.setOnItemChildClickListener(new OnImageItemClickListener(item));
            } else {//图片数组为空
           /* List<String> testImgList = ListImgUtil.getTestImgList(mContext);
            CellImgAdapter cellImgAdapter = new CellImgAdapter(testImgList);
            recyclerViewImg.setAdapter(cellImgAdapter);*/
            }
        }


        //跳转到H5
    }

    /**
     * 没有头像类型 双图 三图类型
     *
     * @param type   1 双图 2 三图
     * @param helper BaseViewHolder
     * @param item   HomeInfoListBean
     *//*
    private void adapterItemMultiImgWithoutHead(int type, BaseViewHolder helper, PostEntity.ListBean item, int position) {
        //首页热门列表这里是Id 不是newsId 不知后台在搞啥
        String id = item.getId();
        if (TextUtils.isEmpty(id)) return;

        //设置评论
        CommentHotUtil.setHotComment(mContext, helper.getView(R.id.iv_comment_icon), helper.getView(R.id.tv_comment_count), item.getCommentCount());

        //点赞按钮
        NavigateToDetailUtil.showShareToast(helper.getView(R.id.rl_share_root_view),mContext,
                new ShareSdkParamBean(item.getTitle(),item.getWebShareUrl(),item.getPreview(),item.getImgUrl(),item.getWebShareUrl()));

        //用户信息
        helper.getView(R.id.rl_head_info_root_view).setVisibility(View.GONE);
        ImageView imageViewHead = helper.getView(R.id.iv_user_head_info);
        TextView tvNameInfo = helper.getView(R.id.tv_name_info);
        TextView tvDescInfo = helper.getView(R.id.tv_desc_info);
        PostEntity.ListBean.UserBean user = item.getUser();
        if (user != null) {
            String headImgUrl = user.getHeadImgUrl();
            loadImg(mContext, headImgUrl, imageViewHead);
            String nickname = user.getNickname();
            String personalDesc = user.getPersonalDesc();
            tvNameInfo.setText(isNotNull(nickname));
            tvDescInfo.setText(isNotNull(personalDesc));
        } else {
            loadImg(mContext, "", imageViewHead);
            tvNameInfo.setText("");
            tvDescInfo.setText("");
        }

        //点击头像 不需要点击
        helper.getView(R.id.iv_user_head_info).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        //点击事件
        View rootView = helper.getView(R.id.ll_root_view_multi);
        rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavigateToDetailUtil.navigateToDetail(mContext, id, item.getMediaType() == 1);
            }
        });

        //点赞的状态和数量
        TextView tvPraise = helper.getView(R.id.tv_praise_info);
        int praiseCount = item.getLikeCount();
        String like = praiseCount + "";
        tvPraise.setText(like);
        //点赞状态
        boolean hasFocus = item.isIsLike();
        helper.addOnClickListener(R.id.iv_praise_icon);
        helper.getView(R.id.iv_praise_icon).setSelected(hasFocus);

        //标题
        TextView tvTitle = helper.getView(R.id.tv_title_top);
        String title = item.getTitle();
        tvTitle.setText(isNotNull(title));

        //评论数
        TextView tvComment = helper.getView(R.id.tv_comment_count);
        int commentCount = item.getCommentCount();
        String com = commentCount + "";
        tvComment.setText(com);

        //图片列表
        RecyclerView recyclerViewImg = helper.getView(R.id.rv_imgs_list);
        GridLayoutManager layoutManager;
        switch (type) {
            case 1:
                layoutManager = new GridLayoutManager(mContext, 2);
                break;
            case 2:
                layoutManager = new GridLayoutManager(mContext, 3);
                break;
            default:
                layoutManager = new GridLayoutManager(mContext, 1);
                break;
        }
        recyclerViewImg.setLayoutManager(layoutManager);


        List<PostImage> list = new ArrayList<>();
        if (type == 0) {//单张
            String imgUrl = item.getImgUrl();
            PostImage postImage = new PostImage();
            postImage.setImgUrl(isNotNull(imgUrl));
            postImage.setNewsId(id);
            list.add(postImage);
            CellImgAdapter cellImgAdapter = new CellImgAdapter(list);
            recyclerViewImg.setAdapter(cellImgAdapter);
        } else {        //多张
            List<PostEntity.ListBean.NewsImgsBean> newsImgs = item.getNewsImgs();
            if (newsImgs != null && newsImgs.size() != 0) {
                for (PostEntity.ListBean.NewsImgsBean homeIndexImgBean : newsImgs) {
                    String imgUrl = homeIndexImgBean.getImgUrl();
                    PostImage postImage = new PostImage();
                    postImage.setImgUrl(isNotNull(imgUrl));
                    postImage.setNewsId(id);
                    list.add(postImage);
                }

                CellImgAdapter cellImgAdapter = new CellImgAdapter(list);
                recyclerViewImg.setAdapter(cellImgAdapter);
            } else {//图片数组为空
           *//* List<String> testImgList = ListImgUtil.getTestImgList(mContext);
            CellImgAdapter cellImgAdapter = new CellImgAdapter(testImgList);
            recyclerViewImg.setAdapter(cellImgAdapter);*//*
            }
        }
        //跳转到H5
    }*/

    /**
     * 适配视频数据
     *
     * @param type
     * @param helper
     * @param item
     */
    private void adapterItemVideo(int type, BaseViewHolder helper, PostEntity.ListBean item, int position) {
        String id = item.getId();
        if (TextUtils.isEmpty(id)) return;

        //设置评论
        CommentHotUtil.setHotComment(mContext, helper.getView(R.id.iv_comment_icon), helper.getView(R.id.tv_comment_count), item.getCommentCount());

        //点赞按钮
        NavigateToDetailUtil.showShareToast(helper.getView(R.id.rl_share_root_view),mContext,
                new ShareSdkParamBean(item.getTitle(),item.getWebShareUrl(),item.getPreview(),item.getImgUrl(),item.getWebShareUrl()));

        //点击头像
        helper.getView(R.id.iv_user_head_info).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //NavigateToDetailUtil.navigateToPerson(mContext, UidUtil.getUid());
            }
        });

        View rootView = helper.getView(R.id.ll_root_view_av);
        rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavigateToDetailUtil.navigateToDetail(mContext, id, item.getMediaType() == 1);
            }
        });

        //头像
        View headRootView = helper.getView(R.id.rl_head_info_root_view);
        if (type == 0) {//有头像
            headRootView.setVisibility(View.VISIBLE);
        } else {        //没有头像
            headRootView.setVisibility(View.GONE);
        }

        //用户信息
        STCircleImageView ivHead = helper.getView(R.id.iv_user_head_info);
        TextView tvName = helper.getView(R.id.tv_name_info);
        TextView tvDesc = helper.getView(R.id.tv_desc_info);
        TextView tvPraise = helper.getView(R.id.tv_praise_info);
        PostEntity.ListBean.UserBean user = item.getUser();
        if (user != null) {
            String nickname = user.getNickname();
            String personalDesc = user.getPersonalDesc();
            String headImgUrl = user.getHeadImgUrl();
            int followerCount = user.getFollowerCount();
            Glide.with(mContext).load(headImgUrl).error(R.drawable.user_default_icon2).placeholder(R.drawable.user_default_icon2).into(ivHead);
            tvName.setText(nickname);
            tvPraise.setText(followerCount + "");
            tvDesc.setText(item.getCreatedDate());
        } else {
            Glide.with(mContext).load(R.drawable.user_default_icon2).error(R.drawable.user_default_icon2).placeholder(R.drawable.user_default_icon2).into(ivHead);
            tvName.setText("");
            tvPraise.setText("");
            tvDesc.setText("");
        }

        //标题
        TextView tvTitle = helper.getView(R.id.tv_title_top);
        String title = item.getTitle();
        tvTitle.setText(isNotNull(title));

        //评论
        TextView tvComment = helper.getView(R.id.tv_comment_count);
        int commentCount = item.getCommentCount();
        String com = commentCount + "";
        tvComment.setText(com);

        //播放器

        //播放器
        String imgUrl = item.getImgUrl();
        JzvdStd player = helper.getView(R.id.js_player);
        player.setUp(
                item.getPlayUrl(),
                "", Jzvd.SCREEN_NORMAL);
        Glide.with(mContext).load(isNotNull(imgUrl)).into(player.thumbImageView);

        //点赞状态和数量

        //点赞的状态和数量
        int praiseCount = item.getLikeCount();
        String like = praiseCount + "";
        tvPraise.setText(like);
        //点赞状态
        boolean hasFocus = item.isIsLike();
        helper.addOnClickListener(R.id.iv_praise_icon);
        helper.getView(R.id.iv_praise_icon).setSelected(hasFocus);
    }

    /**
     * 适配视频 无头像
     *
     * @param helper
     * @param item
     * @param position
     */
    private void adapterVideoNoHead(BaseViewHolder helper, PostEntity.ListBean item, int position) {
        String id = item.getId();
        if (TextUtils.isEmpty(id)) return;

        //设置评论
        CommentHotUtil.setHotComment(mContext, helper.getView(R.id.iv_comment_icon), helper.getView(R.id.tv_comment_count_video), item.getCommentCount());

        //点赞按钮
        NavigateToDetailUtil.showShareToast(helper.getView(R.id.rl_share_root_view),mContext,
                new ShareSdkParamBean(item.getTitle(),item.getWebShareUrl(),item.getPreview(),item.getImgUrl(),item.getWebShareUrl()));

        View rootView = helper.getView(R.id.ll_root_view_video);
        rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavigateToDetailUtil.navigateToDetail(mContext, id, true);
            }
        });

        //标题
        TextView tvTitle = helper.getView(R.id.tv_title);
        String title = item.getTitle();

        tvTitle.setText(!TextUtils.isEmpty(title) ? title : "title");

        //封面
        ImageView ivFaceImg = helper.getView(R.id.iv_img2);
        String imgUrl = item.getImgUrl();
        GlideLoadImgUtil.loadImg(mContext, imgUrl, ivFaceImg);


        //点赞count
        TextView tvPraise = helper.getView(R.id.tv_praise_video);
//        int praiseCount = PreferencesHelper.INSTANCE.getPref(id,0);
        int likeCount = item.getLikeCount();
        String like = likeCount + "";
        tvPraise.setText(like);

        //播放器
        JzvdStd player = helper.getView(R.id.js_player);

        ivFaceImg.setVisibility(View.VISIBLE);

        //点击播放按钮
        ImageView ivClickPlay = helper.getView(R.id.iv_player_video);

        ivClickPlay.setVisibility(View.GONE);

        player.setUp(
                item.getPlayUrl(),
                "", Jzvd.SCREEN_NORMAL);
//        Glide.with(mContext).load(imgUrl).into(player.thumbImageView);
        GlideLoadImgUtil.loadPlayerFaceImg(mContext, imgUrl, player.thumbImageView);

        //点赞
        helper.addOnClickListener(R.id.iv_praise_icon);
        boolean hasFocus = false;// = item.isHasFocus();
        helper.getView(R.id.iv_praise_icon).setSelected(hasFocus);
    }


    private String isNotNull(String string) {
        return !TextUtils.isEmpty(string) ? string : "";
    }

    public void loadImg(Context context, String imgUrl, ImageView imageView) {
        Glide.with(context).load(imgUrl).error(R.drawable.user_default_icon2).placeholder(R.drawable.user_default_icon2).into(imageView);
    }


    private boolean isSelf(String userId){
        if(isDynamic) {
            return false;
        }
        if(TextUtils.isEmpty(userId)){
            return false;
        }
        long uid= LoginOrdinaryUtils.INSTANCE.getUid();
        if(uid==0){
            return false;
        }
        return String.valueOf(uid).equals(userId);
    }



    private OnElementClickListener2 mOnElementClickListener;
    /**
     * 主要用在点击评论图片的事件转发
     *
     */

    private class OnImageItemClickListener  implements OnItemChildClickListener{
        private PostEntity.ListBean topic;

        private OnImageItemClickListener(PostEntity.ListBean topic) {
            this.topic = topic;
        }

        @Override
        public void onItemChildClick(BaseQuickAdapter adapter, View view, int position) {
            if(view.getId()==R.id.iv_img_multi){
                if (mOnElementClickListener != null) {
                    List<JumpBean> jumpBeans=adapter.getData();
                    List<String> tempList=new ArrayList<>();
                    for(JumpBean bean:jumpBeans){
                        tempList.add(bean.getImgUrl());
                    }
                    mOnElementClickListener.onElementClick(topic,((JumpBean)adapter.getItem(position)).getImgUrl(), HtmlParseData.TYPE_IMG, position, tempList);
                }
            }
        }
    }



    public void setmOnElementClickListener(OnElementClickListener2<PostEntity.ListBean> mOnElementClickListener) {
        this.mOnElementClickListener = mOnElementClickListener;
    }
}
