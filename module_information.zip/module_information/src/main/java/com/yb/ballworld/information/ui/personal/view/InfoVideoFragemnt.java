package com.yb.ballworld.information.ui.personal.view;

import android.view.View;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.ui.personal.adapter.InfoVideoAdapter;
import com.yb.ballworld.information.ui.personal.presenter.InfoVideoPresenter;
import com.yb.ballworld.information.ui.profile.view.fragments.RvBaseFragment;

public class InfoVideoFragemnt extends RvBaseFragment<InfoVideoPresenter> {
    public static InfoVideoFragemnt newInstance() {
        InfoVideoFragemnt fragment=new InfoVideoFragemnt();
        return fragment;
    }
    @Override
    protected void loadData() {

    }

    @Override
    protected BaseQuickAdapter getAdapter() {
        return new InfoVideoAdapter(R.layout.item_info_video);
    }

    @Override
    public void initPresenter() {

    }

    @Override
    protected void bindEvent() {

    }

    @Override
    protected void processClick(View view) {

    }
}
