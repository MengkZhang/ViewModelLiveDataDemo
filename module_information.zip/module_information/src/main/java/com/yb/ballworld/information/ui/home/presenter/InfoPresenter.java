package com.yb.ballworld.information.ui.home.presenter;

import android.text.TextUtils;
import android.util.Log;

import com.yb.ballworld.baselib.utils.LogUtils;
import com.yb.ballworld.baselib.utils.PreferencesHelper;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.callback.OnUICallback;
import com.yb.ballworld.information.ui.home.bean.HomeInfoListBean;
import com.yb.ballworld.information.ui.home.bean.InfoListEntity;
import com.yb.ballworld.information.ui.home.constant.FailStateConstant;
import com.yb.ballworld.information.ui.home.constant.LoadMoreType;
import com.yb.ballworld.information.ui.home.service.InfoHttpApi;

import java.util.ArrayList;
import java.util.List;

/**
 * Desc 首页热门和视频的presenter
 * Date 2019/10/7
 * author mengk
 */
public class InfoPresenter implements InfoContract.IInfoPresenter {

    private InfoHttpApi httpApi;
    private InfoContract.IInfoView mView;
    //当前页数
    private int page = 1;
    //返回的总页数
    private int totalPage;
    //资讯类型 0 请求新闻 1 请求视频
    private String mediaType;
    private boolean isRefresh;
    private boolean isLoadMore;
    private String categoryId;
    private String sportType;

    /**
     * 构造方法
     *
     * @param type 资讯类型 0 请求新闻 1 请求视频
     */
    public InfoPresenter(String type, String categoryId, String mediaType, String sportType) {
        this.mediaType = type;
        this.categoryId = categoryId;
        this.mediaType = mediaType;
        this.sportType = sportType;
        httpApi = new InfoHttpApi();
    }

    /**
     * 刷新
     */
    @Override
    public void refreshData() {
        isRefresh = true;
        page = 1;
        loadData(page);
    }

    /**
     * 加载更多
     */
    @Override
    public void loadMoreData() {
        isLoadMore = true;
        page++;
        if (page <= totalPage) { //可以加载更多数据
            loadData(page);
        } else {                 //没有更多数据
            mView.resultLoadMoreSuccess(LoadMoreType.TYPE_ALL_DATA);
        }
    }

    /**
     * 加载数据
     *
     * @param page 当前页数
     */
    @Override
    public void loadData(int page) {
        List<InfoListEntity.ListBean> mHomeInfoLastList = new ArrayList<>();
        //只有正常加载才有loading 加载更多和刷新是没有的
        if (!isRefresh && !isLoadMore) {
            mView.requestLoading();
        }
        //每页的数据条数
        int pageSize = 15;
        httpApi.getNewsListData(categoryId, sportType, page, pageSize, mediaType, new LifecycleCallback<InfoListEntity>(mView.getFragment()) {
            @Override
            public void onSuccess(InfoListEntity data) {
                LogUtils.INSTANCE.e("===z", "InfoListEntity data = " + data);
                if (data != null) {  //data不为空
                    totalPage = data.getTotalPage();
                    List<InfoListEntity.ListBean> list = data.getList();
                    if (list != null && list.size() != 0) {

                        //添加数据的操作
                        if (isRefresh) {
                            mHomeInfoLastList.clear();
                        }
                        mHomeInfoLastList.addAll(list);
                        //还原刷新的状态
                        if (isRefresh) {
                            isRefresh = false;
                            mView.resultRefreshSuccess();
                        }
                        //还原加载更多的状态
                        if (isLoadMore) {
                            isLoadMore = false;
                            mView.resultLoadMoreSuccess(LoadMoreType.TYPE_SUCCESS);
                        }
                        LogUtils.INSTANCE.e("===z", "list mHomeInfoLastList = " + mHomeInfoLastList.size());
                        mView.resultSuccess(mHomeInfoLastList,page);

                    } else {                                    //数据为空

                        judgeStatusEmpty();
                    }
                } else {                                        //data为空

                    judgeStatusEmpty();
                }

            }

            @Override
            public void onFailed(int errCode, String errMsg) {
                LogUtils.INSTANCE.e("===z", "getNewsList fail errorcode = " + errCode + " msg = " + errMsg);
                if (isRefresh) {         //刷新失败
                    isRefresh = false;
                    mView.resultRefreshFail("刷新失败");

                } else if (isLoadMore) { //加载更多失败
                    isLoadMore = false;
                    mView.resultLoadMoreFail("加载更多失败");

                } else {                 //正常加载数据失败

                    mView.resultFail(FailStateConstant.TYPE_ERROR);
                }
            }
        });
    }

    /**
     * 判断刷新 加载更多 和 正常加载
     */
    private void judgeStatusEmpty() {
        if (isRefresh) {
            isRefresh = false;
            mView.resultRefreshFail("刷新数据为空");
        } else if (isLoadMore) {
            isLoadMore = false;
            mView.resultRefreshFail("加载更多数据为空");
        } else {
            dataEmpty();
        }
    }

    /**
     * 数据为空
     */
    private void dataEmpty() {
        mView.resultFail(FailStateConstant.TYPE_EMPTY);
    }

    /**
     * 绑定View
     *
     * @param view
     */
    @Override
    public void attachView(InfoContract.IInfoView view) {
        this.mView = view;
    }

    /**
     * 解绑View
     */
    @Override
    public void detachView() {
        this.mView = null;
    }
}
