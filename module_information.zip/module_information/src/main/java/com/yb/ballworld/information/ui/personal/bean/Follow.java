package com.yb.ballworld.information.ui.personal.bean;

public class Follow {
    private int commentCount;
    private int fansCount;
    private int favoriteCount;
    private int footprintCount;
    private String headImgUrl;
    private int id;
    private boolean isAnchor;
    private boolean isAttention;
    private boolean isAuthor;
    private String nickname;
    private String personalDesc;
    private int postCount;
    private int sex;
    private int userId;

    public void setCommentCount(int commentCount) {
        this.commentCount = commentCount;
    }

    public int getCommentCount() {
        return commentCount;
    }

    public void setFansCount(int fansCount) {
        this.fansCount = fansCount;
    }

    public int getFansCount() {
        return fansCount;
    }

    public void setFavoriteCount(int favoriteCount) {
        this.favoriteCount = favoriteCount;
    }

    public int getFavoriteCount() {
        return favoriteCount;
    }

    public void setFootprintCount(int footprintCount) {
        this.footprintCount = footprintCount;
    }

    public int getFootprintCount() {
        return footprintCount;
    }

    public void setHeadImgUrl(String headImgUrl) {
        this.headImgUrl = headImgUrl;
    }

    public String getHeadImgUrl() {
        return defaultValue(headImgUrl);
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setIsAnchor(boolean isAnchor) {
        this.isAnchor = isAnchor;
    }

    public boolean getIsAnchor() {
        return isAnchor;
    }

    public void setIsAttention(boolean isAttention) {
        this.isAttention = isAttention;
    }

    public boolean getIsAttention() {
        return isAttention;
    }

    public void setIsAuthor(boolean isAuthor) {
        this.isAuthor = isAuthor;
    }

    public boolean getIsAuthor() {
        return isAuthor;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getNickname() {
        return defaultValue(nickname);
    }

    public void setPersonalDesc(String personalDesc) {
        this.personalDesc = personalDesc;
    }

    public String getPersonalDesc() {
        return defaultValue(personalDesc);
    }

    public void setPostCount(int postCount) {
        this.postCount = postCount;
    }

    public int getPostCount() {
        return postCount;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public int getSex() {
        return sex;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getUserId() {
        return userId;
    }


    private String defaultValue(String d) {
        return d == null ? "" : d;
    }

}
