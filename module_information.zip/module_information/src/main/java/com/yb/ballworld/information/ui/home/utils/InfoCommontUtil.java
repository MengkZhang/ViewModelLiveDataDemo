package com.yb.ballworld.information.ui.home.utils;

/**
 * Desc 资讯公共工具类
 * Date 2019/11/18
 * author mengk
 */
public class InfoCommontUtil {


}
