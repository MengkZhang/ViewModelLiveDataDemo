package com.yb.ballworld.information.ui.personal.view;

import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.jeremyliao.liveeventbus.LiveEventBus;
import com.scwang.smartrefresh.layout.util.DensityUtil;
import com.yb.ballworld.base.LiveEventBusKey;
import com.yb.ballworld.baselib.data.UserInfo;
import com.yb.ballworld.baselib.utils.LoginOrdinaryUtils;
import com.yb.ballworld.baselib.widget.tab.XTabLayout;
import com.yb.ballworld.common.base.BaseFragmentAdapter;
import com.yb.ballworld.common.base.BaseFragmentStateAdapter;
import com.yb.ballworld.common.base.mvp.BaseMvpFragment;
import com.yb.ballworld.common.baseapp.AppContext;
import com.yb.ballworld.common.callback.LifecycleCallback;
import com.yb.ballworld.common.utils.DisplayUtil;
import com.yb.ballworld.common.utils.ScreenUtils;
import com.yb.ballworld.information.R;
import com.yb.ballworld.information.http.PersonalHttpApi;
import com.yb.ballworld.information.ui.auth.SpecialAuthActivity;
import com.yb.ballworld.information.ui.home.utils.NavigateToDetailUtil;
import com.yb.ballworld.information.ui.home.view.InfoPublishPopView;
import com.yb.ballworld.information.ui.home.widget.bfpop.BFPopupWindow;
import com.yb.ballworld.information.ui.personal.adapter.UserSpacePagerAdapter;
import com.yb.ballworld.information.ui.personal.bean.PersonalInfo;
import com.yb.ballworld.information.widget.SlidingTitleTabLayout;

import java.util.Arrays;
import java.util.List;

/**
 * 资讯用户空间fragment
 */
public class InfoUserSpaceFragment extends BaseMvpFragment {
    private XTabLayout xTabLayout;
    private ViewPager viewPager;
    private PersonalInfo personalInfo;
    private BaseFragmentAdapter fragmentAdapter;
    private Button ktBt;
    private ImageView btPulish;
    private InfoPublishPopView popupWindow;


    public static InfoUserSpaceFragment newInstance(PersonalInfo personalInfo) {
        InfoUserSpaceFragment fragment = new InfoUserSpaceFragment();
        fragment.personalInfo = personalInfo;
        return fragment;
    }

    @Override
    public void initPresenter() {

    }

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_user_space_layout;
    }

    @Override
    protected void initView() {
        xTabLayout = findView(R.id.xTab);
        viewPager = findView(R.id.viewPager);
        ktBt = findView(R.id.bt_kt);
        btPulish = findView(R.id.bt_publish);

        if(personalInfo==null){
            showPageEmpty("暂无数据");
            return;
        }

        List<String> titles = getTabTitles();
        List<Fragment> fragments = getTabFragments();
        if (isNotEmpty(titles) && isNotEmpty(fragments) && titles.size() == fragments.size()) {
            float width = ScreenUtils.getScreenWidth(AppContext.getAppContext()) / titles.size();
            xTabLayout.setIndicatorWidthNoChange(width);
            xTabLayout.setTabWidthNoChange(width);

            fragmentAdapter = new BaseFragmentAdapter(getChildFragmentManager(), fragments, titles);
            viewPager.setAdapter(fragmentAdapter);
            viewPager.setOffscreenPageLimit(fragments.size());
            viewPager.setCurrentItem(0);
            viewPager.setOffscreenPageLimit(fragmentAdapter.getCount());

            xTabLayout.setViewPager(viewPager, (String[]) titles.toArray());
            xTabLayout.setGradientIndicatorDrawable1();

        }

        if(LoginOrdinaryUtils.INSTANCE.isLogin()){
            getSelfUserInfo();
        }else{
            btPulish.setVisibility(View.GONE);
        }

    }

    @Override
    protected void bindEvent() {
        ktBt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!LoginOrdinaryUtils.INSTANCE.isLogin()){
                    NavigateToDetailUtil.toLogin(getActivity());
                    return;
                }
                SpecialAuthActivity.launch(getActivity());
            }
        });

        btPulish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!LoginOrdinaryUtils.INSTANCE.isLogin()){
                    NavigateToDetailUtil.toLogin(getActivity());
                    return;
                }

                if(popupWindow==null){
                    UserInfo mUserInfo = LoginOrdinaryUtils.INSTANCE.getUserInfo();
                    popupWindow = new InfoPublishPopView(getActivity(),""+mUserInfo.getUid());
                }
               popupWindow.showPop(v);
            }
        });

        // 登录成功后的监听，判断自己是否开通特约
        LiveEventBus.get().with(LiveEventBusKey.KEY_UserLoginSuccess, UserInfo.class)
                .observe(this, new Observer<UserInfo>() {
                    @Override
                    public void onChanged(UserInfo userInfo) {
                        getSelfUserInfo();
                    }
                });
    }

    @Override
    protected void initData() {

    }

    @Override
    protected void processClick(View view) {

    }


    protected List<String> getTabTitles() {
        // TODO 非自己进入页面时，不显示收藏，足迹
        if(isSelf(personalInfo.getId())){
            return add("发表("+personalInfo.getArticleCount()+")", "评论("+personalInfo.getNewsCommentCount()+")", "视频("+personalInfo.getVideoCount()+")", "收藏("+personalInfo.getNewsFavoriteCount()+")", "足迹("+personalInfo.getNewsFootprintCount()+")");
        }else{
            return add("发表("+personalInfo.getArticleCount()+")", "评论("+personalInfo.getNewsCommentCount()+")", "视频("+personalInfo.getVideoCount()+")");
        }
    }


    protected List<Fragment> getTabFragments() {
        // TODO 非自己进入页面时，不显示收藏，足迹
        if(isSelf(personalInfo.getId())){
            return add(
                    InformationPersonalPublishFragment.newInstance(personalInfo.getId()),
                    InformationPersonalCommentFragment.newInstance(personalInfo.getId(), personalInfo.getNickname(), personalInfo.getHeadImgUrl()),
                    InformationPersonalPublishFragment.newInstance(personalInfo.getId(),InformationPersonalPublishFragment.KEY_TYPE_VIDEO),
                    InfoCollectionFragment.newInstance(),
                    InfoFootprintFragment.newInstance()
            );
        }else{
            return add(
                    InformationPersonalPublishFragment.newInstance(personalInfo.getId()),
                    InformationPersonalCommentFragment.newInstance(personalInfo.getId(), personalInfo.getNickname(), personalInfo.getHeadImgUrl()),
                    InformationPersonalPublishFragment.newInstance(personalInfo.getId(),InformationPersonalPublishFragment.KEY_TYPE_VIDEO)
            );
        }
    }

    /**
     * 判断是否用户本人
     *
     * @param userId
     * @return
     */
    private boolean isSelf(String userId) {
        if (TextUtils.isEmpty(userId)) {
            return false;
        }
        long uid = LoginOrdinaryUtils.INSTANCE.getUid();
        if (uid == 0) {
            return false;
        }
        return String.valueOf(uid).equals(userId);
    }


    protected boolean isNotEmpty(List<?> list) {
        return list != null && !list.isEmpty();
    }

    private <T> List<T> add(T... t) {
        return Arrays.asList(t);
    }

    /**
     * 获取自己的用户信息
     */
    private void getSelfUserInfo(){
        UserInfo mUserInfo = LoginOrdinaryUtils.INSTANCE.getUserInfo();
        if(mUserInfo!=null){
            PersonalHttpApi httpApi=new PersonalHttpApi();
            httpApi.getPersonalCommunityInfo(""+mUserInfo.getUid(),new LifecycleCallback<PersonalInfo>(InfoUserSpaceFragment.this) {
                @Override
                public void onSuccess(PersonalInfo data) {
                    if(data!=null){
                        // 已开通特约
                        if (data.getIsEditor() == 1) {
                            ktBt.setVisibility(View.GONE);
                            btPulish.setVisibility(View.VISIBLE);
                        } else {
                            ktBt.setVisibility(View.VISIBLE);
                            btPulish.setVisibility(View.GONE);
                        }
                    }
                }

                @Override
                public void onFailed(int errCode, String errMsg) {

                }
            });
        }
    }
}
