package com.yb.ballworld.information.ui.community.data;

/**
 * Desc: <社区话题图片实体类>
 * Author: JS-Barder
 * Created On: 2019/11/8 17:22
 */
public class CommunityPostImage {
    public int id;
    public String imgUrl;
    public String postId;
}
