package com.yb.ballworld.information.ui.home.bean;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Desc Tab数据结构
 * Date 2019/10/8
 * author mengk
 */
public class HomeIndexTabBean implements Parcelable {
    //id
    private String id;
    //名称
    private String name;
    private String categoryId;
    private String jumpUrl;
    private String lableType;
    private String mediaType;
    private String sportType;

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getJumpUrl() {
        return jumpUrl;
    }

    public void setJumpUrl(String jumpUrl) {
        this.jumpUrl = jumpUrl;
    }

    public String getLableType() {
        return lableType;
    }

    public void setLableType(String lableType) {
        this.lableType = lableType;
    }

    public String getMediaType() {
        return mediaType;
    }

    public void setMediaType(String mediaType) {
        this.mediaType = mediaType;
    }

    public String getSportType() {
        return sportType;
    }

    public void setSportType(String sportType) {
        this.sportType = sportType;
    }

    public static Creator<HomeIndexTabBean> getCREATOR() {
        return CREATOR;
    }

    public HomeIndexTabBean() {}

    protected HomeIndexTabBean(Parcel in) {
        id = in.readString();
        name = in.readString();
    }

    public static final Creator<HomeIndexTabBean> CREATOR = new Creator<HomeIndexTabBean>() {
        @Override
        public HomeIndexTabBean createFromParcel(Parcel in) {
            return new HomeIndexTabBean(in);
        }

        @Override
        public HomeIndexTabBean[] newArray(int size) {
            return new HomeIndexTabBean[size];
        }
    };

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /**
     * 当前对象的内容描述,一般返回0即可
     * @return 0
     */
    @Override
    public int describeContents() {
        return 0;
    }

    /**
     * 将当前对象写入序列化结构中
     * @param dest
     * @param flags
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(name);
    }
}
