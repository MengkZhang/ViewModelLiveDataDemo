package com.yb.ballworld.information.ui.detail;

import com.yb.ballworld.common.base.mvp.BasePresenter;
import com.yb.ballworld.common.base.mvp.VoidModel;

/**
* Desc:
* @author ink
* created at 2019/11/3 20:04
*/
public class InforCommunityRecomPresenter extends BasePresenter<InforCommunityRecomActivity, VoidModel> {

    private int pageNum = 1;
    private int totalPage = 1;
    private final int pageSize = 15;


    public void pullDown(){



    }

    public void pullUp(){



    }

    private void showEmpty(){

    }

    private void showError(){

    }

    private void showData(){

    }


}
