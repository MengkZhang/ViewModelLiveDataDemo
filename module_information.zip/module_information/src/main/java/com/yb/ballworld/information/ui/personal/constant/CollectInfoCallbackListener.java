package com.yb.ballworld.information.ui.personal.constant;

import rxhttp.wrapper.entity.Response;

/**
 * Desc: 收藏结果回调
 * Author: JS-Kylo
 * Created On: 2019/10/14 16:24
 */
public interface CollectInfoCallbackListener {
    void onCollectSuccess(Response response);
    void onCollectFail(String msg);
}
