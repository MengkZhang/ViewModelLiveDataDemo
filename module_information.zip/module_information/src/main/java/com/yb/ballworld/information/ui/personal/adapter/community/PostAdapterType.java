package com.yb.ballworld.information.ui.personal.adapter.community;

import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Desc: 帖子类型
 * Author: JS-Kylo
 * Created On: 2019/11/11 13:06
 */
@IntDef({
        PostAdapterType.TYPE_POST_IMG,
        PostAdapterType.TYPE_POST_VIDEOO
})

@Retention(RetentionPolicy.SOURCE)
public @interface PostAdapterType {
    //单图 普通没有头像类型
    int TYPE_POST_IMG = 1;
    int TYPE_POST_VIDEOO = 2;
}
