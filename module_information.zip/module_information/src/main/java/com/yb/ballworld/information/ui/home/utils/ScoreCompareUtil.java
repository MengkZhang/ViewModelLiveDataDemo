package com.yb.ballworld.information.ui.home.utils;

import android.content.Context;
import android.widget.TextView;

import com.yb.ballworld.information.R;

/**
 * Desc 比较分数
 * Date 2019/10/14
 * author mengk
 */
public class ScoreCompareUtil {
    /**
     * 比较专栏中两个以上的赛事
     * @param context
     * @param hostScore
     * @param guestScore
     * @param tvHost
     * @param tvGeust
     */
    public static void scoreCompare(Context context,int hostScore, int guestScore, TextView tvHost, TextView tvGeust) {
        if (hostScore > guestScore) {
            tvHost.setTextColor(context.getResources().getColor(R.color.color_1e1e1e));
            tvGeust.setTextColor(context.getResources().getColor(R.color.color_999999));
        } else if (hostScore == guestScore) {
            tvHost.setTextColor(context.getResources().getColor(R.color.color_1e1e1e));
            tvHost.setTextColor(context.getResources().getColor(R.color.color_1e1e1e));
        } else {
            tvGeust.setTextColor(context.getResources().getColor(R.color.color_1e1e1e));
            tvHost.setTextColor(context.getResources().getColor(R.color.color_999999));
        }
        tvGeust.setText(hostScore + "");
        tvGeust.setText(guestScore + "");
    }



}
